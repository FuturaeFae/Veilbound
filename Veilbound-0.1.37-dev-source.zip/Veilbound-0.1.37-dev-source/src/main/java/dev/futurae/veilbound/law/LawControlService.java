package dev.futurae.veilbound.law;

import dev.futurae.veilbound.domain.DomainState;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/** Deterministic player-facing catalog/toggle facade used by the physical Axiom Monolith. */
public final class LawControlService {
    public List<LawDefinition> orderedDefinitions(LawRegistry registry) {
        Objects.requireNonNull(registry, "registry");
        ArrayList<LawDefinition> ordered = new ArrayList<>(registry.all());
        ordered.sort(java.util.Comparator.comparing(LawDefinition::displayName).thenComparing(LawDefinition::id));
        return List.copyOf(ordered);
    }

    public Optional<LawDefinition> next(LawRegistry registry, String currentId) {
        List<LawDefinition> ordered = orderedDefinitions(registry);
        if (ordered.isEmpty()) return Optional.empty();
        if (currentId == null) return Optional.of(ordered.getFirst());
        for (int i = 0; i < ordered.size(); i++) {
            if (ordered.get(i).id().equals(currentId)) return Optional.of(ordered.get((i + 1) % ordered.size()));
        }
        return Optional.of(ordered.getFirst());
    }

    public LawService.ChangeResult toggle(DomainState state, LawRegistry registry, String lawId) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(registry, "registry");
        if (lawId == null || lawId.isBlank()) return LawService.ChangeResult.denied("law_not_selected");
        LawDefinition law = registry.get(lawId).orElse(null);
        if (law == null) return LawService.ChangeResult.denied("law_definition_missing");
        return state.imposedLawIds().contains(law.id())
                ? LawService.repeal(state, law, registry)
                : LawService.impose(state, law);
    }

    public Inspection inspect(DomainState state, LawRegistry registry, String lawId) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(registry, "registry");
        LawDefinition law = lawId == null ? null : registry.get(lawId).orElse(null);
        if (law == null) return Inspection.missing();
        return new Inspection(
                true,
                state.imposedLawIds().contains(law.id()),
                law,
                law.prerequisites().stream().filter(id -> !state.imposedLawIds().contains(id)).sorted().toList(),
                law.incompatibleLawIds().stream().filter(state.imposedLawIds()::contains).sorted().toList());
    }

    public record Inspection(
            boolean present,
            boolean imposed,
            LawDefinition law,
            List<String> missingPrerequisites,
            List<String> activeIncompatibilities) {
        private static Inspection missing() {
            return new Inspection(false, false, null, List.of(), List.of());
        }
    }
}
