package dev.futurae.veilbound.ontology;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * Transient per-Domain stability load published by live Ontological Harvesters.
 *
 * <p>This is deliberately not persisted: load is a projection of currently ticking machinery and
 * expires automatically when a chunk unloads or a machine stops reporting.</p>
 */
public final class OntologicalLoadTracker {
    private final Map<UUID, Map<String, Entry>> loads = new HashMap<>();

    public synchronized void publish(UUID ownerId, String machineKey, double load, long tick) {
        Objects.requireNonNull(ownerId, "ownerId");
        String key = Objects.requireNonNull(machineKey, "machineKey");
        if (key.isBlank()) throw new IllegalArgumentException("machineKey may not be blank");
        if (!Double.isFinite(load) || load < 0) throw new IllegalArgumentException("load must be finite and >= 0");
        loads.computeIfAbsent(ownerId, ignored -> new HashMap<>()).put(key, new Entry(load, tick));
    }

    public synchronized double totalFresh(UUID ownerId, long nowTick, long maximumAgeTicks) {
        Objects.requireNonNull(ownerId, "ownerId");
        if (maximumAgeTicks < 0) throw new IllegalArgumentException("maximumAgeTicks must be >= 0");
        Map<String, Entry> ownerLoads = loads.get(ownerId);
        if (ownerLoads == null) return 0.0;
        double total = 0.0;
        Iterator<Entry> iterator = ownerLoads.values().iterator();
        while (iterator.hasNext()) {
            Entry entry = iterator.next();
            if (nowTick - entry.tick() > maximumAgeTicks || nowTick < entry.tick()) {
                iterator.remove();
                continue;
            }
            total += entry.load();
        }
        if (ownerLoads.isEmpty()) loads.remove(ownerId);
        return total;
    }

    public synchronized void clear(UUID ownerId) { loads.remove(Objects.requireNonNull(ownerId, "ownerId")); }

    private record Entry(double load, long tick) {}
}
