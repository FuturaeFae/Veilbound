package dev.futurae.veilbound.breach;

/** Relative fracture severity. Exact spawn cadence is configured outside this enum. */
public enum BreachSeverity {
    MINOR,
    SEVERE,
    EXTREME
}
