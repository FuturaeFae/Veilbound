package dev.futurae.veilbound.milestone;

import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainState;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** Deterministically completes every currently satisfied milestone, including prerequisite chains. */
public final class MilestoneService {
    public EvaluationResult evaluate(DomainState state, MilestoneRegistry registry, int permanentThresholdCount) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(registry, "registry");
        if (permanentThresholdCount < 0) throw new IllegalArgumentException("permanentThresholdCount must be >= 0");

        List<MilestoneDefinition> definitions = registry.all();
        List<MilestoneDefinition> completedNow = new ArrayList<>();
        boolean progressed;
        int passes = 0;
        do {
            progressed = false;
            passes++;
            for (MilestoneDefinition milestone : definitions) {
                if (state.completedMilestoneIds().contains(milestone.id())) continue;
                if (!state.completedMilestoneIds().containsAll(milestone.prerequisiteMilestoneIds())) continue;
                if (!milestone.criteria().matches(state, permanentThresholdCount)) continue;
                if (!state.completeMilestone(milestone.id())) continue;
                for (DomainFeature feature : milestone.unlockedFeatures()) state.unlockFeature(feature);
                completedNow.add(milestone);
                progressed = true;
            }
        } while (progressed && passes <= definitions.size() + 1);
        java.util.Set<String> registeredIds = definitions.stream().map(MilestoneDefinition::id).collect(java.util.stream.Collectors.toSet());
        int currentCompleted = (int) state.completedMilestoneIds().stream().filter(registeredIds::contains).count();
        return new EvaluationResult(List.copyOf(completedNow), currentCompleted, definitions.size());
    }

    public record EvaluationResult(List<MilestoneDefinition> completedNow, int completedCount, int registeredCount) {}
}
