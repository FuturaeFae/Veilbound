package dev.futurae.veilbound.platform.neoforge.inventory;

import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.inventory.CoreCapabilityUpgradeService;
import dev.futurae.veilbound.matter.MatterTransmutationService;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import dev.futurae.veilbound.upgrade.CoreTierUpgradeService;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/** Handles capability-upgrade items and datapack-defined sequential Core-tier feeds. */
public final class NeoForgeCoreUpgradeCoordinator {
    private final VeilboundRuntime runtime;
    private final CoreCapabilityUpgradeService capabilityUpgrades = new CoreCapabilityUpgradeService();
    private final CoreTierUpgradeService tierUpgrades = new CoreTierUpgradeService();
    private final MatterTransmutationService transmutation = new MatterTransmutationService();

    public NeoForgeCoreUpgradeCoordinator(VeilboundRuntime runtime) {
        this.runtime = java.util.Objects.requireNonNull(runtime, "runtime");
    }

    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.isCanceled() || !(event.getEntity() instanceof ServerPlayer player) || event.getLevel().isClientSide()) return;
        if (!event.getLevel().getBlockState(event.getPos()).is(VeilboundBlocks.DIMENSIONAL_CORE.get())) return;

        ItemStack held = event.getItemStack();
        if (held.isEmpty()) return; // empty-hand Core controls are handled by NeoForgeCoreControlCoordinator
        String itemId = BuiltInRegistries.ITEM.getKey(held.getItem()).toString();
        boolean capabilityItem = isCapabilityUpgrade(itemId);

        DomainRecord record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        boolean tierIngredient = record != null && runtime.coreUpgrades().from(record.state().coreTier())
                .map(definition -> definition.ingredients().stream().anyMatch(ingredient -> ingredient.itemId().equals(itemId)))
                .orElse(false);
        if (!capabilityItem && !tierIngredient) return;

        if (!isOwnerPhysicalCore(record, player, event)) {
            player.displayClientMessage(Component.translatable("message.veilbound.core_upgrade.not_owner_core"), true);
            reject(event);
            return;
        }

        if (capabilityItem) {
            handleCapabilityUpgrade(player, record, held, itemId, event);
            return;
        }
        handleTierUpgrade(player, record, held, itemId, event);
    }

    private void handleCapabilityUpgrade(
            ServerPlayer player,
            DomainRecord record,
            ItemStack held,
            String itemId,
            PlayerInteractEvent.RightClickBlock event) {
        CoreCapabilityUpgradeService.FeedResult result = capabilityUpgrades.feed(record.state(), itemId, held.getCount());
        if (!result.accepted()) {
            player.displayClientMessage(Component.translatable("message.veilbound.core_upgrade." + result.reason()), true);
            reject(event);
            return;
        }

        if (!player.getAbilities().instabuild) held.shrink((int) result.consumed());
        if (result.unlockedFeature() == dev.futurae.veilbound.domain.DomainFeature.VEIL_TRANSMUTATION) {
            var migration = transmutation.migrateLegacyInventory(
                    record.state(), record.veilInventory(), record.matterTransmutation(), runtime.matter());
            if (!migration.migrated()) {
                throw new IllegalStateException("Unable to migrate Veil Inventory into Matter terminal: " + migration.reason());
            }
            if (migration.canonicalizedComponentVariants() > 0) {
                dev.futurae.veilbound.Veilbound.LOGGER.warn(
                        "Matter-terminal migration for {} canonicalized {} component-bearing legacy stack variants",
                        player.getUUID(), migration.canonicalizedComponentVariants());
            }
        }
        String unlockedMessage = switch (result.unlockedFeature()) {
            case VEIL_CRAFTING -> "message.veilbound.core_upgrade.crafting_unlocked";
            case VEIL_TRANSMUTATION -> "message.veilbound.core_upgrade.transmutation_unlocked";
            default -> "message.veilbound.core_upgrade.inventory_unlocked";
        };
        player.displayClientMessage(Component.translatable(unlockedMessage), true);
        accept(event);
    }

    private void handleTierUpgrade(
            ServerPlayer player,
            DomainRecord record,
            ItemStack held,
            String itemId,
            PlayerInteractEvent.RightClickBlock event) {
        var result = tierUpgrades.feed(record.state(), runtime.coreUpgrades(), itemId, held.getCount());
        if (!result.recognized()) return;
        if (result.consumed() > 0 && !player.getAbilities().instabuild) held.shrink((int) result.consumed());

        if (result.upgraded()) {
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.core_tier.upgraded", result.from().name(), result.to().name(), result.dimensionalEnergyRequired()), true);
        } else if ("insufficient_dimensional_energy".equals(result.reason())) {
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.core_tier.awaiting_energy", result.to().name(),
                    result.dimensionalEnergy(), result.dimensionalEnergyRequired()), true);
        } else {
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.core_tier.feed_progress", result.to().name(),
                    result.fedItems(), result.requiredItems(), result.dimensionalEnergy(), result.dimensionalEnergyRequired()), true);
        }
        accept(event);
    }

    private static boolean isCapabilityUpgrade(String itemId) {
        return itemId.equals(CoreCapabilityUpgradeService.VEIL_INVENTORY_UPGRADE_ID)
                || itemId.equals(CoreCapabilityUpgradeService.VEIL_CRAFTING_UPGRADE_ID)
                || itemId.equals(CoreCapabilityUpgradeService.VEIL_TRANSMUTATION_UPGRADE_ID);
    }

    private static boolean isOwnerPhysicalCore(
            DomainRecord record, ServerPlayer player, PlayerInteractEvent.RightClickBlock event) {
        return record != null
                && record.identity().dimensionId().equals(event.getLevel().dimension().identifier().toString())
                && record.state().corePosition().x() == event.getPos().getX()
                && record.state().corePosition().y() == event.getPos().getY()
                && record.state().corePosition().z() == event.getPos().getZ()
                && record.ownerId().equals(player.getUUID());
    }

    private static void accept(PlayerInteractEvent.RightClickBlock event) {
        event.setCancellationResult(InteractionResult.SUCCESS);
        event.setCanceled(true);
    }

    private static void reject(PlayerInteractEvent.RightClickBlock event) {
        event.setCancellationResult(InteractionResult.FAIL);
        event.setCanceled(true);
    }
}
