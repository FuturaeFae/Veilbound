package dev.futurae.veilbound.threshold;

import dev.futurae.veilbound.domain.DomainPosition;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/**
 * Loader-neutral Threshold frame activation planning.
 *
 * <p>A connected component of placed Threshold Frame blocks can be converted into one active
 * portal structure only by a player who already owns a personal Domain. The service intentionally
 * validates only the settled invariants: ownership/binding and connected-component discovery.
 * Shape-specific portal admission rules remain platform/runtime behavior.</p>
 */
public final class ThresholdFrameActivationService {
    private ThresholdFrameActivationService() {}

    public static ActivationDecision activate(
            UUID playerId,
            boolean hasBoundDomain,
            Collection<DomainPosition> placedFrames,
            DomainPosition clicked,
            int maxStructureBlocks) {
        Objects.requireNonNull(playerId, "playerId");
        Objects.requireNonNull(placedFrames, "placedFrames");
        Objects.requireNonNull(clicked, "clicked");
        if (!hasBoundDomain) return ActivationDecision.denied("no_bound_domain");

        Set<DomainPosition> frameSet = new LinkedHashSet<>(placedFrames);
        if (!frameSet.contains(clicked)) return ActivationDecision.denied("not_threshold_frame");
        if (maxStructureBlocks < 1) throw new IllegalArgumentException("maxStructureBlocks must be positive");

        Set<DomainPosition> component = connectedComponent(frameSet, clicked, maxStructureBlocks);
        if (component.isEmpty()) return ActivationDecision.denied("not_threshold_frame");
        return ActivationDecision.allowed(UUID.randomUUID(), playerId, component);
    }

    static Set<DomainPosition> connectedComponent(
            Set<DomainPosition> frames, DomainPosition start, int maxStructureBlocks) {
        Set<DomainPosition> visited = new LinkedHashSet<>();
        if (!frames.contains(start)) return visited;

        Deque<DomainPosition> queue = new ArrayDeque<>();
        queue.add(start);
        visited.add(start);
        while (!queue.isEmpty()) {
            DomainPosition current = queue.removeFirst();
            for (DomainPosition neighbor : neighbors(current)) {
                if (frames.contains(neighbor) && visited.add(neighbor)) {
                    if (visited.size() > maxStructureBlocks) {
                        throw new IllegalArgumentException("Connected Threshold frame structure exceeds cap of " + maxStructureBlocks + " blocks");
                    }
                    queue.addLast(neighbor);
                }
            }
        }
        return Set.copyOf(visited);
    }

    private static Set<DomainPosition> neighbors(DomainPosition position) {
        return Set.of(
                new DomainPosition(position.x() + 1, position.y(), position.z()),
                new DomainPosition(position.x() - 1, position.y(), position.z()),
                new DomainPosition(position.x(), position.y() + 1, position.z()),
                new DomainPosition(position.x(), position.y() - 1, position.z()),
                new DomainPosition(position.x(), position.y(), position.z() + 1),
                new DomainPosition(position.x(), position.y(), position.z() - 1));
    }

    public record ActivationDecision(
            boolean allowed,
            UUID structureId,
            UUID ownerId,
            Set<DomainPosition> connectedStructure,
            String reason) {
        public ActivationDecision {
            connectedStructure = connectedStructure == null ? Set.of() : Set.copyOf(connectedStructure);
        }

        public static ActivationDecision denied(String reason) {
            return new ActivationDecision(false, null, null, Set.of(), reason);
        }

        public static ActivationDecision allowed(UUID structureId, UUID ownerId, Set<DomainPosition> connectedStructure) {
            return new ActivationDecision(true, structureId, ownerId, connectedStructure, "ok");
        }
    }
}
