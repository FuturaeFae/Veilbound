package dev.futurae.veilbound.domain;

import java.util.Objects;
import java.util.Optional;

/** Maps each moving Boundary Pylon to exactly one usable-space face. */
public final class BoundaryPylonBindingService {
    private BoundaryPylonBindingService() {}

    /** Core-aligned suggested slot; placement is not restricted to this tangent position. */
    public static DomainPosition expectedPosition(DomainState state, AxisDirection direction) {
        Objects.requireNonNull(state, "state");
        return defaultFacePosition(state.bounds(), state.corePosition(), direction);
    }

    public static DomainPosition defaultFacePosition(DomainBounds b, DomainPosition c, AxisDirection direction) {
        Objects.requireNonNull(b, "bounds");
        Objects.requireNonNull(c, "core");
        Objects.requireNonNull(direction, "direction");
        int x = clamp(c.x(), b.minX(), b.maxX());
        int y = clamp(c.y(), b.minY(), b.maxY());
        int z = clamp(c.z(), b.minZ(), b.maxZ());
        return switch (direction) {
            case POSITIVE_X -> new DomainPosition(Math.addExact(b.maxX(), 1), y, z);
            case NEGATIVE_X -> new DomainPosition(Math.subtractExact(b.minX(), 1), y, z);
            case POSITIVE_Y -> new DomainPosition(x, Math.addExact(b.maxY(), 1), z);
            case NEGATIVE_Y -> new DomainPosition(x, Math.subtractExact(b.minY(), 1), z);
            case POSITIVE_Z -> new DomainPosition(x, y, Math.addExact(b.maxZ(), 1));
            case NEGATIVE_Z -> new DomainPosition(x, y, Math.subtractExact(b.minZ(), 1));
        };
    }

    /** True only when the block is exactly one cell into one face of the Veil, not at an edge/corner ambiguity. */
    public static Optional<AxisDirection> directionForFacePosition(DomainState state, DomainPosition p) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(p, "position");
        DomainBounds b = state.bounds();
        boolean xWithin = p.x() >= b.minX() && p.x() <= b.maxX();
        boolean yWithin = p.y() >= b.minY() && p.y() <= b.maxY();
        boolean zWithin = p.z() >= b.minZ() && p.z() <= b.maxZ();
        if (p.x() == (long) b.maxX() + 1 && yWithin && zWithin) return Optional.of(AxisDirection.POSITIVE_X);
        if (p.x() == (long) b.minX() - 1 && yWithin && zWithin) return Optional.of(AxisDirection.NEGATIVE_X);
        if (p.y() == (long) b.maxY() + 1 && xWithin && zWithin) return Optional.of(AxisDirection.POSITIVE_Y);
        if (p.y() == (long) b.minY() - 1 && xWithin && zWithin) return Optional.of(AxisDirection.NEGATIVE_Y);
        if (p.z() == (long) b.maxZ() + 1 && xWithin && yWithin) return Optional.of(AxisDirection.POSITIVE_Z);
        if (p.z() == (long) b.minZ() - 1 && xWithin && yWithin) return Optional.of(AxisDirection.NEGATIVE_Z);
        return Optional.empty();
    }

    /** Compatibility name used by earlier 0.1.31 work. */
    public static Optional<AxisDirection> directionForExpectedPosition(DomainState state, DomainPosition position) {
        return directionForFacePosition(state, position);
    }

    /** Direction inference for old v11/v12 in-bounds bindings and diagnostics. */
    public static Optional<AxisDirection> inferDirection(DomainPosition core, DomainPosition pylon) {
        Objects.requireNonNull(core, "core");
        Objects.requireNonNull(pylon, "pylon");
        long dx = (long) pylon.x() - core.x();
        long dy = (long) pylon.y() - core.y();
        long dz = (long) pylon.z() - core.z();
        long ax = Math.abs(dx), ay = Math.abs(dy), az = Math.abs(dz);
        long max = Math.max(ax, Math.max(ay, az));
        if (max == 0) return Optional.empty();
        int ties = (ax == max ? 1 : 0) + (ay == max ? 1 : 0) + (az == max ? 1 : 0);
        if (ties != 1) return Optional.empty();
        if (ax == max) return Optional.of(dx > 0 ? AxisDirection.POSITIVE_X : AxisDirection.NEGATIVE_X);
        if (ay == max) return Optional.of(dy > 0 ? AxisDirection.POSITIVE_Y : AxisDirection.NEGATIVE_Y);
        return Optional.of(dz > 0 ? AxisDirection.POSITIVE_Z : AxisDirection.NEGATIVE_Z);
    }

    /** Project an old/arbitrary position to the nearest legal slot on its assigned face. */
    public static DomainPosition projectToFace(DomainState state, AxisDirection direction, DomainPosition p) {
        DomainBounds b = Objects.requireNonNull(state, "state").bounds();
        Objects.requireNonNull(direction, "direction");
        Objects.requireNonNull(p, "position");
        int x = clamp(p.x(), b.minX(), b.maxX());
        int y = clamp(p.y(), b.minY(), b.maxY());
        int z = clamp(p.z(), b.minZ(), b.maxZ());
        return switch (direction) {
            case POSITIVE_X -> new DomainPosition(Math.addExact(b.maxX(), 1), y, z);
            case NEGATIVE_X -> new DomainPosition(Math.subtractExact(b.minX(), 1), y, z);
            case POSITIVE_Y -> new DomainPosition(x, Math.addExact(b.maxY(), 1), z);
            case NEGATIVE_Y -> new DomainPosition(x, Math.subtractExact(b.minY(), 1), z);
            case POSITIVE_Z -> new DomainPosition(x, y, Math.addExact(b.maxZ(), 1));
            case NEGATIVE_Z -> new DomainPosition(x, y, Math.subtractExact(b.minZ(), 1));
        };
    }

    /** Advance with the face while preserving the two tangent coordinates. */
    public static DomainPosition advance(DomainPosition position, AxisDirection direction) {
        Objects.requireNonNull(position, "position");
        return switch (Objects.requireNonNull(direction, "direction")) {
            case POSITIVE_X -> new DomainPosition(Math.addExact(position.x(), 1), position.y(), position.z());
            case NEGATIVE_X -> new DomainPosition(Math.subtractExact(position.x(), 1), position.y(), position.z());
            case POSITIVE_Y -> new DomainPosition(position.x(), Math.addExact(position.y(), 1), position.z());
            case NEGATIVE_Y -> new DomainPosition(position.x(), Math.subtractExact(position.y(), 1), position.z());
            case POSITIVE_Z -> new DomainPosition(position.x(), position.y(), Math.addExact(position.z(), 1));
            case NEGATIVE_Z -> new DomainPosition(position.x(), position.y(), Math.subtractExact(position.z(), 1));
        };
    }

    /** Bind only at a legal face slot. A different block may not silently steal an occupied face. */
    public static BindResult bind(DomainState state, AxisDirection direction, DomainPosition position) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(direction, "direction");
        Objects.requireNonNull(position, "position");
        if (!state.coreActive()) return BindResult.denied("core_inactive");
        if (directionForFacePosition(state, position).filter(direction::equals).isEmpty()) {
            return BindResult.denied("wrong_face_position");
        }
        BoundaryPylonState current = state.pylons().get(direction);
        if (current != null && current.bound() && !position.equals(current.blockPosition())) {
            return BindResult.denied("direction_already_bound");
        }
        boolean enabled = current != null && current.expansionEnabled();
        BoundaryPylonSpeed speed = current == null ? BoundaryPylonSpeed.STABLE : current.speed();
        BoundaryPylonState next = new BoundaryPylonState(direction, enabled, true, position, speed);
        state.setPylon(next);
        return BindResult.allowed(next);
    }

    public static ToggleResult toggleExpansion(DomainState state, AxisDirection direction, DomainPosition position) {
        BindResult bound = bind(state, direction, position);
        if (!bound.bound()) return ToggleResult.denied(bound.reason());
        BoundaryPylonState next = bound.state().withExpansionEnabled(!bound.state().expansionEnabled());
        state.setPylon(next);
        return ToggleResult.allowed(next);
    }

    public static SpeedResult cycleSpeed(DomainState state, AxisDirection direction) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(direction, "direction");
        BoundaryPylonState current = state.pylons().get(direction);
        if (current == null || !current.bound() || !current.online()) return SpeedResult.denied("pylon_offline");
        BoundaryPylonState next = current.cycleSpeed();
        state.setPylon(next);
        return SpeedResult.allowed(next);
    }

    public static boolean moveBoundPylon(DomainState state, AxisDirection direction, DomainPosition from, DomainPosition to) {
        BoundaryPylonState current = state.pylons().get(Objects.requireNonNull(direction, "direction"));
        if (current == null || !current.bound() || !Objects.equals(current.blockPosition(), from)) return false;
        state.setPylon(current.moveTo(Objects.requireNonNull(to, "to")));
        return true;
    }

    public static boolean unbindIfMatching(DomainState state, AxisDirection direction, DomainPosition position) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(direction, "direction");
        Objects.requireNonNull(position, "position");
        BoundaryPylonState current = state.pylons().get(direction);
        if (current == null || !current.bound() || !position.equals(current.blockPosition())) return false;
        state.setPylon(current.unbind());
        return true;
    }

    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }

    public record BindResult(boolean bound, BoundaryPylonState state, String reason) {
        public static BindResult denied(String reason) { return new BindResult(false, null, reason); }
        public static BindResult allowed(BoundaryPylonState state) { return new BindResult(true, state, "ok"); }
    }
    public record ToggleResult(boolean toggled, BoundaryPylonState state, String reason) {
        public static ToggleResult denied(String reason) { return new ToggleResult(false, null, reason); }
        public static ToggleResult allowed(BoundaryPylonState state) { return new ToggleResult(true, state, "ok"); }
    }
    public record SpeedResult(boolean changed, BoundaryPylonState state, String reason) {
        public static SpeedResult denied(String reason) { return new SpeedResult(false, null, reason); }
        public static SpeedResult allowed(BoundaryPylonState state) { return new SpeedResult(true, state, "ok"); }
    }
}
