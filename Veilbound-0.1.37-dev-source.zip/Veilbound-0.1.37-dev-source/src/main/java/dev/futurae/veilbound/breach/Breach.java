package dev.futurae.veilbound.breach;

import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.DomainPosition;
import java.util.Objects;
import java.util.UUID;

/** A fracture in one face of the Veil. Open breaches globally suspend Domain expansion. */
public record Breach(
        UUID id,
        DomainPosition position,
        AxisDirection veilFace,
        BreachSeverity severity,
        boolean open,
        long openedGameTick) {

    public Breach {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(position, "position");
        Objects.requireNonNull(veilFace, "veilFace");
        Objects.requireNonNull(severity, "severity");
        if (openedGameTick < 0) throw new IllegalArgumentException("openedGameTick must be >= 0");
    }

    public Breach sealed() {
        return new Breach(id, position, veilFace, severity, false, openedGameTick);
    }
}
