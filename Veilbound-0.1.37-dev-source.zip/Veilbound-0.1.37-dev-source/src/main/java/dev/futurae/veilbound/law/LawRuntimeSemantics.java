package dev.futurae.veilbound.law;

import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

/** Loader-neutral interpretation of Veilbound's built-in Law effect ids. */
public final class LawRuntimeSemantics {
    public Snapshot snapshot(ActiveLawEffects effects) {
        Objects.requireNonNull(effects, "effects");
        return new Snapshot(
                effects.has(LawEffectIds.HOSTILITY),
                effects.has(LawEffectIds.FAUNA),
                effects.has(LawEffectIds.FLAME),
                effects.has(LawEffectIds.RUIN),
                effects.has(LawEffectIds.GRIEF),
                effects.has(LawEffectIds.CONFLICT),
                effects.has(LawEffectIds.DESCENT),
                effects.has(LawEffectIds.PRESERVATION),
                effects.has(LawEffectIds.TIME),
                effects.has(LawEffectIds.WEATHER),
                unknownEffects(effects));
    }

    public Set<String> unknownEffects(ActiveLawEffects effects) {
        Objects.requireNonNull(effects, "effects");
        LinkedHashSet<String> unknown = new LinkedHashSet<>(effects.effectIds());
        unknown.removeAll(LawEffectIds.BUILT_IN);
        return Set.copyOf(unknown);
    }

    /**
     * Vanilla natural monster spawning is controlled by Hostility; every other natural mob
     * category is controlled by Fauna. Programmatic/spawner/breach emissions are outside this
     * policy and are not suppressed by these two Laws.
     */
    public boolean allowNaturalSpawn(ActiveLawEffects effects, boolean monsterCategory) {
        return monsterCategory ? effects.has(LawEffectIds.HOSTILITY) : effects.has(LawEffectIds.FAUNA);
    }

    public record Snapshot(
            boolean hostility,
            boolean fauna,
            boolean flame,
            boolean ruin,
            boolean grief,
            boolean conflict,
            boolean descent,
            boolean preservation,
            boolean time,
            boolean weather,
            Set<String> unknownEffectIds) {
        public Snapshot {
            unknownEffectIds = Set.copyOf(unknownEffectIds);
        }

        public boolean anyNaturalSpawning() { return hostility || fauna; }
    }
}
