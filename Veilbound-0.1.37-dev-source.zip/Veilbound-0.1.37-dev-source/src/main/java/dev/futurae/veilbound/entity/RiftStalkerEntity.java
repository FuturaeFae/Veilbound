package dev.futurae.veilbound.entity;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/** Mid/high-tier Breach intruder. Enderman movement gives it long-legged pursuit and teleport pressure. */
public final class RiftStalkerEntity extends EnderMan implements BreachLinkedCreature {
    private final BreachLinkData breachLink = new BreachLinkData();

    public RiftStalkerEntity(EntityType<? extends EnderMan> type, Level level) {
        super(type, level);
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        // Breach intruders are inherently hostile; unlike their vanilla parent, they do not wait for
        // darkness, eye contact, or an Evoker owner before selecting a nearby player.
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void veilboundBind(UUID domainOwnerId, UUID sourceBreachId) { breachLink.bind(domainOwnerId, sourceBreachId); }
    @Override
    public Optional<UUID> veilboundDomainOwnerId() { return breachLink.ownerId(); }
    @Override
    public Optional<UUID> veilboundSourceBreachId() { return breachLink.breachId(); }

    @Override
    public boolean requiresCustomPersistence() { return true; }

    /** Breach fauna are pressure mechanics, not a renewable vanilla-XP farm. */
    @Override
    public boolean shouldDropExperience() { return false; }

    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);
        breachLink.save(output);
    }

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);
        breachLink.load(input);
    }
}
