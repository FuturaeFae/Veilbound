package dev.futurae.veilbound.client.screen;

import dev.futurae.veilbound.network.DomainControlsActionPayload;
import dev.futurae.veilbound.network.DomainControlsSnapshotPayload;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;

/** Owner-facing Dimensional Core control panel for Core state, Pylons, and Threshold access. */
public final class DomainControlsScreen extends Screen {
    private static final int PANEL_WIDTH = 500;
    private static final int PANEL_HEIGHT = 286;
    private static final int THRESHOLD_ROWS = 5;
    private static final int PLAYER_ROWS = 6;

    private DomainControlsSnapshotPayload snapshot;
    private int thresholdPage;
    private int playerPage;
    private String selectedThresholdId = "";

    public DomainControlsScreen(DomainControlsSnapshotPayload snapshot) {
        super(Component.translatable("screen.veilbound.domain_controls"));
        this.snapshot = snapshot;
        normalize();
    }

    public void acceptSnapshot(DomainControlsSnapshotPayload next) {
        var old = snapshot.view();
        snapshot = next;
        if (old != next.view()) { thresholdPage = 0; playerPage = 0; }
        normalize();
        if (minecraft != null) { clearWidgets(); init(); }
    }

    private void normalize() {
        if (!selectedThresholdId.isBlank() && snapshot.thresholds().stream().noneMatch(t -> t.id().equals(selectedThresholdId))) {
            selectedThresholdId = "";
        }
        if (selectedThresholdId.isBlank() && !snapshot.thresholds().isEmpty()) selectedThresholdId = snapshot.thresholds().get(0).id();
        thresholdPage = clampPage(thresholdPage, snapshot.thresholds().size(), THRESHOLD_ROWS);
        playerPage = clampPage(playerPage, snapshot.onlinePlayers().size(), PLAYER_ROWS);
    }

    @Override protected void init() {
        super.init();
        int left = Math.max(6, width / 2 - PANEL_WIDTH / 2);
        int top = Math.max(18, height / 2 - PANEL_HEIGHT / 2);
        addTab(left + 10, top + 10, 100, DomainControlsSnapshotPayload.View.CORE,
                "screen.veilbound.domain_controls.tab.core", DomainControlsActionPayload.Action.OPEN_CORE);
        addTab(left + 114, top + 10, 100, DomainControlsSnapshotPayload.View.PYLONS,
                "screen.veilbound.domain_controls.tab.pylons", DomainControlsActionPayload.Action.OPEN_PYLONS);
        addTab(left + 218, top + 10, 112, DomainControlsSnapshotPayload.View.THRESHOLDS,
                "screen.veilbound.domain_controls.tab.thresholds", DomainControlsActionPayload.Action.OPEN_THRESHOLDS);
        if (!snapshot.allowed()) return;
        switch (snapshot.view()) {
            case CORE -> initCore(left, top);
            case PYLONS -> initPylons(left, top);
            case THRESHOLDS -> initThresholds(left, top);
        }
    }

    private void addTab(int x, int y, int w, DomainControlsSnapshotPayload.View view, String key, DomainControlsActionPayload.Action action) {
        Button b = Button.builder(Component.translatable(key), ignored -> send(action, "", "")).bounds(x, y, w, 20).build();
        b.active = snapshot.view() != view;
        addRenderableWidget(b);
    }

    private void initCore(int left, int top) {
        addRenderableWidget(Button.builder(Component.translatable(snapshot.globalExpansion()
                                ? "screen.veilbound.domain_controls.expansion_on" : "screen.veilbound.domain_controls.expansion_off"),
                        b -> send(DomainControlsActionPayload.Action.TOGGLE_GLOBAL_EXPANSION, "", ""))
                .bounds(left + 34, top + 152, 190, 22).build());
    }

    private void initPylons(int left, int top) {
        for (int i = 0; i < snapshot.pylons().size() && i < 6; i++) {
            var pylon = snapshot.pylons().get(i);
            int col = i % 2;
            int row = i / 2;
            String state = !pylon.bound() ? " — Unbound" : pylon.expansionEnabled() ? " — Expanding" : " — Paused";
            Button b = Button.builder(Component.literal(displayDirection(pylon.direction()) + state), ignored ->
                            send(DomainControlsActionPayload.Action.TOGGLE_PYLON, pylon.direction(), ""))
                    .bounds(left + 26 + col * 238, top + 72 + row * 54, 132, 24).build();
            b.active = pylon.bound() && pylon.online();
            addRenderableWidget(b);
            Button speed = Button.builder(Component.literal(displaySpeed(pylon.speed())), ignored ->
                            send(DomainControlsActionPayload.Action.CYCLE_PYLON_SPEED, pylon.direction(), ""))
                    .bounds(left + 162 + col * 238, top + 72 + row * 54, 74, 24).build();
            speed.active = pylon.bound() && pylon.online();
            addRenderableWidget(speed);
        }
    }

    private void initThresholds(int left, int top) {
        int pages = pageCount(snapshot.thresholds().size(), THRESHOLD_ROWS);
        Button prev = Button.builder(Component.literal("<"), b -> { thresholdPage--; rebuild(); })
                .bounds(left + 12, top + 42, 28, 20).build();
        prev.active = thresholdPage > 0; addRenderableWidget(prev);
        Button next = Button.builder(Component.literal(">"), b -> { thresholdPage++; rebuild(); })
                .bounds(left + 204, top + 42, 28, 20).build();
        next.active = thresholdPage + 1 < pages; addRenderableWidget(next);

        List<DomainControlsSnapshotPayload.ThresholdEntry> thresholds = thresholdPageEntries();
        for (int i = 0; i < thresholds.size(); i++) {
            var threshold = thresholds.get(i);
            String label = shortDimension(threshold.sourceDimensionId()) + "  →  " + threshold.domainX() + "," + threshold.domainY() + "," + threshold.domainZ();
            addRenderableWidget(Button.builder(Component.literal(label), b -> { selectedThresholdId = threshold.id(); rebuild(); })
                    .bounds(left + 12, top + 68 + i * 34, 220, 24).build());
        }
        var selected = selectedThreshold();
        if (selected == null) return;
        addRenderableWidget(Button.builder(Component.translatable(selected.publicAccess()
                                ? "screen.veilbound.domain_controls.threshold.public" : "screen.veilbound.domain_controls.threshold.private"),
                        b -> send(DomainControlsActionPayload.Action.TOGGLE_THRESHOLD_PUBLIC, selected.id(), ""))
                .bounds(left + 264, top + 92, 210, 22).build());

        int playerPages = pageCount(snapshot.onlinePlayers().size(), PLAYER_ROWS);
        Button pprev = Button.builder(Component.literal("<"), b -> { playerPage--; rebuild(); })
                .bounds(left + 264, top + 128, 28, 20).build();
        pprev.active = playerPage > 0; addRenderableWidget(pprev);
        Button pnext = Button.builder(Component.literal(">"), b -> { playerPage++; rebuild(); })
                .bounds(left + 446, top + 128, 28, 20).build();
        pnext.active = playerPage + 1 < playerPages; addRenderableWidget(pnext);

        List<DomainControlsSnapshotPayload.PlayerEntry> players = playerPageEntries();
        for (int i = 0; i < players.size(); i++) {
            var player = players.get(i);
            boolean invited = selected.invitedGuestIds().contains(player.uuid());
            Button b = Button.builder(Component.literal((invited ? "✓ " : "+ ") + player.name()), ignored ->
                            send(DomainControlsActionPayload.Action.TOGGLE_THRESHOLD_INVITE, selected.id(), player.uuid()))
                    .bounds(left + 264, top + 154 + i * 20, 210, 18).build();
            addRenderableWidget(b);
        }
    }

    private void rebuild() { clearWidgets(); init(); }
    private void send(DomainControlsActionPayload.Action action, String target, String value) {
        ClientPacketDistributor.sendToServer(new DomainControlsActionPayload(action, target, value));
    }

    private List<DomainControlsSnapshotPayload.ThresholdEntry> thresholdPageEntries() {
        int from = Math.min(thresholdPage * THRESHOLD_ROWS, snapshot.thresholds().size());
        return snapshot.thresholds().subList(from, Math.min(from + THRESHOLD_ROWS, snapshot.thresholds().size()));
    }
    private List<DomainControlsSnapshotPayload.PlayerEntry> playerPageEntries() {
        int from = Math.min(playerPage * PLAYER_ROWS, snapshot.onlinePlayers().size());
        return snapshot.onlinePlayers().subList(from, Math.min(from + PLAYER_ROWS, snapshot.onlinePlayers().size()));
    }
    private DomainControlsSnapshotPayload.ThresholdEntry selectedThreshold() {
        return snapshot.thresholds().stream().filter(t -> t.id().equals(selectedThresholdId)).findFirst().orElse(null);
    }

    @Override public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        extractTransparentBackground(graphics);
    }

    @Override public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
        int left = Math.max(6, width / 2 - PANEL_WIDTH / 2);
        int top = Math.max(18, height / 2 - PANEL_HEIGHT / 2);
        graphics.fill(left, top, left + PANEL_WIDTH, top + PANEL_HEIGHT, 0xF0100E18);
        graphics.fill(left, top, left + PANEL_WIDTH, top + 36, 0xF0271737);
        graphics.fill(left, top + 35, left + PANEL_WIDTH, top + 36, 0xFF9F7AC8);
        graphics.text(font, title, left + 350, top + 16, 0xFFF3ECFF, false);
        if (!snapshot.allowed()) {
            graphics.centeredText(font, Component.translatable("screen.veilbound.domain_controls.denied", snapshot.reason()), width / 2, top + 132, 0xFFFF8585);
            return;
        }
        if (!"ok".equals(snapshot.reason())) graphics.text(font, Component.literal("Result: " + snapshot.reason().replace('_', ' ')), left + 340, top + 44, 0xFFFFC080, false);
        switch (snapshot.view()) {
            case CORE -> renderCore(graphics, left, top);
            case PYLONS -> renderPylons(graphics, left, top);
            case THRESHOLDS -> renderThresholds(graphics, left, top);
        }
    }

    private void renderCore(GuiGraphicsExtractor graphics, int left, int top) {
        graphics.centeredText(font, Component.literal(snapshot.coreTier() + " DIMENSIONAL CORE"), width / 2, top + 62, 0xFFE4BCFF);
        graphics.centeredText(font, Component.translatable("screen.veilbound.domain_controls.de", snapshot.dimensionalEnergy(), snapshot.dimensionalEnergyCapacity()), width / 2, top + 84, 0xFFFFFFFF);
        graphics.centeredText(font, Component.translatable("screen.veilbound.domain_controls.size", snapshot.sizeX(), snapshot.sizeY(), snapshot.sizeZ()), width / 2, top + 104, 0xFFC5BDD0);
        graphics.centeredText(font, Component.translatable("screen.veilbound.domain_controls.fracture", String.format("%.1f", snapshot.fracture())), width / 2, top + 124, 0xFFC5BDD0);
        graphics.centeredText(font, Component.translatable("screen.veilbound.domain_controls.core_hint"), width / 2, top + 198, 0xFF9E93AA);
    }

    private void renderPylons(GuiGraphicsExtractor graphics, int left, int top) {
        graphics.centeredText(font, Component.translatable("screen.veilbound.domain_controls.pylons_hint"), width / 2, top + 46, 0xFFC5BDD0);
        for (int i = 0; i < snapshot.pylons().size() && i < 6; i++) {
            var p = snapshot.pylons().get(i);
            int col = i % 2, row = i / 2;
            int x = left + 26 + col * 238, y = top + 100 + row * 54;
            String pos = p.bound() ? "@ " + p.x() + ", " + p.y() + ", " + p.z() : "Place a pylon on this Core-relative axis";
            graphics.text(font, Component.literal(pos), x + 4, y, p.bound() ? 0xFF9E93AA : 0xFFFFC080, false);
        }
    }

    private void renderThresholds(GuiGraphicsExtractor graphics, int left, int top) {
        graphics.text(font, Component.translatable("screen.veilbound.domain_controls.page", thresholdPage + 1, pageCount(snapshot.thresholds().size(), THRESHOLD_ROWS)), left + 52, top + 47, 0xFFBEB4CA, false);
        var selected = selectedThreshold();
        if (selected == null) {
            graphics.text(font, Component.translatable("screen.veilbound.domain_controls.threshold.none"), left + 264, top + 82, 0xFF9E93AA, false);
            return;
        }
        graphics.text(font, Component.translatable("screen.veilbound.domain_controls.threshold.source", shortDimension(selected.sourceDimensionId())), left + 264, top + 48, 0xFFE4BCFF, false);
        graphics.text(font, Component.translatable("screen.veilbound.domain_controls.threshold.invites", selected.invitedGuestIds().size()), left + 264, top + 70, 0xFFC5BDD0, false);
        graphics.text(font, Component.translatable("screen.veilbound.domain_controls.threshold.online_players"), left + 304, top + 133, 0xFFC5BDD0, false);
        if (snapshot.onlinePlayers().isEmpty()) graphics.text(font, Component.translatable("screen.veilbound.domain_controls.threshold.no_online_players"), left + 264, top + 158, 0xFF9E93AA, false);
    }

    private static int pageCount(int size, int rows) { return Math.max(1, (size + rows - 1) / rows); }
    private static int clampPage(int page, int size, int rows) { return Math.max(0, Math.min(page, pageCount(size, rows) - 1)); }
    private static String shortDimension(String id) {
        if (id == null || id.isBlank()) return "unknown";
        int slash = id.lastIndexOf('/');
        int colon = id.lastIndexOf(':');
        int split = Math.max(slash, colon);
        return split >= 0 && split + 1 < id.length() ? id.substring(split + 1) : id;
    }
    private static String displaySpeed(String raw) {
        if (raw == null || raw.isBlank()) return "Stable";
        String lower = raw.toLowerCase(java.util.Locale.ROOT);
        return Character.toUpperCase(lower.charAt(0)) + lower.substring(1);
    }

    private static String displayDirection(String raw) {
        return switch (raw) {
            case "POSITIVE_X" -> "+X"; case "NEGATIVE_X" -> "−X";
            case "POSITIVE_Y" -> "+Y"; case "NEGATIVE_Y" -> "−Y";
            case "POSITIVE_Z" -> "+Z"; case "NEGATIVE_Z" -> "−Z";
            default -> raw;
        };
    }
}
