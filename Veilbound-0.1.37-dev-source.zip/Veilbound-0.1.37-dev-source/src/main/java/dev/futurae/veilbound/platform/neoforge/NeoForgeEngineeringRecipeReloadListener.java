package dev.futurae.veilbound.platform.neoforge;

import com.google.gson.*;
import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.engineering.*;
import java.io.*;
import java.util.*;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.*;
import net.minecraft.util.profiling.ProfilerFiller;

/** Loads advanced Fabricator/Foundry recipes from data/<namespace>/veilbound/engineering_recipes. */
public final class NeoForgeEngineeringRecipeReloadListener extends SimplePreparableReloadListener<DatapackDefinitionSnapshot<EngineeringRecipe>> {
    public static final Identifier LISTENER_ID = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "engineering_recipes");
    public static final String DIRECTORY = "veilbound/engineering_recipes";
    private final Gson gson = new Gson();
    private final EngineeringRecipeRegistry registry;
    public NeoForgeEngineeringRecipeReloadListener(EngineeringRecipeRegistry registry){ this.registry=Objects.requireNonNull(registry); }

    @Override protected DatapackDefinitionSnapshot<EngineeringRecipe> prepare(ResourceManager manager, ProfilerFiller profiler){
        List<EngineeringRecipe> defs=new ArrayList<>(); List<String>warnings=new ArrayList<>();
        var resources=manager.listResources(DIRECTORY,id->id.getPath().endsWith(".json")).entrySet().stream()
                .sorted(Map.Entry.comparingByKey(Comparator.comparing(Identifier::toString))).toList();
        for(var entry:resources){
            try(Reader reader=entry.getValue().openAsReader()){
                JsonObject o=NeoForgeDefinitionJson.requireObject(gson.fromJson(reader,JsonElement.class));
                String id=NeoForgeDefinitionJson.idFromResource(entry.getKey(),DIRECTORY);
                String display=NeoForgeDefinitionJson.optionalString(o,"display_name",id);
                EngineeringStation station=EngineeringStation.valueOf(NeoForgeDefinitionJson.requiredString(o,"station").trim().toUpperCase(Locale.ROOT));
                List<EngineeringIngredient> inputs=new ArrayList<>();
                JsonArray arr=o.has("inputs")?o.getAsJsonArray("inputs"):new JsonArray();
                for(JsonElement e:arr){ JsonObject in=NeoForgeDefinitionJson.requireObject(e); inputs.add(new EngineeringIngredient(
                        NeoForgeDefinitionJson.requiredString(in,"item"), NeoForgeDefinitionJson.optionalNonNegativeInt(in,"count",1))); }
                JsonObject out=NeoForgeDefinitionJson.requireObject(o.get("output"));
                String output=NeoForgeDefinitionJson.requiredString(out,"item"); int outputCount=NeoForgeDefinitionJson.optionalNonNegativeInt(out,"count",1);
                defs.add(new EngineeringRecipe(id,display,station,inputs,output,outputCount,
                        nonNegativeLong(o,"matter",0),nonNegativeLong(o,"dimensional_energy",0),nonNegativeLong(o,"potential",0),
                        CoreTier.valueOf(NeoForgeDefinitionJson.optionalString(o,"minimum_core_tier","NASCENT").toUpperCase(Locale.ROOT)),
                        NeoForgeDefinitionJson.optionalStringSet(o,"required_memories"),NeoForgeDefinitionJson.optionalStringSet(o,"required_laws"),
                        NeoForgeDefinitionJson.optionalNonNegativeInt(o,"process_ticks",200)));
            }catch(Exception ex){ warnings.add("Ignored engineering recipe "+entry.getKey()+": "+ex.getMessage()); }
        }
        return new DatapackDefinitionSnapshot<>(defs,warnings);
    }
    @Override protected void apply(DatapackDefinitionSnapshot<EngineeringRecipe> snapshot,ResourceManager manager,ProfilerFiller profiler){
        try{registry.replaceAll(snapshot.definitions());}catch(IllegalArgumentException ex){Veilbound.LOGGER.error("Rejected engineering recipes: {}",ex.getMessage());registry.replaceAll(List.of());}
        snapshot.warnings().forEach(w->Veilbound.LOGGER.warn("{}",w));
        Veilbound.LOGGER.info("Loaded {} Veilbound dimensional-engineering recipes",registry.all().size());
    }
    private static long nonNegativeLong(JsonObject o,String key,long fallback){
        if(!o.has(key)) return fallback; JsonElement e=o.get(key); if(!e.isJsonPrimitive()||!e.getAsJsonPrimitive().isNumber()) throw new JsonParseException("'"+key+"' must be a non-negative integer");
        long v=e.getAsLong(); if(v<0) throw new JsonParseException("'"+key+"' must be non-negative"); return v;
    }
}
