package dev.futurae.veilbound.law;

import java.util.Set;

/**
 * Built-in Veilbound Law-effect handler ids.
 *
 * <p>Law definitions remain datapack data. These ids are the platform gameplay contracts that
 * built-in definitions (or compatible datapacks) may request. Merely defining an effect does not
 * impose a Law on any Domain.</p>
 */
public final class LawEffectIds {
    public static final String HOSTILITY = "veilbound:hostility";
    public static final String FAUNA = "veilbound:fauna";
    public static final String FLAME = "veilbound:flame";
    public static final String RUIN = "veilbound:ruin";
    public static final String GRIEF = "veilbound:grief";
    public static final String CONFLICT = "veilbound:conflict";
    public static final String DESCENT = "veilbound:descent";
    public static final String PRESERVATION = "veilbound:preservation";
    public static final String TIME = "veilbound:time";
    public static final String WEATHER = "veilbound:weather";

    public static final Set<String> BUILT_IN = Set.of(
            HOSTILITY,
            FAUNA,
            FLAME,
            RUIN,
            GRIEF,
            CONFLICT,
            DESCENT,
            PRESERVATION,
            TIME,
            WEATHER);

    private LawEffectIds() {}
}
