package dev.futurae.veilbound.memory;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Replace-all facade intended to be rebuilt from datapacks on reload. */
public final class MemoryRegistry {
    private final Map<String, MemoryDefinition> byId = new LinkedHashMap<>();

    public void replaceAll(Collection<MemoryDefinition> memories) {
        byId.clear();
        for (MemoryDefinition memory : memories) {
            if (byId.put(memory.id(), memory) != null) {
                throw new IllegalArgumentException("Duplicate Memory id: " + memory.id());
            }
        }
    }

    public Optional<MemoryDefinition> get(String id) { return Optional.ofNullable(byId.get(id)); }
    public List<MemoryDefinition> all() { return List.copyOf(byId.values()); }
}
