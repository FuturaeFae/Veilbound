package dev.futurae.veilbound.matter;

import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainState;
import dev.futurae.veilbound.inventory.VeilInventory;
import dev.futurae.veilbound.inventory.VeilStackKey;
import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.OptionalLong;

/** Native Matter terminal rules shared by the wireless terminal and physical Interface. */
public final class MatterTransmutationService {
    public LearnResult learn(DomainState state, MatterTransmutationState transmutation, MatterCatalog catalog, String itemId) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(transmutation, "transmutation");
        Objects.requireNonNull(catalog, "catalog");
        if (!state.hasFeature(DomainFeature.VEIL_TRANSMUTATION)) return LearnResult.denied("veil_transmutation_locked");
        OptionalLong value = catalog.amount(itemId);
        if (value.isEmpty() || value.getAsLong() <= 0) return LearnResult.denied("matter_value_missing");
        boolean newlyLearned = transmutation.learn(itemId);
        return new LearnResult(true, newlyLearned, "ok");
    }

    /**
     * Destroys offered physical items, teaches their base item pattern, and credits Matter. Component
     * state is intentionally not part of the learned pattern: damaged/enchanted/custom variants are
     * absorbed as their base item and cannot become an arbitrary state-cloning primitive.
     */
    public AbsorbResult absorb(
            DomainState state,
            MatterTransmutationState transmutation,
            MatterCatalog catalog,
            VeilStackKey stack,
            long offeredCount) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(transmutation, "transmutation");
        Objects.requireNonNull(catalog, "catalog");
        Objects.requireNonNull(stack, "stack");
        if (!state.hasFeature(DomainFeature.VEIL_TRANSMUTATION)) return AbsorbResult.denied("veil_transmutation_locked");
        if (offeredCount <= 0) return AbsorbResult.denied("nothing_offered");

        OptionalLong resolved = catalog.amount(stack.itemId());
        if (resolved.isEmpty() || resolved.getAsLong() <= 0) return AbsorbResult.denied("matter_value_missing");
        long value = resolved.getAsLong();
        long gained;
        try {
            gained = Math.multiplyExact(offeredCount, value);
        } catch (ArithmeticException overflow) {
            return AbsorbResult.denied("matter_value_overflow");
        }
        if (Long.MAX_VALUE - transmutation.storedMatter() < gained) {
            return AbsorbResult.denied("matter_storage_full");
        }

        boolean newlyLearned = transmutation.learn(stack.itemId());
        long accepted = transmutation.addMatter(gained);
        if (accepted != gained) throw new IllegalStateException("Matter preflight disagreed with Matter reserve");
        return new AbsorbResult(true, offeredCount, gained, value, newlyLearned,
                !stack.componentData().isEmpty(), "ok");
    }

    /** Synthesizes up to requestedCount canonical items from a learned pattern and stored Matter. */
    public SynthesisResult synthesize(
            DomainState state,
            MatterTransmutationState transmutation,
            MatterCatalog catalog,
            String itemId,
            long requestedCount) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(transmutation, "transmutation");
        Objects.requireNonNull(catalog, "catalog");
        Objects.requireNonNull(itemId, "itemId");
        if (!state.hasFeature(DomainFeature.VEIL_TRANSMUTATION)) return SynthesisResult.denied("veil_transmutation_locked");
        if (requestedCount <= 0) return SynthesisResult.denied("nothing_requested");
        if (!transmutation.knows(itemId)) return SynthesisResult.denied("pattern_missing");

        OptionalLong resolved = catalog.amount(itemId);
        if (resolved.isEmpty() || resolved.getAsLong() <= 0) return SynthesisResult.denied("matter_value_missing");
        long value = resolved.getAsLong();
        long affordable = transmutation.storedMatter() / value;
        long count = Math.min(requestedCount, affordable);
        if (count <= 0) return SynthesisResult.denied("matter_missing");
        long cost;
        try {
            cost = Math.multiplyExact(count, value);
        } catch (ArithmeticException overflow) {
            return SynthesisResult.denied("matter_cost_overflow");
        }
        if (!transmutation.consumeMatter(cost)) throw new IllegalStateException("Matter affordability preflight disagreed with debit");
        return new SynthesisResult(true, count, cost, value, "ok");
    }

    /**
     * Migration/reconciliation used after the Transmutation upgrade. Valued legacy stacks are
     * absorbed into Matter and teach their base pattern. Unvalued stacks remain exact physical
     * Veil Inventory contents, including their component data. Running this again after a datapack
     * reload also converts previously-unvalued stacks that have since gained a Matter value.
     */
    public MigrationResult migrateLegacyInventory(
            DomainState state,
            VeilInventory inventory,
            MatterTransmutationState transmutation,
            MatterCatalog catalog) {
        Objects.requireNonNull(inventory, "inventory");
        Map<VeilStackKey, Long> legacy = inventory.contents();
        if (legacy.isEmpty()) return new MigrationResult(true, 0L, 0L, 0, List.of(), "ok");
        if (!state.hasFeature(DomainFeature.VEIL_TRANSMUTATION)) return MigrationResult.denied("veil_transmutation_locked");

        long totalMatter = 0L;
        long convertedItems = 0L;
        int canonicalizedVariants = 0;
        List<String> learned = new ArrayList<>();
        LinkedHashMap<VeilStackKey, Long> unvalued = new LinkedHashMap<>();
        for (var entry : legacy.entrySet()) {
            VeilStackKey stack = entry.getKey();
            long count = entry.getValue();
            OptionalLong resolved = catalog.amount(stack.itemId());
            if (resolved.isEmpty() || resolved.getAsLong() <= 0) {
                // No Matter value means no transmutation. Preserve the exact stack identity.
                unvalued.put(stack, count);
                continue;
            }
            long gain;
            try {
                gain = Math.multiplyExact(count, resolved.getAsLong());
                totalMatter = Math.addExact(totalMatter, gain);
                convertedItems = Math.addExact(convertedItems, count);
            } catch (ArithmeticException overflow) {
                return MigrationResult.denied("matter_value_overflow");
            }
            if (!stack.componentData().isEmpty()) canonicalizedVariants++;
            if (!transmutation.knows(stack.itemId()) && !learned.contains(stack.itemId())) learned.add(stack.itemId());
        }
        if (Long.MAX_VALUE - transmutation.storedMatter() < totalMatter) {
            return MigrationResult.denied("matter_storage_full");
        }

        for (String itemId : learned) transmutation.learn(itemId);
        if (totalMatter > 0) {
            long accepted = transmutation.addMatter(totalMatter);
            if (accepted != totalMatter) throw new IllegalStateException("Matter migration preflight disagreed with reserve");
        }
        if (!legacy.equals(unvalued)) inventory.replaceFromPersistence(unvalued);
        return new MigrationResult(true, convertedItems, totalMatter, canonicalizedVariants, List.copyOf(learned), "ok");
    }

    /** Compatibility wrapper retained for older callers/tests: remove stored stacks and absorb them. */
    public ConvertResult convert(
            DomainState state,
            VeilInventory inventory,
            MatterTransmutationState transmutation,
            MatterCatalog catalog,
            VeilStackKey stack,
            long requestedCount) {
        Objects.requireNonNull(inventory, "inventory");
        long available = inventory.count(stack);
        long count = Math.min(available, Math.max(0L, requestedCount));
        if (count <= 0) return ConvertResult.denied("item_not_stored");
        AbsorbResult absorbed = absorb(state, transmutation, catalog, stack, count);
        if (!absorbed.absorbed()) return ConvertResult.denied(absorbed.reason());
        long removed = inventory.extract(stack, count);
        if (removed != count) {
            // This code path is loader-neutral and single-threaded in all current callers. Treat a
            // disagreement as a hard invariant failure rather than silently minting Matter.
            throw new IllegalStateException("Veil Inventory changed during Matter conversion");
        }
        return new ConvertResult(true, count, absorbed.matterGained(), "ok");
    }

    public record LearnResult(boolean allowed, boolean newlyLearned, String reason) {
        public static LearnResult denied(String reason) { return new LearnResult(false, false, reason); }
    }

    public record AbsorbResult(
            boolean absorbed,
            long itemCount,
            long matterGained,
            long matterPerItem,
            boolean newlyLearned,
            boolean canonicalizedComponentState,
            String reason) {
        public static AbsorbResult denied(String reason) {
            return new AbsorbResult(false, 0L, 0L, 0L, false, false, reason);
        }
    }

    public record SynthesisResult(boolean synthesized, long itemCount, long matterSpent, long matterPerItem, String reason) {
        public static SynthesisResult denied(String reason) { return new SynthesisResult(false, 0L, 0L, 0L, reason); }
    }

    public record MigrationResult(
            boolean migrated,
            long itemCount,
            long matterGained,
            int canonicalizedComponentVariants,
            List<String> newlyLearnedPatterns,
            String reason) {
        public MigrationResult { newlyLearnedPatterns = List.copyOf(newlyLearnedPatterns); }
        public static MigrationResult denied(String reason) {
            return new MigrationResult(false, 0L, 0L, 0, List.of(), reason);
        }
    }

    public record ConvertResult(boolean converted, long itemCount, long matterGained, String reason) {
        public static ConvertResult denied(String reason) { return new ConvertResult(false, 0L, 0L, reason); }
    }
}
