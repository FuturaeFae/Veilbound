package dev.futurae.veilbound.platform.neoforge;

import com.mojang.brigadier.arguments.LongArgumentType;
import dev.futurae.veilbound.matter.MatterValue;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.Objects;
import java.util.Set;
import net.minecraft.commands.Commands;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/** ProjectE-style held-item Matter administration without a datapack reload. */
public final class NeoForgeMatterCommandCoordinator {
    private final VeilboundRuntime runtime;

    public NeoForgeMatterCommandCoordinator(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    public void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("veilbound")
                .then(Commands.literal("matter")
                        .then(Commands.literal("get")
                                .executes(ctx -> getHeld(ctx.getSource().getPlayerOrException())))
                        .then(Commands.literal("set")
                                .requires(Commands.hasPermission(Commands.LEVEL_ADMINS))
                                .then(Commands.argument("value", LongArgumentType.longArg(0, Long.MAX_VALUE))
                                        .executes(ctx -> setHeld(
                                                ctx.getSource().getPlayerOrException(),
                                                LongArgumentType.getLong(ctx, "value")))))
                        .then(Commands.literal("clear")
                                .requires(Commands.hasPermission(Commands.LEVEL_ADMINS))
                                .executes(ctx -> clearHeld(ctx.getSource().getPlayerOrException())))));
    }

    private int getHeld(ServerPlayer player) {
        String id = heldItemId(player);
        if (id == null) return 0;
        MatterValue value = runtime.matter().get(id).orElse(null);
        if (value == null || value.amount() <= 0) {
            player.sendSystemMessage(Component.literal(id + " has no Matter value."));
            return 1;
        }
        player.sendSystemMessage(Component.literal(id + " = " + value.amount() + " Matter ["
                + value.source().name().toLowerCase(java.util.Locale.ROOT) + "]"));
        return 1;
    }

    private int setHeld(ServerPlayer player, long amount) {
        String id = heldItemId(player);
        if (id == null) return 0;
        runtime.matter().putAdmin(id, amount, "command:" + player.getUUID());
        var report = runtime.matterReload().recomputeAffected(Set.of(id));
        if (amount == 0) {
            player.sendSystemMessage(Component.literal("Set " + id + " to unvalued (0 Matter). Updated "
                    + report.affectedItemCount() + " affected item identities without /reload."));
        } else {
            player.sendSystemMessage(Component.literal("Set " + id + " = " + amount + " Matter. Updated "
                    + report.affectedItemCount() + " affected item identities without /reload."));
        }
        return 1;
    }

    private int clearHeld(ServerPlayer player) {
        String id = heldItemId(player);
        if (id == null) return 0;
        boolean removed = runtime.matter().removeAdmin(id);
        var report = runtime.matterReload().recomputeAffected(Set.of(id));
        MatterValue resolved = runtime.matter().get(id).orElse(null);
        String fallback = resolved == null || resolved.amount() <= 0
                ? "now unvalued"
                : "now " + resolved.amount() + " Matter [" + resolved.source().name().toLowerCase(java.util.Locale.ROOT) + "]";
        player.sendSystemMessage(Component.literal((removed ? "Cleared" : "No override existed for") + " " + id
                + "; " + fallback + ". Updated " + report.affectedItemCount() + " affected item identities without /reload."));
        return 1;
    }

    private static String heldItemId(ServerPlayer player) {
        ItemStack stack = player.getMainHandItem();
        if (stack.isEmpty()) {
            player.sendSystemMessage(Component.literal("Hold an item in your main hand."));
            return null;
        }
        return BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
    }
}
