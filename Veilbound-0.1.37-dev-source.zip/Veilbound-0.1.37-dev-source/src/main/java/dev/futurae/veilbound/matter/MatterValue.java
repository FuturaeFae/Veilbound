package dev.futurae.veilbound.matter;

public record MatterValue(long amount, Source source, String provenance) {
    public MatterValue {
        if (amount < 0) throw new IllegalArgumentException("Matter value must be non-negative");
        if (source == null) throw new IllegalArgumentException("source may not be null");
        if (provenance == null) provenance = "";
    }

    public boolean authoritative() {
        return source != Source.INFERRED;
    }

    public enum Source {
        /** Live/persisted operator override with highest priority. */
        ADMIN,
        /** Shipped Veilbound baseline table. */
        BUILTIN,
        /** Server/datapack override with priority over BUILTIN. */
        DATAPACK,
        /** Compatibility label retained for old callers; treated as authoritative. */
        EXPLICIT,
        /** Best-effort recipe-derived value. */
        INFERRED
    }
}
