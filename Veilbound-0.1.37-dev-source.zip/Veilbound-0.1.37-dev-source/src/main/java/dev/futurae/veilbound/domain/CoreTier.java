package dev.futurae.veilbound.domain;

/** Authoritative Core progression and hard storage/size ceilings. */
public enum CoreTier {
    NASCENT(25_000L, 33, 0L),
    ANCHORED(250_000L, 129, 20_000L),
    RESONANT(2_500_000L, 513, 200_000L),
    ASCENDANT(25_000_000L, 2_049, 2_000_000L),
    TRANSCENDENT(250_000_000L, Integer.MAX_VALUE, 20_000_000L);

    private final long dimensionalEnergyCapacity;
    private final int defaultHorizontalSizeCap;
    private final long upgradeCostFromPrevious;

    CoreTier(long dimensionalEnergyCapacity, int defaultHorizontalSizeCap, long upgradeCostFromPrevious) {
        this.dimensionalEnergyCapacity = dimensionalEnergyCapacity;
        this.defaultHorizontalSizeCap = defaultHorizontalSizeCap;
        this.upgradeCostFromPrevious = upgradeCostFromPrevious;
    }

    public long dimensionalEnergyCapacity() {
        return dimensionalEnergyCapacity;
    }

    public int defaultHorizontalSizeCap() {
        return defaultHorizontalSizeCap;
    }

    public long upgradeCostFromPrevious() {
        return upgradeCostFromPrevious;
    }

    public boolean isHorizontallyUnlimitedByDefault() {
        return this == TRANSCENDENT;
    }
}
