package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.neoforged.neoforge.transfer.item.ItemResource;

/** Bounded server-authoritative recipe catalog for the Craftables tab. */
public record VeilCraftablesSnapshotPayload(
        boolean allowed,
        String reason,
        boolean allCrafts,
        int page,
        int pageCount,
        long storedMatter,
        int matchingRecipes,
        List<Entry> entries) implements CustomPacketPayload {
    public static final int PAGE_SIZE = 36;
    public static final int GRID_SIZE = 9;
    public static final Type<VeilCraftablesSnapshotPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "veil_craftables_snapshot"));

    public static final StreamCodec<RegistryFriendlyByteBuf, VeilCraftablesSnapshotPayload> STREAM_CODEC =
            new StreamCodec<>() {
                @Override
                public VeilCraftablesSnapshotPayload decode(RegistryFriendlyByteBuf buffer) {
                    boolean allowed = buffer.readBoolean();
                    String reason = buffer.readUtf(128);
                    boolean allCrafts = buffer.readBoolean();
                    int page = Math.max(0, buffer.readVarInt());
                    int pageCount = Math.max(1, buffer.readVarInt());
                    long storedMatter = Math.max(0L, buffer.readVarLong());
                    int matchingRecipes = Math.max(0, buffer.readVarInt());
                    int count = buffer.readVarInt();
                    if (count < 0 || count > PAGE_SIZE) {
                        throw new IllegalArgumentException("Invalid Veil craftables entry count: " + count);
                    }
                    List<Entry> entries = new ArrayList<>(count);
                    for (int i = 0; i < count; i++) {
                        ItemResource result = ItemResource.STREAM_CODEC.decode(buffer);
                        int resultCount = buffer.readVarInt();
                        long matterCost = buffer.readVarLong();
                        boolean craftable = buffer.readBoolean();
                        boolean patternsKnown = buffer.readBoolean();
                        long affordableCrafts = buffer.readVarLong();
                        int gridCount = buffer.readVarInt();
                        if (gridCount != GRID_SIZE) {
                            throw new IllegalArgumentException("Invalid Veil craftables grid size: " + gridCount);
                        }
                        List<ItemResource> grid = new ArrayList<>(GRID_SIZE);
                        List<Boolean> learnedGrid = new ArrayList<>(GRID_SIZE);
                        for (int slot = 0; slot < GRID_SIZE; slot++) {
                            grid.add(ItemResource.STREAM_CODEC.decode(buffer));
                            learnedGrid.add(buffer.readBoolean());
                        }
                        entries.add(new Entry(result, resultCount, matterCost, craftable, patternsKnown,
                                affordableCrafts, grid, learnedGrid));
                    }
                    return new VeilCraftablesSnapshotPayload(
                            allowed, reason, allCrafts, page, pageCount, storedMatter, matchingRecipes, entries);
                }

                @Override
                public void encode(RegistryFriendlyByteBuf buffer, VeilCraftablesSnapshotPayload payload) {
                    buffer.writeBoolean(payload.allowed());
                    buffer.writeUtf(payload.reason(), 128);
                    buffer.writeBoolean(payload.allCrafts());
                    buffer.writeVarInt(payload.page());
                    buffer.writeVarInt(payload.pageCount());
                    buffer.writeVarLong(payload.storedMatter());
                    buffer.writeVarInt(payload.matchingRecipes());
                    int count = Math.min(PAGE_SIZE, payload.entries().size());
                    buffer.writeVarInt(count);
                    for (int i = 0; i < count; i++) {
                        Entry entry = payload.entries().get(i);
                        ItemResource.STREAM_CODEC.encode(buffer, entry.result());
                        buffer.writeVarInt(entry.resultCount());
                        buffer.writeVarLong(entry.matterCost());
                        buffer.writeBoolean(entry.craftable());
                        buffer.writeBoolean(entry.patternsKnown());
                        buffer.writeVarLong(entry.affordableCrafts());
                        buffer.writeVarInt(GRID_SIZE);
                        for (int slot = 0; slot < GRID_SIZE; slot++) {
                            ItemResource.STREAM_CODEC.encode(buffer, entry.grid().get(slot));
                            buffer.writeBoolean(entry.learnedGrid().get(slot));
                        }
                    }
                }
            };

    public VeilCraftablesSnapshotPayload {
        reason = reason == null ? "unknown" : reason;
        page = Math.max(0, page);
        pageCount = Math.max(1, pageCount);
        storedMatter = Math.max(0L, storedMatter);
        matchingRecipes = Math.max(0, matchingRecipes);
        entries = List.copyOf(entries == null ? List.of() : entries);
    }

    /** Compatibility constructor from 0.1.17. */
    public VeilCraftablesSnapshotPayload(
            boolean allowed, String reason, boolean allCrafts, int page, int pageCount,
            long storedMatter, List<Entry> entries) {
        this(allowed, reason, allCrafts, page, pageCount, storedMatter, entries == null ? 0 : entries.size(), entries);
    }

    public static VeilCraftablesSnapshotPayload denied(String reason, boolean allCrafts) {
        return new VeilCraftablesSnapshotPayload(false, reason, allCrafts, 0, 1, 0L, 0, List.of());
    }

    public record Entry(
            ItemResource result,
            int resultCount,
            long matterCost,
            boolean craftable,
            boolean patternsKnown,
            long affordableCrafts,
            List<ItemResource> grid,
            List<Boolean> learnedGrid) {
        public Entry {
            if (result == null) result = ItemResource.EMPTY;
            if (resultCount < 0) throw new IllegalArgumentException("resultCount must be >= 0");
            if (matterCost < 0) throw new IllegalArgumentException("matterCost must be >= 0");
            if (affordableCrafts < 0) throw new IllegalArgumentException("affordableCrafts must be >= 0");
            if (grid == null || grid.size() != GRID_SIZE) {
                throw new IllegalArgumentException("Craftables grid must contain exactly " + GRID_SIZE + " cells");
            }
            if (learnedGrid == null || learnedGrid.size() != GRID_SIZE) {
                throw new IllegalArgumentException("Craftables learned grid must contain exactly " + GRID_SIZE + " cells");
            }
            ArrayList<ItemResource> normalized = new ArrayList<>(GRID_SIZE);
            for (ItemResource resource : grid) normalized.add(resource == null ? ItemResource.EMPTY : resource);
            grid = List.copyOf(normalized);
            learnedGrid = List.copyOf(learnedGrid);
        }

        /** Compatibility constructor from 0.1.17. */
        public Entry(ItemResource result, int resultCount, long matterCost, boolean craftable, List<ItemResource> grid) {
            this(result, resultCount, matterCost, craftable, craftable,
                    matterCost <= 0 ? 0 : (craftable ? 1 : 0), grid, learnedDefaults(grid, craftable));
        }

        private static List<Boolean> learnedDefaults(List<ItemResource> grid, boolean learned) {
            ArrayList<Boolean> flags = new ArrayList<>(GRID_SIZE);
            for (ItemResource resource : grid) flags.add(resource == null || resource.isEmpty() || learned);
            return flags;
        }
    }

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
