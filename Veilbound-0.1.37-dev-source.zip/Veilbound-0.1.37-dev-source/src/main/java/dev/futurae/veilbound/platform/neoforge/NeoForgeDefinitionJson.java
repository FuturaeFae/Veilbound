package dev.futurae.veilbound.platform.neoforge;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.resources.Identifier;

final class NeoForgeDefinitionJson {
    private NeoForgeDefinitionJson() {}

    static String idFromResource(Identifier resourceId, String directory) {
        String prefix = directory + "/";
        String path = resourceId.getPath();
        if (!path.startsWith(prefix) || !path.endsWith(".json")) return null;
        String definitionPath = path.substring(prefix.length(), path.length() - ".json".length());
        if (definitionPath.isBlank() || definitionPath.startsWith("/") || definitionPath.endsWith("/")) return null;
        return resourceId.getNamespace() + ":" + definitionPath;
    }

    static JsonObject requireObject(JsonElement root) {
        if (root == null || !root.isJsonObject()) throw new JsonParseException("expected a JSON object");
        return root.getAsJsonObject();
    }

    static String requiredString(JsonObject object, String key) {
        if (!object.has(key)) throw new JsonParseException("missing required '" + key + "' field");
        JsonElement value = object.get(key);
        if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isString()) {
            throw new JsonParseException("'" + key + "' must be a string");
        }
        String result = value.getAsString();
        if (result.isBlank()) throw new JsonParseException("'" + key + "' may not be blank");
        return result;
    }

    static int optionalNonNegativeInt(JsonObject object, String key, int fallback) {
        if (!object.has(key)) return fallback;
        JsonElement value = object.get(key);
        if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isNumber()) {
            throw new JsonParseException("'" + key + "' must be a non-negative integer");
        }
        int result;
        try {
            result = value.getAsInt();
        } catch (NumberFormatException ex) {
            throw new JsonParseException("'" + key + "' is outside the integer range", ex);
        }
        if (result < 0) throw new JsonParseException("'" + key + "' must be non-negative");
        return result;
    }

    static Set<String> optionalStringSet(JsonObject object, String key) {
        if (!object.has(key)) return Set.of();
        JsonElement value = object.get(key);
        if (!value.isJsonArray()) throw new JsonParseException("'" + key + "' must be an array of strings");
        LinkedHashSet<String> result = new LinkedHashSet<>();
        JsonArray array = value.getAsJsonArray();
        for (JsonElement element : array) {
            if (!element.isJsonPrimitive() || !element.getAsJsonPrimitive().isString()) {
                throw new JsonParseException("'" + key + "' must contain only strings");
            }
            String entry = element.getAsString();
            if (entry.isBlank()) throw new JsonParseException("'" + key + "' may not contain blank strings");
            result.add(entry);
        }
        return Set.copyOf(result);
    }

    static Map<String, String> optionalStringMap(JsonObject object, String key) {
        if (!object.has(key)) return Map.of();
        JsonElement value = object.get(key);
        if (!value.isJsonObject()) throw new JsonParseException("'" + key + "' must be an object of string values");
        LinkedHashMap<String, String> result = new LinkedHashMap<>();
        for (Map.Entry<String, JsonElement> entry : value.getAsJsonObject().entrySet()) {
            JsonElement element = entry.getValue();
            if (!element.isJsonPrimitive() || !element.getAsJsonPrimitive().isString()) {
                throw new JsonParseException("'" + key + "." + entry.getKey() + "' must be a string");
            }
            result.put(entry.getKey(), element.getAsString());
        }
        return Map.copyOf(result);
    }
    static boolean optionalBoolean(JsonObject object, String key, boolean fallback) {
        if (!object.has(key)) return fallback;
        JsonElement value = object.get(key);
        if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isBoolean()) {
            throw new JsonParseException("'" + key + "' must be a boolean");
        }
        return value.getAsBoolean();
    }

    static String optionalString(JsonObject object, String key, String fallback) {
        if (!object.has(key)) return fallback;
        JsonElement value = object.get(key);
        if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isString()) {
            throw new JsonParseException("'" + key + "' must be a string");
        }
        String result = value.getAsString();
        if (result.isBlank()) throw new JsonParseException("'" + key + "' may not be blank");
        return result;
    }

    static JsonObject optionalObject(JsonObject object, String key) {
        if (!object.has(key)) return new JsonObject();
        JsonElement value = object.get(key);
        if (!value.isJsonObject()) throw new JsonParseException("'" + key + "' must be an object");
        return value.getAsJsonObject();
    }

}
