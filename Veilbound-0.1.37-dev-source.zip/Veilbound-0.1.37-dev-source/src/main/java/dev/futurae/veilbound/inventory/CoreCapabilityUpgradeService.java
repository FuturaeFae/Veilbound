package dev.futurae.veilbound.inventory;

import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainState;
import java.util.Objects;

/** Applies crafted capability-upgrade items when they are deliberately fed to the active Core. */
public final class CoreCapabilityUpgradeService {
    public static final String VEIL_INVENTORY_UPGRADE_ID = "veilbound:veil_inventory_upgrade";
    public static final String VEIL_CRAFTING_UPGRADE_ID = "veilbound:veil_crafting_upgrade";
    public static final String VEIL_TRANSMUTATION_UPGRADE_ID = "veilbound:veil_transmutation_upgrade";

    public FeedResult feed(DomainState state, String itemId, long offeredCount) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(itemId, "itemId");
        if (offeredCount <= 0) return FeedResult.denied("nothing_offered");
        if (!state.coreActive()) return FeedResult.denied("core_inactive");

        if (VEIL_INVENTORY_UPGRADE_ID.equals(itemId)) {
            if (state.coreTier().ordinal() < CoreTier.RESONANT.ordinal()) return FeedResult.denied("requires_resonant_core");
            if (state.hasFeature(DomainFeature.VEIL_INVENTORY)) return FeedResult.denied("already_unlocked");
            state.unlockFeature(DomainFeature.VEIL_INVENTORY);
            return FeedResult.accepted(1L, DomainFeature.VEIL_INVENTORY);
        }

        if (VEIL_CRAFTING_UPGRADE_ID.equals(itemId)) {
            if (!state.hasFeature(DomainFeature.VEIL_INVENTORY)) return FeedResult.denied("requires_veil_inventory");
            if (state.hasFeature(DomainFeature.VEIL_CRAFTING)) return FeedResult.denied("already_unlocked");
            state.unlockFeature(DomainFeature.VEIL_CRAFTING);
            return FeedResult.accepted(1L, DomainFeature.VEIL_CRAFTING);
        }

        if (VEIL_TRANSMUTATION_UPGRADE_ID.equals(itemId)) {
            if (!state.hasFeature(DomainFeature.VEIL_CRAFTING)) return FeedResult.denied("requires_veil_crafting");
            if (state.hasFeature(DomainFeature.VEIL_TRANSMUTATION)) return FeedResult.denied("already_unlocked");
            state.unlockFeature(DomainFeature.VEIL_TRANSMUTATION);
            return FeedResult.accepted(1L, DomainFeature.VEIL_TRANSMUTATION);
        }

        return FeedResult.denied("unsupported_upgrade_item");
    }

    public record FeedResult(boolean accepted, long consumed, DomainFeature unlockedFeature, String reason) {
        public static FeedResult denied(String reason) { return new FeedResult(false, 0L, null, reason); }
        public static FeedResult accepted(long consumed, DomainFeature feature) { return new FeedResult(true, consumed, feature, "ok"); }
    }
}
