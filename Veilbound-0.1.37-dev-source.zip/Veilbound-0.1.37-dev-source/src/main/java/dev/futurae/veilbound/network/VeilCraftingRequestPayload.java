package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.neoforged.neoforge.transfer.item.ItemResource;

/** Client proposal for the nine wireless crafting-grid cells. The server remains authoritative. */
public record VeilCraftingRequestPayload(Action action, int page, int quantity, List<ItemResource> grid)
        implements CustomPacketPayload {
    public static final int GRID_SIZE = 9;
    public static final int MAX_CRAFT_QUANTITY = 64;

    public enum Action { PREVIEW, CRAFT_ONCE }

    public static final Type<VeilCraftingRequestPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "veil_crafting_request"));

    public static final StreamCodec<RegistryFriendlyByteBuf, VeilCraftingRequestPayload> STREAM_CODEC =
            new StreamCodec<>() {
                @Override
                public VeilCraftingRequestPayload decode(RegistryFriendlyByteBuf buffer) {
                    int ordinal = buffer.readVarInt();
                    if (ordinal < 0 || ordinal >= Action.values().length) ordinal = 0;
                    int page = Math.max(0, buffer.readVarInt());
                    int quantity = Math.max(1, Math.min(MAX_CRAFT_QUANTITY, buffer.readVarInt()));
                    int count = buffer.readVarInt();
                    if (count != GRID_SIZE) {
                        throw new IllegalArgumentException("Invalid Veil crafting grid size: " + count);
                    }
                    List<ItemResource> grid = new ArrayList<>(GRID_SIZE);
                    for (int i = 0; i < GRID_SIZE; i++) grid.add(ItemResource.STREAM_CODEC.decode(buffer));
                    return new VeilCraftingRequestPayload(Action.values()[ordinal], page, quantity, grid);
                }

                @Override
                public void encode(RegistryFriendlyByteBuf buffer, VeilCraftingRequestPayload payload) {
                    buffer.writeVarInt(payload.action().ordinal());
                    buffer.writeVarInt(payload.page());
                    buffer.writeVarInt(payload.quantity());
                    buffer.writeVarInt(GRID_SIZE);
                    for (ItemResource resource : payload.grid()) ItemResource.STREAM_CODEC.encode(buffer, resource);
                }
            };

    public VeilCraftingRequestPayload {
        if (action == null) action = Action.PREVIEW;
        page = Math.max(0, page);
        quantity = Math.max(1, Math.min(MAX_CRAFT_QUANTITY, quantity));
        if (grid == null || grid.size() != GRID_SIZE) {
            throw new IllegalArgumentException("Veil crafting grid must contain exactly " + GRID_SIZE + " cells");
        }
        ArrayList<ItemResource> normalized = new ArrayList<>(GRID_SIZE);
        for (ItemResource resource : grid) normalized.add(resource == null ? ItemResource.EMPTY : resource);
        grid = List.copyOf(normalized);
    }

    /** Compatibility constructor for 0.1.17 callers. */
    public VeilCraftingRequestPayload(Action action, int page, List<ItemResource> grid) {
        this(action, page, 1, grid);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
