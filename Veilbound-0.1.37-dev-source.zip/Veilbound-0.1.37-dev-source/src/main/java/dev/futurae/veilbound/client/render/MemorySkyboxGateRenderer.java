package dev.futurae.veilbound.client.render;

import dev.futurae.veilbound.client.MemoryClientEnvironmentState;
import dev.futurae.veilbound.memory.DomainCelestialProfile;
import net.minecraft.client.renderer.state.level.LevelRenderState;
import net.minecraft.client.renderer.state.level.SkyRenderState;
import net.neoforged.neoforge.client.CustomSkyboxRenderer;
import org.joml.Matrix4fc;

/**
 * Domain sky gate selected by the Domain dimension type's NeoForge environment attribute.
 *
 * <p>With no earned firmament Memory the vanilla sky is suppressed. A visible Memory yields to
 * the vanilla 26.2 sky renderer after projecting Veilbound's Domain-local celestial angles into
 * the mutable SkyRenderState, so a personal Celestial Cycle does not follow the server Overworld
 * clock merely because the underlying dimension type uses the Overworld clock schema.</p>
 */
public final class MemorySkyboxGateRenderer implements CustomSkyboxRenderer {
    @Override
    public boolean renderSky(
            LevelRenderState levelRenderState,
            SkyRenderState skyRenderState,
            Matrix4fc modelViewMatrix,
            Runnable setupFog) {
        var snapshot = MemoryClientEnvironmentState.snapshot();
        if (!snapshot.semantics().visibleFirmament()) return true;

        var celestial = DomainCelestialProfile.sample(
                snapshot.domainDayTime(), snapshot.semantics().overworldCelestialCycle());
        skyRenderState.sunAngle = celestial.sunAngle();
        skyRenderState.moonAngle = celestial.moonAngle();
        skyRenderState.starAngle = celestial.starAngle();
        skyRenderState.starBrightness = celestial.starBrightness();
        return false;
    }
}
