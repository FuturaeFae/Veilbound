package dev.futurae.veilbound.persistence;

import dev.futurae.veilbound.breach.Breach;
import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.BoundaryPylonState;
import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainLifecycle;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import dev.futurae.veilbound.environment.EnvironmentZone;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Loader-neutral persisted shape. The NeoForge layer can encode this using Minecraft codecs
 * without exposing Minecraft classes to the deterministic rule model.
 */
public record DomainSnapshot(
        UUID ownerId,
        DomainLifecycle lifecycle,
        CoreTier coreTier,
        DomainPosition corePosition,
        DomainBounds bounds,
        long dimensionalEnergy,
        Map<String, Long> coreUpgradeFedItems,
        Map<AxisDirection, BoundaryPylonState> pylons,
        Set<String> imposedLawIds,
        Set<String> unlockedMemoryIds,
        Set<String> completedMilestoneIds,
        Set<DomainFeature> unlockedFeatures,
        List<EnvironmentZone> environmentZones,
        List<Breach> breaches,
        Set<DomainPosition> continuityAnchors,
        double fractureMeter,
        long dayTime,
        int clearWeatherTime,
        boolean raining,
        int rainTime,
        boolean thundering,
        int thunderTime,
        boolean globalExpansionEnabled,
        boolean sovereigntyUnlocked) {

    public DomainSnapshot {
        coreUpgradeFedItems = Map.copyOf(coreUpgradeFedItems);
        for (var entry : coreUpgradeFedItems.entrySet()) {
            if (entry.getKey() == null || entry.getKey().isBlank() || entry.getValue() == null || entry.getValue() <= 0) {
                throw new IllegalArgumentException("Invalid Core upgrade feed entry");
            }
        }
        pylons = Map.copyOf(pylons);
        imposedLawIds = Set.copyOf(imposedLawIds);
        unlockedMemoryIds = Set.copyOf(unlockedMemoryIds);
        completedMilestoneIds = Set.copyOf(completedMilestoneIds);
        unlockedFeatures = Set.copyOf(unlockedFeatures);
        environmentZones = List.copyOf(environmentZones);
        breaches = List.copyOf(breaches);
        continuityAnchors = Set.copyOf(continuityAnchors);
        if (!Double.isFinite(fractureMeter) || fractureMeter < 0) throw new IllegalArgumentException("fractureMeter must be finite and >= 0");
        if (clearWeatherTime < 0 || rainTime < 0 || thunderTime < 0) throw new IllegalArgumentException("weather timers must be >= 0");
    }

    public static DomainSnapshot capture(DomainState state) {
        return new DomainSnapshot(
                state.ownerId(),
                state.lifecycle(),
                state.coreTier(),
                state.corePosition(),
                state.bounds(),
                state.dimensionalEnergy(),
                state.coreUpgradeFedItems(),
                state.pylons(),
                state.imposedLawIds(),
                state.unlockedMemoryIds(),
                state.completedMilestoneIds(),
                state.unlockedFeatures(),
                state.environmentZones(),
                state.breaches(),
                state.continuityAnchors(),
                state.fractureMeter(),
                state.dayTime(),
                state.clearWeatherTime(),
                state.raining(),
                state.rainTime(),
                state.thundering(),
                state.thunderTime(),
                state.globalExpansionEnabled(),
                state.sovereigntyUnlocked());
    }

    public DomainState restore() {
        DomainState state = new DomainState(ownerId);
        state.setBounds(bounds);
        if (lifecycle == DomainLifecycle.CORE_ACTIVE) {
            state.awakenCore(DomainPosition.ORIGIN);
            if (!corePosition.equals(DomainPosition.ORIGIN)) state.relocateCore(corePosition);
            state.setCoreTier(coreTier);
            state.setDimensionalEnergy(dimensionalEnergy);
            state.replaceCoreUpgradeFeed(coreUpgradeFedItems);
            EnumMap<AxisDirection, BoundaryPylonState> restoredPylons = new EnumMap<>(AxisDirection.class);
            restoredPylons.putAll(pylons);
            for (AxisDirection direction : AxisDirection.values()) {
                BoundaryPylonState pylon = restoredPylons.get(direction);
                if (pylon != null) state.setPylon(pylon);
            }
        } else if (dimensionalEnergy != 0) {
            throw new IllegalStateException("Pre-Core snapshot may not contain Dimensional Energy");
        }
        for (String law : imposedLawIds) state.imposeLaw(law);
        for (String memory : unlockedMemoryIds) state.unlockMemory(memory);
        state.restoreCompletedMilestones(completedMilestoneIds);
        for (DomainFeature feature : unlockedFeatures) state.unlockFeature(feature);
        for (EnvironmentZone zone : environmentZones) state.addEnvironmentZone(zone);
        for (Breach breach : breaches) state.addBreach(breach);
        if (lifecycle == DomainLifecycle.CORE_ACTIVE) {
            for (DomainPosition anchor : continuityAnchors) state.addContinuityAnchor(anchor);
            state.setFractureMeter(fractureMeter);
        } else if (!continuityAnchors.isEmpty() || fractureMeter != 0.0) {
            throw new IllegalStateException("Pre-Core snapshot may not contain Continuity Anchors or fracture progress");
        }
        state.setDayTime(dayTime);
        state.setWeatherState(clearWeatherTime, raining, rainTime, thundering, thunderTime);
        if (state.coreActive()) {
            state.setGlobalExpansionEnabled(globalExpansionEnabled);
        }
        state.setSovereigntyUnlocked(sovereigntyUnlocked);
        return state;
    }
}
