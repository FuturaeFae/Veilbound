package dev.futurae.veilbound.platform.neoforge.precore;

import dev.futurae.veilbound.domain.DomainIdentity;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.network.SpatialGeneratorActionPayload;
import dev.futurae.veilbound.network.SpatialGeneratorSnapshotPayload;
import dev.futurae.veilbound.precore.CondensedCharge;
import dev.futurae.veilbound.precore.SpatialGeneratorCondensationService;
import dev.futurae.veilbound.precore.SpatialGeneratorPlanner;
import dev.futurae.veilbound.precore.SpatialGeneratorRuntimePolicy;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import dev.futurae.veilbound.registry.VeilboundDataComponents;
import dev.futurae.veilbound.registry.VeilboundItems;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.Objects;
import java.util.OptionalLong;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.Relative;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/** Physical pre-Core gameplay boundary for charging, condensation, expansion and Core awakening. */
public final class NeoForgeSpatialGeneratorController {
    private static final BlockPos CORE_ORIGIN = BlockPos.ZERO;
    private static final int AWAKENING_MANHATTAN_RANGE = 3;

    private final VeilboundRuntime runtime;

    public NeoForgeSpatialGeneratorController(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    public void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getLevel().isClientSide()) return;
        if (!event.getItemStack().is(VeilboundItems.SPATIAL_GENERATOR.get())) return;
        sendSnapshot(player, findGenerator(player));
        event.setCancellationResult(InteractionResult.SUCCESS);
        event.setCanceled(true);
    }

    public void handle(ServerPlayer player, SpatialGeneratorActionPayload payload) {
        ItemStack generator = findGenerator(player);
        if (generator.isEmpty()) {
            PacketDistributor.sendToPlayer(player, denied("generator_not_held"));
            return;
        }
        var record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null) {
            PacketDistributor.sendToPlayer(player, denied("domain_not_found"));
            return;
        }
        String ownDomain = DomainIdentity.dimensionIdFor(player.getUUID());
        if (!player.level().dimension().identifier().toString().equals(ownDomain)) {
            PacketDistributor.sendToPlayer(player, denied("not_inside_own_domain"));
            return;
        }
        if (record.state().coreActive()) {
            PacketDistributor.sendToPlayer(player, denied("core_already_active"));
            return;
        }

        switch (payload.action()) {
            case OPEN -> { }
            case CONDENSE_FEED_HAND -> condense(player, generator);
            case EXPAND_X -> expand(player, record.state(), generator, DomainAxis.X);
            case EXPAND_Y -> expand(player, record.state(), generator, DomainAxis.Y);
            case EXPAND_Z -> expand(player, record.state(), generator, DomainAxis.Z);
            case AWAKEN_CORE -> awaken(player, generator);
        }
        sendSnapshot(player, generator);
    }

    private void condense(ServerPlayer player, ItemStack generator) {
        ItemStack feed = generator == player.getMainHandItem() ? player.getOffhandItem() : player.getMainHandItem();
        if (feed.isEmpty() || feed.is(VeilboundItems.NUCLEUS_CATALYST.get())) return;
        var key = BuiltInRegistries.ITEM.getKey(feed.getItem());
        if (key == null) return;
        OptionalLong matter = runtime.matter().amount(key.toString());
        if (matter.isEmpty() || matter.getAsLong() <= 0) {
            player.displayClientMessage(Component.translatable("message.veilbound.spatial_generator.no_matter_value"), false);
            return;
        }

        int storedFe = generator.getOrDefault(VeilboundDataComponents.SPATIAL_GENERATOR_FE.get(), 0);
        var plan = SpatialGeneratorCondensationService.plan(
                matter.getAsLong(), feed.getCount(), storedFe, runtime.spatialGeneratorPolicy().policy());
        if (!plan.allowed()) {
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.spatial_generator.action_denied", plan.reason()), false);
            return;
        }

        long oldCharge = generator.getOrDefault(VeilboundDataComponents.SPATIAL_GENERATOR_CHARGE.get(), 0L);
        long newCharge;
        try {
            newCharge = Math.addExact(oldCharge, plan.producedChargeMilli());
        } catch (ArithmeticException overflow) {
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.spatial_generator.action_denied", "charge_overflow"), false);
            return;
        }
        generator.set(VeilboundDataComponents.SPATIAL_GENERATOR_FE.get(), (int) (storedFe - plan.consumedForgeEnergy()));
        generator.set(VeilboundDataComponents.SPATIAL_GENERATOR_CHARGE.get(), newCharge);
        if (!player.getAbilities().instabuild) feed.shrink(plan.acceptedItems());
    }

    private void expand(ServerPlayer player, dev.futurae.veilbound.domain.DomainState state, ItemStack generator, DomainAxis axis) {
        var b = state.bounds();
        var previousBounds = b;
        int x = b.sizeX(), y = b.sizeY(), z = b.sizeZ();
        switch (axis) {
            case X -> x++;
            case Y -> y++;
            case Z -> z++;
        }
        CondensedCharge charge = new CondensedCharge(
                generator.getOrDefault(VeilboundDataComponents.SPATIAL_GENERATOR_CHARGE.get(), 0L));
        var plan = SpatialGeneratorPlanner.plan(
                state, x, y, z, runtime.spatialGeneratorPolicy().policy().expansionCosts(), charge);
        var result = SpatialGeneratorPlanner.apply(state, plan, charge);
        if (result.applied()) {
            generator.set(VeilboundDataComponents.SPATIAL_GENERATOR_CHARGE.get(), result.remainingCharge().milliUnits());
            seedPreCoreResonantAccretion(player, previousBounds, state.bounds());
        }
    }


    /**
     * Pre-Core expansion exposes the first usable dimensional material. One Resonant accretion is
     * guaranteed in each newly admitted slice when an air cell is available. This deliberately
     * bootstraps the first Dimensional Fabricator without requiring post-Core Pylons or creative
     * acquisition, while remaining bounded by the Spatial Generator's 10-block pre-Core axes.
     */
    private void seedPreCoreResonantAccretion(ServerPlayer player,
            dev.futurae.veilbound.domain.DomainBounds previous,
            dev.futurae.veilbound.domain.DomainBounds current) {
        if (!(player.level() instanceof ServerLevel level)) return;
        java.util.ArrayList<BlockPos> candidates = new java.util.ArrayList<>();
        for (int x = current.minX(); x <= current.maxX(); x++) {
            for (int y = current.minY(); y <= current.maxY(); y++) {
                for (int z = current.minZ(); z <= current.maxZ(); z++) {
                    DomainPosition p = new DomainPosition(x, y, z);
                    if (previous.contains(p)) continue;
                    BlockPos bp = new BlockPos(x, y, z);
                    if (bp.equals(CORE_ORIGIN) || !level.getBlockState(bp).isAir()) continue;
                    candidates.add(bp);
                }
            }
        }
        if (candidates.isEmpty()) return;
        java.util.Collections.shuffle(candidates);
        level.setBlockAndUpdate(candidates.getFirst(), VeilboundBlocks.RESONANT_ORE.get().defaultBlockState());
    }

    private void awaken(ServerPlayer player, ItemStack generator) {
        var record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null || record.state().coreActive()) return;
        var state = record.state();
        SpatialGeneratorRuntimePolicy policy = runtime.spatialGeneratorPolicy().policy();
        CondensedCharge charge = new CondensedCharge(
                generator.getOrDefault(VeilboundDataComponents.SPATIAL_GENERATOR_CHARGE.get(), 0L));
        if (!state.hasInitialCoreSpace()) {
            player.displayClientMessage(Component.translatable("message.veilbound.spatial_generator.domain_too_small"), false);
            return;
        }
        if (!charge.canPayWhole(policy.awakeningChargeRequirement())) {
            player.displayClientMessage(Component.translatable("message.veilbound.spatial_generator.need_charge", policy.awakeningChargeRequirement()), false);
            return;
        }
        ItemStack catalyst = generator == player.getMainHandItem() ? player.getOffhandItem() : player.getMainHandItem();
        if (!catalyst.is(VeilboundItems.NUCLEUS_CATALYST.get())) {
            player.displayClientMessage(Component.translatable("message.veilbound.spatial_generator.need_catalyst"), false);
            return;
        }
        if (!withinAwakeningRange(player.blockPosition())) {
            player.displayClientMessage(Component.translatable("message.veilbound.spatial_generator.need_origin"), false);
            return;
        }
        if (!(player.level() instanceof ServerLevel level)) return;
        BlockState previous = level.getBlockState(CORE_ORIGIN);
        if (!previous.canBeReplaced()) {
            player.displayClientMessage(Component.translatable("message.veilbound.spatial_generator.origin_obstructed"), false);
            return;
        }

        if (!level.setBlockAndUpdate(CORE_ORIGIN, VeilboundBlocks.DIMENSIONAL_CORE.get().defaultBlockState())) return;
        try {
            state.awakenCore(DomainPosition.ORIGIN);
        } catch (RuntimeException failure) {
            level.setBlockAndUpdate(CORE_ORIGIN, previous);
            throw failure;
        }

        generator.set(VeilboundDataComponents.SPATIAL_GENERATOR_CHARGE.get(),
                charge.spendWhole(policy.awakeningChargeRequirement()).milliUnits());
        if (!player.getAbilities().instabuild) catalyst.shrink(1);

        // The Core now occupies the old starter arrival block. Stand the owner safely on top.
        player.teleportTo(level, 0.5D, 1.0D, 0.5D, Set.<Relative>of(), player.getYRot(), player.getXRot(), true);
        player.displayClientMessage(Component.translatable("message.veilbound.spatial_generator.core_awakened"), false);
    }

    public void sendSnapshot(ServerPlayer player, ItemStack generator) {
        if (generator == null || generator.isEmpty()) {
            PacketDistributor.sendToPlayer(player, denied("generator_not_held"));
            return;
        }
        var record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null) {
            PacketDistributor.sendToPlayer(player, denied("domain_not_found"));
            return;
        }
        if (!player.level().dimension().identifier().toString().equals(DomainIdentity.dimensionIdFor(player.getUUID()))) {
            PacketDistributor.sendToPlayer(player, denied("not_inside_own_domain"));
            return;
        }
        if (record.state().coreActive()) {
            PacketDistributor.sendToPlayer(player, denied("core_already_active"));
            return;
        }
        var b = record.state().bounds();
        var p = runtime.spatialGeneratorPolicy().policy();
        ItemStack catalyst = generator == player.getMainHandItem() ? player.getOffhandItem() : player.getMainHandItem();
        PacketDistributor.sendToPlayer(player, new SpatialGeneratorSnapshotPayload(
                true, "ok", b.sizeX(), b.sizeY(), b.sizeZ(),
                generator.getOrDefault(VeilboundDataComponents.SPATIAL_GENERATOR_FE.get(), 0),
                SpatialGeneratorRuntimePolicy.ITEM_FE_CAPACITY,
                generator.getOrDefault(VeilboundDataComponents.SPATIAL_GENERATOR_CHARGE.get(), 0L),
                p.condensedChargePerNewBlock(), p.awakeningChargeRequirement(),
                catalyst.is(VeilboundItems.NUCLEUS_CATALYST.get()),
                withinAwakeningRange(player.blockPosition()),
                player.level().getBlockState(CORE_ORIGIN).canBeReplaced()));
    }

    private static boolean withinAwakeningRange(BlockPos pos) {
        long distance = Math.abs((long) pos.getX() - CORE_ORIGIN.getX())
                + Math.abs((long) pos.getY() - CORE_ORIGIN.getY())
                + Math.abs((long) pos.getZ() - CORE_ORIGIN.getZ());
        return distance <= AWAKENING_MANHATTAN_RANGE;
    }

    private static ItemStack findGenerator(ServerPlayer player) {
        if (player.getMainHandItem().is(VeilboundItems.SPATIAL_GENERATOR.get())) return player.getMainHandItem();
        if (player.getOffhandItem().is(VeilboundItems.SPATIAL_GENERATOR.get())) return player.getOffhandItem();
        return ItemStack.EMPTY;
    }

    private static SpatialGeneratorSnapshotPayload denied(String reason) {
        return new SpatialGeneratorSnapshotPayload(false, reason, 0, 0, 0, 0,
                SpatialGeneratorRuntimePolicy.ITEM_FE_CAPACITY, 0, 0,
                SpatialGeneratorRuntimePolicy.SETTLED_AWAKENING_CHARGE, false, false, false);
    }

    private enum DomainAxis { X, Y, Z }
}
