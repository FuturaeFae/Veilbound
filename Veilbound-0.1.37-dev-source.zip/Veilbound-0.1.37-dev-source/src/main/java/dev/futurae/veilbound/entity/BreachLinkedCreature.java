package dev.futurae.veilbound.entity;

import java.util.Optional;
import java.util.UUID;

/** Marker contract for Veil creatures whose lifetime is owned by one Domain Breach. */
public interface BreachLinkedCreature {
    void veilboundBind(UUID domainOwnerId, UUID sourceBreachId);
    Optional<UUID> veilboundDomainOwnerId();
    Optional<UUID> veilboundSourceBreachId();
}
