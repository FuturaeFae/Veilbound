package dev.futurae.veilbound.law;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/** Data-driven registry facade. Hunger and Restoration are intentionally absent. */
public final class LawRegistry {
    private final Map<String, LawDefinition> laws = new LinkedHashMap<>();

    public void replaceAll(Collection<LawDefinition> definitions) {
        laws.clear();
        for (LawDefinition definition : definitions) laws.put(definition.id(), definition);
    }

    public Optional<LawDefinition> get(String id) { return Optional.ofNullable(laws.get(id)); }
    public Collection<LawDefinition> all() { return ListCopy.copyOf(laws.values()); }

    private static final class ListCopy {
        private static <T> Collection<T> copyOf(Collection<T> source) { return java.util.List.copyOf(source); }
    }
}
