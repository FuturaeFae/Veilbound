package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Bounded server-authoritative state for Archive, Orrery, and Environmental Zone management. */
public record MemoryManagementSnapshotPayload(
        View view,
        boolean allowed,
        String reason,
        boolean environmentalMastery,
        List<MemoryEntry> memories,
        List<ZoneEntry> zones) implements CustomPacketPayload {

    public static final int MAX_MEMORIES = 256;
    public static final int MAX_ZONES = 128;
    public static final int MAX_TAGS = 16;
    public enum View { ARCHIVE, ORRERY, ZONES }

    public static final Type<MemoryManagementSnapshotPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "memory_management_snapshot"));

    public static final StreamCodec<RegistryFriendlyByteBuf, MemoryManagementSnapshotPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override public MemoryManagementSnapshotPayload decode(RegistryFriendlyByteBuf buffer) {
            int viewOrdinal = buffer.readVarInt();
            View[] views = View.values();
            View view = viewOrdinal >= 0 && viewOrdinal < views.length ? views[viewOrdinal] : View.ARCHIVE;
            boolean allowed = buffer.readBoolean();
            String reason = buffer.readUtf(128);
            boolean mastery = buffer.readBoolean();
            int memoryCount = buffer.readVarInt();
            if (memoryCount < 0 || memoryCount > MAX_MEMORIES) throw new IllegalArgumentException("Invalid Memory snapshot size: " + memoryCount);
            List<MemoryEntry> memories = new ArrayList<>(memoryCount);
            for (int i = 0; i < memoryCount; i++) {
                String id = buffer.readUtf(128);
                String name = buffer.readUtf(128);
                boolean archived = buffer.readBoolean();
                boolean active = buffer.readBoolean();
                boolean prerequisitesMet = buffer.readBoolean();
                int tagCount = buffer.readVarInt();
                if (tagCount < 0 || tagCount > MAX_TAGS) throw new IllegalArgumentException("Invalid Memory tag count: " + tagCount);
                List<String> tags = new ArrayList<>(tagCount);
                for (int t = 0; t < tagCount; t++) tags.add(buffer.readUtf(64));
                String captureSummary = buffer.readUtf(512);
                memories.add(new MemoryEntry(id, name, archived, active, prerequisitesMet, tags, captureSummary));
            }
            int zoneCount = buffer.readVarInt();
            if (zoneCount < 0 || zoneCount > MAX_ZONES) throw new IllegalArgumentException("Invalid Environmental Zone snapshot size: " + zoneCount);
            List<ZoneEntry> zones = new ArrayList<>(zoneCount);
            for (int i = 0; i < zoneCount; i++) {
                zones.add(new ZoneEntry(
                        buffer.readUtf(64), buffer.readUtf(96), buffer.readUtf(128), buffer.readUtf(128),
                        buffer.readInt(), buffer.readInt(), buffer.readInt(),
                        buffer.readInt(), buffer.readInt(), buffer.readInt(),
                        buffer.readInt(), buffer.readBoolean()));
            }
            return new MemoryManagementSnapshotPayload(view, allowed, reason, mastery, memories, zones);
        }

        @Override public void encode(RegistryFriendlyByteBuf buffer, MemoryManagementSnapshotPayload payload) {
            buffer.writeVarInt(payload.view().ordinal());
            buffer.writeBoolean(payload.allowed());
            buffer.writeUtf(payload.reason(), 128);
            buffer.writeBoolean(payload.environmentalMastery());
            int memoryCount = Math.min(MAX_MEMORIES, payload.memories().size());
            buffer.writeVarInt(memoryCount);
            for (int i = 0; i < memoryCount; i++) {
                MemoryEntry memory = payload.memories().get(i);
                buffer.writeUtf(memory.id(), 128);
                buffer.writeUtf(memory.displayName(), 128);
                buffer.writeBoolean(memory.archived());
                buffer.writeBoolean(memory.active());
                buffer.writeBoolean(memory.prerequisitesMet());
                int tagCount = Math.min(MAX_TAGS, memory.tags().size());
                buffer.writeVarInt(tagCount);
                for (int t = 0; t < tagCount; t++) buffer.writeUtf(memory.tags().get(t), 64);
                buffer.writeUtf(memory.captureSummary(), 512);
            }
            int zoneCount = Math.min(MAX_ZONES, payload.zones().size());
            buffer.writeVarInt(zoneCount);
            for (int i = 0; i < zoneCount; i++) {
                ZoneEntry zone = payload.zones().get(i);
                buffer.writeUtf(zone.id(), 64);
                buffer.writeUtf(zone.name(), 96);
                buffer.writeUtf(zone.memoryId(), 128);
                buffer.writeUtf(zone.memoryDisplayName(), 128);
                buffer.writeInt(zone.minX()); buffer.writeInt(zone.minY()); buffer.writeInt(zone.minZ());
                buffer.writeInt(zone.maxX()); buffer.writeInt(zone.maxY()); buffer.writeInt(zone.maxZ());
                buffer.writeInt(zone.priority());
                buffer.writeBoolean(zone.blend());
            }
        }
    };

    public MemoryManagementSnapshotPayload {
        if (view == null) view = View.ARCHIVE;
        reason = reason == null ? "unknown" : reason;
        memories = List.copyOf(memories == null ? List.of() : memories);
        zones = List.copyOf(zones == null ? List.of() : zones);
    }

    public static MemoryManagementSnapshotPayload denied(View view, String reason) {
        return new MemoryManagementSnapshotPayload(view, false, reason, false, List.of(), List.of());
    }

    public record MemoryEntry(
            String id,
            String displayName,
            boolean archived,
            boolean active,
            boolean prerequisitesMet,
            List<String> tags,
            String captureSummary) {
        public MemoryEntry {
            id = id == null ? "" : id;
            displayName = displayName == null ? id : displayName;
            tags = List.copyOf(tags == null ? List.of() : tags);
            captureSummary = captureSummary == null ? "" : captureSummary;
        }
    }

    public record ZoneEntry(
            String id,
            String name,
            String memoryId,
            String memoryDisplayName,
            int minX, int minY, int minZ,
            int maxX, int maxY, int maxZ,
            int priority,
            boolean blend) {
        public ZoneEntry {
            id = id == null ? "" : id;
            name = name == null ? "" : name;
            memoryId = memoryId == null ? "" : memoryId;
            memoryDisplayName = memoryDisplayName == null ? memoryId : memoryDisplayName;
        }
    }

    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
