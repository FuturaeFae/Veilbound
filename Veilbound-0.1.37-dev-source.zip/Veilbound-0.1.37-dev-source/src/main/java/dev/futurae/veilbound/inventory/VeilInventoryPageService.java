package dev.futurae.veilbound.inventory;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** Deterministic bounded paging used by the wireless Veil Inventory screen. */
public final class VeilInventoryPageService {
    public static final int DEFAULT_PAGE_SIZE = 45;
    public static final int MAX_PAGE_SIZE = 90;

    public Page page(VeilInventory inventory, int requestedPage, int requestedPageSize) {
        Objects.requireNonNull(inventory, "inventory");
        int pageSize = Math.max(1, Math.min(MAX_PAGE_SIZE, requestedPageSize));
        List<Entry> entries = inventory.contents().entrySet().stream()
                .map(entry -> new Entry(entry.getKey(), entry.getValue()))
                .sorted(Comparator.comparing((Entry e) -> e.key().itemId())
                        .thenComparing(e -> e.key().componentData()))
                .toList();
        int pageCount = Math.max(1, (entries.size() + pageSize - 1) / pageSize);
        int page = Math.max(0, Math.min(requestedPage, pageCount - 1));
        int from = Math.min(entries.size(), page * pageSize);
        int to = Math.min(entries.size(), from + pageSize);
        return new Page(page, pageCount, pageSize, inventory.totalItems(), inventory.distinctTypes(),
                new ArrayList<>(entries.subList(from, to)));
    }

    public record Entry(VeilStackKey key, long count) {
        public Entry {
            Objects.requireNonNull(key, "key");
            if (count <= 0) throw new IllegalArgumentException("count must be > 0");
        }
    }

    public record Page(int page, int pageCount, int pageSize, long totalItems, int distinctTypes, List<Entry> entries) {
        public Page {
            entries = List.copyOf(entries);
        }
    }
}
