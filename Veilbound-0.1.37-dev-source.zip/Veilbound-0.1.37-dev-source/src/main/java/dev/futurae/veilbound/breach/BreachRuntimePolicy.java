package dev.futurae.veilbound.breach;

import dev.futurae.veilbound.stability.StabilityBand;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;

/** Reloadable fracture accumulation, breach cap, Stitcher costs, and intruder cadence. */
public final class BreachRuntimePolicy {
    private final EnumMap<StabilityBand, Double> fractureDeltaPerEvaluation;
    private final double fractureThreshold;
    private final double maximumFractureMeter;
    private final int maxOpenBreaches;
    private final double stitcherRange;
    private final EnumMap<BreachSeverity, Long> stitcherDimensionalEnergyCosts;
    private final BreachSpawnPolicy spawnPolicy;
    private final BreachHazardPolicy hazardPolicy;

    public BreachRuntimePolicy(
            Map<StabilityBand, Double> fractureDeltaPerEvaluation,
            double fractureThreshold,
            double maximumFractureMeter,
            int maxOpenBreaches,
            double stitcherRange,
            Map<BreachSeverity, Long> stitcherDimensionalEnergyCosts,
            BreachSpawnPolicy spawnPolicy) {
        this(fractureDeltaPerEvaluation, fractureThreshold, maximumFractureMeter, maxOpenBreaches,
                stitcherRange, stitcherDimensionalEnergyCosts, spawnPolicy, BreachHazardPolicy.developmentDefault());
    }

    public BreachRuntimePolicy(
            Map<StabilityBand, Double> fractureDeltaPerEvaluation,
            double fractureThreshold,
            double maximumFractureMeter,
            int maxOpenBreaches,
            double stitcherRange,
            Map<BreachSeverity, Long> stitcherDimensionalEnergyCosts,
            BreachSpawnPolicy spawnPolicy,
            BreachHazardPolicy hazardPolicy) {
        Objects.requireNonNull(fractureDeltaPerEvaluation, "fractureDeltaPerEvaluation");
        Objects.requireNonNull(stitcherDimensionalEnergyCosts, "stitcherDimensionalEnergyCosts");
        this.spawnPolicy = Objects.requireNonNull(spawnPolicy, "spawnPolicy");
        this.hazardPolicy = Objects.requireNonNull(hazardPolicy, "hazardPolicy");
        if (!(fractureThreshold > 0) || !Double.isFinite(fractureThreshold)
                || !Double.isFinite(maximumFractureMeter) || maximumFractureMeter < fractureThreshold) {
            throw new IllegalArgumentException("fracture meter bounds are invalid");
        }
        if (maxOpenBreaches < 1) throw new IllegalArgumentException("maxOpenBreaches must be >= 1");
        if (!(stitcherRange > 0) || !Double.isFinite(stitcherRange)) {
            throw new IllegalArgumentException("stitcherRange must be finite and > 0");
        }
        this.fractureDeltaPerEvaluation = new EnumMap<>(StabilityBand.class);
        for (StabilityBand band : StabilityBand.values()) {
            Double value = Objects.requireNonNull(fractureDeltaPerEvaluation.get(band), "Missing fracture delta for " + band);
            if (!Double.isFinite(value)) throw new IllegalArgumentException("Fracture deltas must be finite");
            this.fractureDeltaPerEvaluation.put(band, value);
        }
        this.stitcherDimensionalEnergyCosts = new EnumMap<>(BreachSeverity.class);
        for (BreachSeverity severity : BreachSeverity.values()) {
            Long cost = Objects.requireNonNull(stitcherDimensionalEnergyCosts.get(severity), "Missing Stitcher cost for " + severity);
            if (cost < 0) throw new IllegalArgumentException("Stitcher costs must be >= 0");
            this.stitcherDimensionalEnergyCosts.put(severity, cost);
        }
        this.fractureThreshold = fractureThreshold;
        this.maximumFractureMeter = maximumFractureMeter;
        this.maxOpenBreaches = maxOpenBreaches;
        this.stitcherRange = stitcherRange;
    }

    public double fractureDelta(StabilityBand band) { return fractureDeltaPerEvaluation.get(band); }
    public double fractureThreshold() { return fractureThreshold; }
    public double maximumFractureMeter() { return maximumFractureMeter; }
    public int maxOpenBreaches() { return maxOpenBreaches; }
    public double stitcherRange() { return stitcherRange; }
    public long stitcherDimensionalEnergyCost(BreachSeverity severity) { return stitcherDimensionalEnergyCosts.get(severity); }
    public Map<BreachSeverity, Long> stitcherDimensionalEnergyCosts() { return Map.copyOf(stitcherDimensionalEnergyCosts); }
    public Map<StabilityBand, Double> fractureDeltas() { return Map.copyOf(fractureDeltaPerEvaluation); }
    public BreachSpawnPolicy spawnPolicy() { return spawnPolicy; }
    public BreachHazardPolicy hazardPolicy() { return hazardPolicy; }
}
