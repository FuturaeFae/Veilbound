package dev.futurae.veilbound.client;

import dev.futurae.veilbound.memory.MemoryRuntimeSemantics;
import dev.futurae.veilbound.network.MemoryEnvironmentSnapshotPayload;
import java.util.List;
import java.util.Map;

/** Client-only projection of the server-authoritative Orrery environment for the current Domain. */
public final class MemoryClientEnvironmentState {
    private static final MemoryRuntimeSemantics SEMANTICS = new MemoryRuntimeSemantics();
    private static Snapshot snapshot = Snapshot.empty();

    private MemoryClientEnvironmentState() {}

    public static void accept(MemoryEnvironmentSnapshotPayload payload) {
        snapshot = payload.active()
                ? new Snapshot(
                        payload.dimensionId(), true, payload.domainDayTime(), payload.dayCycleAdvancing(),
                        payload.rememberedRainActive(), payload.memoryIds(), payload.environmentalProfile(),
                        SEMANTICS.snapshot(payload.environmentalProfile()))
                : new Snapshot(
                        payload.dimensionId(), false, payload.domainDayTime(), false, false,
                        List.of(), Map.of(), MemoryRuntimeSemantics.Snapshot.empty());
    }

    /** Locally interpolate between the server's bounded clock snapshots. */
    public static void tick() {
        if (snapshot.active() && snapshot.dayCycleAdvancing()) {
            snapshot = new Snapshot(
                    snapshot.dimensionId(), true, snapshot.domainDayTime() + 1L, true,
                    snapshot.rememberedRainActive(), snapshot.memoryIds(), snapshot.environmentalProfile(),
                    snapshot.semantics());
        }
    }

    public static Snapshot snapshot() { return snapshot; }

    public static void clear() { snapshot = Snapshot.empty(); }

    public static void clearIfDimensionChanged(String currentDimensionId) {
        if (!snapshot.dimensionId().isEmpty() && !snapshot.dimensionId().equals(currentDimensionId)) clear();
    }

    public record Snapshot(
            String dimensionId,
            boolean active,
            long domainDayTime,
            boolean dayCycleAdvancing,
            boolean rememberedRainActive,
            List<String> memoryIds,
            Map<String, String> environmentalProfile,
            MemoryRuntimeSemantics.Snapshot semantics) {
        public Snapshot {
            dimensionId = dimensionId == null ? "" : dimensionId;
            memoryIds = List.copyOf(memoryIds);
            environmentalProfile = Map.copyOf(environmentalProfile);
        }
        public static Snapshot empty() {
            return new Snapshot("", false, 0L, false, false, List.of(), Map.of(),
                    MemoryRuntimeSemantics.Snapshot.empty());
        }
    }
}
