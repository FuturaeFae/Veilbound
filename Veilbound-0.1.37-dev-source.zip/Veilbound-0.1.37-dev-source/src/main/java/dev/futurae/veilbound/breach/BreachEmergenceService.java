package dev.futurae.veilbound.breach;

import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import java.util.Objects;
import java.util.random.RandomGenerator;

/** Loader-neutral scheduler decision logic for creatures emerging from one open Breach. */
public final class BreachEmergenceService {
    private BreachEmergenceService() {}

    public static long initialDueTick(Breach breach, BreachSpawnPolicy policy, long nowTick, RandomGenerator random) {
        Objects.requireNonNull(breach, "breach");
        Objects.requireNonNull(policy, "policy");
        if (!breach.open()) return Long.MAX_VALUE;
        return safeAdd(nowTick, policy.nextDelayTicks(breach.severity(), random));
    }

    public static Decision evaluate(
            Breach breach,
            BreachSpawnPolicy policy,
            long nowTick,
            long dueTick,
            int localLinkedCreatureCount,
            RandomGenerator random) {
        Objects.requireNonNull(breach, "breach");
        Objects.requireNonNull(policy, "policy");
        Objects.requireNonNull(random, "random");
        if (localLinkedCreatureCount < 0) throw new IllegalArgumentException("localLinkedCreatureCount must be >= 0");
        if (!breach.open()) return Decision.inactive();
        if (nowTick < dueTick) return Decision.waiting(dueTick);

        long nextDue = safeAdd(nowTick, policy.nextDelayTicks(breach.severity(), random));
        if (localLinkedCreatureCount >= policy.localCreatureCap()) return Decision.capped(nextDue);
        return Decision.spawn(policy.selectCreature(breach.severity(), random), nextDue);
    }

    /**
     * Chooses a spawn point just inside the current Veil face, then clamps tangent jitter to usable Domain bounds.
     * Keeping this geometry loader-neutral makes boundary safety independently testable from NeoForge entity spawning.
     */
    public static DomainPosition emergencePosition(
            DomainBounds bounds,
            Breach breach,
            double emergenceRadius,
            RandomGenerator random) {
        Objects.requireNonNull(bounds, "bounds");
        Objects.requireNonNull(breach, "breach");
        Objects.requireNonNull(random, "random");
        if (!(emergenceRadius >= 0.0) || !Double.isFinite(emergenceRadius)) {
            throw new IllegalArgumentException("emergenceRadius must be finite and >= 0");
        }

        DomainPosition p = breach.position();
        int radius = Math.max(0, (int) Math.floor(emergenceRadius));
        int a = radius == 0 ? 0 : random.nextInt(-radius, radius + 1);
        int b = radius == 0 ? 0 : random.nextInt(-radius, radius + 1);
        int x = p.x();
        int y = p.y();
        int z = p.z();
        AxisDirection face = breach.veilFace();
        switch (face) {
            case POSITIVE_X -> { x--; y += a; z += b; }
            case NEGATIVE_X -> { x++; y += a; z += b; }
            case POSITIVE_Y -> { y--; x += a; z += b; }
            case NEGATIVE_Y -> { y++; x += a; z += b; }
            case POSITIVE_Z -> { z--; x += a; y += b; }
            case NEGATIVE_Z -> { z++; x += a; y += b; }
        }
        return new DomainPosition(
                clamp(x, bounds.minX(), bounds.maxX()),
                clamp(y, bounds.minY(), bounds.maxY()),
                clamp(z, bounds.minZ(), bounds.maxZ()));
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static long safeAdd(long tick, int delay) {
        if (tick > Long.MAX_VALUE - delay) return Long.MAX_VALUE;
        return tick + delay;
    }

    public record Decision(Status status, VoidCreatureType creatureType, long nextDueTick) {
        public enum Status { INACTIVE, WAITING, CAPPED, SPAWN }
        public static Decision inactive() { return new Decision(Status.INACTIVE, null, Long.MAX_VALUE); }
        public static Decision waiting(long dueTick) { return new Decision(Status.WAITING, null, dueTick); }
        public static Decision capped(long nextDue) { return new Decision(Status.CAPPED, null, nextDue); }
        public static Decision spawn(VoidCreatureType type, long nextDue) { return new Decision(Status.SPAWN, Objects.requireNonNull(type), nextDue); }
        public boolean shouldSpawn() { return status == Status.SPAWN; }
    }
}
