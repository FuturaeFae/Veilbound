package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.block.entity.AxiomMonolithBlockEntity;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.law.LawAxiomAttunementService;
import dev.futurae.veilbound.law.LawControlService;
import dev.futurae.veilbound.law.LawDefinition;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.Objects;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/** Server-authoritative physical Axiom-item -> permanent Monolith attunement -> empty-hand Law toggle. */
public final class NeoForgeAxiomMonolithCoordinator {
    private final VeilboundRuntime runtime;
    private final LawControlService controls = new LawControlService();

    public NeoForgeAxiomMonolithCoordinator(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    /**
     * A fresh Monolith consumes exactly one Law-specific Axiom item and becomes permanently
     * dedicated to that Law. Once attuned, empty-hand right-click toggles only that Law. There is
     * deliberately no sneak-cycle shortcut and no way to overwrite the stored attunement.
     */
    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.isCanceled() || !(event.getEntity() instanceof ServerPlayer player) || event.getLevel().isClientSide()) return;
        if (!event.getLevel().getBlockState(event.getPos()).is(VeilboundBlocks.AXIOM_MONOLITH.get())) return;
        if (!(event.getLevel().getBlockEntity(event.getPos()) instanceof AxiomMonolithBlockEntity monolith)) return;

        DomainRecord record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null || !record.identity().dimensionId().equals(event.getLevel().dimension().identifier().toString())) {
            message(player, "message.veilbound.law.not_owner_domain");
            consume(event, InteractionResult.FAIL);
            return;
        }
        if (monolith.ownerId() != null && !monolith.ownerId().equals(player.getUUID())) {
            message(player, "message.veilbound.law.not_owner_monolith");
            consume(event, InteractionResult.FAIL);
            return;
        }
        monolith.bindOwner(player.getUUID());

        if (!record.state().coreActive()) {
            message(player, "message.veilbound.law.core_inactive");
            consume(event, InteractionResult.FAIL);
            return;
        }

        if (monolith.lawId() == null) {
            if (event.getItemStack().isEmpty()) {
                message(player, "message.veilbound.law.requires_axiom");
                consume(event, InteractionResult.FAIL);
                return;
            }
            String heldId = BuiltInRegistries.ITEM.getKey(event.getItemStack().getItem()).toString();
            var attunement = LawAxiomAttunementService.plan(null, heldId, runtime.laws());
            if (!attunement.allowed()) {
                message(player, "message.veilbound.law." + attunement.reason());
                consume(event, InteractionResult.FAIL);
                return;
            }
            LawDefinition law = attunement.law();
            monolith.attune(law.id());
            if (!player.getAbilities().instabuild) event.getItemStack().shrink(attunement.itemsConsumed());
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.law.attuned", law.displayName()), false);
            preview(player, record, law);
            consume(event, InteractionResult.SUCCESS);
            return;
        }

        LawDefinition law = runtime.laws().get(monolith.lawId()).orElse(null);
        if (law == null) {
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.law.definition_missing", monolith.lawId()), true);
            consume(event, InteractionResult.FAIL);
            return;
        }
        if (!event.getItemStack().isEmpty()) {
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.law.empty_hand_toggle", law.displayName()), true);
            consume(event, InteractionResult.FAIL);
            return;
        }

        var result = controls.toggle(record.state(), runtime.laws(), law.id());
        if (!result.changed()) {
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.law.toggle_denied", law.displayName(), readableReason(result.reason())), true);
            consume(event, InteractionResult.FAIL);
            return;
        }
        boolean imposed = record.state().imposedLawIds().contains(law.id());
        player.displayClientMessage(Component.translatable(
                imposed ? "message.veilbound.law.imposed" : "message.veilbound.law.repealed",
                law.displayName()), true);
        consume(event, InteractionResult.SUCCESS);
    }

    private void preview(ServerPlayer player, DomainRecord record, LawDefinition law) {
        var inspection = controls.inspect(record.state(), runtime.laws(), law.id());
        Component status = Component.translatable(inspection.imposed()
                ? "message.veilbound.law.status_imposed"
                : "message.veilbound.law.status_available");
        player.displayClientMessage(Component.translatable(
                "message.veilbound.law.preview", law.displayName(), status, law.progressionWeight()), true);
        if (!inspection.missingPrerequisites().isEmpty()) {
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.law.missing_prerequisites",
                    String.join(", ", inspection.missingPrerequisites())), false);
        }
        if (!inspection.activeIncompatibilities().isEmpty()) {
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.law.active_incompatibilities",
                    String.join(", ", inspection.activeIncompatibilities())), false);
        }
    }

    private static String readableReason(String reason) {
        if (reason == null || reason.isBlank()) return "denied";
        return reason.replace('_', ' ');
    }

    private static void message(ServerPlayer player, String key) {
        player.displayClientMessage(Component.translatable(key), true);
    }

    private static void consume(PlayerInteractEvent.RightClickBlock event, InteractionResult result) {
        event.setCancellationResult(result);
        event.setCanceled(true);
    }
}
