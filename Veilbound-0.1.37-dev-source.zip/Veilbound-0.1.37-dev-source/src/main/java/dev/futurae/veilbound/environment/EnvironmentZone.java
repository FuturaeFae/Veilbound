package dev.futurae.veilbound.environment;

import dev.futurae.veilbound.domain.DomainBounds;
import java.util.Map;
import java.util.UUID;

/**
 * A stored Domain-region profile. Bounds are selected with temporary in-world
 * markers/holographic preview; no permanent anchor/corner blocks are required.
 *
 * <p>Priority/blending remain ordinary zone parameters so older persisted zones stay binary
 * compatible: {@code priority} defaults to 0 and {@code blend} defaults to false.</p>
 */
public record EnvironmentZone(UUID id, String name, DomainBounds bounds, String memoryProfileId, Map<String, String> parameters) {
    public EnvironmentZone {
        if (id == null) throw new IllegalArgumentException("id may not be null");
        if (name == null || name.isBlank()) throw new IllegalArgumentException("name may not be blank");
        if (bounds == null) throw new IllegalArgumentException("bounds may not be null");
        if (memoryProfileId == null || memoryProfileId.isBlank()) throw new IllegalArgumentException("memoryProfileId may not be blank");
        parameters = Map.copyOf(parameters == null ? Map.of() : parameters);
    }

    public int priority() {
        String raw = parameters.get("priority");
        if (raw == null || raw.isBlank()) return 0;
        try { return Integer.parseInt(raw.trim()); }
        catch (NumberFormatException ignored) { return 0; }
    }

    public boolean blendWithLowerPriority() {
        return Boolean.parseBoolean(parameters.getOrDefault("blend", "false"));
    }
}
