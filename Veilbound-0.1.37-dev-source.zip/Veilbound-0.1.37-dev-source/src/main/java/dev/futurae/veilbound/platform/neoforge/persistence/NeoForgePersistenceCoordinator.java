package dev.futurae.veilbound.platform.neoforge.persistence;

import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.Objects;
import net.neoforged.neoforge.event.server.ServerStartedEvent;

/** Binds the singleton server runtime to Minecraft's global SavedData once the server is ready. */
public final class NeoForgePersistenceCoordinator {
    private final VeilboundRuntime runtime;

    public NeoForgePersistenceCoordinator(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    public void onServerStarted(ServerStartedEvent event) {
        VeilboundServerData.attach(event.getServer(), runtime);
        VeilboundMatterOverridesData.attach(event.getServer(), runtime.matter(), runtime.matterReload());
    }
}
