package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Empty client -> server signal meaning the player pressed Veilbound's Domain travel key. */
public record DomainTravelRequestPayload() implements CustomPacketPayload {
    public static final DomainTravelRequestPayload INSTANCE = new DomainTravelRequestPayload();
    public static final Type<DomainTravelRequestPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "domain_travel"));
    public static final StreamCodec<RegistryFriendlyByteBuf, DomainTravelRequestPayload> STREAM_CODEC =
            StreamCodec.unit(INSTANCE);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
