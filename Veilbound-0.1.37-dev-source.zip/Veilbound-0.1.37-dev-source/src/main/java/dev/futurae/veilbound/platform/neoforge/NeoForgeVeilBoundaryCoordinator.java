package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.BoundaryPylonBindingService;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.platform.neoforge.world.NeoForgeDomainLevelService;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.level.PistonEvent;
import net.neoforged.neoforge.event.level.block.BreakBlockEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Server-side hard boundary for personal Domains. Usable-space bounds are authoritative: ordinary
 * blocks, entities, fluids, and piston movement may not cross them. Boundary Pylons are the sole
 * block-placement exception and live one cell into the Veil on their assigned moving face.
 */
public final class NeoForgeVeilBoundaryCoordinator {
    private static final int PISTON_MAX_PUSH = 12;
    private static final double EPSILON = 0.01;

    private final VeilboundRuntime runtime;
    private final NeoForgeDomainLevelService domainLevels;

    public NeoForgeVeilBoundaryCoordinator(VeilboundRuntime runtime, NeoForgeDomainLevelService domainLevels) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        this.domainLevels = Objects.requireNonNull(domainLevels, "domainLevels");
    }

    public void onPlaceBlock(BlockEvent.EntityPlaceEvent event) {
        if (event.isCanceled()) return;
        DomainRecord record = recordForLevel(event.getLevel());
        if (record == null) return;
        DomainPosition pos = position(event.getPos());
        if (record.state().bounds().contains(pos)) return;

        // The only legal block in the impassable Veil is the owner's Pylon at its exact face slot.
        if (event.getPlacedBlock().is(VeilboundBlocks.BOUNDARY_PYLON.get())
                && event.getEntity() instanceof ServerPlayer player
                && player.getUUID().equals(record.ownerId())
                && BoundaryPylonBindingService.directionForExpectedPosition(record.state(), pos).isPresent()) {
            return;
        }
        event.setCanceled(true);
    }

    public void onBreakBlock(BreakBlockEvent event) {
        if (event.isCanceled()) return;
        DomainRecord record = recordForLevel(event.getLevel());
        if (record == null) return;
        DomainPosition pos = position(event.getPos());
        if (record.state().bounds().contains(pos)) return;

        boolean ownerBoundPylon = event.getPlayer() instanceof ServerPlayer player
                && player.getUUID().equals(record.ownerId())
                && event.getState().is(VeilboundBlocks.BOUNDARY_PYLON.get())
                && record.state().pylons().values().stream()
                    .anyMatch(pylon -> pylon.bound() && pos.equals(pylon.blockPosition()));
        if (!ownerBoundPylon) event.setCanceled(true);
    }

    /** Prevent fluid-generated blocks (cobble/obsidian/fire variants) from crossing the usable edge. */
    public void onFluidPlaceBlock(BlockEvent.FluidPlaceBlockEvent event) {
        if (event.isCanceled()) return;
        DomainRecord record = recordForLevel(event.getLevel());
        if (record != null && !record.state().bounds().contains(position(event.getPos()))) event.setCanceled(true);
    }

    /**
     * Veilbound does not attempt to make pistons Veil-aware. Conservatively stop any piston close
     * enough to a face that its vanilla 12-block movement could cross the boundary.
     */
    public void onPistonPre(PistonEvent.Pre event) {
        if (event.isCanceled()) return;
        DomainRecord record = recordForLevel(event.getLevel());
        if (record == null) return;
        BlockPos p = event.getPos();
        DomainBounds b = record.state().bounds();
        if (p.getX() - b.minX() <= PISTON_MAX_PUSH || b.maxX() - p.getX() <= PISTON_MAX_PUSH
                || p.getY() - b.minY() <= PISTON_MAX_PUSH || b.maxY() - p.getY() <= PISTON_MAX_PUSH
                || p.getZ() - b.minZ() <= PISTON_MAX_PUSH || b.maxZ() - p.getZ() <= PISTON_MAX_PUSH) {
            event.setCanceled(true);
        }
    }

    /** Clamp every live entity to the usable volume. This also covers guests and Veil creatures. */
    public void onServerTick(ServerTickEvent.Post event) {
        for (DomainRecord record : runtime.domains().records()) {
            ServerLevel level = domainLevels.liveLevel(event.getServer(), record.ownerId()).orElse(null);
            if (level == null) continue;
            DomainBounds b = record.state().bounds();
            for (Entity entity : level.getAllEntities()) {
                if (entity.isRemoved() || entity.isSpectator()) continue;
                clampEntity(entity, b);
            }
        }
    }

    private static void clampEntity(Entity entity, DomainBounds b) {
        double halfWidth = Math.max(0.0, entity.getBbWidth() * 0.5);
        double height = Math.max(0.0, entity.getBbHeight());
        double minX = b.minX() + halfWidth + EPSILON;
        double maxX = b.maxX() + 1.0 - halfWidth - EPSILON;
        double minY = b.minY() + EPSILON;
        double maxY = b.maxY() + 1.0 - height - EPSILON;
        double minZ = b.minZ() + halfWidth + EPSILON;
        double maxZ = b.maxZ() + 1.0 - halfWidth - EPSILON;
        if (minX > maxX) { minX = maxX = b.minX() + 0.5; }
        if (minY > maxY) { minY = maxY = b.minY() + EPSILON; }
        if (minZ > maxZ) { minZ = maxZ = b.minZ() + 0.5; }
        double x = clamp(entity.getX(), minX, maxX);
        double y = clamp(entity.getY(), minY, maxY);
        double z = clamp(entity.getZ(), minZ, maxZ);
        if (x == entity.getX() && y == entity.getY() && z == entity.getZ()) return;
        entity.setPos(x, y, z);
        entity.setDeltaMovement(0.0, 0.0, 0.0);
        entity.resetFallDistance();
    }

    private DomainRecord recordForLevel(LevelAccessor accessor) {
        if (!(accessor instanceof Level level)) return null;
        return recordForDimension(level.dimension().identifier().toString());
    }

    private DomainRecord recordForDimension(String dimensionId) {
        return runtime.domains().records().stream()
                .filter(record -> record.identity().dimensionId().equals(dimensionId))
                .findFirst().orElse(null);
    }

    private static DomainPosition position(BlockPos pos) { return new DomainPosition(pos.getX(), pos.getY(), pos.getZ()); }
    private static double clamp(double value, double min, double max) { return Math.max(min, Math.min(max, value)); }
}
