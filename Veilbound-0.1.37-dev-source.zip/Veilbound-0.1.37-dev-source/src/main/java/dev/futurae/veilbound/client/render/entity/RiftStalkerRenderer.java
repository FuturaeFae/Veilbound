package dev.futurae.veilbound.client.render.entity;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.client.renderer.entity.EndermanRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.EndermanRenderState;
import net.minecraft.resources.Identifier;

/** Uses Enderman movement/proportions but never the vanilla Enderman texture. */
public final class RiftStalkerRenderer extends EndermanRenderer {
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "textures/entity/breach/rift_stalker.png");
    public RiftStalkerRenderer(EntityRendererProvider.Context context) { super(context); }
    @Override public Identifier getTextureLocation(EndermanRenderState state) { return TEXTURE; }
}
