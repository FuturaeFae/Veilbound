package dev.futurae.veilbound.platform.neoforge;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.energy.TransductionPolicy;
import dev.futurae.veilbound.energy.TransductionPolicyRegistry;
import dev.futurae.veilbound.energy.TransductionRuntimePolicy;
import java.io.Reader;
import java.util.Objects;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

/** Loads the single data/veilbound/veilbound/balance/dimensional_transducer.json policy. */
public final class NeoForgeTransductionPolicyReloadListener extends SimplePreparableReloadListener<TransductionRuntimePolicy> {
    public static final Identifier LISTENER_ID = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "transduction_policy");
    private static final Identifier RESOURCE_ID = Identifier.fromNamespaceAndPath(
            Veilbound.MOD_ID, "veilbound/balance/dimensional_transducer.json");
    private final Gson gson = new Gson();
    private final TransductionPolicyRegistry registry;

    public NeoForgeTransductionPolicyReloadListener(TransductionPolicyRegistry registry) {
        this.registry = Objects.requireNonNull(registry, "registry");
    }

    @Override
    protected TransductionRuntimePolicy prepare(ResourceManager manager, ProfilerFiller profiler) {
        return manager.getResource(RESOURCE_ID).map(resource -> {
            try (Reader reader = resource.openAsReader()) {
                JsonElement parsed = gson.fromJson(reader, JsonElement.class);
                if (parsed == null || !parsed.isJsonObject()) throw new IllegalArgumentException("root must be an object");
                JsonObject o = parsed.getAsJsonObject();
                TransductionRuntimePolicy fallback = TransductionRuntimePolicy.DEVELOPMENT_DEFAULT;
                int cycleTicks = integer(o, "cycle_ticks", fallback.cycleTicks());
                int capacity = integer(o, "forge_energy_capacity", fallback.forgeEnergyCapacity());
                int maxInput = integer(o, "max_forge_energy_input", fallback.maxForgeEnergyInput());
                long matterCapacity = longValue(o, "matter_capacity", fallback.matterCapacity());
                long fePerMatter = longValue(o, "forge_energy_per_matter", fallback.conversion().forgeEnergyPerMatter());
                long matterPerDe = o.has("matter_per_dimensional_energy")
                        ? o.get("matter_per_dimensional_energy").getAsLong()
                        : fallback.conversion().matterPerDimensionalEnergy();
                return new TransductionRuntimePolicy(
                        cycleTicks, capacity, maxInput, matterCapacity, new TransductionPolicy(fePerMatter, matterPerDe));
            } catch (Exception ex) {
                Veilbound.LOGGER.warn("Invalid {}: {}; using development default", RESOURCE_ID, ex.getMessage());
                return TransductionRuntimePolicy.DEVELOPMENT_DEFAULT;
            }
        }).orElse(TransductionRuntimePolicy.DEVELOPMENT_DEFAULT);
    }

    @Override
    protected void apply(TransductionRuntimePolicy policy, ResourceManager manager, ProfilerFiller profiler) {
        registry.replace(policy);
        Veilbound.LOGGER.info(
                "Loaded Dimensional Transducer policy: every {} ticks, FE buffer {}, max input {}, Matter buffer {}, {} FE/Matter and {} Matter/DE",
                policy.cycleTicks(), policy.forgeEnergyCapacity(), policy.maxForgeEnergyInput(), policy.matterCapacity(),
                policy.conversion().forgeEnergyPerMatter(), policy.conversion().matterPerDimensionalEnergy());
    }

    private static int integer(JsonObject o, String key, int fallback) {
        return o.has(key) ? o.get(key).getAsInt() : fallback;
    }
    private static long longValue(JsonObject o, String key, long fallback) {
        return o.has(key) ? o.get(key).getAsLong() : fallback;
    }
}
