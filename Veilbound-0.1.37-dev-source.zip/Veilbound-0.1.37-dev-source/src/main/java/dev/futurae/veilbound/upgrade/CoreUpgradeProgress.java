package dev.futurae.veilbound.upgrade;

import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.domain.DomainState;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/** Legacy in-memory helper retained for tests/add-ons; authoritative gameplay uses CoreTierUpgradeService. */
public final class CoreUpgradeProgress {
    private final CoreUpgradeDefinition definition;
    private final Map<String, Long> fed = new LinkedHashMap<>();

    public CoreUpgradeProgress(CoreUpgradeDefinition definition) {
        this.definition = Objects.requireNonNull(definition, "definition");
    }

    public CoreUpgradeDefinition definition() { return definition; }
    public Map<String, Long> fed() { return Map.copyOf(fed); }

    /** Returns how many of the offered items were accepted. Excess is not consumed. */
    public long feed(String itemId, long offeredCount) {
        if (offeredCount <= 0) return 0;
        UpgradeIngredient requirement = definition.ingredients().stream()
                .filter(ingredient -> ingredient.itemId().equals(itemId))
                .findFirst()
                .orElse(null);
        if (requirement == null) return 0;
        long already = fed.getOrDefault(itemId, 0L);
        long remaining = Math.max(0L, requirement.count() - already);
        long accepted = Math.min(remaining, offeredCount);
        if (accepted > 0) fed.put(itemId, already + accepted);
        return accepted;
    }

    public boolean complete() {
        for (UpgradeIngredient requirement : definition.ingredients()) {
            if (fed.getOrDefault(requirement.itemId(), 0L) < requirement.count()) return false;
        }
        return true;
    }

    public UpgradeResult finalizeUpgrade(DomainState state) {
        Objects.requireNonNull(state, "state");
        if (!state.coreActive()) return UpgradeResult.denied("core_inactive");
        if (state.coreTier() != definition.from()) return UpgradeResult.denied("wrong_core_tier");
        if (!complete()) return UpgradeResult.denied("requirements_incomplete");
        long energyCost = definition.to().upgradeCostFromPrevious();
        if (!state.consumeDimensionalEnergy(energyCost)) return UpgradeResult.denied("insufficient_dimensional_energy");
        CoreTier previous = state.coreTier();
        state.setCoreTier(definition.to());
        return UpgradeResult.allowed(previous, definition.to());
    }

    public record UpgradeResult(boolean upgraded, CoreTier from, CoreTier to, String reason) {
        public static UpgradeResult denied(String reason) { return new UpgradeResult(false, null, null, reason); }
        public static UpgradeResult allowed(CoreTier from, CoreTier to) { return new UpgradeResult(true, from, to, "ok"); }
    }
}
