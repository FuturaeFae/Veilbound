package dev.futurae.veilbound.client.screen;

import dev.futurae.veilbound.network.OntologyMachineActionPayload;
import dev.futurae.veilbound.network.OntologyMachineSnapshotPayload;
import dev.futurae.veilbound.ontology.OntologicalMode;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;

/** Unified telemetry/control surface for Veilbound's non-cliche boundary-observation industry. */
public final class OntologyMachineScreen extends Screen {
    private static final int WIDTH=420, HEIGHT=246;
    private OntologyMachineSnapshotPayload snapshot;
    private int autoRefreshTicks;

    public OntologyMachineScreen(OntologyMachineSnapshotPayload snapshot){
        super(Component.translatable("screen.veilbound.ontology.title")); this.snapshot=snapshot;
    }

    public void acceptSnapshot(OntologyMachineSnapshotPayload next){ snapshot=next; if(minecraft!=null){ clearWidgets(); init(); } }

    @Override protected void init(){
        super.init(); if(!snapshot.allowed())return;
        int left=width/2-WIDTH/2, top=height/2-HEIGHT/2;
        addRenderableWidget(Button.builder(Component.translatable("screen.veilbound.ontology.refresh"), b->send(OntologyMachineActionPayload.Action.REFRESH,""))
                .bounds(left+WIDTH-86,top+8,70,20).build());
        if(snapshot.harvester()){
            int y=top+201, x=left+16;
            for(OntologicalMode mode:OntologicalMode.values()){
                Button button=Button.builder(Component.translatable("screen.veilbound.ontology.mode."+mode.name().toLowerCase(java.util.Locale.ROOT)),
                        b->send(OntologyMachineActionPayload.Action.SET_MODE,mode.name()))
                        .bounds(x,y,88,20).build();
                button.active=!mode.name().equals(snapshot.mode()); addRenderableWidget(button); x+=100;
            }
        }
    }

    @Override public void tick(){
        super.tick();
        if(snapshot.allowed() && ++autoRefreshTicks>=20){ autoRefreshTicks=0; send(OntologyMachineActionPayload.Action.REFRESH,""); }
    }

    private void send(OntologyMachineActionPayload.Action action,String value){
        ClientPacketDistributor.sendToServer(new OntologyMachineActionPayload(action,snapshot.x(),snapshot.y(),snapshot.z(),value));
    }

    @Override public void extractBackground(GuiGraphicsExtractor graphics,int mouseX,int mouseY,float partialTick){ extractTransparentBackground(graphics); }

    @Override public void extractRenderState(GuiGraphicsExtractor g,int mouseX,int mouseY,float partialTick){
        super.extractRenderState(g,mouseX,mouseY,partialTick);
        int left=width/2-WIDTH/2, top=height/2-HEIGHT/2;
        g.fill(left,top,left+WIDTH,top+HEIGHT,0xF00C1018);
        g.fill(left,top,left+WIDTH,top+36,0xF01A1830);
        g.fill(left,top+35,left+WIDTH,top+36,0xFF8E6CE8);
        Component heading=snapshot.harvester()?Component.translatable("screen.veilbound.ontology.harvester"):snapshot.compiler()?Component.translatable("screen.veilbound.ontology.compiler"):title;
        g.text(font,heading,left+16,top+13,0xFFF4EEFF,false);
        if(!snapshot.allowed()){ g.centeredText(font,Component.translatable("screen.veilbound.ontology.denied",snapshot.reason()),width/2,top+110,0xFFFF8585); return; }
        bar(g,left+16,top+51,388,16,snapshot.storedPotential(),snapshot.potentialCapacity(),0xFF7654D8,
                Component.translatable("screen.veilbound.ontology.potential",format(snapshot.storedPotential()),format(snapshot.potentialCapacity())));
        if(snapshot.harvester()) renderHarvester(g,left,top); else renderCompiler(g,left,top);
    }

    private void renderHarvester(GuiGraphicsExtractor g,int left,int top){
        int y=top+80;
        line(g,left+16,y,Component.translatable("screen.veilbound.ontology.current_mode",snapshot.mode()),0xFFE3D5FF); y+=16;
        line(g,left+16,y,Component.translatable("screen.veilbound.ontology.vanes",snapshot.contributingVanes(),snapshot.maxVanes()),0xFFC9D8FF); y+=16;
        line(g,left+16,y,Component.translatable("screen.veilbound.ontology.production",format(snapshot.lastProduced()),format(snapshot.potentialPerVane())),0xFF9FE7D2); y+=16;
        line(g,left+16,y,Component.translatable("screen.veilbound.ontology.stability_load",two(snapshot.stabilityLoad())),0xFFFFC98E); y+=16;
        line(g,left+16,y,Component.translatable("screen.veilbound.ontology.instability",two(snapshot.fractureMeter()),snapshot.openBreaches(),two(snapshot.instabilityMultiplier())),0xFFFFA3C7); y+=16;
        line(g,left+16,y,Component.translatable("screen.veilbound.ontology.explanation"),0xFFB9B0C7);
    }

    private void renderCompiler(GuiGraphicsExtractor g,int left,int top){
        int y=top+80;
        bar(g,left+16,y,388,14,snapshot.coreDimensionalEnergy(),snapshot.coreDimensionalEnergyCapacity(),0xFF4F9BD8,
                Component.translatable("screen.veilbound.ontology.core_de",format(snapshot.coreDimensionalEnergy()),format(snapshot.coreDimensionalEnergyCapacity()))); y+=27;
        line(g,left+16,y,Component.translatable("screen.veilbound.ontology.compiler_status",snapshot.compilerStatus()),0xFFE3D5FF); y+=16;
        line(g,left+16,y,Component.translatable("screen.veilbound.ontology.compiler_rate",format(snapshot.matterPerPotential()),format(snapshot.dimensionalEnergyPerPotential())),0xFF9FE7D2); y+=16;
        line(g,left+16,y,Component.translatable("screen.veilbound.ontology.compiler_cycle",format(snapshot.maxPotentialPerCycle())),0xFFC9D8FF); y+=16;
        line(g,left+16,y,Component.translatable("screen.veilbound.ontology.matter_reserve",format(snapshot.storedMatter())),0xFFE3B6FF); y+=16;
        line(g,left+16,y,Component.translatable("screen.veilbound.ontology.compiler_explanation"),0xFFB9B0C7);
    }

    private void bar(GuiGraphicsExtractor g,int x,int y,int w,int h,long value,long max,int fill,Component label){
        g.fill(x,y,x+w,y+h,0xFF211F2A); int filled=max<=0?0:(int)Math.min(w,Math.round((double)value/max*w)); if(filled>0)g.fill(x,y,x+filled,y+h,fill);
        g.centeredText(font,label,x+w/2,y+4,0xFFFFFFFF);
    }
    private void line(GuiGraphicsExtractor g,int x,int y,Component c,int color){ g.text(font,c,x,y,color,false); }
    private static String format(long value){ return String.format(java.util.Locale.ROOT,"%,d",value); }
    private static String two(double value){ return String.format(java.util.Locale.ROOT,"%.2f",value); }
}
