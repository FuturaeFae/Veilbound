package dev.futurae.veilbound.platform.neoforge.network;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.client.VeilboundClient;
import dev.futurae.veilbound.network.DomainTravelRequestPayload;
import dev.futurae.veilbound.network.EngineeringStationActionPayload;
import dev.futurae.veilbound.network.EngineeringStationSnapshotPayload;
import dev.futurae.veilbound.network.OpenEngineeringCodexPayload;
import dev.futurae.veilbound.network.OntologyMachineActionPayload;
import dev.futurae.veilbound.network.OntologyMachineSnapshotPayload;
import dev.futurae.veilbound.network.DomainControlsActionPayload;
import dev.futurae.veilbound.network.DomainControlsSnapshotPayload;
import dev.futurae.veilbound.network.MemoryEnvironmentSnapshotPayload;
import dev.futurae.veilbound.network.MemoryManagementActionPayload;
import dev.futurae.veilbound.network.MemoryManagementSnapshotPayload;
import dev.futurae.veilbound.network.SpatialGeneratorActionPayload;
import dev.futurae.veilbound.network.SpatialGeneratorSnapshotPayload;
import dev.futurae.veilbound.network.VeilCraftingPreviewPayload;
import dev.futurae.veilbound.network.VeilCraftablesRequestPayload;
import dev.futurae.veilbound.network.VeilCraftablesSnapshotPayload;
import dev.futurae.veilbound.network.VeilCraftingRequestPayload;
import dev.futurae.veilbound.network.VeilInventoryActionPayload;
import dev.futurae.veilbound.network.VeilInventorySnapshotPayload;
import dev.futurae.veilbound.platform.neoforge.inventory.NeoForgeVeilCraftingController;
import dev.futurae.veilbound.platform.neoforge.inventory.NeoForgeVeilCraftablesController;
import dev.futurae.veilbound.platform.neoforge.inventory.NeoForgeVeilInventoryController;
import dev.futurae.veilbound.platform.neoforge.NeoForgeMemoryManagementController;
import dev.futurae.veilbound.platform.neoforge.NeoForgeDomainControlsController;
import dev.futurae.veilbound.platform.neoforge.travel.NeoForgeDomainTravelExecutor;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/** Registers Veilbound's server-authoritative play payloads. */
public final class NeoForgeNetworking {
    private static final String PROTOCOL = "14";
    private static final NeoForgeVeilInventoryController VEIL_INVENTORY =
            new NeoForgeVeilInventoryController(Veilbound.runtime());
    private static final NeoForgeVeilCraftingController VEIL_CRAFTING =
            new NeoForgeVeilCraftingController(Veilbound.runtime(), VEIL_INVENTORY);
    private static final NeoForgeVeilCraftablesController VEIL_CRAFTABLES =
            new NeoForgeVeilCraftablesController(Veilbound.runtime());
    private static final NeoForgeMemoryManagementController MEMORY_MANAGEMENT =
            new NeoForgeMemoryManagementController(Veilbound.runtime());
    private static final NeoForgeDomainControlsController DOMAIN_CONTROLS =
            new NeoForgeDomainControlsController(Veilbound.runtime());
    private static final dev.futurae.veilbound.platform.neoforge.NeoForgeEngineeringStationController ENGINEERING =
            new dev.futurae.veilbound.platform.neoforge.NeoForgeEngineeringStationController(Veilbound.runtime());

    private NeoForgeNetworking() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(PROTOCOL);
        registrar.playToServer(
                DomainControlsActionPayload.TYPE,
                DomainControlsActionPayload.STREAM_CODEC,
                NeoForgeNetworking::handleDomainControlsAction);
        registrar.playToClient(
                DomainControlsSnapshotPayload.TYPE,
                DomainControlsSnapshotPayload.STREAM_CODEC,
                NeoForgeNetworking::handleDomainControlsSnapshot);
        registrar.playToServer(
                EngineeringStationActionPayload.TYPE,
                EngineeringStationActionPayload.STREAM_CODEC,
                NeoForgeNetworking::handleEngineeringStationAction);
        registrar.playToClient(
                EngineeringStationSnapshotPayload.TYPE,
                EngineeringStationSnapshotPayload.STREAM_CODEC,
                NeoForgeNetworking::handleEngineeringStationSnapshot);
        registrar.playToClient(
                OpenEngineeringCodexPayload.TYPE,
                OpenEngineeringCodexPayload.STREAM_CODEC,
                NeoForgeNetworking::handleOpenEngineeringCodex);
        registrar.playToServer(
                OntologyMachineActionPayload.TYPE,
                OntologyMachineActionPayload.STREAM_CODEC,
                NeoForgeNetworking::handleOntologyMachineAction);
        registrar.playToClient(
                OntologyMachineSnapshotPayload.TYPE,
                OntologyMachineSnapshotPayload.STREAM_CODEC,
                NeoForgeNetworking::handleOntologyMachineSnapshot);
        registrar.playToServer(
                DomainTravelRequestPayload.TYPE,
                DomainTravelRequestPayload.STREAM_CODEC,
                NeoForgeNetworking::handleDomainTravel);
        registrar.playToClient(
                MemoryEnvironmentSnapshotPayload.TYPE,
                MemoryEnvironmentSnapshotPayload.STREAM_CODEC,
                NeoForgeNetworking::handleMemoryEnvironmentSnapshot);
        registrar.playToServer(
                MemoryManagementActionPayload.TYPE,
                MemoryManagementActionPayload.STREAM_CODEC,
                NeoForgeNetworking::handleMemoryManagementAction);
        registrar.playToClient(
                MemoryManagementSnapshotPayload.TYPE,
                MemoryManagementSnapshotPayload.STREAM_CODEC,
                NeoForgeNetworking::handleMemoryManagementSnapshot);
        registrar.playToServer(
                VeilInventoryActionPayload.TYPE,
                VeilInventoryActionPayload.STREAM_CODEC,
                NeoForgeNetworking::handleVeilInventoryAction);
        registrar.playToClient(
                VeilInventorySnapshotPayload.TYPE,
                VeilInventorySnapshotPayload.STREAM_CODEC,
                NeoForgeNetworking::handleVeilInventorySnapshot);
        registrar.playToServer(
                VeilCraftingRequestPayload.TYPE,
                VeilCraftingRequestPayload.STREAM_CODEC,
                NeoForgeNetworking::handleVeilCraftingRequest);
        registrar.playToClient(
                VeilCraftingPreviewPayload.TYPE,
                VeilCraftingPreviewPayload.STREAM_CODEC,
                NeoForgeNetworking::handleVeilCraftingPreview);
        registrar.playToServer(
                VeilCraftablesRequestPayload.TYPE,
                VeilCraftablesRequestPayload.STREAM_CODEC,
                NeoForgeNetworking::handleVeilCraftablesRequest);
        registrar.playToClient(
                VeilCraftablesSnapshotPayload.TYPE,
                VeilCraftablesSnapshotPayload.STREAM_CODEC,
                NeoForgeNetworking::handleVeilCraftablesSnapshot);
        registrar.playToServer(
                SpatialGeneratorActionPayload.TYPE,
                SpatialGeneratorActionPayload.STREAM_CODEC,
                NeoForgeNetworking::handleSpatialGeneratorAction);
        registrar.playToClient(
                SpatialGeneratorSnapshotPayload.TYPE,
                SpatialGeneratorSnapshotPayload.STREAM_CODEC,
                NeoForgeNetworking::handleSpatialGeneratorSnapshot);
    }

    private static void handleDomainControlsAction(DomainControlsActionPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        context.enqueueWork(() -> DOMAIN_CONTROLS.handle(player, payload));
    }

    private static void handleDomainControlsSnapshot(DomainControlsSnapshotPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> VeilboundClient.handleDomainControlsSnapshot(payload));
    }

    private static void handleEngineeringStationAction(EngineeringStationActionPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        context.enqueueWork(() -> ENGINEERING.handle(player, payload));
    }

    private static void handleEngineeringStationSnapshot(EngineeringStationSnapshotPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> VeilboundClient.handleEngineeringStationSnapshot(payload));
    }

    private static void handleOpenEngineeringCodex(OpenEngineeringCodexPayload payload, IPayloadContext context) {
        context.enqueueWork(VeilboundClient::openEngineeringCodex);
    }

    private static void handleOntologyMachineAction(OntologyMachineActionPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        context.enqueueWork(() -> ENGINEERING.handle(player, payload));
    }

    private static void handleOntologyMachineSnapshot(OntologyMachineSnapshotPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> VeilboundClient.handleOntologyMachineSnapshot(payload));
    }

    private static void handleDomainTravel(DomainTravelRequestPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        context.enqueueWork(() -> {
            NeoForgeDomainTravelExecutor.TravelResult result =
                    Veilbound.domainTravel().handleDomainKey(player.level().getServer(), player);
            if (!result.success()) {
                if ("domain_not_bound".equals(result.reason())) {
                    player.displayClientMessage(Component.translatable("message.veilbound.travel.domain_not_bound"), true);
                }
                Veilbound.LOGGER.debug(
                        "Rejected Domain-key travel request from {}: {}",
                        player.getUUID(), result.reason());
            }
        });
    }


    private static void handleMemoryEnvironmentSnapshot(MemoryEnvironmentSnapshotPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> VeilboundClient.handleMemoryEnvironmentSnapshot(payload));
    }

    private static void handleMemoryManagementAction(MemoryManagementActionPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        context.enqueueWork(() -> MEMORY_MANAGEMENT.handle(player, payload));
    }

    private static void handleMemoryManagementSnapshot(MemoryManagementSnapshotPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> VeilboundClient.handleMemoryManagementSnapshot(payload));
    }

    private static void handleVeilInventoryAction(VeilInventoryActionPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        context.enqueueWork(() -> VEIL_INVENTORY.handle(player, payload));
    }

    private static void handleVeilInventorySnapshot(VeilInventorySnapshotPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> VeilboundClient.handleVeilInventorySnapshot(payload));
    }

    private static void handleVeilCraftingRequest(VeilCraftingRequestPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        context.enqueueWork(() -> VEIL_CRAFTING.handle(player, payload));
    }

    private static void handleVeilCraftingPreview(VeilCraftingPreviewPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> VeilboundClient.handleVeilCraftingPreview(payload));
    }

    private static void handleVeilCraftablesRequest(VeilCraftablesRequestPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        context.enqueueWork(() -> VEIL_CRAFTABLES.handle(player, payload));
    }

    private static void handleVeilCraftablesSnapshot(VeilCraftablesSnapshotPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> VeilboundClient.handleVeilCraftablesSnapshot(payload));
    }

    private static void handleSpatialGeneratorAction(SpatialGeneratorActionPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        context.enqueueWork(() -> Veilbound.spatialGenerator().handle(player, payload));
    }

    private static void handleSpatialGeneratorSnapshot(SpatialGeneratorSnapshotPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> VeilboundClient.handleSpatialGeneratorSnapshot(payload));
    }
}
