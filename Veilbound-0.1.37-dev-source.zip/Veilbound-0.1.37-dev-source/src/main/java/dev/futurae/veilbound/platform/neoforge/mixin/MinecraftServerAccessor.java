package dev.futurae.veilbound.platform.neoforge.mixin;

import java.util.concurrent.Executor;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelStorageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Minimal access Veilbound needs to construct a normal ServerLevel at runtime.
 * The live level map itself is intentionally accessed through NeoForge's public
 * forgeGetWorldMap() hook rather than through another mixin accessor.
 */
@Mixin(MinecraftServer.class)
public interface MinecraftServerAccessor {
    @Accessor("executor")
    Executor veilbound$getExecutor();

    @Accessor("storageSource")
    LevelStorageSource.LevelStorageAccess veilbound$getStorageSource();
}
