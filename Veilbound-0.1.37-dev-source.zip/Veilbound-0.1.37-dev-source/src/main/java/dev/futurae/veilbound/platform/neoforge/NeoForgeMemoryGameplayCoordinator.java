package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.memory.DomainOrreryService;
import dev.futurae.veilbound.memory.MemoryArchiveService;
import dev.futurae.veilbound.memory.MemoryCaptureService;
import dev.futurae.veilbound.memory.MemoryDefinition;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import dev.futurae.veilbound.registry.VeilboundItems;
import dev.futurae.veilbound.registry.VeilboundDataComponents;
import dev.futurae.veilbound.network.MemoryManagementSnapshotPayload;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/** Physical Mnemonic Vessel -> Memory Archive -> Domain Orrery interaction path. */
public final class NeoForgeMemoryGameplayCoordinator {
    private final VeilboundRuntime runtime;
    private final MemoryCaptureService capture = new MemoryCaptureService();
    private final MemoryArchiveService archive = new MemoryArchiveService();
    private final DomainOrreryService orrery = new DomainOrreryService();
    private final NeoForgeMemoryManagementController management;

    public NeoForgeMemoryGameplayCoordinator(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        this.management = new NeoForgeMemoryManagementController(runtime);
    }

    /** Right-clicking open air with a Mnemonic Vessel attempts an environmental capture. */
    public void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !(event.getLevel() instanceof ServerLevel level)) return;
        if (!event.getItemStack().is(VeilboundItems.MNEMONIC_VESSEL.get())) return;

        DomainRecord record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null) {
            message(player, "message.veilbound.memory.no_domain");
            consume(event, InteractionResult.FAIL);
            return;
        }
        ItemStack vessel = event.getItemStack();
        String carriedMemoryId = carriedMemory(vessel, record);
        if (carriedMemoryId != null) {
            MemoryDefinition memory = runtime.memories().get(carriedMemoryId).orElse(null);
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.memory.vessel_occupied", memory == null ? carriedMemoryId : memory.displayName()), true);
            consume(event, InteractionResult.FAIL);
            return;
        }

        var result = capture.choose(runtime.memories().all(), observation(level, player.blockPosition()), record.state().unlockedMemoryIds());
        if (!result.capturable()) {
            message(player, "message.veilbound.memory." + result.reason());
            consume(event, InteractionResult.FAIL);
            return;
        }
        vessel.set(VeilboundDataComponents.MNEMONIC_VESSEL_MEMORY.get(), result.memory().id());
        player.displayClientMessage(Component.translatable(
                "message.veilbound.memory.captured", result.memory().displayName()), true);
        consume(event, InteractionResult.SUCCESS);
    }

    /** Archive ingests the held Vessel capture; Orrery cycles earned Memories entirely in-world. */
    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getLevel().isClientSide()) return;
        var state = event.getLevel().getBlockState(event.getPos());
        boolean isArchive = state.is(VeilboundBlocks.MEMORY_ARCHIVE.get());
        boolean isOrrery = state.is(VeilboundBlocks.DOMAIN_ORRERY.get());
        if (!isArchive && !isOrrery) return;

        DomainRecord record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null || !record.identity().dimensionId().equals(event.getLevel().dimension().identifier().toString())) {
            message(player, "message.veilbound.memory.not_owner_domain");
            consume(event, InteractionResult.FAIL);
            return;
        }

        if (isArchive) handleArchive(player, record, event);
        else handleOrrery(player, record, event);
    }

    private void handleArchive(ServerPlayer player, DomainRecord record, PlayerInteractEvent.RightClickBlock event) {
        if (!event.getItemStack().is(VeilboundItems.MNEMONIC_VESSEL.get())) {
            management.open(player, MemoryManagementSnapshotPayload.View.ARCHIVE);
            consume(event, InteractionResult.SUCCESS);
            return;
        }
        ItemStack vessel = event.getItemStack();
        String carriedMemoryId = carriedMemory(vessel, record);
        var result = archive.archive(record.state(), carriedMemoryId, runtime.memories());
        if (!result.archived()) {
            message(player, "message.veilbound.memory." + result.reason());
            consume(event, InteractionResult.FAIL);
            return;
        }
        vessel.remove(VeilboundDataComponents.MNEMONIC_VESSEL_MEMORY.get());
        MemoryDefinition memory = runtime.memories().get(result.memoryId()).orElseThrow();
        player.displayClientMessage(Component.translatable(
                "message.veilbound.memory.archived", memory.displayName()), true);
        consume(event, InteractionResult.SUCCESS);
    }

    private void handleOrrery(ServerPlayer player, DomainRecord record, PlayerInteractEvent.RightClickBlock event) {
        if (player.isShiftKeyDown()) {
            orrery.select(record.state(), record.memoryProgress(), runtime.memories(), List.of());
            message(player, "message.veilbound.memory.orrery_cleared");
            consume(event, InteractionResult.SUCCESS);
            return;
        }
        management.open(player, MemoryManagementSnapshotPayload.View.ORRERY);
        consume(event, InteractionResult.SUCCESS);
    }

    /**
     * v7-v10 stored one pending capture on the Domain rather than the physical Vessel. The first
     * empty Vessel interaction after upgrading transfers that legacy capture losslessly.
     */
    private static String carriedMemory(ItemStack vessel, DomainRecord record) {
        String carried = vessel.get(VeilboundDataComponents.MNEMONIC_VESSEL_MEMORY.get());
        if (carried != null && !carried.isBlank()) return carried;
        String legacy = record.memoryProgress().capturedMemoryId().orElse(null);
        if (legacy == null || legacy.isBlank()) return null;
        vessel.set(VeilboundDataComponents.MNEMONIC_VESSEL_MEMORY.get(), legacy);
        record.memoryProgress().clearCapturedMemory();
        return legacy;
    }

    private static Map<String, String> observation(ServerLevel level, BlockPos pos) {
        LinkedHashMap<String, String> observation = new LinkedHashMap<>();
        observation.put("dimension", level.dimension().identifier().toString());
        observation.put("sky", level.canSeeSky(pos) ? "visible" : "blocked");
        observation.put("weather", level.isThundering() ? "thunder" : level.isRaining() ? "rain" : "clear");
        long dayTime = Math.floorMod(level.getDefaultClockTime(), 24_000L);
        observation.put("time_band", dayTime >= 13_000L && dayTime < 23_000L ? "night" : "day");
        String biome = level.getBiome(pos).unwrapKey().map(key -> key.identifier().toString()).orElse("unknown");
        observation.put("biome", biome);
        observation.put("biome_family", biomeFamily(biome));
        return Map.copyOf(observation);
    }

    private static String biomeFamily(String biomeId) {
        String path = biomeId.toLowerCase(Locale.ROOT);
        for (String family : List.of("forest", "jungle", "desert", "taiga", "swamp", "savanna", "ocean", "plains", "badlands")) {
            if (path.contains(family)) return family;
        }
        return "other";
    }

    private static void message(ServerPlayer player, String key) {
        player.displayClientMessage(Component.translatable(key), true);
    }

    private static void consume(PlayerInteractEvent.RightClickItem event, InteractionResult result) {
        event.setCancellationResult(result);
        event.setCanceled(true);
    }

    private static void consume(PlayerInteractEvent.RightClickBlock event, InteractionResult result) {
        event.setCancellationResult(result);
        event.setCanceled(true);
    }
}
