package dev.futurae.veilbound.platform.neoforge.travel;

import dev.futurae.veilbound.travel.ReturnAnchor;
import dev.futurae.veilbound.travel.SafeReturnSearch;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.LevelData;
import net.minecraft.world.phys.AABB;

/**
 * Resolves an exact persisted return anchor into a currently safe server teleport destination.
 *
 * <p>Resolution is intentionally conservative: preserve the exact saved coordinates whenever the
 * player's bounding box still fits; otherwise probe a small deterministic neighborhood for a
 * collision-free position with physical support. Only after those options fail (or the original
 * dimension is no longer loaded/available) does Veilbound fall back to the server respawn point.</p>
 */
public final class NeoForgeReturnAnchorResolver {

    public ResolvedReturn resolve(MinecraftServer server, ServerPlayer player, ReturnAnchor anchor) {
        Objects.requireNonNull(server, "server");
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(anchor, "anchor");

        ServerLevel sourceLevel = server.getLevel(levelKey(anchor.dimensionId()));
        if (sourceLevel != null) {
            if (fits(sourceLevel, player, anchor.x(), anchor.y(), anchor.z())) {
                return new ResolvedReturn(
                        sourceLevel, anchor.x(), anchor.y(), anchor.z(), anchor.yaw(), anchor.pitch(), Resolution.EXACT);
            }

            BlockPos origin = BlockPos.containing(anchor.x(), anchor.y(), anchor.z());
            for (SafeReturnSearch.BlockOffset offset : SafeReturnSearch.candidates()) {
                double x = origin.getX() + offset.dx() + 0.5D;
                double y = origin.getY() + offset.dy();
                double z = origin.getZ() + offset.dz() + 0.5D;
                if (fitsWithSupport(sourceLevel, player, x, y, z)) {
                    return new ResolvedReturn(sourceLevel, x, y, z, anchor.yaw(), anchor.pitch(), Resolution.NEARBY_SAFE);
                }
            }
        }

        return resolveSpawnFallback(server, player);
    }

    private static ResolvedReturn resolveSpawnFallback(MinecraftServer server, ServerPlayer player) {
        LevelData.RespawnData respawn = server.getRespawnData();
        ServerLevel level = server.getLevel(respawn.dimension());
        if (level == null) level = server.overworld();

        BlockPos requested = respawn.pos();
        BlockPos adjusted = player.adjustSpawnLocation(level, requested);
        return new ResolvedReturn(
                level,
                adjusted.getX() + 0.5D,
                adjusted.getY(),
                adjusted.getZ() + 0.5D,
                respawn.yaw(),
                respawn.pitch(),
                Resolution.SPAWN_FALLBACK);
    }

    private static boolean fits(ServerLevel level, ServerPlayer player, double x, double y, double z) {
        AABB box = movedBox(player, x, y, z);
        return level.noCollision(player, box);
    }

    private static boolean fitsWithSupport(ServerLevel level, ServerPlayer player, double x, double y, double z) {
        AABB box = movedBox(player, x, y, z);
        if (!level.noCollision(player, box)) return false;
        // Probe just below the destination box so a normal floor qualifies as support without
        // demanding that the player-shaped box itself intersect that floor.
        return level.findSupportingBlock(player, box.move(0.0D, -0.05D, 0.0D)).isPresent();
    }

    private static AABB movedBox(ServerPlayer player, double x, double y, double z) {
        return player.getBoundingBox().move(x - player.getX(), y - player.getY(), z - player.getZ());
    }

    private static ResourceKey<Level> levelKey(String dimensionId) {
        return ResourceKey.create(Registries.DIMENSION, Identifier.parse(dimensionId));
    }

    public enum Resolution {
        EXACT,
        NEARBY_SAFE,
        SPAWN_FALLBACK
    }

    public record ResolvedReturn(
            ServerLevel level,
            double x,
            double y,
            double z,
            float yaw,
            float pitch,
            Resolution resolution) {
        public ResolvedReturn {
            Objects.requireNonNull(level, "level");
            Objects.requireNonNull(resolution, "resolution");
        }
    }
}
