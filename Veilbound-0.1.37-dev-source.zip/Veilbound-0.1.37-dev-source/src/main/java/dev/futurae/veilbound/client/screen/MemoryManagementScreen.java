package dev.futurae.veilbound.client.screen;

import dev.futurae.veilbound.network.MemoryManagementActionPayload;
import dev.futurae.veilbound.network.MemoryManagementSnapshotPayload;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;

/** Owner-only management surface for the Memory Archive, Domain Orrery, and Environmental Zones. */
public final class MemoryManagementScreen extends Screen {
    private static final int PANEL_WIDTH = 520;
    private static final int PANEL_HEIGHT = 292;
    private static final int MEMORY_ROWS = 8;
    private static final int ZONE_ROWS = 6;

    private MemoryManagementSnapshotPayload snapshot;
    private int memoryPage;
    private int zonePage;
    private String selectedMemoryId = "";
    private String selectedZoneId = "";
    private EditBox zoneName;

    public MemoryManagementScreen(MemoryManagementSnapshotPayload snapshot) {
        super(Component.translatable("screen.veilbound.memory_management"));
        this.snapshot = snapshot;
        normalizeSelection();
    }

    public void acceptSnapshot(MemoryManagementSnapshotPayload next) {
        MemoryManagementSnapshotPayload.View oldView = snapshot.view();
        snapshot = next;
        if (oldView != next.view()) {
            memoryPage = 0;
            zonePage = 0;
        }
        normalizeSelection();
        if (minecraft != null) rebuildWidgets();
    }

    private void normalizeSelection() {
        if (!selectedMemoryId.isBlank() && snapshot.memories().stream().noneMatch(m -> m.id().equals(selectedMemoryId))) {
            selectedMemoryId = "";
        }
        if (selectedMemoryId.isBlank() && !snapshot.memories().isEmpty()) {
            selectedMemoryId = snapshot.memories().get(0).id();
        }
        if (!selectedZoneId.isBlank() && snapshot.zones().stream().noneMatch(z -> z.id().equals(selectedZoneId))) {
            selectedZoneId = "";
        }
        if (selectedZoneId.isBlank() && !snapshot.zones().isEmpty()) {
            selectedZoneId = snapshot.zones().get(0).id();
        }
        memoryPage = clampPage(memoryPage, snapshot.memories().size(), MEMORY_ROWS);
        zonePage = clampPage(zonePage, snapshot.zones().size(), ZONE_ROWS);
    }

    private void rebuildWidgets() {
        clearWidgets();
        init();
    }

    @Override
    protected void init() {
        super.init();
        int left = Math.max(6, width / 2 - PANEL_WIDTH / 2);
        int top = Math.max(18, height / 2 - PANEL_HEIGHT / 2);

        addTab(left + 10, top + 10, 104, MemoryManagementSnapshotPayload.View.ARCHIVE,
                "screen.veilbound.memory_management.tab.archive", MemoryManagementActionPayload.Action.OPEN_ARCHIVE);
        addTab(left + 118, top + 10, 104, MemoryManagementSnapshotPayload.View.ORRERY,
                "screen.veilbound.memory_management.tab.orrery", MemoryManagementActionPayload.Action.OPEN_ORRERY);
        addTab(left + 226, top + 10, 104, MemoryManagementSnapshotPayload.View.ZONES,
                "screen.veilbound.memory_management.tab.zones", MemoryManagementActionPayload.Action.OPEN_ZONES);

        if (!snapshot.allowed()) return;
        switch (snapshot.view()) {
            case ARCHIVE -> initArchive(left, top);
            case ORRERY -> initOrrery(left, top);
            case ZONES -> initZones(left, top);
        }
    }

    private void addTab(int x, int y, int w, MemoryManagementSnapshotPayload.View view,
                        String key, MemoryManagementActionPayload.Action action) {
        Button tab = Button.builder(Component.translatable(key), b -> send(action, "", ""))
                .bounds(x, y, w, 20).build();
        tab.active = snapshot.view() != view;
        addRenderableWidget(tab);
    }

    private void initArchive(int left, int top) {
        addMemoryPaging(left, top);
        List<MemoryManagementSnapshotPayload.MemoryEntry> page = memoryPageEntries();
        for (int i = 0; i < page.size(); i++) {
            var memory = page.get(i);
            Component label = Component.literal(memory.archived() ? "◆ " : "◇ ").append(Component.literal(memory.displayName()));
            addRenderableWidget(Button.builder(label, b -> {
                        selectedMemoryId = memory.id();
                        rebuildWidgets();
                    }).bounds(left + 12, top + 66 + i * 23, 224, 20).build());
        }
    }

    private void initOrrery(int left, int top) {
        addMemoryPaging(left, top);
        List<MemoryManagementSnapshotPayload.MemoryEntry> page = memoryPageEntries();
        for (int i = 0; i < page.size(); i++) {
            var memory = page.get(i);
            String marker = memory.active() ? "● " : memory.archived() ? "○ " : "◇ ";
            Button row = Button.builder(Component.literal(marker + memory.displayName()), b -> {
                        selectedMemoryId = memory.id();
                        send(MemoryManagementActionPayload.Action.TOGGLE_ORRERY_MEMORY, memory.id(), "");
                    }).bounds(left + 12, top + 66 + i * 23, 224, 20).build();
            row.active = memory.archived();
            addRenderableWidget(row);
        }
        Button clear = Button.builder(Component.translatable("screen.veilbound.memory_management.orrery.clear"),
                        b -> send(MemoryManagementActionPayload.Action.CLEAR_ORRERY, "", ""))
                .bounds(left + 348, top + 250, 150, 20).build();
        clear.active = snapshot.memories().stream().anyMatch(MemoryManagementSnapshotPayload.MemoryEntry::active);
        addRenderableWidget(clear);
    }

    private void addMemoryPaging(int left, int top) {
        int pages = pageCount(snapshot.memories().size(), MEMORY_ROWS);
        Button previous = Button.builder(Component.literal("<"), b -> {
                    memoryPage = Math.max(0, memoryPage - 1);
                    rebuildWidgets();
                }).bounds(left + 12, top + 40, 30, 20).build();
        previous.active = memoryPage > 0;
        addRenderableWidget(previous);
        Button next = Button.builder(Component.literal(">"), b -> {
                    memoryPage = Math.min(pages - 1, memoryPage + 1);
                    rebuildWidgets();
                }).bounds(left + 206, top + 40, 30, 20).build();
        next.active = memoryPage + 1 < pages;
        addRenderableWidget(next);
    }

    private void initZones(int left, int top) {
        if (!snapshot.environmentalMastery()) return;
        int pages = pageCount(snapshot.zones().size(), ZONE_ROWS);
        Button previous = Button.builder(Component.literal("<"), b -> {
                    zonePage = Math.max(0, zonePage - 1);
                    rebuildWidgets();
                }).bounds(left + 12, top + 40, 30, 20).build();
        previous.active = zonePage > 0;
        addRenderableWidget(previous);
        Button next = Button.builder(Component.literal(">"), b -> {
                    zonePage = Math.min(pages - 1, zonePage + 1);
                    rebuildWidgets();
                }).bounds(left + 206, top + 40, 30, 20).build();
        next.active = zonePage + 1 < pages;
        addRenderableWidget(next);

        List<MemoryManagementSnapshotPayload.ZoneEntry> page = zonePageEntries();
        for (int i = 0; i < page.size(); i++) {
            var zone = page.get(i);
            Component label = Component.literal(zone.name() + "  [" + zone.priority() + "]");
            addRenderableWidget(Button.builder(label, b -> {
                        selectedZoneId = zone.id();
                        rebuildWidgets();
                    }).bounds(left + 12, top + 66 + i * 28, 224, 20).build());
        }

        var selected = selectedZone();
        if (selected == null) return;
        int x = left + 260;
        int y = top + 72;
        addRenderableWidget(Button.builder(Component.literal("−"), b ->
                        send(MemoryManagementActionPayload.Action.ZONE_PRIORITY_DOWN, selected.id(), ""))
                .bounds(x, y + 55, 30, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b ->
                        send(MemoryManagementActionPayload.Action.ZONE_PRIORITY_UP, selected.id(), ""))
                .bounds(x + 116, y + 55, 30, 20).build());
        addRenderableWidget(Button.builder(Component.translatable(
                                selected.blend() ? "screen.veilbound.memory_management.zone.blend_on"
                                        : "screen.veilbound.memory_management.zone.blend_off"),
                        b -> send(MemoryManagementActionPayload.Action.ZONE_TOGGLE_BLEND, selected.id(), ""))
                .bounds(x + 152, y + 55, 94, 20).build());

        addRenderableWidget(Button.builder(Component.literal("<"), b -> retune(selected, -1))
                .bounds(x, y + 91, 30, 20).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> retune(selected, 1))
                .bounds(x + 216, y + 91, 30, 20).build());

        zoneName = new EditBox(font, 166, 20, Component.translatable("screen.veilbound.memory_management.zone.name"));
        zoneName.setMaxLength(48);
        zoneName.setValue(selected.name());
        zoneName.setPosition(x, y + 130);
        addRenderableWidget(zoneName);
        addRenderableWidget(Button.builder(Component.translatable("screen.veilbound.memory_management.zone.rename"), b ->
                        send(MemoryManagementActionPayload.Action.ZONE_RENAME, selected.id(), zoneName.getValue()))
                .bounds(x + 172, y + 130, 74, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("screen.veilbound.memory_management.zone.delete"), b ->
                        send(MemoryManagementActionPayload.Action.ZONE_DELETE, selected.id(), ""))
                .bounds(x + 146, y + 166, 100, 20).build());
    }

    private void retune(MemoryManagementSnapshotPayload.ZoneEntry zone, int direction) {
        List<MemoryManagementSnapshotPayload.MemoryEntry> archived = snapshot.memories().stream()
                .filter(MemoryManagementSnapshotPayload.MemoryEntry::archived).toList();
        if (archived.isEmpty()) return;
        int current = 0;
        for (int i = 0; i < archived.size(); i++) {
            if (archived.get(i).id().equals(zone.memoryId())) { current = i; break; }
        }
        int next = Math.floorMod(current + direction, archived.size());
        send(MemoryManagementActionPayload.Action.ZONE_RETUNE, zone.id(), archived.get(next).id());
    }

    private void send(MemoryManagementActionPayload.Action action, String target, String value) {
        ClientPacketDistributor.sendToServer(new MemoryManagementActionPayload(action, target, value));
    }

    private List<MemoryManagementSnapshotPayload.MemoryEntry> memoryPageEntries() {
        int from = Math.min(memoryPage * MEMORY_ROWS, snapshot.memories().size());
        int to = Math.min(from + MEMORY_ROWS, snapshot.memories().size());
        return snapshot.memories().subList(from, to);
    }

    private List<MemoryManagementSnapshotPayload.ZoneEntry> zonePageEntries() {
        int from = Math.min(zonePage * ZONE_ROWS, snapshot.zones().size());
        int to = Math.min(from + ZONE_ROWS, snapshot.zones().size());
        return snapshot.zones().subList(from, to);
    }

    private MemoryManagementSnapshotPayload.MemoryEntry selectedMemory() {
        return snapshot.memories().stream().filter(m -> m.id().equals(selectedMemoryId)).findFirst().orElse(null);
    }

    private MemoryManagementSnapshotPayload.ZoneEntry selectedZone() {
        return snapshot.zones().stream().filter(z -> z.id().equals(selectedZoneId)).findFirst().orElse(null);
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        extractTransparentBackground(graphics);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
        int left = Math.max(6, width / 2 - PANEL_WIDTH / 2);
        int top = Math.max(18, height / 2 - PANEL_HEIGHT / 2);
        graphics.fill(left, top, left + PANEL_WIDTH, top + PANEL_HEIGHT, 0xF0100E18);
        graphics.fill(left, top, left + PANEL_WIDTH, top + 36, 0xF029173B);
        graphics.fill(left, top + 35, left + PANEL_WIDTH, top + 36, 0xFF9F7AC8);
        graphics.text(font, title, left + 348, top + 16, 0xFFF3ECFF, false);

        if (!snapshot.allowed()) {
            graphics.centeredText(font, Component.translatable("screen.veilbound.memory_management.denied", snapshot.reason()),
                    width / 2, top + 130, 0xFFFF8585);
            return;
        }
        if (!"ok".equals(snapshot.reason())) {
            graphics.text(font, Component.translatable("screen.veilbound.memory_management.status", humanReason(snapshot.reason())),
                    left + 344, top + 44, 0xFFFFC080, false);
        }

        switch (snapshot.view()) {
            case ARCHIVE -> renderArchive(graphics, left, top);
            case ORRERY -> renderOrrery(graphics, left, top);
            case ZONES -> renderZones(graphics, left, top);
        }
    }

    private void renderArchive(GuiGraphicsExtractor graphics, int left, int top) {
        int archived = (int) snapshot.memories().stream().filter(MemoryManagementSnapshotPayload.MemoryEntry::archived).count();
        graphics.text(font, Component.translatable("screen.veilbound.memory_management.archive.count", archived, snapshot.memories().size()),
                left + 250, top + 72, 0xFFE4BCFF, false);
        graphics.text(font, Component.translatable("screen.veilbound.memory_management.page",
                        memoryPage + 1, pageCount(snapshot.memories().size(), MEMORY_ROWS)), left + 58, top + 46, 0xFFBEB4CA, false);
        var selected = selectedMemory();
        if (selected == null) return;
        graphics.text(font, Component.literal(selected.displayName()), left + 250, top + 96, 0xFFFFFFFF, false);
        graphics.text(font, Component.translatable(selected.archived()
                        ? "screen.veilbound.memory_management.archive.archived"
                        : "screen.veilbound.memory_management.archive.unarchived"),
                left + 250, top + 112, selected.archived() ? 0xFF86E5A7 : 0xFFFFA1A1, false);
        graphics.text(font, Component.translatable("screen.veilbound.memory_management.prerequisites",
                        selected.prerequisitesMet() ? "met" : "missing"), left + 250, top + 130, 0xFFC5BDD0, false);
        graphics.text(font, Component.translatable("screen.veilbound.memory_management.tags",
                        selected.tags().isEmpty() ? "—" : String.join(", ", selected.tags())), left + 250, top + 148, 0xFFC5BDD0, false);
        graphics.text(font, Component.translatable("screen.veilbound.memory_management.capture"), left + 250, top + 176, 0xFFE4BCFF, false);
        graphics.text(font, Component.literal(shorten(selected.captureSummary(), 54)), left + 250, top + 192, 0xFFC5BDD0, false);
        graphics.text(font, Component.translatable("screen.veilbound.memory_management.archive.hint"), left + 250, top + 238, 0xFF9E93AA, false);
    }

    private void renderOrrery(GuiGraphicsExtractor graphics, int left, int top) {
        int active = (int) snapshot.memories().stream().filter(MemoryManagementSnapshotPayload.MemoryEntry::active).count();
        graphics.text(font, Component.translatable("screen.veilbound.memory_management.page",
                        memoryPage + 1, pageCount(snapshot.memories().size(), MEMORY_ROWS)), left + 58, top + 46, 0xFFBEB4CA, false);
        graphics.text(font, Component.translatable("screen.veilbound.memory_management.orrery.active", active),
                left + 250, top + 72, 0xFFE4BCFF, false);
        graphics.text(font, Component.translatable("screen.veilbound.memory_management.orrery.hint"),
                left + 250, top + 96, 0xFFC5BDD0, false);
        int y = top + 122;
        for (var memory : snapshot.memories().stream().filter(MemoryManagementSnapshotPayload.MemoryEntry::active).limit(6).toList()) {
            graphics.text(font, Component.literal("• " + memory.displayName()), left + 260, y, 0xFF86E5A7, false);
            y += 15;
        }
        if (active == 0) {
            graphics.text(font, Component.translatable("screen.veilbound.memory_management.orrery.none"),
                    left + 260, y, 0xFF9E93AA, false);
        }
    }

    private void renderZones(GuiGraphicsExtractor graphics, int left, int top) {
        if (!snapshot.environmentalMastery()) {
            graphics.centeredText(font, Component.translatable("screen.veilbound.memory_management.zones.locked"),
                    width / 2, top + 126, 0xFFFFC080);
            graphics.centeredText(font, Component.translatable("screen.veilbound.memory_management.zones.locked_hint"),
                    width / 2, top + 146, 0xFFC5BDD0);
            return;
        }
        graphics.text(font, Component.translatable("screen.veilbound.memory_management.page",
                        zonePage + 1, pageCount(snapshot.zones().size(), ZONE_ROWS)), left + 58, top + 46, 0xFFBEB4CA, false);
        var selected = selectedZone();
        if (selected == null) {
            graphics.text(font, Component.translatable("screen.veilbound.memory_management.zones.none"),
                    left + 260, top + 88, 0xFF9E93AA, false);
            graphics.text(font, Component.translatable("screen.veilbound.memory_management.zones.create_hint"),
                    left + 260, top + 110, 0xFFC5BDD0, false);
            return;
        }
        int x = left + 260;
        int y = top + 72;
        graphics.text(font, Component.literal(selected.name()), x, y, 0xFFFFFFFF, false);
        graphics.text(font, Component.translatable("screen.veilbound.memory_management.zone.bounds",
                        selected.minX(), selected.minY(), selected.minZ(), selected.maxX(), selected.maxY(), selected.maxZ()),
                x, y + 18, 0xFFC5BDD0, false);
        graphics.text(font, Component.translatable("screen.veilbound.memory_management.zone.priority", selected.priority()),
                x + 38, y + 61, 0xFFE4BCFF, false);
        graphics.text(font, Component.translatable("screen.veilbound.memory_management.zone.memory", selected.memoryDisplayName()),
                x + 38, y + 97, 0xFFE4BCFF, false);
        graphics.text(font, Component.translatable("screen.veilbound.memory_management.zone.rename_hint"), x, y + 118, 0xFF9E93AA, false);
    }

    private static int pageCount(int size, int rows) {
        return Math.max(1, (size + rows - 1) / rows);
    }

    private static int clampPage(int page, int size, int rows) {
        return Math.max(0, Math.min(page, pageCount(size, rows) - 1));
    }

    private static String shorten(String value, int max) {
        if (value == null) return "";
        return value.length() <= max ? value : value.substring(0, Math.max(0, max - 1)) + "…";
    }

    private static String humanReason(String reason) {
        return reason == null ? "unknown" : reason.replace('_', ' ');
    }
}
