package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.BoundaryPylonBindingService;
import dev.futurae.veilbound.domain.BoundaryPylonState;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import dev.futurae.veilbound.network.DomainControlsSnapshotPayload;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.Objects;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.level.block.BreakBlockEvent;

/** Binds physical Boundary Pylons to the six Core-relative expansion directions. */
public final class NeoForgeBoundaryPylonCoordinator {
    private final VeilboundRuntime runtime;
    private final NeoForgeDomainControlsController controls;

    public NeoForgeBoundaryPylonCoordinator(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        this.controls = new NeoForgeDomainControlsController(runtime);
    }

    /** Placement claims one physical block for one direction; a second block may not steal it. */
    public void onPlaceBlock(BlockEvent.EntityPlaceEvent event) {
        if (event.isCanceled() || !(event.getEntity() instanceof ServerPlayer player)) return;
        if (!event.getPlacedBlock().is(VeilboundBlocks.BOUNDARY_PYLON.get())) return;

        DomainRecord record = ownerRecordInCurrentDomain(player);
        if (record == null) {
            message(player, "message.veilbound.pylon.not_owner_domain");
            event.setCanceled(true);
            return;
        }
        DomainPosition position = toDomainPosition(event.getPos());
        AxisDirection direction = BoundaryPylonBindingService.directionForExpectedPosition(record.state(), position).orElse(null);
        if (direction == null) {
            message(player, "message.veilbound.pylon.ambiguous_direction");
            event.setCanceled(true);
            return;
        }
        var result = BoundaryPylonBindingService.bind(record.state(), direction, position);
        if (!result.bound()) {
            message(player, "message.veilbound.pylon." + result.reason());
            event.setCanceled(true);
            return;
        }
        player.displayClientMessage(Component.translatable(
                "message.veilbound.pylon.bound", displayDirection(direction)), true);
    }

    /** Right-click toggles expansion only for the exact bound physical pylon. */
    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getLevel().isClientSide()) return;
        if (!event.getLevel().getBlockState(event.getPos()).is(VeilboundBlocks.BOUNDARY_PYLON.get())) return;

        DomainRecord record = ownerRecordInCurrentDomain(player);
        if (record == null) {
            message(player, "message.veilbound.pylon.not_owner_domain");
            consume(event, InteractionResult.FAIL);
            return;
        }

        if (player.isShiftKeyDown()) {
            controls.open(player, DomainControlsSnapshotPayload.View.PYLONS);
            consume(event, InteractionResult.SUCCESS);
            return;
        }

        DomainPosition position = toDomainPosition(event.getPos());
        AxisDirection direction = boundDirectionAt(record, position);
        if (direction == null) {
            message(player, "message.veilbound.pylon.ambiguous_direction");
            consume(event, InteractionResult.FAIL);
            return;
        }

        var result = BoundaryPylonBindingService.toggleExpansion(record.state(), direction, position);
        if (!result.toggled()) {
            message(player, "message.veilbound.pylon." + result.reason());
            consume(event, InteractionResult.FAIL);
            return;
        }
        BoundaryPylonState next = result.state();
        player.displayClientMessage(Component.translatable(
                next.expansionEnabled() ? "message.veilbound.pylon.enabled" : "message.veilbound.pylon.disabled",
                displayDirection(direction)), true);
        consume(event, InteractionResult.SUCCESS);
    }

    /** Breaking an unrelated duplicate pylon cannot disable the actual face binding. */
    public void onBreakBlock(BreakBlockEvent event) {
        if (event.isCanceled() || !(event.getPlayer() instanceof ServerPlayer player)
                || !event.getState().is(VeilboundBlocks.BOUNDARY_PYLON.get())) return;
        DomainRecord record = ownerRecordInCurrentDomain(player);
        if (record == null) return;
        DomainPosition position = toDomainPosition(event.getPos());
        AxisDirection direction = boundDirectionAt(record, position);
        if (direction != null) BoundaryPylonBindingService.unbindIfMatching(record.state(), direction, position);
    }

    private static AxisDirection boundDirectionAt(DomainRecord record, DomainPosition position) {
        return record.state().pylons().values().stream()
                .filter(pylon -> pylon.bound() && position.equals(pylon.blockPosition()))
                .map(BoundaryPylonState::direction)
                .findFirst().orElse(null);
    }

    private DomainRecord ownerRecordInCurrentDomain(ServerPlayer player) {
        DomainRecord record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null) return null;
        String dimensionId = player.level().dimension().identifier().toString();
        return record.identity().dimensionId().equals(dimensionId) ? record : null;
    }

    private static DomainPosition toDomainPosition(net.minecraft.core.BlockPos pos) {
        return new DomainPosition(pos.getX(), pos.getY(), pos.getZ());
    }

    private static String displayDirection(AxisDirection direction) {
        return switch (direction) {
            case POSITIVE_X -> "+X";
            case NEGATIVE_X -> "-X";
            case POSITIVE_Y -> "+Y";
            case NEGATIVE_Y -> "-Y";
            case POSITIVE_Z -> "+Z";
            case NEGATIVE_Z -> "-Z";
        };
    }

    private static void message(ServerPlayer player, String key) {
        player.displayClientMessage(Component.translatable(key), true);
    }

    private static void consume(PlayerInteractEvent.RightClickBlock event, InteractionResult result) {
        event.setCancellationResult(result);
        event.setCanceled(true);
    }
}
