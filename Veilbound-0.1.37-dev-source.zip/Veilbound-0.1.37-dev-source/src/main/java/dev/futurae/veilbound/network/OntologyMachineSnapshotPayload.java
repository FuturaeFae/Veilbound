package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Bounded server-authoritative telemetry for one owner-bound ontology machine. */
public record OntologyMachineSnapshotPayload(
        int x, int y, int z, boolean allowed, String reason, String machine,
        long storedPotential, long potentialCapacity,
        String mode, int contributingVanes, long lastProduced, double stabilityLoad,
        double fractureMeter, int openBreaches, double instabilityMultiplier,
        long potentialPerVane, int maxVanes,
        String compilerStatus, long coreDimensionalEnergy, long coreDimensionalEnergyCapacity,
        long storedMatter, long matterPerPotential, long dimensionalEnergyPerPotential, long maxPotentialPerCycle)
        implements CustomPacketPayload {

    public static final Type<OntologyMachineSnapshotPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "ontology_machine_snapshot"));
    public static final StreamCodec<RegistryFriendlyByteBuf, OntologyMachineSnapshotPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override public OntologyMachineSnapshotPayload decode(RegistryFriendlyByteBuf b) {
            return new OntologyMachineSnapshotPayload(
                    b.readInt(),b.readInt(),b.readInt(),b.readBoolean(),b.readUtf(96),b.readUtf(32),
                    b.readLong(),b.readLong(),b.readUtf(32),b.readVarInt(),b.readLong(),b.readDouble(),
                    b.readDouble(),b.readVarInt(),b.readDouble(),b.readLong(),b.readVarInt(),b.readUtf(96),
                    b.readLong(),b.readLong(),b.readLong(),b.readLong(),b.readLong(),b.readLong());
        }
        @Override public void encode(RegistryFriendlyByteBuf b, OntologyMachineSnapshotPayload p) {
            b.writeInt(p.x()); b.writeInt(p.y()); b.writeInt(p.z()); b.writeBoolean(p.allowed()); b.writeUtf(p.reason(),96); b.writeUtf(p.machine(),32);
            b.writeLong(p.storedPotential()); b.writeLong(p.potentialCapacity()); b.writeUtf(p.mode(),32); b.writeVarInt(Math.max(0,p.contributingVanes()));
            b.writeLong(Math.max(0,p.lastProduced())); b.writeDouble(p.stabilityLoad()); b.writeDouble(p.fractureMeter()); b.writeVarInt(Math.max(0,p.openBreaches()));
            b.writeDouble(p.instabilityMultiplier()); b.writeLong(Math.max(0,p.potentialPerVane())); b.writeVarInt(Math.max(0,p.maxVanes())); b.writeUtf(p.compilerStatus(),96);
            b.writeLong(Math.max(0,p.coreDimensionalEnergy())); b.writeLong(Math.max(0,p.coreDimensionalEnergyCapacity())); b.writeLong(Math.max(0,p.storedMatter()));
            b.writeLong(Math.max(0,p.matterPerPotential())); b.writeLong(Math.max(0,p.dimensionalEnergyPerPotential())); b.writeLong(Math.max(0,p.maxPotentialPerCycle()));
        }
    };
    public OntologyMachineSnapshotPayload {
        reason=reason==null?"unknown":reason; machine=machine==null?"":machine; mode=mode==null?"":mode; compilerStatus=compilerStatus==null?"":compilerStatus;
    }
    public static OntologyMachineSnapshotPayload denied(int x,int y,int z,String reason){
        return new OntologyMachineSnapshotPayload(x,y,z,false,reason,"",0,0,"",0,0,0,0,0,1,0,0,"",0,0,0,0,0,0);
    }
    public boolean harvester(){ return "HARVESTER".equals(machine); }
    public boolean compiler(){ return "COMPILER".equals(machine); }
    @Override public Type<? extends CustomPacketPayload> type(){ return TYPE; }
}
