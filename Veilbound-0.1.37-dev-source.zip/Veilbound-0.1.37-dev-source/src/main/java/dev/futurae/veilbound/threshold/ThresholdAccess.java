package dev.futurae.veilbound.threshold;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/** Owner-controlled access state for guests entering through a Threshold. */
public final class ThresholdAccess {
    private final Set<UUID> invitedGuests = new HashSet<>();
    private boolean publicAccess;
    private Runnable mutationListener = () -> {};

    public boolean publicAccess() { return publicAccess; }
    public void setPublicAccess(boolean value) {
        if (publicAccess != value) {
            publicAccess = value;
            mutationListener.run();
        }
    }
    public void invite(UUID playerId) { if (invitedGuests.add(Objects.requireNonNull(playerId))) mutationListener.run(); }
    public void revoke(UUID playerId) { if (invitedGuests.remove(playerId)) mutationListener.run(); }
    public boolean canEnter(UUID playerId) { return publicAccess || invitedGuests.contains(playerId); }
    public Set<UUID> invitedGuests() { return Set.copyOf(invitedGuests); }
    public void setMutationListener(Runnable listener) { mutationListener = Objects.requireNonNull(listener, "listener"); }
}
