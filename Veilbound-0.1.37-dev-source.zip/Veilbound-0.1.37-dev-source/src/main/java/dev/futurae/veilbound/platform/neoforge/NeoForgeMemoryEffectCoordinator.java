package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.law.LawRuntimeSemantics;
import dev.futurae.veilbound.memory.MemoryEffectPolicy;
import dev.futurae.veilbound.memory.MemoryEnvironmentRuntime;
import dev.futurae.veilbound.memory.MemoryRuntimeSemantics;
import dev.futurae.veilbound.network.MemoryEnvironmentSnapshotPayload;
import dev.futurae.veilbound.platform.neoforge.world.NeoForgeDomainLevelService;
import dev.futurae.veilbound.platform.neoforge.world.VeilboundServerLevel;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.HashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Applies the server-authoritative portion of active Orrery Memories to already-live Domains.
 * Dormant Domains are never loaded solely for Memory effects.
 */
public final class NeoForgeMemoryEffectCoordinator {
    // Minecraft 26.2 removed BlockTags.SAPLINGS as a Java constant while retaining the vanilla
    // datapack tag itself. Keep using the canonical tag without pinning this runtime to the old API.
    private static final TagKey<Block> SAPLINGS = TagKey.create(
            Registries.BLOCK, Identifier.fromNamespaceAndPath("minecraft", "saplings"));
    private final VeilboundRuntime runtime;
    private final NeoForgeDomainLevelService domainLevels;
    private final Map<UUID, Integer> lastSentSignature = new HashMap<>();

    public NeoForgeMemoryEffectCoordinator(VeilboundRuntime runtime, NeoForgeDomainLevelService domainLevels) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        this.domainLevels = Objects.requireNonNull(domainLevels, "domainLevels");
    }

    public void onServerTick(ServerTickEvent.Post event) {
        MemoryEffectPolicy policy = runtime.memoryEffectPolicy().policy();
        long gameTime = event.getServer().overworld().getGameTime();
        boolean evaluate = gameTime % policy.evaluationTicks() == 0;
        boolean fertilityPulse = gameTime % policy.fertilityPulseTicks() == 0;

        Set<UUID> playersInsideDomains = new HashSet<>();
        for (DomainRecord record : runtime.domains().records()) {
            domainLevels.liveLevel(event.getServer(), record.ownerId()).ifPresent(level -> {
                for (ServerPlayer player : level.players()) playersInsideDomains.add(player.getUUID());

                MemoryEnvironmentRuntime.Resolution baseResolution = runtime.memoryEnvironment()
                        .resolve(record.state(), record.memoryProgress(), runtime.memories());
                LawRuntimeSemantics.Snapshot laws = runtime.lawRuntimeSemantics()
                        .snapshot(runtime.activeLawEffects(record.state()));

                // Domain-wide vanilla-facing state uses only the global Orrery. Environmental Zones
                // are intentionally player/position-local and must never make another zone rain.
                synchronizeRuleSubstrate(level, laws, baseResolution.semantics());

                boolean anyVisibleDayCycle = baseResolution.active()
                        && baseResolution.semantics().overworldDayCycle();
                for (ServerPlayer player : level.players()) {
                    MemoryEnvironmentRuntime.Resolution local = runtime.memoryEnvironment().resolveAt(
                            record.state(), record.memoryProgress(), runtime.memories(),
                            new DomainPosition(player.blockPosition().getX(), player.blockPosition().getY(), player.blockPosition().getZ()));
                    anyVisibleDayCycle |= local.active() && local.semantics().overworldDayCycle();
                    if (fertilityPulse && local.active() && local.semantics().verdantFertility()) {
                        pulseFertility(level, record, player, policy);
                    }
                    synchronizeClient(level, record, player, local, laws);
                }

                if (level instanceof VeilboundServerLevel domainLevel) {
                    domainLevel.tickRememberedClock(laws.time() && anyVisibleDayCycle);
                    // Only the global Orrery projects level-wide rain. Zone rain is synchronized
                    // directly to each client so one named region cannot weather the entire Domain.
                    domainLevel.setRememberedRain(
                            laws.weather() && baseResolution.active() && baseResolution.semantics().rainWeather(),
                            policy.forcedRainRefreshTicks());
                    if (evaluate) domainLevel.persistEnvironmentState();
                }
                if (evaluate) synchronizeWeather(level, laws, baseResolution.semantics(), policy);
            });
        }
        lastSentSignature.keySet().removeIf(playerId -> !playersInsideDomains.contains(playerId));
    }

    /** Time/weather need both their Law permission and their corresponding remembered substrate. */
    private static void synchronizeRuleSubstrate(
            ServerLevel level,
            LawRuntimeSemantics.Snapshot laws,
            MemoryRuntimeSemantics.Snapshot memories) {
        if (level instanceof VeilboundServerLevel domainLevel) {
            domainLevel.applyEnvironmentLaws(
                    laws, memories.overworldDayCycle(), memories.rainWeather());
            domainLevel.applyMemoryIllumination(memories);
        }
    }

    private static void synchronizeWeather(
            ServerLevel level,
            LawRuntimeSemantics.Snapshot laws,
            MemoryRuntimeSemantics.Snapshot memories,
            MemoryEffectPolicy policy) {
        if (level instanceof VeilboundServerLevel domainLevel) {
            domainLevel.setRememberedRain(
                    laws.weather() && memories.rainWeather(), policy.forcedRainRefreshTicks());
        }
    }

    private static void pulseFertility(
            ServerLevel level, DomainRecord record, ServerPlayer player, MemoryEffectPolicy policy) {
        if (policy.fertilityAttemptsPerPlayer() == 0) return;
        BlockPos origin = player.blockPosition();
        for (int attempt = 0; attempt < policy.fertilityAttemptsPerPlayer(); attempt++) {
            int dx = level.getRandom().nextInt(policy.fertilityHorizontalRadius() * 2 + 1)
                    - policy.fertilityHorizontalRadius();
            int dy = level.getRandom().nextInt(policy.fertilityVerticalRadius() * 2 + 1)
                    - policy.fertilityVerticalRadius();
            int dz = level.getRandom().nextInt(policy.fertilityHorizontalRadius() * 2 + 1)
                    - policy.fertilityHorizontalRadius();
            BlockPos pos = origin.offset(dx, dy, dz);
            if (!recordedDomainPosition(level, record, pos)) continue;
            BlockState state = level.getBlockState(pos);
            if ((state.is(BlockTags.CROPS) || state.is(SAPLINGS)) && state.isRandomlyTicking()) {
                state.randomTick(level, pos, level.getRandom());
            }
        }
    }

    /** Generation/runtime bounds remain authoritative; never stimulate unloaded/out-of-build-height positions. */
    private static boolean recordedDomainPosition(ServerLevel level, DomainRecord record, BlockPos pos) {
        return !level.isOutsideBuildHeight(pos)
                && level.hasChunkAt(pos)
                && record.state().bounds().contains(new DomainPosition(pos.getX(), pos.getY(), pos.getZ()));
    }

    private void synchronizeClient(
            ServerLevel level,
            DomainRecord record,
            ServerPlayer player,
            MemoryEnvironmentRuntime.Resolution resolution,
            LawRuntimeSemantics.Snapshot laws) {
        long dayTime = level instanceof VeilboundServerLevel domainLevel
                ? domainLevel.rememberedDayTime()
                : record.state().dayTime();
        boolean dayCycleAdvancing = resolution.active()
                && laws.time()
                && resolution.semantics().overworldDayCycle();
        boolean rememberedRainActive = resolution.active()
                && laws.weather()
                && resolution.semantics().rainWeather();
        int signature = Objects.hash(
                record.identity().dimensionId(), resolution.active(), resolution.memoryIds(),
                resolution.environmentalProfile(), resolution.zoneName(), dayTime / 20L,
                dayCycleAdvancing, rememberedRainActive);
        MemoryEnvironmentSnapshotPayload payload = resolution.active()
                ? new MemoryEnvironmentSnapshotPayload(
                        record.identity().dimensionId(), true, dayTime, dayCycleAdvancing,
                        rememberedRainActive, resolution.memoryIds(), resolution.environmentalProfile())
                : MemoryEnvironmentSnapshotPayload.inactive(record.identity().dimensionId(), dayTime);
        Integer previous = lastSentSignature.put(player.getUUID(), signature);
        if (previous == null || previous != signature) PacketDistributor.sendToPlayer(player, payload);
    }

}
