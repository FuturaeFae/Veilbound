package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Bounded server-authoritative Orrery environment snapshot for the local Domain client. */
public record MemoryEnvironmentSnapshotPayload(
        String dimensionId,
        boolean active,
        long domainDayTime,
        boolean dayCycleAdvancing,
        boolean rememberedRainActive,
        List<String> memoryIds,
        Map<String, String> environmentalProfile) implements CustomPacketPayload {
    public static final int MAX_MEMORIES = 16;
    public static final int MAX_PROFILE_ENTRIES = 32;
    public static final int MAX_ID_LENGTH = 256;
    public static final Type<MemoryEnvironmentSnapshotPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "memory_environment_snapshot"));

    public static final StreamCodec<RegistryFriendlyByteBuf, MemoryEnvironmentSnapshotPayload> STREAM_CODEC =
            new StreamCodec<>() {
                @Override
                public MemoryEnvironmentSnapshotPayload decode(RegistryFriendlyByteBuf buffer) {
                    String dimensionId = buffer.readUtf(MAX_ID_LENGTH);
                    boolean active = buffer.readBoolean();
                    long dayTime = buffer.readLong();
                    boolean dayCycleAdvancing = buffer.readBoolean();
                    boolean rememberedRainActive = buffer.readBoolean();
                    int memoryCount = buffer.readVarInt();
                    if (memoryCount < 0 || memoryCount > MAX_MEMORIES) {
                        throw new IllegalArgumentException("Invalid Memory environment id count: " + memoryCount);
                    }
                    List<String> ids = new ArrayList<>(memoryCount);
                    for (int i = 0; i < memoryCount; i++) ids.add(buffer.readUtf(MAX_ID_LENGTH));
                    int profileCount = buffer.readVarInt();
                    if (profileCount < 0 || profileCount > MAX_PROFILE_ENTRIES) {
                        throw new IllegalArgumentException("Invalid Memory environment profile count: " + profileCount);
                    }
                    LinkedHashMap<String, String> profile = new LinkedHashMap<>();
                    for (int i = 0; i < profileCount; i++) {
                        String key = buffer.readUtf(MAX_ID_LENGTH);
                        String value = buffer.readUtf(MAX_ID_LENGTH);
                        if (profile.put(key, value) != null) {
                            throw new IllegalArgumentException("Duplicate Memory environment profile key: " + key);
                        }
                    }
                    return new MemoryEnvironmentSnapshotPayload(
                            dimensionId, active, dayTime, dayCycleAdvancing, rememberedRainActive, ids, profile);
                }

                @Override
                public void encode(RegistryFriendlyByteBuf buffer, MemoryEnvironmentSnapshotPayload payload) {
                    buffer.writeUtf(payload.dimensionId(), MAX_ID_LENGTH);
                    buffer.writeBoolean(payload.active());
                    buffer.writeLong(payload.domainDayTime());
                    buffer.writeBoolean(payload.dayCycleAdvancing());
                    buffer.writeBoolean(payload.rememberedRainActive());
                    int memoryCount = Math.min(MAX_MEMORIES, payload.memoryIds().size());
                    buffer.writeVarInt(memoryCount);
                    for (int i = 0; i < memoryCount; i++) {
                        buffer.writeUtf(payload.memoryIds().get(i), MAX_ID_LENGTH);
                    }
                    int profileCount = Math.min(MAX_PROFILE_ENTRIES, payload.environmentalProfile().size());
                    buffer.writeVarInt(profileCount);
                    int written = 0;
                    for (Map.Entry<String, String> entry : payload.environmentalProfile().entrySet()) {
                        if (written++ >= profileCount) break;
                        buffer.writeUtf(entry.getKey(), MAX_ID_LENGTH);
                        buffer.writeUtf(entry.getValue(), MAX_ID_LENGTH);
                    }
                }
            };

    public MemoryEnvironmentSnapshotPayload {
        dimensionId = dimensionId == null ? "" : dimensionId;
        memoryIds = List.copyOf(memoryIds == null ? List.of() : memoryIds);
        environmentalProfile = Collections.unmodifiableMap(new LinkedHashMap<>(
                environmentalProfile == null ? Map.of() : environmentalProfile));
        if (memoryIds.size() > MAX_MEMORIES) throw new IllegalArgumentException("Too many active Memories");
        if (environmentalProfile.size() > MAX_PROFILE_ENTRIES) throw new IllegalArgumentException("Too many profile entries");
    }

    public static MemoryEnvironmentSnapshotPayload inactive(String dimensionId, long domainDayTime) {
        return new MemoryEnvironmentSnapshotPayload(
                dimensionId, false, domainDayTime, false, false, List.of(), Map.of());
    }

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
