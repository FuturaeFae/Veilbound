package dev.futurae.veilbound.memory;

/**
 * Reloadable development tuning for concrete Memory mechanics.
 *
 * <p>These numbers are intentionally policy data rather than progression constants: the Memory
 * definitions choose <em>what</em> an Orrery remembers, while this policy controls how frequently
 * the base runtime samples or reinforces those effects.</p>
 */
public record MemoryEffectPolicy(
        int evaluationTicks,
        int forcedRainRefreshTicks,
        int fertilityPulseTicks,
        int fertilityAttemptsPerPlayer,
        int fertilityHorizontalRadius,
        int fertilityVerticalRadius) {

    public static final MemoryEffectPolicy DEVELOPMENT_DEFAULT =
            new MemoryEffectPolicy(20, 2400, 40, 8, 8, 3);

    public MemoryEffectPolicy {
        if (evaluationTicks <= 0) throw new IllegalArgumentException("evaluationTicks must be > 0");
        if (forcedRainRefreshTicks <= 0) throw new IllegalArgumentException("forcedRainRefreshTicks must be > 0");
        if (fertilityPulseTicks <= 0) throw new IllegalArgumentException("fertilityPulseTicks must be > 0");
        if (fertilityAttemptsPerPlayer < 0 || fertilityAttemptsPerPlayer > 256) {
            throw new IllegalArgumentException("fertilityAttemptsPerPlayer must be in [0, 256]");
        }
        if (fertilityHorizontalRadius < 0 || fertilityHorizontalRadius > 64) {
            throw new IllegalArgumentException("fertilityHorizontalRadius must be in [0, 64]");
        }
        if (fertilityVerticalRadius < 0 || fertilityVerticalRadius > 32) {
            throw new IllegalArgumentException("fertilityVerticalRadius must be in [0, 32]");
        }
    }
}
