package dev.futurae.veilbound.platform.neoforge.travel;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.function.BooleanSupplier;

/**
 * Server-thread reentrancy guard for Veilbound-owned dimension changes.
 *
 * <p>NeoForge fires PlayerChangedDimensionEvent for the same teleports Veilbound performs. Presence
 * reconciliation must ignore those events because the travel executor is already applying the
 * authoritative state transition transactionally.</p>
 */
public final class NeoForgeTransitGuard {
    private static final ThreadLocal<Map<UUID, Integer>> DEPTH = ThreadLocal.withInitial(HashMap::new);

    private NeoForgeTransitGuard() {}

    public static boolean isInternal(UUID playerId) {
        Objects.requireNonNull(playerId, "playerId");
        return DEPTH.get().getOrDefault(playerId, 0) > 0;
    }

    public static boolean run(UUID playerId, BooleanSupplier action) {
        Objects.requireNonNull(playerId, "playerId");
        Objects.requireNonNull(action, "action");
        Map<UUID, Integer> depths = DEPTH.get();
        depths.merge(playerId, 1, Integer::sum);
        try {
            return action.getAsBoolean();
        } finally {
            int next = depths.getOrDefault(playerId, 1) - 1;
            if (next <= 0) depths.remove(playerId);
            else depths.put(playerId, next);
            if (depths.isEmpty()) DEPTH.remove();
        }
    }
}
