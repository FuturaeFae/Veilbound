package dev.futurae.veilbound.threshold;

import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 * Centralizes the invariant that guests cannot remain in an owner's Domain after that owner
 * leaves it or unloads. The returned sessions tell the platform layer exactly where each guest
 * must be teleported back to.
 */
public final class DomainPresenceCoordinator {
    private final ThresholdSessionManager sessions;

    public DomainPresenceCoordinator(ThresholdSessionManager sessions) {
        this.sessions = Objects.requireNonNull(sessions, "sessions");
    }

    /**
     * Non-destructive evacuation plan for live platform teleports. Sessions remain authoritative
     * until each guest has actually reached their return location.
     */
    public List<GuestThresholdSession> guestsRequiringEvacuation(UUID ownerId) {
        return sessions.sessionsForOwner(Objects.requireNonNull(ownerId, "ownerId"));
    }

    public boolean completeGuestEvacuation(UUID ownerId, UUID guestId) {
        return sessions.completeGuestEvacuation(
                Objects.requireNonNull(guestId, "guestId"),
                Objects.requireNonNull(ownerId, "ownerId"));
    }

    public List<GuestThresholdSession> ownerLeftDomain(UUID ownerId) {
        return sessions.evacuateOwnerDomain(Objects.requireNonNull(ownerId, "ownerId"));
    }

    public List<GuestThresholdSession> ownerDisconnected(UUID ownerId) {
        return sessions.evacuateOwnerDomain(Objects.requireNonNull(ownerId, "ownerId"));
    }

    public List<GuestThresholdSession> ownerDomainUnloaded(UUID ownerId) {
        return sessions.evacuateOwnerDomain(Objects.requireNonNull(ownerId, "ownerId"));
    }
}
