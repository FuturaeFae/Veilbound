package dev.futurae.veilbound.threshold;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/**
 * One-shot portal touch latch.
 *
 * <p>A successful Threshold transit arms the player. The latch stays armed until platform code
 * confirms the player has physically left all active portal cells, preventing exact-return
 * anchors inside the source portal from immediately sending the player back.</p>
 */
public final class PortalTouchLatch {
    private final Set<UUID> armed = new HashSet<>();

    public boolean isArmed(UUID playerId) {
        return armed.contains(Objects.requireNonNull(playerId, "playerId"));
    }

    public void arm(UUID playerId) {
        armed.add(Objects.requireNonNull(playerId, "playerId"));
    }

    public void clear(UUID playerId) {
        armed.remove(Objects.requireNonNull(playerId, "playerId"));
    }

    public int armedCount() { return armed.size(); }
}
