package dev.futurae.veilbound.breach;

/** Dedicated Veilbound creatures that may emerge from an open breach. */
public enum VoidCreatureType {
    VOID_CRAWLER,
    RIFT_STALKER,
    NULL_WRAITH
}
