package dev.futurae.veilbound.memory;

import dev.futurae.veilbound.domain.DomainFeature;
import java.util.Map;
import java.util.Set;

/** Unlockable remembered-reality profile exposed through the Archive/Orrery progression. */
public record MemoryDefinition(
        String id,
        String displayName,
        Set<String> tags,
        Map<String, String> environmentalProfile,
        Map<String, String> captureConditions,
        Set<String> prerequisiteMemoryIds,
        Set<DomainFeature> unlockedFeatures) {

    public MemoryDefinition {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("id may not be blank");
        if (displayName == null || displayName.isBlank()) throw new IllegalArgumentException("displayName may not be blank");
        tags = Set.copyOf(tags == null ? Set.of() : tags);
        environmentalProfile = Map.copyOf(environmentalProfile == null ? Map.of() : environmentalProfile);
        captureConditions = Map.copyOf(captureConditions == null ? Map.of() : captureConditions);
        prerequisiteMemoryIds = Set.copyOf(prerequisiteMemoryIds == null ? Set.of() : prerequisiteMemoryIds);
        unlockedFeatures = Set.copyOf(unlockedFeatures == null ? Set.of() : unlockedFeatures);
    }

    /** Compatibility constructor used by the first prerequisite-capable Memory implementation. */
    public MemoryDefinition(
            String id,
            String displayName,
            Set<String> tags,
            Map<String, String> environmentalProfile,
            Set<String> prerequisiteMemoryIds,
            Set<DomainFeature> unlockedFeatures) {
        this(id, displayName, tags, environmentalProfile, Map.of(), prerequisiteMemoryIds, unlockedFeatures);
    }

    /** Compatibility constructor for the initial implementation slice. */
    public MemoryDefinition(String id, String displayName, Set<String> tags, Map<String, String> environmentalProfile) {
        this(id, displayName, tags, environmentalProfile, Map.of(), Set.of(), Set.of());
    }
}
