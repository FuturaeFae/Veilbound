package dev.futurae.veilbound.domain;

import java.util.Objects;

/**
 * Central sterile-Domain gates. Fresh Domains return false for every living/environmental
 * process here; unlocks are earned through the progression systems rather than vanilla rules.
 */
public final class DomainEcologyRules {
    private DomainEcologyRules() {}

    public static boolean allowsCropAndPlantGrowth(DomainState state) {
        return has(state, DomainFeature.FERTILITY);
    }

    public static boolean allowsTreeGrowth(DomainState state) {
        return has(state, DomainFeature.FERTILITY) && has(state, DomainFeature.ARBOREAL_GROWTH);
    }

    public static boolean allowsNormalPassiveLife(DomainState state) {
        return has(state, DomainFeature.LIFE);
    }

    public static boolean allowsNormalPredatoryLife(DomainState state) {
        return has(state, DomainFeature.LIFE) && has(state, DomainFeature.PREDATION);
    }

    public static boolean allowsWeather(DomainState state) {
        return has(state, DomainFeature.WEATHER);
    }

    public static boolean allowsCelestialCycle(DomainState state) {
        return has(state, DomainFeature.CELESTIAL_CYCLE);
    }

    public static boolean allowsAmbientEnvironment(DomainState state) {
        return has(state, DomainFeature.AMBIENCE);
    }

    private static boolean has(DomainState state, DomainFeature feature) {
        return Objects.requireNonNull(state, "state").hasFeature(feature);
    }
}
