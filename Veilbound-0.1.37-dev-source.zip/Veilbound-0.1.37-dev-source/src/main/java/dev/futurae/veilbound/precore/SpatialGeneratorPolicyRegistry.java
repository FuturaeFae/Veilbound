package dev.futurae.veilbound.precore;

import java.util.Objects;

/** Replace-all holder for datapack reloads. */
public final class SpatialGeneratorPolicyRegistry {
    private SpatialGeneratorRuntimePolicy policy = SpatialGeneratorRuntimePolicy.DEVELOPMENT_DEFAULT;
    public SpatialGeneratorRuntimePolicy policy() { return policy; }
    public void replace(SpatialGeneratorRuntimePolicy policy) { this.policy = Objects.requireNonNull(policy, "policy"); }
}
