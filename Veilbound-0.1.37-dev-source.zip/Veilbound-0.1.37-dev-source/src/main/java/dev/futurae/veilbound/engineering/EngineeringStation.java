package dev.futurae.veilbound.engineering;

public enum EngineeringStation {
    DIMENSIONAL_FABRICATOR,
    VEIL_FOUNDRY
}
