package dev.futurae.veilbound.domain;

import dev.futurae.veilbound.breach.Breach;
import dev.futurae.veilbound.environment.EnvironmentZone;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/** Persisted owner-authoritative state for one personal Domain. */
public final class DomainState {
    /** Initial Core ritual requires the pre-Core Domain to reach a 3x3 footprint and 2-block height. */
    public static final int INITIAL_CORE_MIN_SIZE_X = 3;
    public static final int INITIAL_CORE_MIN_SIZE_Y = 2;
    public static final int INITIAL_CORE_MIN_SIZE_Z = 3;
    private final UUID ownerId;
    private DomainLifecycle lifecycle;
    private CoreTier coreTier;
    private DomainPosition corePosition;
    private DomainBounds bounds;
    private long dimensionalEnergy;
    private final Map<String, Long> coreUpgradeFedItems;
    private final EnumMap<AxisDirection, BoundaryPylonState> pylons;
    private final Set<String> imposedLawIds;
    private final Set<String> unlockedMemoryIds;
    private final Set<String> completedMilestoneIds;
    private final EnumSet<DomainFeature> unlockedFeatures;
    private final List<EnvironmentZone> environmentZones;
    private final List<Breach> breaches;
    private final Set<DomainPosition> continuityAnchors;
    private double fractureMeter;
    private long dayTime;
    private int clearWeatherTime;
    private boolean raining;
    private int rainTime;
    private boolean thundering;
    private int thunderTime;
    private boolean globalExpansionEnabled;
    private boolean sovereigntyUnlocked;
    private Runnable mutationListener = () -> {};

    public DomainState(UUID ownerId) {
        this.ownerId = Objects.requireNonNull(ownerId, "ownerId");
        this.lifecycle = DomainLifecycle.PRE_CORE;
        this.coreTier = CoreTier.NASCENT;
        this.corePosition = DomainPosition.ORIGIN;
        this.bounds = DomainBounds.initial();
        this.dimensionalEnergy = 0;
        this.coreUpgradeFedItems = new LinkedHashMap<>();
        this.pylons = new EnumMap<>(AxisDirection.class);
        for (AxisDirection direction : AxisDirection.values()) {
            pylons.put(direction, new BoundaryPylonState(direction, false, false, null, BoundaryPylonSpeed.STABLE));
        }
        this.imposedLawIds = new HashSet<>();
        this.unlockedMemoryIds = new HashSet<>();
        this.completedMilestoneIds = new java.util.LinkedHashSet<>();
        this.unlockedFeatures = EnumSet.noneOf(DomainFeature.class);
        this.environmentZones = new ArrayList<>();
        this.breaches = new ArrayList<>();
        this.continuityAnchors = new HashSet<>();
        this.fractureMeter = 0.0;
        this.dayTime = 0L;
        this.clearWeatherTime = 0;
        this.raining = false;
        this.rainTime = 0;
        this.thundering = false;
        this.thunderTime = 0;
        this.globalExpansionEnabled = true;
    }

    public UUID ownerId() { return ownerId; }
    public DomainLifecycle lifecycle() { return lifecycle; }
    public boolean coreActive() { return lifecycle == DomainLifecycle.CORE_ACTIVE; }
    public CoreTier coreTier() { return coreTier; }
    public DomainPosition corePosition() { return corePosition; }
    public DomainBounds bounds() { return bounds; }
    public long dimensionalEnergy() { return dimensionalEnergy; }
    public Map<String, Long> coreUpgradeFedItems() { return Map.copyOf(coreUpgradeFedItems); }
    public EnumMap<AxisDirection, BoundaryPylonState> pylons() { return new EnumMap<>(pylons); }
    public Set<String> imposedLawIds() { return Set.copyOf(imposedLawIds); }
    public Set<String> unlockedMemoryIds() { return Set.copyOf(unlockedMemoryIds); }
    public Set<String> completedMilestoneIds() { return Set.copyOf(completedMilestoneIds); }
    public Set<DomainFeature> unlockedFeatures() { return Set.copyOf(unlockedFeatures); }
    public List<EnvironmentZone> environmentZones() { return List.copyOf(environmentZones); }
    public List<Breach> breaches() { return List.copyOf(breaches); }
    public Set<DomainPosition> continuityAnchors() { return Set.copyOf(continuityAnchors); }
    public double fractureMeter() { return fractureMeter; }
    public long dayTime() { return dayTime; }
    public int clearWeatherTime() { return clearWeatherTime; }
    public boolean raining() { return raining; }
    public int rainTime() { return rainTime; }
    public boolean thundering() { return thundering; }
    public int thunderTime() { return thunderTime; }
    public boolean hasOpenBreach() { return breaches.stream().anyMatch(Breach::open); }
    public boolean globalExpansionEnabled() { return globalExpansionEnabled; }
    public boolean sovereigntyUnlocked() { return sovereigntyUnlocked; }

    public boolean hasInitialCoreSpace() {
        return bounds.sizeX() >= INITIAL_CORE_MIN_SIZE_X
                && bounds.sizeY() >= INITIAL_CORE_MIN_SIZE_Y
                && bounds.sizeZ() >= INITIAL_CORE_MIN_SIZE_Z;
    }

    /** Core ritual is only valid at the authoritative Domain origin after pre-Core spatial growth. */
    public void awakenCore(DomainPosition ritualPosition) {
        Objects.requireNonNull(ritualPosition, "ritualPosition");
        if (coreActive()) throw new IllegalStateException("Core is already active");
        if (!DomainPosition.ORIGIN.equals(ritualPosition)) {
            throw new IllegalArgumentException("Initial Core ritual must occur at Domain origin");
        }
        if (!hasInitialCoreSpace()) {
            throw new IllegalStateException("Initial Core ritual requires at least a 3x3 horizontal Domain with 2 blocks of height");
        }
        this.lifecycle = DomainLifecycle.CORE_ACTIVE;
        this.corePosition = ritualPosition;
        // Awakening consumes 50,000 Condensed Charge. The dimensional collapse leaves the
        // new Nascent Core with a one-time ignition reserve equal to its full DE capacity,
        // allowing the first Transducer/Fabricator bootstrap without inventing a pre-Core
        // DE source. All later DE is produced by normal Domain machinery.
        this.dimensionalEnergy = this.coreTier.dimensionalEnergyCapacity();
        changed();
    }

    /** Relocation is intentionally a ritual-level operation; validation belongs to the ritual service. */
    public void relocateCore(DomainPosition newPosition) {
        if (!coreActive()) throw new IllegalStateException("Cannot relocate a Core before awakening it");
        if (!bounds.contains(newPosition)) throw new IllegalArgumentException("Core must remain inside Domain bounds");
        this.corePosition = Objects.requireNonNull(newPosition, "newPosition");
        changed();
    }

    public void setDimensionalEnergy(long amount) {
        requireCore();
        if (amount < 0 || amount > coreTier.dimensionalEnergyCapacity()) {
            throw new IllegalArgumentException("Dimensional Energy outside Core capacity");
        }
        this.dimensionalEnergy = amount;
        changed();
    }

    public long insertDimensionalEnergy(long amount) {
        requireCore();
        if (amount <= 0) return 0;
        long accepted = Math.min(amount, coreTier.dimensionalEnergyCapacity() - dimensionalEnergy);
        dimensionalEnergy += accepted;
        if (accepted > 0) changed();
        return accepted;
    }

    public boolean consumeDimensionalEnergy(long amount) {
        requireCore();
        if (amount < 0) throw new IllegalArgumentException("amount must be >= 0");
        if (dimensionalEnergy < amount) return false;
        dimensionalEnergy -= amount;
        if (amount > 0) changed();
        return true;
    }

    public void setBounds(DomainBounds bounds) {
        DomainBounds candidate = Objects.requireNonNull(bounds, "bounds");
        if (!candidate.contains(corePosition)) {
            throw new IllegalArgumentException("Domain bounds may not exclude the Core/origin position");
        }
        if (!this.bounds.equals(candidate)) {
            this.bounds = candidate;
            changed();
        }
    }

    public void setCoreTier(CoreTier tier) {
        requireCore();
        CoreTier next = Objects.requireNonNull(tier, "tier");
        if (this.coreTier != next) coreUpgradeFedItems.clear();
        this.coreTier = next;
        this.dimensionalEnergy = Math.min(dimensionalEnergy, tier.dimensionalEnergyCapacity());
        changed();
    }

    public long feedCoreUpgradeItem(String itemId, long offeredCount, long requiredTotal) {
        requireCore();
        Objects.requireNonNull(itemId, "itemId");
        if (offeredCount <= 0 || requiredTotal <= 0) return 0L;
        long already = coreUpgradeFedItems.getOrDefault(itemId, 0L);
        long accepted = Math.min(offeredCount, Math.max(0L, requiredTotal - already));
        if (accepted > 0) {
            coreUpgradeFedItems.put(itemId, already + accepted);
            changed();
        }
        return accepted;
    }

    public void replaceCoreUpgradeFeed(Map<String, Long> fed) {
        Objects.requireNonNull(fed, "fed");
        LinkedHashMap<String, Long> replacement = new LinkedHashMap<>();
        for (var entry : fed.entrySet()) {
            String id = Objects.requireNonNull(entry.getKey(), "itemId");
            long count = Objects.requireNonNull(entry.getValue(), "count");
            if (id.isBlank() || count <= 0) throw new IllegalArgumentException("Invalid Core upgrade feed entry");
            replacement.put(id, count);
        }
        coreUpgradeFedItems.clear();
        coreUpgradeFedItems.putAll(replacement);
        changed();
    }

    public void clearCoreUpgradeFeed() {
        if (!coreUpgradeFedItems.isEmpty()) {
            coreUpgradeFedItems.clear();
            changed();
        }
    }

    public void setPylon(BoundaryPylonState pylon) {
        requireCore();
        pylons.put(pylon.direction(), pylon);
        changed();
    }

    public void imposeLaw(String lawId) { if (imposedLawIds.add(Objects.requireNonNull(lawId))) changed(); }
    public void repealLaw(String lawId) { if (imposedLawIds.remove(lawId)) changed(); }
    public void unlockMemory(String memoryId) { if (unlockedMemoryIds.add(Objects.requireNonNull(memoryId))) changed(); }
    public void revokeMemory(String memoryId) { if (unlockedMemoryIds.remove(memoryId)) changed(); }
    public boolean completeMilestone(String milestoneId) {
        String id = Objects.requireNonNull(milestoneId, "milestoneId");
        if (id.isBlank()) throw new IllegalArgumentException("milestoneId may not be blank");
        boolean added = completedMilestoneIds.add(id);
        if (added) changed();
        return added;
    }
    public void restoreCompletedMilestones(Set<String> milestoneIds) {
        Objects.requireNonNull(milestoneIds, "milestoneIds");
        java.util.LinkedHashSet<String> replacement = new java.util.LinkedHashSet<>();
        for (String id : milestoneIds) {
            String value = Objects.requireNonNull(id, "milestoneId");
            if (value.isBlank()) throw new IllegalArgumentException("milestoneId may not be blank");
            replacement.add(value);
        }
        if (!completedMilestoneIds.equals(replacement)) {
            completedMilestoneIds.clear();
            completedMilestoneIds.addAll(replacement);
            changed();
        }
    }
    public void unlockFeature(DomainFeature feature) { if (unlockedFeatures.add(Objects.requireNonNull(feature))) changed(); }
    public void revokeFeature(DomainFeature feature) { if (unlockedFeatures.remove(feature)) changed(); }
    public boolean hasFeature(DomainFeature feature) { return unlockedFeatures.contains(feature); }

    public void addEnvironmentZone(EnvironmentZone zone) {
        Objects.requireNonNull(zone, "zone");
        if (!bounds.contains(zone.bounds())) throw new IllegalArgumentException("Environmental Zone must be inside Domain bounds");
        if (environmentZones.stream().anyMatch(existing -> existing.id().equals(zone.id()))) {
            throw new IllegalArgumentException("Environmental Zone id already exists");
        }
        environmentZones.add(zone);
        changed();
    }

    public void replaceEnvironmentZone(EnvironmentZone zone) {
        Objects.requireNonNull(zone, "zone");
        if (!bounds.contains(zone.bounds())) throw new IllegalArgumentException("Environmental Zone must be inside Domain bounds");
        for (int i = 0; i < environmentZones.size(); i++) {
            if (environmentZones.get(i).id().equals(zone.id())) {
                environmentZones.set(i, zone);
                changed();
                return;
            }
        }
        throw new IllegalArgumentException("Unknown Environmental Zone: " + zone.id());
    }

    public void removeEnvironmentZone(UUID zoneId) { if (environmentZones.removeIf(z -> z.id().equals(zoneId))) changed(); }

    public void addBreach(Breach breach) {
        Objects.requireNonNull(breach, "breach");
        if (breaches.stream().anyMatch(existing -> existing.id().equals(breach.id()))) {
            throw new IllegalArgumentException("Breach id already exists");
        }
        breaches.add(breach);
        changed();
    }

    public void replaceBreach(Breach breach) {
        Objects.requireNonNull(breach, "breach");
        for (int i = 0; i < breaches.size(); i++) {
            if (breaches.get(i).id().equals(breach.id())) {
                breaches.set(i, breach);
                changed();
                return;
            }
        }
        throw new IllegalArgumentException("Unknown breach: " + breach.id());
    }

    public void removeSealedBreaches() { if (breaches.removeIf(breach -> !breach.open())) changed(); }

    public void addContinuityAnchor(DomainPosition position) {
        requireCore();
        DomainPosition candidate = Objects.requireNonNull(position, "position");
        if (!bounds.contains(candidate)) throw new IllegalArgumentException("Continuity Anchor must be inside Domain bounds");
        if (continuityAnchors.add(candidate)) changed();
    }

    public void removeContinuityAnchor(DomainPosition position) {
        if (continuityAnchors.remove(Objects.requireNonNull(position, "position"))) changed();
    }

    public void setFractureMeter(double amount) {
        requireCore();
        if (!Double.isFinite(amount) || amount < 0) throw new IllegalArgumentException("fracture meter must be finite and >= 0");
        if (Double.compare(fractureMeter, amount) != 0) {
            fractureMeter = amount;
            changed();
        }
    }


    public void setDayTime(long dayTime) {
        if (this.dayTime != dayTime) {
            this.dayTime = dayTime;
            changed();
        }
    }

    public void setWeatherState(
            int clearWeatherTime, boolean raining, int rainTime, boolean thundering, int thunderTime) {
        if (clearWeatherTime < 0 || rainTime < 0 || thunderTime < 0) {
            throw new IllegalArgumentException("weather timers must be >= 0");
        }
        if (this.clearWeatherTime != clearWeatherTime
                || this.raining != raining
                || this.rainTime != rainTime
                || this.thundering != thundering
                || this.thunderTime != thunderTime) {
            this.clearWeatherTime = clearWeatherTime;
            this.raining = raining;
            this.rainTime = rainTime;
            this.thundering = thundering;
            this.thunderTime = thunderTime;
            changed();
        }
    }


    public void setGlobalExpansionEnabled(boolean value) {
        requireCore();
        if (globalExpansionEnabled != value) {
            globalExpansionEnabled = value;
            changed();
        }
    }

    public boolean toggleGlobalExpansion() {
        setGlobalExpansionEnabled(!globalExpansionEnabled);
        return globalExpansionEnabled;
    }

    public void setSovereigntyUnlocked(boolean value) { if (sovereigntyUnlocked != value) { sovereigntyUnlocked = value; changed(); } }

    public void setMutationListener(Runnable listener) {
        this.mutationListener = Objects.requireNonNull(listener, "listener");
    }

    private void changed() { mutationListener.run(); }

    private void requireCore() {
        if (!coreActive()) throw new IllegalStateException("Dimensional Core is not active");
    }
}
