package dev.futurae.veilbound.persistence;

import dev.futurae.veilbound.breach.Breach;
import dev.futurae.veilbound.breach.BreachSeverity;
import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.BoundaryPylonState;
import dev.futurae.veilbound.domain.BoundaryPylonSpeed;
import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainLifecycle;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.environment.EnvironmentZone;
import dev.futurae.veilbound.travel.ReturnAnchor;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Small versioned binary payload carried by Minecraft SavedData through Codec.STRING.
 * Keeping this loader-neutral lets persistence round-trip tests run without a Minecraft runtime.
 */
public final class VeilboundSnapshotBinaryCodec {
    private static final int MAGIC = 0x5645494C; // VEIL
    private static final int VERSION = 14;
    private static final int MIN_SUPPORTED_VERSION = 1;
    private static final int MAX_COLLECTION = 1_000_000;

    private VeilboundSnapshotBinaryCodec() {}

    public static String encode(VeilboundPersistenceSnapshot snapshot) {
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (DataOutputStream out = new DataOutputStream(bytes)) {
                out.writeInt(MAGIC);
                out.writeInt(VERSION);
                writeDomains(out, snapshot.domains());
                writeThresholds(out, snapshot.thresholds());
            }
            return Base64.getEncoder().encodeToString(bytes.toByteArray());
        } catch (IOException impossible) {
            throw new IllegalStateException("Unexpected in-memory persistence failure", impossible);
        }
    }

    public static VeilboundPersistenceSnapshot decode(String payload) {
        if (payload == null || payload.isBlank()) return new VeilboundPersistenceSnapshot(List.of(), List.of());
        try {
            byte[] bytes = Base64.getDecoder().decode(payload);
            try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(bytes))) {
                if (in.readInt() != MAGIC) throw new IllegalArgumentException("Not Veilbound persistence data");
                int version = in.readInt();
                if (version < MIN_SUPPORTED_VERSION || version > VERSION) {
                    throw new IllegalArgumentException("Unsupported Veilbound persistence version: " + version);
                }
                VeilboundPersistenceSnapshot snapshot = new VeilboundPersistenceSnapshot(readDomains(in, version), readThresholds(in, version));
                if (in.available() != 0) throw new IllegalArgumentException("Trailing bytes in Veilbound persistence payload");
                return snapshot;
            }
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (EOFException e) {
            throw new IllegalArgumentException("Truncated Veilbound persistence payload", e);
        } catch (IOException e) {
            throw new IllegalArgumentException("Unable to decode Veilbound persistence payload", e);
        }
    }

    private static void writeDomains(DataOutputStream out, List<DomainRecordSnapshot> domains) throws IOException {
        out.writeInt(domains.size());
        for (DomainRecordSnapshot record : domains) {
            writeUuid(out, record.ownerId());
            writeString(out, record.dimensionId());
            out.writeLong(record.seed());
            out.writeBoolean(record.starterPocketInitialized());
            writeDomain(out, record.domain());
            writeVeilInventory(out, record.veilInventory());
            writeMatterTransmutation(out, record.matterTransmutation());
            writeMemoryProgress(out, record.memoryProgress());
            out.writeBoolean(record.ownerReturnAnchor() != null);
            if (record.ownerReturnAnchor() != null) writeAnchor(out, record.ownerReturnAnchor());
        }
    }

    private static List<DomainRecordSnapshot> readDomains(DataInputStream in, int version) throws IOException {
        int count = readCount(in, "domains");
        List<DomainRecordSnapshot> result = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            UUID owner = readUuid(in);
            String dimensionId = readString(in);
            long seed = in.readLong();
            boolean starterPocketInitialized = version >= 2 && in.readBoolean();
            DomainSnapshot domain = readDomain(in, version);
            VeilInventorySnapshot veilInventory = version >= 4 ? readVeilInventory(in) : VeilInventorySnapshot.EMPTY;
            MatterTransmutationSnapshot matterTransmutation = version >= 5 ? readMatterTransmutation(in, version) : MatterTransmutationSnapshot.EMPTY;
            MemoryProgressSnapshot memoryProgress = version >= 7 ? readMemoryProgress(in) : MemoryProgressSnapshot.EMPTY;
            ReturnAnchor anchor = in.readBoolean() ? readAnchor(in) : null;
            result.add(new DomainRecordSnapshot(owner, dimensionId, seed, starterPocketInitialized, domain, veilInventory, matterTransmutation, memoryProgress, anchor));
        }
        return result;
    }

    private static void writeDomain(DataOutputStream out, DomainSnapshot s) throws IOException {
        writeUuid(out, s.ownerId());
        writeEnum(out, s.lifecycle());
        writeEnum(out, s.coreTier());
        writePosition(out, s.corePosition());
        writeBounds(out, s.bounds());
        out.writeLong(s.dimensionalEnergy());
        out.writeInt(s.coreUpgradeFedItems().size());
        for (var entry : s.coreUpgradeFedItems().entrySet()) {
            writeString(out, entry.getKey());
            out.writeLong(entry.getValue());
        }

        out.writeInt(AxisDirection.values().length);
        for (AxisDirection direction : AxisDirection.values()) {
            BoundaryPylonState pylon = s.pylons().get(direction);
            out.writeBoolean(pylon != null);
            if (pylon != null) {
                writeEnum(out, pylon.direction());
                out.writeBoolean(pylon.expansionEnabled());
                out.writeBoolean(pylon.online());
                out.writeBoolean(pylon.blockPosition() != null);
                if (pylon.blockPosition() != null) writePosition(out, pylon.blockPosition());
                writeEnum(out, pylon.speed());
            }
        }
        writeStrings(out, s.imposedLawIds());
        writeStrings(out, s.unlockedMemoryIds());
        out.writeInt(s.unlockedFeatures().size());
        for (DomainFeature feature : s.unlockedFeatures()) writeEnum(out, feature);
        writeStrings(out, s.completedMilestoneIds());

        out.writeInt(s.environmentZones().size());
        for (EnvironmentZone zone : s.environmentZones()) {
            writeUuid(out, zone.id());
            writeString(out, zone.name());
            writeBounds(out, zone.bounds());
            writeString(out, zone.memoryProfileId());
            out.writeInt(zone.parameters().size());
            for (var entry : zone.parameters().entrySet()) {
                writeString(out, entry.getKey());
                writeString(out, entry.getValue());
            }
        }

        out.writeInt(s.breaches().size());
        for (Breach breach : s.breaches()) {
            writeUuid(out, breach.id());
            writePosition(out, breach.position());
            writeEnum(out, breach.veilFace());
            writeEnum(out, breach.severity());
            out.writeBoolean(breach.open());
            out.writeLong(breach.openedGameTick());
        }
        out.writeInt(s.continuityAnchors().size());
        for (DomainPosition anchor : s.continuityAnchors()) writePosition(out, anchor);
        out.writeDouble(s.fractureMeter());
        out.writeLong(s.dayTime());
        out.writeInt(s.clearWeatherTime());
        out.writeBoolean(s.raining());
        out.writeInt(s.rainTime());
        out.writeBoolean(s.thundering());
        out.writeInt(s.thunderTime());
        out.writeBoolean(s.globalExpansionEnabled());
        out.writeBoolean(s.sovereigntyUnlocked());
    }

    private static DomainSnapshot readDomain(DataInputStream in, int version) throws IOException {
        UUID owner = readUuid(in);
        DomainLifecycle lifecycle = readEnum(in, DomainLifecycle.class);
        CoreTier coreTier = readEnum(in, CoreTier.class);
        DomainPosition corePosition = readPosition(in);
        DomainBounds bounds = readBounds(in);
        long de = in.readLong();
        Map<String, Long> coreUpgradeFedItems = new LinkedHashMap<>();
        if (version >= 11) {
            int coreFeedCount = readCount(in, "Core upgrade feed entries");
            for (int i = 0; i < coreFeedCount; i++) {
                String itemId = readString(in);
                long count = in.readLong();
                if (itemId.isBlank() || count <= 0 || coreUpgradeFedItems.putIfAbsent(itemId, count) != null) {
                    throw new IllegalArgumentException("Invalid or duplicate Core upgrade feed entry");
                }
            }
        }

        int pylonSlots = readCount(in, "pylons");
        if (pylonSlots != AxisDirection.values().length) throw new IllegalArgumentException("Unexpected pylon slot count");
        Map<AxisDirection, BoundaryPylonState> pylons = new EnumMap<>(AxisDirection.class);
        for (int i = 0; i < pylonSlots; i++) {
            if (in.readBoolean()) {
                AxisDirection direction = readEnum(in, AxisDirection.class);
                boolean expansionEnabled = in.readBoolean();
                boolean online = in.readBoolean();
                if (version >= 11) {
                    DomainPosition blockPosition = in.readBoolean() ? readPosition(in) : null;
                    if (online && blockPosition == null) {
                        throw new IllegalArgumentException("Online Boundary Pylon is missing its physical binding");
                    }
                    if (!online && expansionEnabled) {
                        throw new IllegalArgumentException("Offline Boundary Pylon may not keep expansion enabled");
                    }
                    BoundaryPylonSpeed speed = version >= 13
                            ? readEnum(in, BoundaryPylonSpeed.class)
                            : BoundaryPylonSpeed.STABLE;
                    pylons.put(direction, new BoundaryPylonState(direction, expansionEnabled, online, blockPosition, speed));
                } else {
                    // v1-v10 did not persist physical pylon positions and could mark all six slots online.
                    // Fail closed on migration: the next physical interaction rebinds the real block.
                    pylons.put(direction, new BoundaryPylonState(direction, false, false, null));
                }
            }
        }
        Set<String> laws = readStrings(in, "laws");
        Set<String> memories = readStrings(in, "memories");
        int featureCount = readCount(in, "features");
        Set<DomainFeature> features = new LinkedHashSet<>();
        for (int i = 0; i < featureCount; i++) features.add(readEnum(in, DomainFeature.class));
        Set<String> completedMilestones = version >= 12 ? readStrings(in, "milestones") : Set.of();

        int zoneCount = readCount(in, "environment zones");
        List<EnvironmentZone> zones = new ArrayList<>(zoneCount);
        for (int i = 0; i < zoneCount; i++) {
            UUID id = readUuid(in);
            String name = readString(in);
            DomainBounds zoneBounds = readBounds(in);
            String memory = readString(in);
            int parameterCount = readCount(in, "zone parameters");
            Map<String, String> parameters = new LinkedHashMap<>();
            for (int p = 0; p < parameterCount; p++) parameters.put(readString(in), readString(in));
            zones.add(new EnvironmentZone(id, name, zoneBounds, memory, parameters));
        }

        int breachCount = readCount(in, "breaches");
        List<Breach> breaches = new ArrayList<>(breachCount);
        for (int i = 0; i < breachCount; i++) {
            breaches.add(new Breach(
                    readUuid(in), readPosition(in), readEnum(in, AxisDirection.class),
                    readEnum(in, BreachSeverity.class), in.readBoolean(), in.readLong()));
        }
        Set<DomainPosition> continuityAnchors = new LinkedHashSet<>();
        double fractureMeter = 0.0;
        if (version >= 8) {
            int anchorCount = readCount(in, "continuity anchors");
            for (int i = 0; i < anchorCount; i++) {
                DomainPosition anchor = readPosition(in);
                if (!continuityAnchors.add(anchor)) throw new IllegalArgumentException("Duplicate Continuity Anchor position");
            }
            fractureMeter = in.readDouble();
            if (!Double.isFinite(fractureMeter) || fractureMeter < 0) throw new IllegalArgumentException("Invalid fracture meter");
        }
        long dayTime = 0L;
        int clearWeatherTime = 0;
        boolean raining = false;
        int rainTime = 0;
        boolean thundering = false;
        int thunderTime = 0;
        if (version >= 9) {
            dayTime = in.readLong();
            clearWeatherTime = in.readInt();
            raining = in.readBoolean();
            rainTime = in.readInt();
            thundering = in.readBoolean();
            thunderTime = in.readInt();
            if (clearWeatherTime < 0 || rainTime < 0 || thunderTime < 0) {
                throw new IllegalArgumentException("Invalid Domain weather timers");
            }
        }
        boolean globalExpansionEnabled = true;
        if (version >= 10) {
            globalExpansionEnabled = in.readBoolean();
            // v10-v13 persisted a Core Matter Intake toggle. The Core is DE-only from v14 onward;
            // consume and discard that legacy bit so old development saves remain readable.
            if (version <= 13) in.readBoolean();
        }
        boolean sovereignty = in.readBoolean();
        return new DomainSnapshot(owner, lifecycle, coreTier, corePosition, bounds, de, coreUpgradeFedItems, pylons, laws, memories, completedMilestones, features, zones, breaches, continuityAnchors, fractureMeter, dayTime, clearWeatherTime, raining, rainTime, thundering, thunderTime, globalExpansionEnabled, sovereignty);
    }


    private static void writeVeilInventory(DataOutputStream out, VeilInventorySnapshot inventory) throws IOException {
        out.writeInt(inventory.stacks().size());
        for (VeilInventorySnapshot.StoredStack stack : inventory.stacks()) {
            writeString(out, stack.itemId());
            writeString(out, stack.componentData());
            out.writeLong(stack.count());
        }
    }

    private static VeilInventorySnapshot readVeilInventory(DataInputStream in) throws IOException {
        int count = readCount(in, "Veil Inventory stacks");
        List<VeilInventorySnapshot.StoredStack> stacks = new ArrayList<>(count);
        Set<String> exactKeys = new LinkedHashSet<>();
        for (int i = 0; i < count; i++) {
            String itemId = readString(in);
            String componentData = readString(in);
            long stackCount = in.readLong();
            if (stackCount <= 0) throw new IllegalArgumentException("Invalid Veil Inventory stack count: " + stackCount);
            String exactKey = itemId + "\u0000" + componentData;
            if (!exactKeys.add(exactKey)) throw new IllegalArgumentException("Duplicate Veil Inventory stack identity");
            stacks.add(new VeilInventorySnapshot.StoredStack(itemId, componentData, stackCount));
        }
        return new VeilInventorySnapshot(stacks);
    }


    private static void writeMatterTransmutation(DataOutputStream out, MatterTransmutationSnapshot state) throws IOException {
        out.writeLong(state.storedMatter());
        out.writeInt(state.learnedItemIds().size());
        for (String itemId : state.learnedItemIds()) writeString(out, itemId);
        out.writeInt(state.favoriteItemIds().size());
        for (String itemId : state.favoriteItemIds()) writeString(out, itemId);
        out.writeInt(state.recentItemIds().size());
        for (String itemId : state.recentItemIds()) writeString(out, itemId);
    }

    private static MatterTransmutationSnapshot readMatterTransmutation(DataInputStream in, int version) throws IOException {
        long matter = in.readLong();
        if (matter < 0) throw new IllegalArgumentException("Invalid stored Matter amount: " + matter);
        int count = readCount(in, "Matter transmutation patterns");
        Set<String> patterns = new LinkedHashSet<>();
        for (int i = 0; i < count; i++) {
            String itemId = readString(in);
            if (!patterns.add(itemId)) throw new IllegalArgumentException("Duplicate Matter transmutation pattern: " + itemId);
        }
        if (version < 6) return new MatterTransmutationSnapshot(matter, patterns);

        int favoriteCount = readCount(in, "Matter favorite patterns");
        Set<String> favorites = new LinkedHashSet<>();
        for (int i = 0; i < favoriteCount; i++) {
            String itemId = readString(in);
            if (!patterns.contains(itemId)) throw new IllegalArgumentException("Favorite Matter pattern is not learned: " + itemId);
            if (!favorites.add(itemId)) throw new IllegalArgumentException("Duplicate favorite Matter pattern: " + itemId);
        }
        int recentCount = readCount(in, "Matter recent patterns");
        List<String> recent = new ArrayList<>();
        Set<String> recentDedupe = new LinkedHashSet<>();
        for (int i = 0; i < recentCount; i++) {
            String itemId = readString(in);
            if (!patterns.contains(itemId)) throw new IllegalArgumentException("Recent Matter pattern is not learned: " + itemId);
            if (!recentDedupe.add(itemId)) throw new IllegalArgumentException("Duplicate recent Matter pattern: " + itemId);
            recent.add(itemId);
        }
        return new MatterTransmutationSnapshot(matter, patterns, favorites, recent);
    }


    private static void writeMemoryProgress(DataOutputStream out, MemoryProgressSnapshot state) throws IOException {
        out.writeBoolean(state.capturedMemoryId() != null);
        if (state.capturedMemoryId() != null) writeString(out, state.capturedMemoryId());
        out.writeInt(state.activeOrreryMemoryIds().size());
        for (String id : state.activeOrreryMemoryIds()) writeString(out, id);
    }

    private static MemoryProgressSnapshot readMemoryProgress(DataInputStream in) throws IOException {
        String captured = in.readBoolean() ? readString(in) : null;
        int count = readCount(in, "active Orrery Memories");
        List<String> active = new ArrayList<>(count);
        Set<String> dedupe = new LinkedHashSet<>();
        for (int i = 0; i < count; i++) {
            String id = readString(in);
            if (!dedupe.add(id)) throw new IllegalArgumentException("Duplicate active Orrery Memory: " + id);
            active.add(id);
        }
        return new MemoryProgressSnapshot(captured, active);
    }

    private static void writeThresholds(DataOutputStream out, List<ThresholdSnapshot> thresholds) throws IOException {
        out.writeInt(thresholds.size());
        for (ThresholdSnapshot threshold : thresholds) {
            writeUuid(out, threshold.id());
            writeUuid(out, threshold.ownerId());
            writeString(out, threshold.sourceDimensionId());
            out.writeInt(threshold.sourcePositions().size());
            for (DomainPosition source : threshold.sourcePositions()) writePosition(out, source);
            writePosition(out, threshold.domainPosition());
            out.writeBoolean(threshold.publicAccess());
            out.writeInt(threshold.invitedGuests().size());
            for (UUID guest : threshold.invitedGuests()) writeUuid(out, guest);
        }
    }

    private static List<ThresholdSnapshot> readThresholds(DataInputStream in, int version) throws IOException {
        int count = readCount(in, "thresholds");
        List<ThresholdSnapshot> result = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            UUID id = readUuid(in);
            UUID owner = readUuid(in);
            String sourceDimensionId = "";
            Set<DomainPosition> sourcePositions = Set.of();
            if (version >= 3) {
                sourceDimensionId = readString(in);
                int sourceCount = readCount(in, "threshold source positions");
                Set<DomainPosition> mutableSources = new LinkedHashSet<>();
                for (int s = 0; s < sourceCount; s++) mutableSources.add(readPosition(in));
                sourcePositions = Set.copyOf(mutableSources);
            }
            DomainPosition position = readPosition(in);
            boolean publicAccess = in.readBoolean();
            int guestCount = readCount(in, "threshold guests");
            Set<UUID> guests = new LinkedHashSet<>();
            for (int g = 0; g < guestCount; g++) guests.add(readUuid(in));
            result.add(new ThresholdSnapshot(id, owner, sourceDimensionId, sourcePositions, position, publicAccess, guests));
        }
        return result;
    }

    private static void writeAnchor(DataOutputStream out, ReturnAnchor anchor) throws IOException {
        writeString(out, anchor.dimensionId());
        out.writeDouble(anchor.x());
        out.writeDouble(anchor.y());
        out.writeDouble(anchor.z());
        out.writeFloat(anchor.yaw());
        out.writeFloat(anchor.pitch());
    }

    private static ReturnAnchor readAnchor(DataInputStream in) throws IOException {
        return new ReturnAnchor(readString(in), in.readDouble(), in.readDouble(), in.readDouble(), in.readFloat(), in.readFloat());
    }

    private static void writePosition(DataOutputStream out, DomainPosition p) throws IOException {
        out.writeInt(p.x()); out.writeInt(p.y()); out.writeInt(p.z());
    }
    private static DomainPosition readPosition(DataInputStream in) throws IOException {
        return new DomainPosition(in.readInt(), in.readInt(), in.readInt());
    }
    private static void writeBounds(DataOutputStream out, DomainBounds b) throws IOException {
        out.writeInt(b.minX()); out.writeInt(b.minY()); out.writeInt(b.minZ());
        out.writeInt(b.maxX()); out.writeInt(b.maxY()); out.writeInt(b.maxZ());
    }
    private static DomainBounds readBounds(DataInputStream in) throws IOException {
        return new DomainBounds(in.readInt(), in.readInt(), in.readInt(), in.readInt(), in.readInt(), in.readInt());
    }
    private static void writeUuid(DataOutputStream out, UUID id) throws IOException { out.writeLong(id.getMostSignificantBits()); out.writeLong(id.getLeastSignificantBits()); }
    private static UUID readUuid(DataInputStream in) throws IOException { return new UUID(in.readLong(), in.readLong()); }
    private static <E extends Enum<E>> void writeEnum(DataOutputStream out, E value) throws IOException { writeString(out, value.name()); }
    private static <E extends Enum<E>> E readEnum(DataInputStream in, Class<E> type) throws IOException {
        try { return Enum.valueOf(type, readString(in)); }
        catch (IllegalArgumentException e) { throw new IllegalArgumentException("Unknown " + type.getSimpleName() + " in persistence", e); }
    }
    private static void writeStrings(DataOutputStream out, Set<String> values) throws IOException {
        out.writeInt(values.size());
        for (String value : values) writeString(out, value);
    }
    private static Set<String> readStrings(DataInputStream in, String label) throws IOException {
        int count = readCount(in, label);
        Set<String> result = new LinkedHashSet<>();
        for (int i = 0; i < count; i++) result.add(readString(in));
        return result;
    }
    private static void writeString(DataOutputStream out, String value) throws IOException {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        out.writeInt(bytes.length);
        out.write(bytes);
    }
    private static String readString(DataInputStream in) throws IOException {
        int length = in.readInt();
        if (length < 0 || length > 16_777_216) throw new IllegalArgumentException("Invalid persistence string length: " + length);
        byte[] bytes = in.readNBytes(length);
        if (bytes.length != length) throw new IOException("Truncated persistence string: expected " + length + " bytes, got " + bytes.length);
        return new String(bytes, StandardCharsets.UTF_8);
    }
    private static int readCount(DataInputStream in, String label) throws IOException {
        int count = in.readInt();
        if (count < 0 || count > MAX_COLLECTION) throw new IllegalArgumentException("Invalid " + label + " count: " + count);
        return count;
    }
}
