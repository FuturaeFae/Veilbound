package dev.futurae.veilbound.energy;

import dev.futurae.veilbound.matter.MatterCatalog;
import java.util.Objects;
import java.util.OptionalLong;

/**
 * Values physical item input for the Dimensional Transducer's own Matter reservoir.
 *
 * <p>This is deliberately separate from Veil Inventory Matter. The Transducer accepts only items
 * with a real positive catalog value (built-in, datapack, or conservative recipe inference).
 * Genuinely unvalued items are rejected, and this machine never teaches or consumes terminal patterns.
 */
public final class TransducerMatterInputService {
    private TransducerMatterInputService() {}

    public static Plan plan(
            MatterCatalog catalog,
            String itemId,
            int offeredItems,
            long storedMatter,
            long matterCapacity) {
        Objects.requireNonNull(catalog, "catalog");
        Objects.requireNonNull(itemId, "itemId");
        if (offeredItems < 0) return Plan.denied("invalid_item_count");
        if (offeredItems == 0) return Plan.denied("no_items");
        if (storedMatter < 0 || matterCapacity < 1 || storedMatter > matterCapacity) {
            return Plan.denied("invalid_matter_buffer");
        }

        OptionalLong value = catalog.amount(itemId);
        if (value.isEmpty() || value.getAsLong() <= 0) return Plan.denied("no_matter_value");
        long matterPerItem = value.getAsLong();
        long room = matterCapacity - storedMatter;
        if (room < matterPerItem) return Plan.denied("matter_buffer_full");

        long maxItemsByRoom = room / matterPerItem;
        int consumed = (int) Math.min((long) offeredItems, Math.min((long) Integer.MAX_VALUE, maxItemsByRoom));
        if (consumed <= 0) return Plan.denied("matter_buffer_full");
        try {
            long added = Math.multiplyExact((long) consumed, matterPerItem);
            return Plan.allowed(consumed, added, matterPerItem);
        } catch (ArithmeticException overflow) {
            return Plan.denied("matter_overflow");
        }
    }

    public record Plan(boolean accepted, int itemsConsumed, long matterAdded, long matterPerItem, String reason) {
        public static Plan denied(String reason) { return new Plan(false, 0, 0L, 0L, reason); }
        public static Plan allowed(int count, long matterAdded, long matterPerItem) {
            return new Plan(true, count, matterAdded, matterPerItem, "ok");
        }
    }
}
