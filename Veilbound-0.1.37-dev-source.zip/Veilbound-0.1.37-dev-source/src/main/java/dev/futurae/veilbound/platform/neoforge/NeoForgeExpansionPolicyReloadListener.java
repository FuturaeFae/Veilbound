package dev.futurae.veilbound.platform.neoforge;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.domain.ExpansionPolicy;
import dev.futurae.veilbound.domain.ExpansionPolicyRegistry;
import dev.futurae.veilbound.domain.ExpansionRuntimePolicy;
import java.io.Reader;
import java.util.Objects;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

/** Loads the single data/veilbound/veilbound/balance/domain_expansion.json growth policy. */
public final class NeoForgeExpansionPolicyReloadListener extends SimplePreparableReloadListener<ExpansionRuntimePolicy> {
    public static final Identifier LISTENER_ID = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "domain_expansion_policy");
    private static final Identifier RESOURCE_ID = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "veilbound/balance/domain_expansion.json");
    private final Gson gson = new Gson();
    private final ExpansionPolicyRegistry registry;

    public NeoForgeExpansionPolicyReloadListener(ExpansionPolicyRegistry registry) {
        this.registry = Objects.requireNonNull(registry, "registry");
    }

    @Override
    protected ExpansionRuntimePolicy prepare(ResourceManager manager, ProfilerFiller profiler) {
        return manager.getResource(RESOURCE_ID).map(resource -> {
            try (Reader reader = resource.openAsReader()) {
                JsonElement parsed = gson.fromJson(reader, JsonElement.class);
                if (parsed == null || !parsed.isJsonObject()) throw new IllegalArgumentException("root must be an object");
                JsonObject o = parsed.getAsJsonObject();
                int cycleTicks = integer(o, "cycle_ticks", ExpansionRuntimePolicy.DEVELOPMENT_DEFAULT.cycleTicks());
                long dePerBlock = longValue(o, "dimensional_energy_per_new_block",
                        ExpansionRuntimePolicy.DEVELOPMENT_DEFAULT.expansionPolicy().dimensionalEnergyPerNewBlock());
                int verticalCap = integer(o, "vertical_span_cap", ExpansionPolicy.ABSOLUTE_MAX_VERTICAL_SPAN);
                int horizontalCap = integer(o, "transcendent_horizontal_cap", 0);
                return new ExpansionRuntimePolicy(cycleTicks, new ExpansionPolicy(dePerBlock, verticalCap, horizontalCap));
            } catch (Exception ex) {
                Veilbound.LOGGER.warn("Invalid {}: {}; using development default", RESOURCE_ID, ex.getMessage());
                return ExpansionRuntimePolicy.DEVELOPMENT_DEFAULT;
            }
        }).orElse(ExpansionRuntimePolicy.DEVELOPMENT_DEFAULT);
    }

    @Override
    protected void apply(ExpansionRuntimePolicy policy, ResourceManager manager, ProfilerFiller profiler) {
        registry.replace(policy);
        Veilbound.LOGGER.info("Loaded Domain expansion policy: every {} ticks, {} DE/new block, vertical cap {}, Transcendent horizontal cap {}",
                policy.cycleTicks(), policy.expansionPolicy().dimensionalEnergyPerNewBlock(),
                policy.expansionPolicy().verticalSpanCap(), policy.expansionPolicy().transcendentHorizontalCap());
    }

    private static int integer(JsonObject o, String key, int fallback) {
        return o.has(key) ? o.get(key).getAsInt() : fallback;
    }
    private static long longValue(JsonObject o, String key, long fallback) {
        return o.has(key) ? o.get(key).getAsLong() : fallback;
    }
}
