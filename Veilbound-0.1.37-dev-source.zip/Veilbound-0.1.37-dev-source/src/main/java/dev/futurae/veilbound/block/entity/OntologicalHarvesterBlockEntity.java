package dev.futurae.veilbound.block.entity;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.ontology.OntologicalHarvesterPolicy;
import dev.futurae.veilbound.ontology.OntologicalHarvesterService;
import dev.futurae.veilbound.ontology.OntologicalMode;
import dev.futurae.veilbound.ontology.PotentialReservoir;
import dev.futurae.veilbound.registry.VeilboundBlockEntities;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jspecify.annotations.Nullable;

/**
 * Harvests Potential from a bounded connected Probability-Vane array. A vane contributes only while
 * it physically touches a current usable-space face, so Domain expansion naturally asks the player
 * to extend/reposition their observation array rather than granting free infinite scaling.
 */
public final class OntologicalHarvesterBlockEntity extends BlockEntity {
    public static final long POTENTIAL_CAPACITY = 2_097_152L;
    public static final long MAX_TRANSFER_PER_TICK = 16_384L;
    private final PotentialReservoir potential = new PotentialReservoir(POTENTIAL_CAPACITY);
    private final OntologicalHarvesterService harvester = new OntologicalHarvesterService();
    private UUID ownerId;
    private OntologicalMode mode = OntologicalMode.STABLE;
    private int contributingVanes;
    private double lastStabilityLoad;
    private long lastProduced;

    public OntologicalHarvesterBlockEntity(BlockPos pos, BlockState state) { super(VeilboundBlockEntities.ONTOLOGICAL_HARVESTER.get(), pos, state); }
    public void bindOwner(UUID ownerId) { if (this.ownerId == null) { this.ownerId = Objects.requireNonNull(ownerId); setChanged(); } }
    public @Nullable UUID ownerId() { return ownerId; }
    public OntologicalMode mode() { return mode; }
    public int contributingVanes() { return contributingVanes; }
    public long storedPotential() { return potential.stored(); }
    public long potentialCapacity() { return potential.capacity(); }
    public double lastStabilityLoad() { return lastStabilityLoad; }
    public long lastProduced() { return lastProduced; }
    public OntologicalMode cycleMode() { OntologicalMode[] values = OntologicalMode.values(); mode = values[(mode.ordinal() + 1) % values.length]; setChanged(); return mode; }
    public OntologicalMode setMode(OntologicalMode next) { mode = Objects.requireNonNull(next, "next"); setChanged(); return mode; }

    public static void tick(Level level, BlockPos pos, BlockState state, OntologicalHarvesterBlockEntity be) {
        if (!(level instanceof ServerLevel serverLevel) || be.ownerId == null) return;
        DomainRecord record = Veilbound.runtime().domains().getRecord(be.ownerId).orElse(null);
        if (record == null || !record.identity().dimensionId().equals(level.dimension().identifier().toString())) return;

        be.transferAdjacentPotential();
        if (level.getGameTime() % 20L != 0L) return;

        OntologicalHarvesterPolicy policy = Veilbound.runtime().ontologyPolicy().policy().harvester();
        int vanes = be.countBoundaryVanes(record.state().bounds(), policy.maxContributingVanes());
        int openBreaches = (int) record.state().breaches().stream().filter(dev.futurae.veilbound.breach.Breach::open).count();
        var plan = be.harvester.plan(vanes, be.mode, record.state().fractureMeter(), openBreaches, policy);
        long accepted = be.potential.insert(plan.potentialProduced());
        be.contributingVanes = plan.contributingVanes();
        be.lastStabilityLoad = plan.stabilityLoad();
        Veilbound.runtime().ontologicalLoads().publish(
                be.ownerId, level.dimension().identifier() + "@" + pos.asLong(), be.lastStabilityLoad, level.getGameTime());
        be.lastProduced = accepted;
        if (accepted > 0 || be.contributingVanes != 0) be.setChanged();
    }

    private void transferAdjacentPotential() {
        if (potential.stored() <= 0 || level == null) return;
        long remainingBudget = Math.min(MAX_TRANSFER_PER_TICK, potential.stored());
        for (Direction direction : Direction.values()) {
            if (remainingBudget <= 0) break;
            BlockEntity target = level.getBlockEntity(worldPosition.relative(direction));
            long accepted = 0;
            if (target instanceof EngineeringStationBlockEntity station) accepted = station.receivePotential(remainingBudget);
            else if (target instanceof OntologicalCompilerBlockEntity compiler) accepted = compiler.receivePotential(remainingBudget);
            if (accepted > 0) { potential.consume(accepted); remainingBudget -= accepted; setChanged(); }
        }
    }

    private int countBoundaryVanes(DomainBounds bounds, int cap) {
        if (level == null || cap <= 0) return 0;
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        Set<BlockPos> visited = new HashSet<>();
        for (Direction direction : Direction.values()) queue.add(worldPosition.relative(direction));
        int count = 0;
        while (!queue.isEmpty() && count < cap && visited.size() < cap * 8) {
            BlockPos pos = queue.removeFirst();
            if (!visited.add(pos)) continue;
            if (!level.getBlockState(pos).is(VeilboundBlocks.PROBABILITY_VANE.get())) continue;
            if (isBoundaryExposed(bounds, pos)) count++;
            for (Direction direction : Direction.values()) queue.addLast(pos.relative(direction));
        }
        return count;
    }

    private static boolean isBoundaryExposed(DomainBounds bounds, BlockPos pos) {
        DomainPosition p = new DomainPosition(pos.getX(), pos.getY(), pos.getZ());
        if (!bounds.contains(p)) return false;
        return p.x() == bounds.minX() || p.x() == bounds.maxX()
                || p.y() == bounds.minY() || p.y() == bounds.maxY()
                || p.z() == bounds.minZ() || p.z() == bounds.maxZ();
    }

    @Override protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        if (ownerId != null) output.putString("owner", ownerId.toString());
        output.putString("potential", Long.toString(potential.stored()));
        output.putString("mode", mode.name());
    }
    @Override protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        ownerId = input.getString("owner").flatMap(raw -> { try { return java.util.Optional.of(UUID.fromString(raw)); } catch (IllegalArgumentException ignored) { return java.util.Optional.empty(); } }).orElse(null);
        long restored; try { restored = Long.parseLong(input.getString("potential").orElse("0")); } catch (NumberFormatException ignored) { restored = 0; }
        potential.setStored(Math.max(0L, Math.min(POTENTIAL_CAPACITY, restored)));
        mode = input.getString("mode").flatMap(raw -> { try { return java.util.Optional.of(OntologicalMode.valueOf(raw)); } catch (IllegalArgumentException ignored) { return java.util.Optional.empty(); } }).orElse(OntologicalMode.STABLE);
    }
}
