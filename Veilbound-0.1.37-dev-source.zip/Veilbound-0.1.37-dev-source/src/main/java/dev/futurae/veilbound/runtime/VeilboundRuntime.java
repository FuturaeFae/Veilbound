package dev.futurae.veilbound.runtime;

import dev.futurae.veilbound.domain.DomainRepository;
import dev.futurae.veilbound.domain.DomainRuntimeTracker;
import dev.futurae.veilbound.domain.ExpansionPolicyRegistry;
import dev.futurae.veilbound.energy.TransductionPolicyRegistry;
import dev.futurae.veilbound.engineering.EngineeringRecipeRegistry;
import dev.futurae.veilbound.inventory.VeilInventoryAccessService;
import dev.futurae.veilbound.inventory.VeilStoragePolicy;
import dev.futurae.veilbound.law.ActiveLawEffects;
import dev.futurae.veilbound.law.LawEffectResolver;
import dev.futurae.veilbound.law.LawRegistry;
import dev.futurae.veilbound.law.LawRuntimeSemantics;
import dev.futurae.veilbound.matter.DefaultMatterValues;
import dev.futurae.veilbound.matter.MatterCatalog;
import dev.futurae.veilbound.matter.MatterReloadService;
import dev.futurae.veilbound.matter.VeilboundMatterExclusions;
import dev.futurae.veilbound.memory.MemoryEnvironmentRuntime;
import dev.futurae.veilbound.memory.MemoryEffectPolicyRegistry;
import dev.futurae.veilbound.memory.MemoryRegistry;
import dev.futurae.veilbound.milestone.MilestoneRegistry;
import dev.futurae.veilbound.ontology.OntologicalLoadTracker;
import dev.futurae.veilbound.ontology.OntologyPolicyRegistry;
import dev.futurae.veilbound.persistence.VeilboundPersistenceSnapshot;
import dev.futurae.veilbound.precore.SpatialGeneratorPolicyRegistry;
import dev.futurae.veilbound.stability.StabilityPolicyRegistry;
import dev.futurae.veilbound.threshold.DomainPresenceCoordinator;
import dev.futurae.veilbound.threshold.ThresholdRegistry;
import dev.futurae.veilbound.threshold.ThresholdSessionManager;
import dev.futurae.veilbound.travel.OwnerDomainTravelService;
import dev.futurae.veilbound.upgrade.CoreUpgradeRegistry;

/**
 * Loader-neutral composition root for one running server instance.
 *
 * NeoForge lifecycle code owns when this runtime is created/reloaded/saved; gameplay services
 * depend on this object instead of constructing disconnected repositories of their own.
 */
public final class VeilboundRuntime {
    private final DomainRepository domains = new DomainRepository();
    private final DomainRuntimeTracker domainRuntime = new DomainRuntimeTracker();
    private final ExpansionPolicyRegistry expansionPolicy = new ExpansionPolicyRegistry();
    private final TransductionPolicyRegistry transductionPolicy = new TransductionPolicyRegistry();
    private final StabilityPolicyRegistry stabilityPolicy = new StabilityPolicyRegistry();
    private final ThresholdRegistry thresholds = new ThresholdRegistry();
    private final ThresholdSessionManager thresholdSessions = new ThresholdSessionManager();
    private final DomainPresenceCoordinator domainPresence = new DomainPresenceCoordinator(thresholdSessions);
    private final MemoryRegistry memories = new MemoryRegistry();
    private final MilestoneRegistry milestones = new MilestoneRegistry();
    private final MemoryEnvironmentRuntime memoryEnvironment = new MemoryEnvironmentRuntime();
    private final MemoryEffectPolicyRegistry memoryEffectPolicy = new MemoryEffectPolicyRegistry();
    private final LawRegistry laws = new LawRegistry();
    private final LawEffectResolver lawEffects = new LawEffectResolver();
    private final LawRuntimeSemantics lawRuntimeSemantics = new LawRuntimeSemantics();
    private final MatterCatalog matter = new MatterCatalog();
    private final MatterReloadService matterReload = new MatterReloadService(matter);
    private final SpatialGeneratorPolicyRegistry spatialGeneratorPolicy = new SpatialGeneratorPolicyRegistry();
    private final CoreUpgradeRegistry coreUpgrades = new CoreUpgradeRegistry();
    private final EngineeringRecipeRegistry engineeringRecipes = new EngineeringRecipeRegistry();
    private final OntologicalLoadTracker ontologicalLoads = new OntologicalLoadTracker();
    private final OntologyPolicyRegistry ontologyPolicy = new OntologyPolicyRegistry();
    private final VeilStoragePolicy veilStoragePolicy = new VeilStoragePolicy();
    private final VeilInventoryAccessService veilInventoryAccess = new VeilInventoryAccessService(domains, veilStoragePolicy);
    private final OwnerDomainTravelService ownerTravel = new OwnerDomainTravelService(domains);

    public VeilboundRuntime() {
        DefaultMatterValues.installInto(matter);
        VeilboundMatterExclusions.installInto(matter);
    }

    public DomainRepository domains() { return domains; }
    public DomainRuntimeTracker domainRuntime() { return domainRuntime; }
    public ExpansionPolicyRegistry expansionPolicy() { return expansionPolicy; }
    public TransductionPolicyRegistry transductionPolicy() { return transductionPolicy; }
    public StabilityPolicyRegistry stabilityPolicy() { return stabilityPolicy; }
    public ThresholdRegistry thresholds() { return thresholds; }
    public ThresholdSessionManager thresholdSessions() { return thresholdSessions; }
    public DomainPresenceCoordinator domainPresence() { return domainPresence; }
    public MemoryRegistry memories() { return memories; }
    public MilestoneRegistry milestones() { return milestones; }
    public MemoryEnvironmentRuntime memoryEnvironment() { return memoryEnvironment; }
    public MemoryEffectPolicyRegistry memoryEffectPolicy() { return memoryEffectPolicy; }
    public LawRegistry laws() { return laws; }
    public LawEffectResolver lawEffectResolver() { return lawEffects; }
    public ActiveLawEffects activeLawEffects(dev.futurae.veilbound.domain.DomainState state) {
        return lawEffects.resolve(state, laws);
    }
    public LawRuntimeSemantics lawRuntimeSemantics() { return lawRuntimeSemantics; }
    public MatterCatalog matter() { return matter; }
    public MatterReloadService matterReload() { return matterReload; }
    public SpatialGeneratorPolicyRegistry spatialGeneratorPolicy() { return spatialGeneratorPolicy; }
    public CoreUpgradeRegistry coreUpgrades() { return coreUpgrades; }
    public EngineeringRecipeRegistry engineeringRecipes() { return engineeringRecipes; }
    public OntologicalLoadTracker ontologicalLoads() { return ontologicalLoads; }
    public OntologyPolicyRegistry ontologyPolicy() { return ontologyPolicy; }
    public VeilStoragePolicy veilStoragePolicy() { return veilStoragePolicy; }
    public VeilInventoryAccessService veilInventoryAccess() { return veilInventoryAccess; }
    public OwnerDomainTravelService ownerTravel() { return ownerTravel; }

    public VeilboundPersistenceSnapshot capturePersistentState() {
        return VeilboundPersistenceSnapshot.capture(domains, thresholds);
    }

    public void restorePersistentState(VeilboundPersistenceSnapshot snapshot) {
        java.util.Objects.requireNonNull(snapshot, "snapshot").restoreInto(domains, thresholds);
    }

    /** SavedData calls this once attached so every durable mutation marks the payload dirty. */
    public void setPersistenceDirtyListener(Runnable listener) {
        java.util.Objects.requireNonNull(listener, "listener");
        domains.setMutationListener(listener);
        thresholds.setMutationListener(listener);
    }
}
