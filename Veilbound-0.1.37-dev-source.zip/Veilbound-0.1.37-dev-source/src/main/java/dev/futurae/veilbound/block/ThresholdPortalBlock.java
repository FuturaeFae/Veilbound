package dev.futurae.veilbound.block;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.block.entity.ThresholdPortalBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.InsideBlockEffectApplier;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

/** Active full-block Threshold portal visual and touch trigger. */
public final class ThresholdPortalBlock extends Block implements EntityBlock {
    public ThresholdPortalBlock(BlockBehaviour.Properties properties) {
        super(properties.noCollision().noOcclusion());
    }


    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ThresholdPortalBlockEntity(pos, state);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    protected void entityInside(
            BlockState state,
            Level level,
            BlockPos pos,
            Entity entity,
            InsideBlockEffectApplier effectApplier,
            boolean isPrecise) {
        if (!level.isClientSide() && entity instanceof ServerPlayer player) {
            Veilbound.thresholdPortalTransit().onPortalTouch(player, pos);
        }
        super.entityInside(state, level, pos, entity, effectApplier, isPrecise);
    }

}
