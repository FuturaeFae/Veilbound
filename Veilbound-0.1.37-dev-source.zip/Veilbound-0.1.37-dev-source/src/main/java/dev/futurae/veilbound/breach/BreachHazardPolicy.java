package dev.futurae.veilbound.breach;

import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;

/** Reloadable proximity-hazard tuning for players standing near an open breach. */
public final class BreachHazardPolicy {
    private final EnumMap<BreachSeverity, HazardBand> bands;
    private final int particleIntervalTicks;

    public BreachHazardPolicy(Map<BreachSeverity, HazardBand> bands, int particleIntervalTicks) {
        Objects.requireNonNull(bands, "bands");
        if (particleIntervalTicks < 1) throw new IllegalArgumentException("particleIntervalTicks must be >= 1");
        this.bands = new EnumMap<>(BreachSeverity.class);
        for (BreachSeverity severity : BreachSeverity.values()) {
            this.bands.put(severity, Objects.requireNonNull(bands.get(severity), "Missing hazard band for " + severity));
        }
        this.particleIntervalTicks = particleIntervalTicks;
    }

    public HazardBand band(BreachSeverity severity) { return bands.get(Objects.requireNonNull(severity)); }
    public int particleIntervalTicks() { return particleIntervalTicks; }

    public record HazardBand(double radius, double damage, int damageIntervalTicks, int particleCount) {
        public HazardBand {
            if (!(radius >= 0.0) || !Double.isFinite(radius)) throw new IllegalArgumentException("hazard radius must be finite and >= 0");
            if (!(damage >= 0.0) || !Double.isFinite(damage)) throw new IllegalArgumentException("hazard damage must be finite and >= 0");
            if (damageIntervalTicks < 1) throw new IllegalArgumentException("damageIntervalTicks must be >= 1");
            if (particleCount < 0) throw new IllegalArgumentException("particleCount must be >= 0");
        }
    }

    public static BreachHazardPolicy developmentDefault() {
        EnumMap<BreachSeverity, HazardBand> bands = new EnumMap<>(BreachSeverity.class);
        // Development tuning only: Minor is warning/visual pressure; higher severities become damaging.
        bands.put(BreachSeverity.MINOR, new HazardBand(3.0, 0.0, 40, 4));
        bands.put(BreachSeverity.SEVERE, new HazardBand(4.5, 1.0, 40, 8));
        bands.put(BreachSeverity.EXTREME, new HazardBand(6.0, 2.0, 20, 12));
        return new BreachHazardPolicy(bands, 10);
    }
}
