package dev.futurae.veilbound.ritual;

import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.domain.DomainRepository;
import java.util.Objects;
import java.util.UUID;

/** Loader-neutral one-time binding ritual for a player's personal Domain. */
public final class GenesisSeedService {
    private GenesisSeedService() {}

    public static BindResult bind(DomainRepository domains, UUID ownerId) {
        Objects.requireNonNull(domains, "domains");
        Objects.requireNonNull(ownerId, "ownerId");
        DomainRecord existing = domains.getRecord(ownerId).orElse(null);
        if (existing != null) return BindResult.denied(existing, "domain_already_bound");
        DomainRecord created = domains.createRecord(ownerId);
        return BindResult.created(created);
    }

    public record BindResult(boolean bound, DomainRecord domain, String reason) {
        public static BindResult denied(DomainRecord domain, String reason) {
            return new BindResult(false, domain, reason);
        }
        public static BindResult created(DomainRecord domain) {
            return new BindResult(true, Objects.requireNonNull(domain, "domain"), "ok");
        }
    }
}
