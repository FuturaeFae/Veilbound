package dev.futurae.veilbound.threshold;

import dev.futurae.veilbound.travel.ReturnAnchor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Enforces the owner-presence rule and preserves one exact return anchor per guest.
 * Minecraft teleport execution is deliberately outside this loader-neutral class.
 */
public final class ThresholdSessionManager {
    private final Map<UUID, GuestThresholdSession> byGuest = new LinkedHashMap<>();

    public EntryDecision beginGuestEntry(
            ThresholdDefinition threshold,
            UUID guestId,
            ReturnAnchor returnAnchor,
            long gameTick,
            boolean ownerOnline,
            boolean ownerInsideDomain) {
        Objects.requireNonNull(threshold, "threshold");
        Objects.requireNonNull(guestId, "guestId");
        Objects.requireNonNull(returnAnchor, "returnAnchor");
        if (!ownerOnline) return EntryDecision.denied("owner_offline");
        if (!ownerInsideDomain) return EntryDecision.denied("owner_not_inside_domain");
        if (guestId.equals(threshold.ownerId())) return EntryDecision.denied("owner_not_guest");
        if (!threshold.access().canEnter(guestId)) return EntryDecision.denied("not_invited");
        if (byGuest.containsKey(guestId)) return EntryDecision.denied("already_in_domain_session");

        GuestThresholdSession session = new GuestThresholdSession(
                guestId, threshold.ownerId(), threshold.id(), returnAnchor, gameTick);
        byGuest.put(guestId, session);
        return EntryDecision.allowed(session);
    }

    public Optional<GuestThresholdSession> session(UUID guestId) {
        return Optional.ofNullable(byGuest.get(guestId));
    }

    public Optional<GuestThresholdSession> endGuestSession(UUID guestId) {
        return Optional.ofNullable(byGuest.remove(guestId));
    }

    /** Snapshot only the guests whose active visit entered through one specific Threshold. */
    public List<GuestThresholdSession> sessionsForThreshold(UUID thresholdId) {
        Objects.requireNonNull(thresholdId, "thresholdId");
        return byGuest.values().stream()
                .filter(session -> session.thresholdId().equals(thresholdId))
                .toList();
    }

    /** Snapshot the guests that must leave before this owner's Domain can become ownerless. */
    public List<GuestThresholdSession> sessionsForOwner(UUID ownerId) {
        Objects.requireNonNull(ownerId, "ownerId");
        return byGuest.values().stream()
                .filter(session -> session.ownerId().equals(ownerId))
                .toList();
    }

    /** Complete one evacuation only after the platform confirms the guest was moved safely. */
    public boolean completeGuestEvacuation(UUID guestId, UUID expectedOwnerId) {
        Objects.requireNonNull(guestId, "guestId");
        Objects.requireNonNull(expectedOwnerId, "expectedOwnerId");
        GuestThresholdSession session = byGuest.get(guestId);
        if (session == null || !session.ownerId().equals(expectedOwnerId)) return false;
        byGuest.remove(guestId);
        return true;
    }

    /** Remove and return every guest that must be evacuated before this owner leaves/unloads. */
    public List<GuestThresholdSession> evacuateOwnerDomain(UUID ownerId) {
        Objects.requireNonNull(ownerId, "ownerId");
        List<GuestThresholdSession> evacuated = new ArrayList<>();
        var iterator = byGuest.entrySet().iterator();
        while (iterator.hasNext()) {
            var entry = iterator.next();
            if (entry.getValue().ownerId().equals(ownerId)) {
                evacuated.add(entry.getValue());
                iterator.remove();
            }
        }
        return List.copyOf(evacuated);
    }

    public Collection<GuestThresholdSession> activeSessions() {
        return List.copyOf(byGuest.values());
    }

    public record EntryDecision(boolean allowed, GuestThresholdSession session, String reason) {
        public static EntryDecision denied(String reason) { return new EntryDecision(false, null, reason); }
        public static EntryDecision allowed(GuestThresholdSession session) { return new EntryDecision(true, session, "ok"); }
    }
}
