package dev.futurae.veilbound.milestone;

import dev.futurae.veilbound.domain.DomainFeature;
import java.util.Objects;
import java.util.Set;

/** Data-driven progression threshold and its durable Domain-feature rewards. */
public record MilestoneDefinition(
        String id,
        String displayName,
        Set<String> prerequisiteMilestoneIds,
        MilestoneCriteria criteria,
        Set<DomainFeature> unlockedFeatures) {
    public MilestoneDefinition {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("id may not be blank");
        if (displayName == null || displayName.isBlank()) throw new IllegalArgumentException("displayName may not be blank");
        prerequisiteMilestoneIds = Set.copyOf(Objects.requireNonNull(prerequisiteMilestoneIds, "prerequisiteMilestoneIds"));
        criteria = Objects.requireNonNull(criteria, "criteria");
        unlockedFeatures = Set.copyOf(Objects.requireNonNull(unlockedFeatures, "unlockedFeatures"));
        if (prerequisiteMilestoneIds.contains(id)) throw new IllegalArgumentException("Milestone may not require itself");
    }
}
