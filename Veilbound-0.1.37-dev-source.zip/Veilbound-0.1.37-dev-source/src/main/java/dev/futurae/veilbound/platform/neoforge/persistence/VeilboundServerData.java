package dev.futurae.veilbound.platform.neoforge.persistence;

import com.mojang.serialization.Codec;
import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.persistence.VeilboundPersistenceSnapshot;
import dev.futurae.veilbound.persistence.VeilboundSnapshotBinaryCodec;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

/** Server-global durable Veilbound registry, stored under world/data/veilbound/domains.dat. */
public final class VeilboundServerData extends SavedData {
    private static final Codec<VeilboundServerData> CODEC = Codec.STRING.xmap(
            VeilboundServerData::fromPayload,
            VeilboundServerData::toPayload);

    @SuppressWarnings("DataFlowIssue") // NeoForge/Minecraft 26.x permits null DataFixTypes for mod SavedData.
    public static final SavedDataType<VeilboundServerData> TYPE = new SavedDataType<>(
            Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "domains"),
            VeilboundServerData::new,
            CODEC,
            null);

    private VeilboundPersistenceSnapshot snapshot;
    private VeilboundRuntime attachedRuntime;

    public VeilboundServerData() {
        this(new VeilboundPersistenceSnapshot(java.util.List.of(), java.util.List.of()));
    }

    private VeilboundServerData(VeilboundPersistenceSnapshot snapshot) {
        this.snapshot = snapshot;
    }

    public static VeilboundServerData attach(MinecraftServer server, VeilboundRuntime runtime) {
        VeilboundServerData data = server.getDataStorage().computeIfAbsent(TYPE);
        data.attachRuntime(runtime);
        return data;
    }

    private void attachRuntime(VeilboundRuntime runtime) {
        this.attachedRuntime = java.util.Objects.requireNonNull(runtime, "runtime");
        runtime.setPersistenceDirtyListener(() -> {});
        runtime.restorePersistentState(snapshot);
        runtime.setPersistenceDirtyListener(this::setDirty);
    }

    public VeilboundPersistenceSnapshot snapshot() {
        return attachedRuntime != null ? attachedRuntime.capturePersistentState() : snapshot;
    }

    private String toPayload() {
        snapshot = snapshot();
        return VeilboundSnapshotBinaryCodec.encode(snapshot);
    }

    private static VeilboundServerData fromPayload(String payload) {
        return new VeilboundServerData(VeilboundSnapshotBinaryCodec.decode(payload));
    }
}
