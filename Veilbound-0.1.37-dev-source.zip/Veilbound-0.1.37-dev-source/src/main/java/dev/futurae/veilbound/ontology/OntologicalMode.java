package dev.futurae.veilbound.ontology;

public enum OntologicalMode {
    QUIET(0.5, 0.25),
    STABLE(1.0, 1.0),
    DRIVEN(2.0, 4.0),
    PARADOX(4.0, 16.0);
    private final double productionMultiplier;
    private final double stabilityMultiplier;
    OntologicalMode(double productionMultiplier, double stabilityMultiplier) {
        this.productionMultiplier = productionMultiplier;
        this.stabilityMultiplier = stabilityMultiplier;
    }
    public double productionMultiplier() { return productionMultiplier; }
    public double stabilityMultiplier() { return stabilityMultiplier; }
}
