package dev.futurae.veilbound.upgrade;

import java.util.Objects;

/** One data-driven item requirement fed into the Core during an upgrade. */
public record UpgradeIngredient(String itemId, long count) {
    public UpgradeIngredient {
        Objects.requireNonNull(itemId, "itemId");
        if (itemId.isBlank()) throw new IllegalArgumentException("itemId may not be blank");
        if (count <= 0) throw new IllegalArgumentException("count must be > 0");
    }
}
