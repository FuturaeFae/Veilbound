package dev.futurae.veilbound.registry;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Development/discovery tab; recipes/progression still determine survival access. */
public final class VeilboundCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Veilbound.MOD_ID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> VEILBOUND = TABS.register("veilbound", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.veilbound"))
                    .icon(() -> VeilboundItems.SPATIAL_GENERATOR.get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        output.accept(VeilboundItems.DIMENSIONAL_CORE.get());
                        output.accept(VeilboundItems.DIMENSIONAL_TRANSDUCER.get());
                        output.accept(VeilboundItems.BOUNDARY_PYLON.get());
                        output.accept(VeilboundItems.DOMAIN_ORRERY.get());
                        output.accept(VeilboundItems.MEMORY_ARCHIVE.get());
                        output.accept(VeilboundItems.AXIOM_MONOLITH.get());
                        output.accept(VeilboundItems.AXIOM_OF_HOSTILITY.get());
                        output.accept(VeilboundItems.AXIOM_OF_FAUNA.get());
                        output.accept(VeilboundItems.AXIOM_OF_FLAME.get());
                        output.accept(VeilboundItems.AXIOM_OF_RUIN.get());
                        output.accept(VeilboundItems.AXIOM_OF_GRIEF.get());
                        output.accept(VeilboundItems.AXIOM_OF_CONFLICT.get());
                        output.accept(VeilboundItems.AXIOM_OF_DESCENT.get());
                        output.accept(VeilboundItems.AXIOM_OF_PRESERVATION.get());
                        output.accept(VeilboundItems.AXIOM_OF_TIME.get());
                        output.accept(VeilboundItems.AXIOM_OF_WEATHER.get());
                        output.accept(VeilboundItems.CONTINUITY_ANCHOR.get());
                        output.accept(VeilboundItems.THRESHOLD_FRAME.get());
                        output.accept(VeilboundItems.VEIL_INTERFACE.get());
                        output.accept(VeilboundItems.VEIL_INVENTORY_UPGRADE.get());
                        output.accept(VeilboundItems.VEIL_CRAFTING_UPGRADE.get());
                        output.accept(VeilboundItems.VEIL_TRANSMUTATION_UPGRADE.get());
                        output.accept(VeilboundItems.GENESIS_SEED.get());
                        output.accept(VeilboundItems.SPATIAL_GENERATOR.get());
                        output.accept(VeilboundItems.NUCLEUS_CATALYST.get());
                        output.accept(VeilboundItems.VOID_ANCHOR.get());
                        output.accept(VeilboundItems.MNEMONIC_VESSEL.get());
                        output.accept(VeilboundItems.RESONANCE_LENS.get());
                        output.accept(VeilboundItems.VEIL_STITCHER.get());
                        output.accept(VeilboundItems.RESONANT_ORE.get());
                        output.accept(VeilboundItems.PHASE_ORE.get());
                        output.accept(VeilboundItems.MNEMONIC_CRYSTAL_ORE.get());
                        output.accept(VeilboundItems.CAUSALITE_ORE.get());
                        output.accept(VeilboundItems.AXIOMITE_ORE.get());
                        output.accept(VeilboundItems.PARADOX_ORE.get());
                        output.accept(VeilboundItems.DIMENSIONAL_FABRICATOR.get());
                        output.accept(VeilboundItems.VEIL_FOUNDRY.get());
                        output.accept(VeilboundItems.PROBABILITY_VANE.get());
                        output.accept(VeilboundItems.ONTOLOGICAL_HARVESTER.get());
                        output.accept(VeilboundItems.ONTOLOGICAL_COMPILER.get());
                        output.accept(VeilboundItems.VEIL_LANCE.get());
                        output.accept(VeilboundItems.FOLDED_MATTER_BLOCK.get());
                        output.accept(VeilboundItems.CAUSAL_STEEL_BLOCK.get());
                        output.accept(VeilboundItems.AXIOMATIC_GLASS_BLOCK.get());
                        output.accept(VeilboundItems.CONTINUITY_CRYSTAL_BLOCK.get());
                        output.accept(VeilboundItems.SOVEREIGN_ALLOY_BLOCK.get());
                        output.accept(VeilboundItems.WORLDLINE_LATTICE_BLOCK.get());
                        output.accept(VeilboundItems.PARADOX_CONTAINMENT_BLOCK.get());
                        output.accept(VeilboundItems.SOVEREIGN_CONDUIT_BLOCK.get());
                        output.accept(VeilboundItems.CROWNED_SINGULARITY_BLOCK.get());
                        output.accept(VeilboundItems.RESONANT_CRYSTAL.get());
                        output.accept(VeilboundItems.PHASE_CRYSTAL.get());
                        output.accept(VeilboundItems.MNEMONIC_CRYSTAL.get());
                        output.accept(VeilboundItems.CAUSALITE_SHARD.get());
                        output.accept(VeilboundItems.AXIOMITE_SHARD.get());
                        output.accept(VeilboundItems.PARADOX_CRYSTAL.get());
                        output.accept(VeilboundItems.VEIL_RESIDUE.get());
                        output.accept(VeilboundItems.FRACTURED_ESSENCE.get());
                        output.accept(VeilboundItems.CAUSAL_SHARD.get());
                        output.accept(VeilboundItems.UNRESOLVED_MATTER.get());
                        output.accept(VeilboundItems.RESONANT_FRAME_SEGMENT.get());
                        output.accept(VeilboundItems.PHASE_LOGIC_ARRAY.get());
                        output.accept(VeilboundItems.DIMENSIONAL_CAPACITOR.get());
                        output.accept(VeilboundItems.PHASE_COIL.get());
                        output.accept(VeilboundItems.CAUSAL_LATTICE.get());
                        output.accept(VeilboundItems.MNEMONIC_MATRIX.get());
                        output.accept(VeilboundItems.CONTINUITY_INDUCTOR.get());
                        output.accept(VeilboundItems.PATTERN_MATRIX.get());
                        output.accept(VeilboundItems.TRANSMUTATION_LATTICE.get());
                        output.accept(VeilboundItems.MATERIAL_PHASE_REGULATOR.get());
                        output.accept(VeilboundItems.BOUNDARY_SKELETON.get());
                        output.accept(VeilboundItems.CAUSAL_PROCESSOR.get());
                        output.accept(VeilboundItems.AXIOMATIC_CONTROLLER.get());
                        output.accept(VeilboundItems.LAW_KERNEL.get());
                        output.accept(VeilboundItems.ONTOLOGICAL_MATRIX.get());
                        output.accept(VeilboundItems.SINGULARITY_REGULATOR.get());
                        output.accept(VeilboundItems.FOLDED_SPACE_BRACE.get());
                        output.accept(VeilboundItems.TRANSCENDENT_FRAMEWORK.get());
                        output.accept(VeilboundItems.SOVEREIGN_COMPUTATION_CORE.get());
                        output.accept(VeilboundItems.CONTINUITY_SPINDLE.get());
                        output.accept(VeilboundItems.WORLDLINE_BEARING.get());
                        output.accept(VeilboundItems.AXIOM_BUS.get());
                        output.accept(VeilboundItems.MNEMONIC_PRISM.get());
                        output.accept(VeilboundItems.CAUSAL_MANIFOLD.get());
                        output.accept(VeilboundItems.PARADOX_GOVERNOR.get());
                        output.accept(VeilboundItems.HORIZON_LENS.get());
                        output.accept(VeilboundItems.TRANSFINITE_LOGIC_ARRAY.get());
                        output.accept(VeilboundItems.REALITY_LATTICE.get());
                        output.accept(VeilboundItems.DOMAIN_SPINE.get());
                        output.accept(VeilboundItems.SINGULARITY_CROWN.get());
                        output.accept(VeilboundItems.INVARIANT_MESH.get());
                        output.accept(VeilboundItems.ONTOLOGY_PUMP.get());
                        output.accept(VeilboundItems.PHASE_COMPRESSION_RING.get());
                        output.accept(VeilboundItems.CONTINUITY_FLYWHEEL.get());
                        output.accept(VeilboundItems.CAUSAL_CLOCK.get());
                        output.accept(VeilboundItems.AXIOM_SHUNT.get());
                        output.accept(VeilboundItems.MEMORY_REFRACTOR.get());
                        output.accept(VeilboundItems.VOID_PRESSURE_REGULATOR.get());
                        output.accept(VeilboundItems.SOVEREIGN_SERVO.get());
                        output.accept(VeilboundItems.REGALIA_CORE.get());
                        output.accept(VeilboundItems.EVENTIDE_PLATE.get());
                        output.accept(VeilboundItems.ABSOLUTE_BOUNDARY_NODE.get());
                        output.accept(VeilboundItems.FOLDED_MATTER.get());
                        output.accept(VeilboundItems.CAUSAL_STEEL.get());
                        output.accept(VeilboundItems.AXIOMATIC_GLASS.get());
                        output.accept(VeilboundItems.CONTINUITY_CRYSTAL.get());
                        output.accept(VeilboundItems.SOVEREIGN_ALLOY.get());
                        output.accept(VeilboundItems.ANCHORED_CORE_ASSEMBLY.get());
                        output.accept(VeilboundItems.RESONANT_CORE_ASSEMBLY.get());
                        output.accept(VeilboundItems.ASCENDANT_CORE_ASSEMBLY.get());
                        output.accept(VeilboundItems.TRANSCENDENT_CORE_ASSEMBLY.get());
                        output.accept(VeilboundItems.VEIL_ENGINEERING_CODEX.get());
                        output.accept(VeilboundItems.PHASEBREAKER.get());
                        output.accept(VeilboundItems.RIFT_CUTTER.get());
                        output.accept(VeilboundItems.BOUNDARY_SPADE.get());
                        output.accept(VeilboundItems.RESONANCE_MULTITOOL.get());
                        output.accept(VeilboundItems.PHASEWEAVE_HELMET.get());
                        output.accept(VeilboundItems.PHASEWEAVE_CHESTPLATE.get());
                        output.accept(VeilboundItems.PHASEWEAVE_LEGGINGS.get());
                        output.accept(VeilboundItems.PHASEWEAVE_BOOTS.get());
                        output.accept(VeilboundItems.CAUSAL_HELMET.get());
                        output.accept(VeilboundItems.CAUSAL_CHESTPLATE.get());
                        output.accept(VeilboundItems.CAUSAL_LEGGINGS.get());
                        output.accept(VeilboundItems.CAUSAL_BOOTS.get());
                        output.accept(VeilboundItems.SOVEREIGN_HELMET.get());
                        output.accept(VeilboundItems.SOVEREIGN_CHESTPLATE.get());
                        output.accept(VeilboundItems.SOVEREIGN_LEGGINGS.get());
                        output.accept(VeilboundItems.SOVEREIGN_BOOTS.get());
                    })
                    .build());

    private VeilboundCreativeTabs() {}

    public static void register(IEventBus modBus) {
        TABS.register(modBus);
    }
}
