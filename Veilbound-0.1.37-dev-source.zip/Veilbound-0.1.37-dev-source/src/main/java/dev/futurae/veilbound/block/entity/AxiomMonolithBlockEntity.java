package dev.futurae.veilbound.block.entity;

import dev.futurae.veilbound.registry.VeilboundBlockEntities;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jspecify.annotations.Nullable;

/** Persistent owner binding and permanent datapack Law attunement for one physical Axiom Monolith. */
public final class AxiomMonolithBlockEntity extends BlockEntity {
    private UUID ownerId;
    private String lawId;

    public AxiomMonolithBlockEntity(BlockPos pos, BlockState state) {
        super(VeilboundBlockEntities.AXIOM_MONOLITH.get(), pos, state);
    }

    public void bindOwner(UUID ownerId) {
        UUID candidate = Objects.requireNonNull(ownerId, "ownerId");
        if (this.ownerId == null) {
            this.ownerId = candidate;
            setChanged();
        }
    }

    public void attune(String lawId) {
        String candidate = Objects.requireNonNull(lawId, "lawId").trim();
        if (candidate.isEmpty()) throw new IllegalArgumentException("lawId may not be blank");
        if (this.lawId != null && !this.lawId.equals(candidate)) {
            throw new IllegalStateException("Axiom Monolith attunement is permanent");
        }
        if (this.lawId == null) {
            this.lawId = candidate;
            setChanged();
        }
    }

    public @Nullable UUID ownerId() { return ownerId; }
    public @Nullable String lawId() { return lawId; }

    @Override
    protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        if (ownerId != null) output.putString("owner", ownerId.toString());
        if (lawId != null) output.putString("law", lawId);
    }

    @Override
    protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        ownerId = input.getString("owner").flatMap(raw -> {
            try { return java.util.Optional.of(UUID.fromString(raw)); }
            catch (IllegalArgumentException ignored) { return java.util.Optional.empty(); }
        }).orElse(null);
        lawId = input.getString("law").filter(raw -> !raw.isBlank()).orElse(null);
    }
}
