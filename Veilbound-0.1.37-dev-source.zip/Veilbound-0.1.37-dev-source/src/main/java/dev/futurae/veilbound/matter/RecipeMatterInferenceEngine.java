package dev.futurae.veilbound.matter;

import dev.futurae.veilbound.matter.RecipeMatterModel.IngredientSlot;
import dev.futurae.veilbound.matter.RecipeMatterModel.ItemAmount;
import dev.futurae.veilbound.matter.RecipeMatterModel.OutputStack;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.OptionalLong;

/**
 * Conservative fixed-point Matter inference.
 *
 * Rules:
 *  - explicit values are immutable and always win;
 *  - every ingredient alternative must be resolved before a slot is trusted;
 *  - the cheapest alternative in a slot is used;
 *  - known returned containers/byproducts reduce net consumed value;
 *  - output count divides net cost using integer floor;
 *  - multiple recipes compete and the cheapest valid production path wins;
 *  - seedless cycles stay unresolved.
 */
public final class RecipeMatterInferenceEngine {
    public InferenceReport recompute(MatterCatalog catalog, Collection<RecipeMatterModel> recipes) {
        Map<String, MatterValue> working = new LinkedHashMap<>();
        working.putAll(catalog.authoritativeSnapshot());

        int maxPasses = Math.max(16, recipes.size() * 4 + working.size() * 2);
        int passes = 0;
        int updates = 0;
        boolean changed;
        do {
            changed = false;
            passes++;
            for (RecipeMatterModel recipe : recipes) {
                if (!catalog.hasAuthoritative(recipe.primaryOutput().itemId())) {
                    OptionalLong candidate = candidateValue(recipe, working);
                    if (candidate.isPresent()) {
                        String outputId = recipe.primaryOutput().itemId();
                        MatterValue existing = working.get(outputId);
                        long amount = candidate.getAsLong();
                        if (existing == null || !existing.authoritative() && amount < existing.amount()) {
                            working.put(outputId, new MatterValue(
                                    amount,
                                    MatterValue.Source.INFERRED,
                                    "recipe:" + recipe.recipeId()));
                            updates++;
                            changed = true;
                        }
                    }
                }

                // ProjectE's graph can propagate fixed output values back through simple furnace
                // conversions. Do this only for one-input smelting/blasting recipes so Veilbound
                // can recover raw-ore values from ProjectE's fixed ingot/scrap anchors without
                // attempting unsafe algebra across crafting tags or multi-ingredient recipes.
                ReverseCandidate reverse = reverseFurnaceCandidate(recipe, working, catalog);
                if (reverse != null) {
                    MatterValue existing = working.get(reverse.itemId());
                    if (existing == null || !existing.authoritative() && reverse.amount() < existing.amount()) {
                        working.put(reverse.itemId(), new MatterValue(
                                reverse.amount(), MatterValue.Source.INFERRED,
                                "reverse-recipe:" + recipe.recipeId()));
                        updates++;
                        changed = true;
                    }
                }
            }
        } while (changed && passes < maxPasses);

        Map<String, MatterValue> inferred = new LinkedHashMap<>();
        working.forEach((id, value) -> {
            if (value.source() == MatterValue.Source.INFERRED) inferred.put(id, value);
        });
        catalog.replaceInferred(inferred);

        int unresolvedRecipes = 0;
        for (RecipeMatterModel recipe : recipes) {
            if (!catalog.hasAuthoritative(recipe.primaryOutput().itemId()) && candidateValue(recipe, working).isEmpty()) {
                unresolvedRecipes++;
            }
        }
        return new InferenceReport(passes, updates, inferred.size(), unresolvedRecipes, changed);
    }

    /** Recomputes only the supplied closure while preserving unrelated inferred values. */
    public InferenceReport recomputeSubset(
            MatterCatalog catalog, Collection<RecipeMatterModel> recipes, java.util.Set<String> affectedIds) {
        java.util.Set<String> affected = java.util.Set.copyOf(affectedIds);
        Map<String, MatterValue> working = new LinkedHashMap<>();
        working.putAll(catalog.authoritativeSnapshot());
        catalog.inferredSnapshot().forEach((id, value) -> { if (!affected.contains(id)) working.put(id, value); });

        int maxPasses = Math.max(16, recipes.size() * 4 + affected.size() * 4);
        int passes = 0;
        int updates = 0;
        boolean changed;
        do {
            changed = false;
            passes++;
            for (RecipeMatterModel recipe : recipes) {
                String outputId = recipe.primaryOutput().itemId();
                if (affected.contains(outputId) && !catalog.hasAuthoritative(outputId)) {
                    OptionalLong candidate = candidateValue(recipe, working);
                    MatterValue existing = working.get(outputId);
                    if (candidate.isPresent()) {
                        long amount = candidate.getAsLong();
                        if (existing == null || (!existing.authoritative() && amount < existing.amount())) {
                            working.put(outputId, new MatterValue(amount, MatterValue.Source.INFERRED,
                                    "recipe:" + recipe.recipeId()));
                            updates++; changed = true;
                        }
                    }
                }
                ReverseCandidate reverse = reverseFurnaceCandidate(recipe, working, catalog);
                if (reverse != null && affected.contains(reverse.itemId())) {
                    MatterValue existing = working.get(reverse.itemId());
                    if (existing == null || (!existing.authoritative() && reverse.amount() < existing.amount())) {
                        working.put(reverse.itemId(), new MatterValue(reverse.amount(), MatterValue.Source.INFERRED,
                                "reverse-recipe:" + recipe.recipeId()));
                        updates++; changed = true;
                    }
                }
            }
        } while (changed && passes < maxPasses);

        LinkedHashMap<String, MatterValue> inferred = new LinkedHashMap<>();
        for (String id : affected) {
            MatterValue value = working.get(id);
            if (value != null && value.source() == MatterValue.Source.INFERRED) inferred.put(id, value);
        }
        catalog.replaceInferredSubset(affected, inferred);
        int unresolved = 0;
        for (String id : affected) if (!catalog.hasAuthoritative(id) && catalog.amount(id).isEmpty()) unresolved++;
        return new InferenceReport(passes, updates, inferred.size(), unresolved, changed);
    }

    private ReverseCandidate reverseFurnaceCandidate(
            RecipeMatterModel recipe, Map<String, MatterValue> values, MatterCatalog catalog) {
        String type = recipe.recipeType().toLowerCase(java.util.Locale.ROOT);
        if (!(type.contains("smelting") || type.contains("blasting"))) return null;
        if (recipe.inputs().size() != 1 || !recipe.returnedOrByproductOutputs().isEmpty()) return null;
        IngredientSlot slot = recipe.inputs().get(0);
        if (slot.alternatives().size() != 1) return null;
        ItemAmount input = slot.alternatives().get(0);
        if (catalog.hasAuthoritative(input.itemId())) return null;
        MatterValue output = values.get(recipe.primaryOutput().itemId());
        if (output == null || output.amount() <= 0) return null;
        try {
            long totalOutput = Math.multiplyExact(output.amount(), recipe.primaryOutput().count());
            long amount = totalOutput / input.count();
            return amount < 0 ? null : new ReverseCandidate(input.itemId(), amount);
        } catch (ArithmeticException overflow) {
            return null;
        }
    }

    private record ReverseCandidate(String itemId, long amount) {}

    private OptionalLong candidateValue(RecipeMatterModel recipe, Map<String, MatterValue> values) {
        long totalInputs = 0;
        for (IngredientSlot slot : recipe.inputs()) {
            OptionalLong slotCost = cheapestFullyResolvedAlternative(slot, values);
            if (slotCost.isEmpty()) return OptionalLong.empty();
            totalInputs = saturatedAdd(totalInputs, slotCost.getAsLong());
        }

        long returnedValue = 0;
        for (OutputStack returned : recipe.returnedOrByproductOutputs()) {
            MatterValue known = values.get(returned.itemId());
            if (known == null || known.amount() < 0 || (known.amount() == 0 && !isFreeSynthetic(returned.itemId()))) return OptionalLong.empty();
            returnedValue = saturatedAdd(returnedValue, saturatedMultiply(known.amount(), returned.count()));
        }

        long netConsumed = Math.max(0L, totalInputs - returnedValue);
        return OptionalLong.of(netConsumed / recipe.primaryOutput().count());
    }

    private OptionalLong cheapestFullyResolvedAlternative(IngredientSlot slot, Map<String, MatterValue> values) {
        long cheapest = Long.MAX_VALUE;
        for (ItemAmount alternative : slot.alternatives()) {
            MatterValue value = values.get(alternative.itemId());
            // Unknown alternatives are potentially cheaper than every known option. Refuse to
            // overvalue until all choices are understood.
            if (value == null || value.amount() < 0 || (value.amount() == 0 && !isFreeSynthetic(alternative.itemId()))) return OptionalLong.empty();
            long cost = saturatedMultiply(value.amount(), alternative.count());
            cheapest = Math.min(cheapest, cost);
        }
        return cheapest == Long.MAX_VALUE ? OptionalLong.empty() : OptionalLong.of(cheapest);
    }

    private static boolean isFreeSynthetic(String itemId) {
        return "projecte:fluid/water_bucket_content".equals(itemId);
    }

    private long saturatedAdd(long a, long b) {
        if (a > Long.MAX_VALUE - b) return Long.MAX_VALUE;
        return a + b;
    }

    private long saturatedMultiply(long a, long b) {
        if (a == 0 || b == 0) return 0;
        if (a > Long.MAX_VALUE / b) return Long.MAX_VALUE;
        return a * b;
    }

    public record InferenceReport(
            int passes,
            int valueUpdates,
            int inferredItemCount,
            int unresolvedRecipeCount,
            boolean hitIterationLimit) {}
}
