package dev.futurae.veilbound.ontology;

import java.util.Objects;

/** Replace-all holder so datapack reloads cannot partially update ontology balance. */
public final class OntologyPolicyRegistry {
    private OntologyRuntimePolicy policy = OntologyRuntimePolicy.DEVELOPMENT_DEFAULT;
    public OntologyRuntimePolicy policy() { return policy; }
    public void replace(OntologyRuntimePolicy policy) { this.policy = Objects.requireNonNull(policy, "policy"); }
}
