package dev.futurae.veilbound.upgrade;

import dev.futurae.veilbound.domain.CoreTier;
import java.util.List;
import java.util.Objects;

/** Data-driven sequential Core upgrade recipe. */
public record CoreUpgradeDefinition(CoreTier from, CoreTier to, List<UpgradeIngredient> ingredients) {
    public CoreUpgradeDefinition {
        Objects.requireNonNull(from, "from");
        Objects.requireNonNull(to, "to");
        ingredients = List.copyOf(ingredients);
        if (to.ordinal() != from.ordinal() + 1) {
            throw new IllegalArgumentException("Core upgrades must advance exactly one tier");
        }
        if (ingredients.isEmpty()) throw new IllegalArgumentException("Core upgrade must require fed items");
        java.util.HashSet<String> ids = new java.util.HashSet<>();
        for (UpgradeIngredient ingredient : ingredients) {
            if (!ids.add(ingredient.itemId())) throw new IllegalArgumentException("Duplicate Core upgrade ingredient: " + ingredient.itemId());
        }
    }
}
