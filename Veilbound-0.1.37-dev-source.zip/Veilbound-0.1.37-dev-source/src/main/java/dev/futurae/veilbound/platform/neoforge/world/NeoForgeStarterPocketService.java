package dev.futurae.veilbound.platform.neoforge.world;

import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.StarterPocketLayout;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;

/** Creates the one-time physical foothold for a newly-created personal Domain. */
public final class NeoForgeStarterPocketService {
    /** Usable Domain space is y=0..1; the support block lives immediately below it. */
    public static final DomainPosition FLOOR = StarterPocketLayout.VOID_ANCHOR_FLOOR;
    public static final double ARRIVAL_X = StarterPocketLayout.ARRIVAL_X;
    public static final double ARRIVAL_Y = StarterPocketLayout.ARRIVAL_Y;
    public static final double ARRIVAL_Z = StarterPocketLayout.ARRIVAL_Z;

    /**
     * Called exactly once for a newly-created Domain. Existing Domains are never repaired here:
     * after the owner intentionally breaks/moves the starter Void Anchor, it must stay moved.
     */
    public boolean create(ServerLevel level) {
        Objects.requireNonNull(level, "level");
        BlockPos floor = new BlockPos(FLOOR.x(), FLOOR.y(), FLOOR.z());
        if (level.getBlockState(floor).is(VeilboundBlocks.VOID_ANCHOR.get())) return true;
        if (!level.isEmptyBlock(floor)) return false;
        return level.setBlockAndUpdate(floor, VeilboundBlocks.VOID_ANCHOR.get().defaultBlockState());
    }
}
