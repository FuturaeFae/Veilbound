package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Client requests for the Archive/Orrery/Environmental Zone management surface. */
public record MemoryManagementActionPayload(Action action, String targetId, String value) implements CustomPacketPayload {
    public static final int MAX_TARGET_LENGTH = 128;
    public static final int MAX_VALUE_LENGTH = 128;

    public enum Action {
        OPEN_ARCHIVE,
        OPEN_ORRERY,
        OPEN_ZONES,
        TOGGLE_ORRERY_MEMORY,
        CLEAR_ORRERY,
        ZONE_DELETE,
        ZONE_PRIORITY_UP,
        ZONE_PRIORITY_DOWN,
        ZONE_TOGGLE_BLEND,
        ZONE_RETUNE,
        ZONE_RENAME
    }

    public static final Type<MemoryManagementActionPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "memory_management_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, MemoryManagementActionPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override public MemoryManagementActionPayload decode(RegistryFriendlyByteBuf buffer) {
            int ordinal = buffer.readVarInt();
            Action[] values = Action.values();
            Action action = ordinal >= 0 && ordinal < values.length ? values[ordinal] : Action.OPEN_ARCHIVE;
            return new MemoryManagementActionPayload(
                    action,
                    buffer.readUtf(MAX_TARGET_LENGTH),
                    buffer.readUtf(MAX_VALUE_LENGTH));
        }

        @Override public void encode(RegistryFriendlyByteBuf buffer, MemoryManagementActionPayload payload) {
            buffer.writeVarInt(payload.action().ordinal());
            buffer.writeUtf(payload.targetId(), MAX_TARGET_LENGTH);
            buffer.writeUtf(payload.value(), MAX_VALUE_LENGTH);
        }
    };

    public MemoryManagementActionPayload {
        if (action == null) action = Action.OPEN_ARCHIVE;
        targetId = targetId == null ? "" : targetId;
        value = value == null ? "" : value;
        if (targetId.length() > MAX_TARGET_LENGTH) targetId = targetId.substring(0, MAX_TARGET_LENGTH);
        if (value.length() > MAX_VALUE_LENGTH) value = value.substring(0, MAX_VALUE_LENGTH);
    }

    public static MemoryManagementActionPayload openArchive() {
        return new MemoryManagementActionPayload(Action.OPEN_ARCHIVE, "", "");
    }
    public static MemoryManagementActionPayload openOrrery() {
        return new MemoryManagementActionPayload(Action.OPEN_ORRERY, "", "");
    }
    public static MemoryManagementActionPayload openZones() {
        return new MemoryManagementActionPayload(Action.OPEN_ZONES, "", "");
    }

    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
