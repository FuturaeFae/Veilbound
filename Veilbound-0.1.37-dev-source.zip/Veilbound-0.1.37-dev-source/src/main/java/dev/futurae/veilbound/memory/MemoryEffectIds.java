package dev.futurae.veilbound.memory;

/** Built-in environmental profile keys/values implemented by Veilbound's base runtime. */
public final class MemoryEffectIds {
    public static final String VISUAL_SKY = "visual.sky";
    public static final String VISUAL_WEATHER = "visual.weather";
    public static final String VISUAL_FLORA = "visual.flora";
    public static final String VISUAL_CELESTIAL_CYCLE = "visual.celestial_cycle";

    public static final String MECHANIC_ILLUMINATION = "mechanic.illumination";
    public static final String MECHANIC_WEATHER = "mechanic.weather";
    public static final String MECHANIC_FERTILITY = "mechanic.fertility";
    public static final String MECHANIC_DAY_CYCLE = "mechanic.day_cycle";

    public static final String OPEN_SKY = "veilbound:open_sky";
    public static final String NATURAL_DAYLIGHT = "veilbound:natural_daylight";
    public static final String GENTLE_RAIN = "veilbound:gentle_rain";
    public static final String RAIN = "veilbound:rain";
    public static final String VERDANT = "veilbound:verdant";
    public static final String OVERWORLD = "minecraft:overworld";

    private MemoryEffectIds() {}
}
