package dev.futurae.veilbound.threshold;

import dev.futurae.veilbound.domain.DomainPosition;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 * Loader-neutral planning/commit boundary for deactivating one persistent Threshold structure.
 *
 * <p>The platform must evacuate every guest returned by {@link #plan} before calling
 * {@link #commit}. This ordering guarantees the persistent binding and frame structure are not
 * removed while somebody still depends on that Threshold for a safe return path.</p>
 */
public final class ThresholdDeactivationService {
    private final ThresholdRegistry thresholds;
    private final ThresholdSessionManager sessions;

    public ThresholdDeactivationService(ThresholdRegistry thresholds, ThresholdSessionManager sessions) {
        this.thresholds = Objects.requireNonNull(thresholds, "thresholds");
        this.sessions = Objects.requireNonNull(sessions, "sessions");
    }

    public PlanResult plan(String sourceDimensionId, DomainPosition brokenPortalPosition) {
        Objects.requireNonNull(sourceDimensionId, "sourceDimensionId");
        Objects.requireNonNull(brokenPortalPosition, "brokenPortalPosition");
        ThresholdDefinition threshold = thresholds.findAt(sourceDimensionId, brokenPortalPosition).orElse(null);
        if (threshold == null) return PlanResult.denied("unbound_portal_block");
        return PlanResult.allowed(new DeactivationPlan(
                threshold,
                sessions.sessionsForThreshold(threshold.id())));
    }

    /** Commit only after every guest in the plan has been moved safely and its session closed. */
    public CommitResult commit(DeactivationPlan plan) {
        Objects.requireNonNull(plan, "plan");
        ThresholdDefinition current = thresholds.get(plan.threshold().id()).orElse(null);
        if (current == null) return CommitResult.denied("threshold_already_removed");
        if (!current.equals(plan.threshold())) return CommitResult.denied("threshold_changed_during_deactivation");
        if (!sessions.sessionsForThreshold(current.id()).isEmpty()) {
            return CommitResult.denied("threshold_still_has_guests");
        }
        if (!thresholds.removeSystem(current.id())) return CommitResult.denied("threshold_remove_failed");
        return CommitResult.allowed(current);
    }

    public record DeactivationPlan(ThresholdDefinition threshold, List<GuestThresholdSession> guests) {
        public DeactivationPlan {
            Objects.requireNonNull(threshold, "threshold");
            guests = List.copyOf(Objects.requireNonNull(guests, "guests"));
        }
    }

    public record PlanResult(boolean allowed, DeactivationPlan plan, String reason) {
        static PlanResult denied(String reason) { return new PlanResult(false, null, reason); }
        static PlanResult allowed(DeactivationPlan plan) { return new PlanResult(true, plan, "ok"); }
    }

    public record CommitResult(boolean success, ThresholdDefinition removedThreshold, String reason) {
        static CommitResult denied(String reason) { return new CommitResult(false, null, reason); }
        static CommitResult allowed(ThresholdDefinition threshold) { return new CommitResult(true, threshold, "ok"); }
    }
}
