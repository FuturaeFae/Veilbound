package dev.futurae.veilbound.inventory;

import java.util.Objects;

/**
 * Exact digital-stack identity. The platform adapter owns component serialization; the core
 * deliberately treats it as opaque canonical data so differently-componented items never merge.
 */
public record VeilStackKey(String itemId, String componentData) {
    public VeilStackKey {
        Objects.requireNonNull(itemId, "itemId");
        Objects.requireNonNull(componentData, "componentData");
        if (itemId.isBlank()) throw new IllegalArgumentException("itemId may not be blank");
    }

    public static VeilStackKey plain(String itemId) {
        return new VeilStackKey(itemId, "");
    }
}
