package dev.futurae.veilbound.ritual;

import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import dev.futurae.veilbound.upgrade.UpgradeIngredient;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/** Lossless incremental ingredient feeding for the origin Core ritual. */
public final class CoreAwakeningProgress {
    private final CoreAwakeningDefinition definition;
    private final Map<String, Long> fed = new LinkedHashMap<>();

    public CoreAwakeningProgress(CoreAwakeningDefinition definition) {
        this.definition = Objects.requireNonNull(definition, "definition");
    }

    public CoreAwakeningDefinition definition() { return definition; }
    public Map<String, Long> fed() { return Map.copyOf(fed); }

    /** Returns exactly how many offered items were accepted; excess is never consumed. */
    public long feed(String itemId, long offeredCount) {
        Objects.requireNonNull(itemId, "itemId");
        if (offeredCount <= 0) return 0;
        UpgradeIngredient requirement = definition.ingredients().stream()
                .filter(ingredient -> ingredient.itemId().equals(itemId))
                .findFirst()
                .orElse(null);
        if (requirement == null) return 0;
        long already = fed.getOrDefault(itemId, 0L);
        long remaining = Math.max(0L, requirement.count() - already);
        long accepted = Math.min(remaining, offeredCount);
        if (accepted > 0) fed.put(itemId, already + accepted);
        return accepted;
    }

    public boolean complete() {
        for (UpgradeIngredient requirement : definition.ingredients()) {
            if (fed.getOrDefault(requirement.itemId(), 0L) < requirement.count()) return false;
        }
        return true;
    }

    public AwakeningResult finalizeAt(DomainState state, DomainPosition ritualPosition) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(ritualPosition, "ritualPosition");
        if (state.coreActive()) return AwakeningResult.denied("core_already_active");
        if (!DomainPosition.ORIGIN.equals(ritualPosition)) return AwakeningResult.denied("not_domain_origin");
        if (!state.hasInitialCoreSpace()) return AwakeningResult.denied("domain_too_small");
        if (!complete()) return AwakeningResult.denied("requirements_incomplete");
        state.awakenCore(ritualPosition);
        return AwakeningResult.allowed();
    }

    public record AwakeningResult(boolean awakened, String reason) {
        public static AwakeningResult denied(String reason) { return new AwakeningResult(false, reason); }
        public static AwakeningResult allowed() { return new AwakeningResult(true, "ok"); }
    }
}
