package dev.futurae.veilbound.persistence;

import dev.futurae.veilbound.inventory.VeilInventory;
import dev.futurae.veilbound.inventory.VeilStackKey;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** Exact persistent contents of one owner's digital Veil Inventory. */
public record VeilInventorySnapshot(List<StoredStack> stacks) {
    public static final VeilInventorySnapshot EMPTY = new VeilInventorySnapshot(List.of());

    public VeilInventorySnapshot {
        stacks = List.copyOf(stacks);
    }

    public static VeilInventorySnapshot capture(VeilInventory inventory) {
        Objects.requireNonNull(inventory, "inventory");
        return new VeilInventorySnapshot(inventory.contents().entrySet().stream()
                .map(entry -> new StoredStack(entry.getKey().itemId(), entry.getKey().componentData(), entry.getValue()))
                .toList());
    }

    public void restoreInto(VeilInventory inventory) {
        Objects.requireNonNull(inventory, "inventory");
        Map<VeilStackKey, Long> restored = new LinkedHashMap<>();
        for (StoredStack stack : stacks) {
            VeilStackKey key = new VeilStackKey(stack.itemId(), stack.componentData());
            if (restored.put(key, stack.count()) != null) {
                throw new IllegalArgumentException("Duplicate Veil Inventory stack identity in persistence");
            }
        }
        inventory.replaceFromPersistence(restored);
    }

    public record StoredStack(String itemId, String componentData, long count) {
        public StoredStack {
            Objects.requireNonNull(itemId, "itemId");
            Objects.requireNonNull(componentData, "componentData");
            if (itemId.isBlank()) throw new IllegalArgumentException("itemId may not be blank");
            if (count <= 0) throw new IllegalArgumentException("count must be > 0");
        }
    }
}
