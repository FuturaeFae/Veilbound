package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Bounded station state and recipe browser data sent only to the interacting owner. */
public record EngineeringStationSnapshotPayload(
        int x, int y, int z,
        boolean allowed,
        String reason,
        String station,
        long storedMatter,
        long matterCapacity,
        long storedPotential,
        long potentialCapacity,
        String selectedRecipeId,
        int progressTicks,
        int processTicks,
        String status,
        List<InventoryEntry> inventory,
        List<RecipeEntry> recipes) implements CustomPacketPayload {

    public static final int MAX_RECIPES = 128;
    public static final int MAX_INPUTS = 32;
    public static final int MAX_REQUIREMENTS = 32;
    public static final int MAX_MISSING = 48;
    public static final int MAX_INVENTORY = 128;

    public static final Type<EngineeringStationSnapshotPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "engineering_station_snapshot"));

    public static final StreamCodec<RegistryFriendlyByteBuf, EngineeringStationSnapshotPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override public EngineeringStationSnapshotPayload decode(RegistryFriendlyByteBuf b) {
            int x=b.readInt(), y=b.readInt(), z=b.readInt();
            boolean allowed=b.readBoolean();
            String reason=b.readUtf(192), station=b.readUtf(64);
            long matter=b.readLong(), matterCap=b.readLong(), potential=b.readLong(), potentialCap=b.readLong();
            String selected=b.readUtf(192); int progress=b.readVarInt(), process=b.readVarInt(); String status=b.readUtf(192);
            int inventoryCount = checked(b.readVarInt(), MAX_INVENTORY, "inventory");
            List<InventoryEntry> inventory = new ArrayList<>(inventoryCount);
            for (int i=0;i<inventoryCount;i++) inventory.add(new InventoryEntry(b.readUtf(192), b.readLong()));
            int recipeCount = checked(b.readVarInt(), MAX_RECIPES, "recipes");
            List<RecipeEntry> recipes = new ArrayList<>(recipeCount);
            for (int i=0;i<recipeCount;i++) {
                String id=b.readUtf(192), name=b.readUtf(192), output=b.readUtf(192); int outputCount=b.readVarInt();
                long mc=b.readLong(), de=b.readLong(), pc=b.readLong(); String tier=b.readUtf(64); int ticks=b.readVarInt();
                List<String> inputs = readStrings(b, MAX_INPUTS, 192);
                List<String> memories = readStrings(b, MAX_REQUIREMENTS, 192);
                List<String> laws = readStrings(b, MAX_REQUIREMENTS, 192);
                List<String> missing = readStrings(b, MAX_MISSING, 256);
                recipes.add(new RecipeEntry(id,name,output,outputCount,mc,de,pc,tier,ticks,inputs,memories,laws,missing));
            }
            return new EngineeringStationSnapshotPayload(x,y,z,allowed,reason,station,matter,matterCap,potential,potentialCap,selected,progress,process,status,inventory,recipes);
        }
        @Override public void encode(RegistryFriendlyByteBuf b, EngineeringStationSnapshotPayload p) {
            b.writeInt(p.x()); b.writeInt(p.y()); b.writeInt(p.z()); b.writeBoolean(p.allowed());
            b.writeUtf(p.reason(),192); b.writeUtf(p.station(),64);
            b.writeLong(p.storedMatter()); b.writeLong(p.matterCapacity()); b.writeLong(p.storedPotential()); b.writeLong(p.potentialCapacity());
            b.writeUtf(p.selectedRecipeId(),192); b.writeVarInt(Math.max(0,p.progressTicks())); b.writeVarInt(Math.max(0,p.processTicks())); b.writeUtf(p.status(),192);
            int invCount=Math.min(MAX_INVENTORY,p.inventory().size()); b.writeVarInt(invCount);
            for(int i=0;i<invCount;i++){ var e=p.inventory().get(i); b.writeUtf(e.itemId(),192); b.writeLong(e.count()); }
            int recipeCount=Math.min(MAX_RECIPES,p.recipes().size()); b.writeVarInt(recipeCount);
            for(int i=0;i<recipeCount;i++){
                var r=p.recipes().get(i); b.writeUtf(r.id(),192); b.writeUtf(r.displayName(),192); b.writeUtf(r.outputItemId(),192); b.writeVarInt(r.outputCount());
                b.writeLong(r.matterCost()); b.writeLong(r.deCost()); b.writeLong(r.potentialCost()); b.writeUtf(r.minimumCoreTier(),64); b.writeVarInt(r.processTicks());
                writeStrings(b,r.inputs(),MAX_INPUTS,192); writeStrings(b,r.requiredMemories(),MAX_REQUIREMENTS,192); writeStrings(b,r.requiredLaws(),MAX_REQUIREMENTS,192); writeStrings(b,r.missing(),MAX_MISSING,256);
            }
        }
    };

    public EngineeringStationSnapshotPayload {
        reason=reason==null?"unknown":reason; station=station==null?"":station; selectedRecipeId=selectedRecipeId==null?"":selectedRecipeId; status=status==null?"":status;
        inventory=List.copyOf(inventory==null?List.of():inventory); recipes=List.copyOf(recipes==null?List.of():recipes);
    }
    public static EngineeringStationSnapshotPayload denied(int x,int y,int z,String reason){ return new EngineeringStationSnapshotPayload(x,y,z,false,reason,"",0,0,0,0,"",0,0,"",List.of(),List.of()); }
    public record InventoryEntry(String itemId,long count){ public InventoryEntry{ if(itemId==null)itemId=""; if(count<0)count=0; } }
    public record RecipeEntry(String id,String displayName,String outputItemId,int outputCount,long matterCost,long deCost,long potentialCost,String minimumCoreTier,int processTicks,List<String> inputs,List<String> requiredMemories,List<String> requiredLaws,List<String> missing){
        public RecipeEntry{ id=id==null?"":id; displayName=displayName==null?id:displayName; outputItemId=outputItemId==null?"":outputItemId; minimumCoreTier=minimumCoreTier==null?"":minimumCoreTier; inputs=List.copyOf(inputs==null?List.of():inputs); requiredMemories=List.copyOf(requiredMemories==null?List.of():requiredMemories); requiredLaws=List.copyOf(requiredLaws==null?List.of():requiredLaws); missing=List.copyOf(missing==null?List.of():missing); }
    }
    private static int checked(int value,int max,String what){ if(value<0||value>max)throw new IllegalArgumentException("Invalid "+what+" count: "+value); return value; }
    private static List<String> readStrings(RegistryFriendlyByteBuf b,int max,int len){ int n=checked(b.readVarInt(),max,"string list"); List<String> out=new ArrayList<>(n); for(int i=0;i<n;i++)out.add(b.readUtf(len)); return out; }
    private static void writeStrings(RegistryFriendlyByteBuf b,List<String> values,int max,int len){ int n=Math.min(max,values.size()); b.writeVarInt(n); for(int i=0;i<n;i++)b.writeUtf(values.get(i),len); }
    @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
}
