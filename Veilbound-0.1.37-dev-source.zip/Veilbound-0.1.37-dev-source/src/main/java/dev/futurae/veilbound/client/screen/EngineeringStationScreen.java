package dev.futurae.veilbound.client.screen;

import dev.futurae.veilbound.network.EngineeringStationActionPayload;
import dev.futurae.veilbound.network.EngineeringStationSnapshotPayload;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;

/** Recipe browser/status panel for Dimensional Fabricator and Veil Foundry. */
public final class EngineeringStationScreen extends Screen {
    private static final int WIDTH=620, HEIGHT=332, ROWS=8;
    private EngineeringStationSnapshotPayload snapshot;
    private int page;
    private String selectedId="";
    public EngineeringStationScreen(EngineeringStationSnapshotPayload snapshot){ super(Component.translatable("screen.veilbound.engineering")); this.snapshot=snapshot; selectedId=snapshot.selectedRecipeId(); normalize(); }
    public void acceptSnapshot(EngineeringStationSnapshotPayload next){ snapshot=next; if(!next.selectedRecipeId().isBlank())selectedId=next.selectedRecipeId(); normalize(); if(minecraft!=null){clearWidgets();init();} }
    private void normalize(){ page=Math.max(0,Math.min(page,pageCount()-1)); if(selectedId.isBlank()&&!snapshot.recipes().isEmpty())selectedId=snapshot.recipes().get(0).id(); if(snapshot.recipes().stream().noneMatch(r->r.id().equals(selectedId)))selectedId=snapshot.recipes().isEmpty()?"":snapshot.recipes().get(0).id(); }
    @Override protected void init(){ super.init(); int l=Math.max(4,width/2-WIDTH/2), t=Math.max(12,height/2-HEIGHT/2); if(!snapshot.allowed())return;
        Button prev=Button.builder(Component.literal("<"),b->{page--;rebuild();}).bounds(l+12,t+44,28,20).build(); prev.active=page>0; addRenderableWidget(prev);
        Button next=Button.builder(Component.literal(">"),b->{page++;rebuild();}).bounds(l+230,t+44,28,20).build(); next.active=page+1<pageCount(); addRenderableWidget(next);
        List<EngineeringStationSnapshotPayload.RecipeEntry> rows=pageRows();
        for(int i=0;i<rows.size();i++){ var r=rows.get(i); String prefix=r.id().equals(snapshot.selectedRecipeId())?"▶ ":r.missing().isEmpty()?"✓ ":"• "; addRenderableWidget(Button.builder(Component.literal(prefix+r.displayName()),b->{selectedId=r.id();send(EngineeringStationActionPayload.Action.SELECT_RECIPE,r.id());}).bounds(l+12,t+72+i*28,246,22).build()); }
        var selected=selected();
        if(selected!=null){ Button claim=Button.builder(Component.translatable("screen.veilbound.engineering.claim"),b->send(EngineeringStationActionPayload.Action.CLAIM_OUTPUT,selected.outputItemId())).bounds(l+390,t+286,102,22).build(); claim.active=stored(selected.outputItemId())>0; addRenderableWidget(claim); }
        addRenderableWidget(Button.builder(Component.translatable("screen.veilbound.engineering.refresh"),b->send(EngineeringStationActionPayload.Action.REFRESH,"")).bounds(l+500,t+286,96,22).build());
    }
    private void rebuild(){clearWidgets();init();}
    private void send(EngineeringStationActionPayload.Action action,String value){ ClientPacketDistributor.sendToServer(new EngineeringStationActionPayload(action,snapshot.x(),snapshot.y(),snapshot.z(),value)); }
    private int pageCount(){return Math.max(1,(snapshot.recipes().size()+ROWS-1)/ROWS);} private List<EngineeringStationSnapshotPayload.RecipeEntry> pageRows(){int from=Math.min(page*ROWS,snapshot.recipes().size());return snapshot.recipes().subList(from,Math.min(from+ROWS,snapshot.recipes().size()));}
    private EngineeringStationSnapshotPayload.RecipeEntry selected(){return snapshot.recipes().stream().filter(r->r.id().equals(selectedId)).findFirst().orElse(null);} private long stored(String id){return snapshot.inventory().stream().filter(e->e.itemId().equals(id)).mapToLong(EngineeringStationSnapshotPayload.InventoryEntry::count).sum();}
    @Override public void extractBackground(GuiGraphicsExtractor g,int mouseX,int mouseY,float partial){extractTransparentBackground(g);}
    @Override public void extractRenderState(GuiGraphicsExtractor g,int mouseX,int mouseY,float partial){super.extractRenderState(g,mouseX,mouseY,partial); int l=Math.max(4,width/2-WIDTH/2),t=Math.max(12,height/2-HEIGHT/2); g.fill(l,t,l+WIDTH,t+HEIGHT,0xF00D0B14);g.fill(l,t,l+WIDTH,t+34,0xF02A163C);g.fill(l,t+33,l+WIDTH,t+34,0xFFB783E3);g.text(font,Component.translatable("screen.veilbound.engineering.title",pretty(snapshot.station())),l+12,t+12,0xFFF2E9FF,false);
        if(!snapshot.allowed()){g.centeredText(font,Component.translatable("screen.veilbound.engineering.denied",snapshot.reason()),width/2,t+150,0xFFFF8585);return;}
        g.text(font,Component.translatable("screen.veilbound.engineering.page",page+1,pageCount()),l+54,t+49,0xFFC7B9D4,false);
        g.text(font,Component.translatable("screen.veilbound.engineering.buffers",fmt(snapshot.storedMatter()),fmt(snapshot.matterCapacity()),fmt(snapshot.storedPotential()),fmt(snapshot.potentialCapacity())),l+278,t+44,0xFFDFCBEF,false);
        g.text(font,Component.translatable("screen.veilbound.engineering.feed_hint"),l+278,t+60,0xFF9E93AA,false);
        var r=selected(); if(r==null)return;
        int x=l+278,y=t+84; g.text(font,Component.literal(r.displayName()),x,y,0xFFE4BCFF,false); y+=18; g.text(font,Component.literal("→ "+r.outputItemId()+" × "+r.outputCount()),x,y,0xFFFFFFFF,false);y+=18;
        g.text(font,Component.literal("Matter "+fmt(r.matterCost())+"   DE "+fmt(r.deCost())+"   Potential "+fmt(r.potentialCost())),x,y,0xFFC5BDD0,false);y+=16;g.text(font,Component.literal("Core "+r.minimumCoreTier()+"   Process "+String.format("%.1fs",r.processTicks()/20.0)),x,y,0xFFC5BDD0,false);y+=20;
        g.text(font,Component.translatable("screen.veilbound.engineering.inputs"),x,y,0xFFE4BCFF,false);y+=14; for(String input:r.inputs().stream().limit(6).toList()){g.text(font,Component.literal("• "+input),x+8,y,0xFFC5BDD0,false);y+=13;}
        if(!r.requiredMemories().isEmpty()){g.text(font,Component.literal("Memories: "+String.join(", ",r.requiredMemories())),x,y,0xFF9ED6FF,false);y+=14;} if(!r.requiredLaws().isEmpty()){g.text(font,Component.literal("Laws: "+String.join(", ",r.requiredLaws())),x,y,0xFFFFC080,false);y+=14;}
        if(r.id().equals(snapshot.selectedRecipeId())){int total=Math.max(1,snapshot.processTicks());int bar=220;int fill=(int)Math.min(bar,(long)bar*Math.max(0,snapshot.progressTicks())/total);g.fill(x,t+266,x+bar,t+276,0xFF33273D);g.fill(x,t+266,x+fill,t+276,0xFFB783E3);g.text(font,Component.literal(snapshot.status().replace('_',' ')),x+228,t+266,0xFFBEB4CA,false);}
        if(!r.missing().isEmpty()){String first=r.missing().get(0).replace('_',' ');g.text(font,Component.translatable("screen.veilbound.engineering.missing",first),x,t+244,0xFFFF8585,false);} else g.text(font,Component.translatable("screen.veilbound.engineering.ready"),x,t+244,0xFF92E8A8,false);
    }
    private static String pretty(String raw){if(raw==null)return"Engineering Station";String s=raw.toLowerCase(java.util.Locale.ROOT).replace('_',' ');return Character.toUpperCase(s.charAt(0))+s.substring(1);} private static String fmt(long n){if(n>=1_000_000_000L)return String.format("%.2fB",n/1_000_000_000.0);if(n>=1_000_000L)return String.format("%.2fM",n/1_000_000.0);if(n>=1_000L)return String.format("%.1fk",n/1_000.0);return Long.toString(n);}
}
