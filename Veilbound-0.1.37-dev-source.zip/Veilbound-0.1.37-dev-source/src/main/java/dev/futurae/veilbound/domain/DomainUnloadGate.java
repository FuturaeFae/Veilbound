package dev.futurae.veilbound.domain;

/**
 * Central safety gate for unloading a runtime Domain level. A Domain may only disappear from
 * memory after every player has left/been evacuated and no chunk/transit/runtime requirement
 * still depends on it. Persisted Domain data remains intact while unloaded (dormant).
 */
public final class DomainUnloadGate {
    private DomainUnloadGate() {}

    public static Decision evaluate(
            int playersInside,
            int forcedChunks,
            int pendingTransits,
            int activeRuntimeRequirements) {
        if (playersInside < 0 || forcedChunks < 0 || pendingTransits < 0 || activeRuntimeRequirements < 0) {
            throw new IllegalArgumentException("Domain unload counters must be >= 0");
        }
        if (playersInside > 0) return Decision.denied("players_inside");
        if (forcedChunks > 0) return Decision.denied("forced_chunks");
        if (pendingTransits > 0) return Decision.denied("pending_transit");
        if (activeRuntimeRequirements > 0) return Decision.denied("active_runtime_requirement");
        return Decision.permitted();
    }

    public record Decision(boolean allowed, String reason) {
        public static Decision denied(String reason) { return new Decision(false, reason); }
        public static Decision permitted() { return new Decision(true, "ok"); }
    }
}
