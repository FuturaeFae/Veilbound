package dev.futurae.veilbound.threshold;

import dev.futurae.veilbound.travel.ReturnAnchor;

import java.util.Objects;
import java.util.UUID;

/** One active guest visit and its per-player evacuation destination. */
public record GuestThresholdSession(
        UUID guestId,
        UUID ownerId,
        UUID thresholdId,
        ReturnAnchor returnAnchor,
        long enteredGameTick) {
    public GuestThresholdSession {
        Objects.requireNonNull(guestId, "guestId");
        Objects.requireNonNull(ownerId, "ownerId");
        Objects.requireNonNull(thresholdId, "thresholdId");
        Objects.requireNonNull(returnAnchor, "returnAnchor");
        if (guestId.equals(ownerId)) throw new IllegalArgumentException("Owner is not a guest session");
        if (enteredGameTick < 0) throw new IllegalArgumentException("enteredGameTick must be >= 0");
    }
}
