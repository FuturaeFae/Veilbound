package dev.futurae.veilbound.matter;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Immutable set of Matter overrides produced by a successful datapack resource scan.
 *
 * Keeping this separate from {@link MatterCatalog} lets NeoForge stage a reload and only
 * publish it once the server finishes the corresponding datapack reload/sync cycle.
 */
public record MatterDatapackSnapshot(Map<String, OverrideValue> values, List<String> warnings) {
    private static final MatterDatapackSnapshot EMPTY = new MatterDatapackSnapshot(Map.of(), List.of());

    public MatterDatapackSnapshot {
        Objects.requireNonNull(values, "values");
        Objects.requireNonNull(warnings, "warnings");
        values = Collections.unmodifiableMap(new LinkedHashMap<>(values));
        warnings = List.copyOf(warnings);
    }

    public static MatterDatapackSnapshot empty() {
        return EMPTY;
    }

    public void applyTo(MatterCatalog catalog) {
        Objects.requireNonNull(catalog, "catalog");
        catalog.clearDatapack();
        values.forEach((itemId, override) ->
                catalog.putDatapack(itemId, override.amount(), override.provenance()));
    }

    public record OverrideValue(long amount, String provenance) {
        public OverrideValue {
            if (amount < 0) throw new IllegalArgumentException("Matter override must be non-negative");
            provenance = provenance == null ? "" : provenance;
        }
    }
}
