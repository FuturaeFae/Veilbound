package dev.futurae.veilbound.matter;

import java.util.Collection;

/**
 * Platform/mod compatibility seam for converting loaded recipes into Veilbound's conservative
 * loader-neutral Matter model. Opaque recipes may simply be omitted rather than guessed.
 */
@FunctionalInterface
public interface MatterRecipeSource {
    Collection<RecipeMatterModel> normalizedRecipes();
}
