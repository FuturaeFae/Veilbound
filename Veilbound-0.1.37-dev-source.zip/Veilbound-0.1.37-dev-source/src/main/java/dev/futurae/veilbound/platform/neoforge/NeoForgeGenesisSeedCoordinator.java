package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.domain.DomainIdentity;
import dev.futurae.veilbound.registry.VeilboundItems;
import dev.futurae.veilbound.ritual.GenesisSeedService;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.Objects;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/** Consumes a Genesis Seed to bind exactly one personal Domain to the player's UUID. */
public final class NeoForgeGenesisSeedCoordinator {
    private final VeilboundRuntime runtime;

    public NeoForgeGenesisSeedCoordinator(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    public void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (event.isCanceled() || !(event.getEntity() instanceof ServerPlayer player) || event.getLevel().isClientSide()) return;
        if (!event.getItemStack().is(VeilboundItems.GENESIS_SEED.get())) return;
        bind(player, event.getLevel().dimension().identifier().toString(), event.getItemStack(),
                result -> { event.setCancellationResult(result); event.setCanceled(true); });
    }

    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.isCanceled() || !(event.getEntity() instanceof ServerPlayer player) || event.getLevel().isClientSide()) return;
        if (!event.getItemStack().is(VeilboundItems.GENESIS_SEED.get())) return;
        bind(player, event.getLevel().dimension().identifier().toString(), event.getItemStack(),
                result -> { event.setCancellationResult(result); event.setCanceled(true); });
    }

    private void bind(ServerPlayer player, String currentDimension, net.minecraft.world.item.ItemStack held,
            java.util.function.Consumer<InteractionResult> finish) {
        if (DomainIdentity.ownerFromDimensionId(currentDimension).isPresent()) {
            player.displayClientMessage(Component.translatable("message.veilbound.genesis_seed.outside_only"), true);
            finish.accept(InteractionResult.FAIL);
            return;
        }
        GenesisSeedService.BindResult result = GenesisSeedService.bind(runtime.domains(), player.getUUID());
        if (!result.bound()) {
            player.displayClientMessage(Component.translatable("message.veilbound.genesis_seed." + result.reason()), true);
            finish.accept(InteractionResult.FAIL);
            return;
        }
        runtime.domainRuntime().setOwnerOnline(player.getUUID(), true);
        runtime.domainRuntime().setOwnerInside(player.getUUID(), false);
        if (!player.getAbilities().instabuild) held.shrink(1);
        player.displayClientMessage(Component.translatable("message.veilbound.genesis_seed.bound"), false);
        finish.accept(InteractionResult.SUCCESS);
    }
}
