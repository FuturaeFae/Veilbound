package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Small client request surface; every mutation is revalidated server-side. */
public record SpatialGeneratorActionPayload(Action action) implements CustomPacketPayload {
    public enum Action { OPEN, CONDENSE_FEED_HAND, EXPAND_X, EXPAND_Y, EXPAND_Z, AWAKEN_CORE }
    public static final Type<SpatialGeneratorActionPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "spatial_generator_action"));
    public static final StreamCodec<RegistryFriendlyByteBuf, SpatialGeneratorActionPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override public SpatialGeneratorActionPayload decode(RegistryFriendlyByteBuf buffer) {
            int i = buffer.readVarInt();
            Action[] values = Action.values();
            return new SpatialGeneratorActionPayload(i >= 0 && i < values.length ? values[i] : Action.OPEN);
        }
        @Override public void encode(RegistryFriendlyByteBuf buffer, SpatialGeneratorActionPayload payload) {
            buffer.writeVarInt(payload.action().ordinal());
        }
    };
    public SpatialGeneratorActionPayload { if (action == null) action = Action.OPEN; }
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
