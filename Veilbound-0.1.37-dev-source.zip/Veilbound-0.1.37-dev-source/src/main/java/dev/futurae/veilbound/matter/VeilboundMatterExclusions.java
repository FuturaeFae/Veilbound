package dev.futurae.veilbound.matter;

import java.util.List;

/** Technology intentionally excluded from Matter valuation to prevent closed-loop fabrication exploits. */
public final class VeilboundMatterExclusions {
    private static final List<String> IDS = List.of(
        "dimensional_fabricator","veil_foundry","probability_vane","ontological_harvester","ontological_compiler","veil_lance",
        "folded_matter_block","causal_steel_block","axiomatic_glass_block","continuity_crystal_block","sovereign_alloy_block",
        "resonant_frame_segment","phase_logic_array","dimensional_capacitor","phase_coil","causal_lattice","mnemonic_matrix",
        "continuity_inductor","pattern_matrix","transmutation_lattice","material_phase_regulator","boundary_skeleton","causal_processor",
        "axiomatic_controller","law_kernel","ontological_matrix","singularity_regulator","folded_space_brace","transcendent_framework",
        "sovereign_computation_core","folded_matter","causal_steel","axiomatic_glass","continuity_crystal","sovereign_alloy",
        "anchored_core_assembly","resonant_core_assembly","ascendant_core_assembly","transcendent_core_assembly",
        "axiom_of_hostility","axiom_of_fauna","axiom_of_flame","axiom_of_ruin","axiom_of_grief","axiom_of_conflict",
        "axiom_of_descent","axiom_of_preservation","axiom_of_time","axiom_of_weather",
        "phasebreaker","rift_cutter","boundary_spade","resonance_multitool",
        "phaseweave_helmet","phaseweave_chestplate","phaseweave_leggings","phaseweave_boots",
        "causal_helmet","causal_chestplate","causal_leggings","causal_boots",
        "sovereign_helmet","sovereign_chestplate","sovereign_leggings","sovereign_boots",
        "paradox_crystal","veil_residue","fractured_essence","causal_shard","unresolved_matter"
    );
    private VeilboundMatterExclusions() {}
    public static void installInto(MatterCatalog catalog) {
        for (String path : IDS) catalog.putBuiltIn("veilbound:" + path, 0, "veilbound:nontransmutable_technology");
    }
}
