package dev.futurae.veilbound.stability;

import dev.futurae.veilbound.domain.DomainState;
import java.util.Objects;

/** Deterministic stability calculation; game events decide when to roll/create a breach. */
public final class StabilityCalculator {
    private StabilityCalculator() {}

    public static StabilitySnapshot calculate(
            DomainState state,
            int permanentThresholds,
            int continuityAnchors,
            StabilityPolicy policy) {
        return calculate(state, permanentThresholds, continuityAnchors, 0.0, policy);
    }

    public static StabilitySnapshot calculate(
            DomainState state,
            int permanentThresholds,
            int continuityAnchors,
            double externalMachineLoad,
            StabilityPolicy policy) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(policy, "policy");
        if (permanentThresholds < 0 || continuityAnchors < 0) {
            throw new IllegalArgumentException("counts must be >= 0");
        }
        if (!Double.isFinite(externalMachineLoad) || externalMachineLoad < 0) {
            throw new IllegalArgumentException("externalMachineLoad must be finite and >= 0");
        }
        var active = state.pylons().values().stream()
                .filter(pylon -> pylon.online() && pylon.expansionEnabled())
                .toList();
        int activePylons = active.size();
        double pylonLoad = active.stream()
                .mapToDouble(pylon -> pylon.speed().scaleSquared(policy.activePylonLoad()))
                .sum();
        double load = pylonLoad
                + permanentThresholds * policy.thresholdLoad()
                + continuityAnchors * policy.continuityAnchorLoad()
                + externalMachineLoad;
        double ratio = load / policy.capacity();
        StabilityBand band;
        if (ratio >= policy.rupturingRatio()) band = StabilityBand.RUPTURING;
        else if (ratio >= policy.criticalRatio()) band = StabilityBand.CRITICAL;
        else if (ratio >= policy.strainedRatio()) band = StabilityBand.STRAINED;
        else band = StabilityBand.STABLE;
        return new StabilitySnapshot(load, policy.capacity(), ratio, band, activePylons, permanentThresholds, continuityAnchors);
    }
}
