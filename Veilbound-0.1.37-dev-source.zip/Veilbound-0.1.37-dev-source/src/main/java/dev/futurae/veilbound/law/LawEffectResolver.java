package dev.futurae.veilbound.law;

import dev.futurae.veilbound.domain.DomainState;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/** Resolves the active effect-id set from persisted imposed Law ids and the live datapack registry. */
public final class LawEffectResolver {
    public ActiveLawEffects resolve(DomainState state, LawRegistry registry) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(registry, "registry");

        List<String> imposedIds = new ArrayList<>(state.imposedLawIds());
        imposedIds.sort(String::compareTo);
        LinkedHashSet<String> effects = new LinkedHashSet<>();
        LinkedHashMap<String, LinkedHashSet<String>> sources = new LinkedHashMap<>();
        List<String> missing = new ArrayList<>();

        for (String lawId : imposedIds) {
            LawDefinition definition = registry.get(lawId).orElse(null);
            if (definition == null) {
                missing.add(lawId);
                continue;
            }
            List<String> lawEffects = new ArrayList<>(definition.effectIds());
            lawEffects.sort(String::compareTo);
            for (String effectId : lawEffects) {
                effects.add(effectId);
                sources.computeIfAbsent(effectId, ignored -> new LinkedHashSet<>()).add(lawId);
            }
        }

        Map<String, Set<String>> immutableSources = new LinkedHashMap<>();
        sources.forEach((effect, lawIds) -> immutableSources.put(effect, Set.copyOf(lawIds)));
        return new ActiveLawEffects(effects, immutableSources, missing);
    }
}
