package dev.futurae.veilbound.platform.neoforge;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.precore.SpatialGeneratorPolicyRegistry;
import dev.futurae.veilbound.precore.SpatialGeneratorRuntimePolicy;
import java.io.Reader;
import java.util.Objects;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

/** Loads the tuneable costs around the settled 35% / 50,000-charge pre-Core rules. */
public final class NeoForgeSpatialGeneratorPolicyReloadListener extends SimplePreparableReloadListener<SpatialGeneratorRuntimePolicy> {
    public static final Identifier LISTENER_ID = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "spatial_generator_policy");
    private static final Identifier RESOURCE_ID = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "veilbound/balance/spatial_generator.json");
    private final Gson gson = new Gson();
    private final SpatialGeneratorPolicyRegistry registry;

    public NeoForgeSpatialGeneratorPolicyReloadListener(SpatialGeneratorPolicyRegistry registry) {
        this.registry = Objects.requireNonNull(registry, "registry");
    }

    @Override
    protected SpatialGeneratorRuntimePolicy prepare(ResourceManager manager, ProfilerFiller profiler) {
        var d = SpatialGeneratorRuntimePolicy.DEVELOPMENT_DEFAULT;
        return manager.getResource(RESOURCE_ID).map(resource -> {
            try (Reader reader = resource.openAsReader()) {
                JsonElement parsed = gson.fromJson(reader, JsonElement.class);
                if (parsed == null || !parsed.isJsonObject()) throw new IllegalArgumentException("root must be an object");
                JsonObject o = parsed.getAsJsonObject();
                long fe = o.has("forge_energy_per_raw_matter") ? o.get("forge_energy_per_raw_matter").getAsLong() : d.forgeEnergyPerRawMatter();
                long expansion = o.has("condensed_charge_per_new_block") ? o.get("condensed_charge_per_new_block").getAsLong() : d.condensedChargePerNewBlock();
                return new SpatialGeneratorRuntimePolicy(
                        SpatialGeneratorRuntimePolicy.SETTLED_EFFICIENCY_BPS, fe, expansion,
                        SpatialGeneratorRuntimePolicy.SETTLED_AWAKENING_CHARGE);
            } catch (Exception ex) {
                Veilbound.LOGGER.warn("Invalid {}: {}; using development default", RESOURCE_ID, ex.getMessage());
                return d;
            }
        }).orElse(d);
    }

    @Override
    protected void apply(SpatialGeneratorRuntimePolicy policy, ResourceManager manager, ProfilerFiller profiler) {
        registry.replace(policy);
        Veilbound.LOGGER.info("Loaded Spatial Generator policy: 35% efficiency, {} FE/raw Matter, {} CC/new block, 50,000 CC awakening",
                policy.forgeEnergyPerRawMatter(), policy.condensedChargePerNewBlock());
    }
}
