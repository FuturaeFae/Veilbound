package dev.futurae.veilbound.travel;

import java.util.Objects;

/**
 * Exact cross-dimension position used by owner recall and guest Threshold evacuation.
 * The platform layer is responsible for resolving a nearby safe position and finally the
 * destination dimension/world spawn when the exact anchor can no longer be used safely.
 */
public record ReturnAnchor(
        String dimensionId,
        double x,
        double y,
        double z,
        float yaw,
        float pitch) {
    public ReturnAnchor {
        Objects.requireNonNull(dimensionId, "dimensionId");
        if (dimensionId.isBlank()) throw new IllegalArgumentException("dimensionId may not be blank");
        if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)) {
            throw new IllegalArgumentException("anchor coordinates must be finite");
        }
        if (!Float.isFinite(yaw) || !Float.isFinite(pitch)) {
            throw new IllegalArgumentException("anchor rotation must be finite");
        }
    }
}
