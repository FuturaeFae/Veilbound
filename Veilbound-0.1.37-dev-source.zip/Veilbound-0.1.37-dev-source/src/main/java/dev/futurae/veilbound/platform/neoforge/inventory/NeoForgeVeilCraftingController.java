package dev.futurae.veilbound.platform.neoforge.inventory;

import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainState;
import dev.futurae.veilbound.inventory.VeilCraftingService;
import dev.futurae.veilbound.inventory.VeilStackKey;
import dev.futurae.veilbound.matter.MatterTransmutationState;
import dev.futurae.veilbound.network.VeilCraftingPreviewPayload;
import dev.futurae.veilbound.network.VeilCraftingRequestPayload;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.core.NonNullList;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeType;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.transfer.item.ItemResource;

/**
 * Bridges a proposed 3x3 wireless grid to authoritative server recipes. After Transmutation,
 * valued ingredients can be synthesized from learned Matter patterns while unvalued ingredients
 * continue to come from exact physical stacks retained in Veil Inventory.
 */
public final class NeoForgeVeilCraftingController {
    private final VeilboundRuntime runtime;
    private final NeoForgeVeilInventoryController inventoryController;
    private final VeilCraftingService crafting = new VeilCraftingService();

    public NeoForgeVeilCraftingController(
            VeilboundRuntime runtime,
            NeoForgeVeilInventoryController inventoryController) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        this.inventoryController = Objects.requireNonNull(inventoryController, "inventoryController");
    }

    public void handle(ServerPlayer player, VeilCraftingRequestPayload payload) {
        Evaluation evaluation = evaluate(player, payload.grid(), payload.quantity());
        if (payload.action() == VeilCraftingRequestPayload.Action.CRAFT_ONCE && evaluation.craftable()) {
            var result = evaluation.transmutation() == null
                    ? crafting.craft(
                            evaluation.state(), evaluation.inventory(), evaluation.capacity(),
                            evaluation.ingredients(), evaluation.returnedStacks())
                    : crafting.craftWithMatter(
                            evaluation.state(), evaluation.inventory(), evaluation.capacity(),
                            evaluation.ingredients(), List.of(), evaluation.transmutation());
            if (!result.crafted()) {
                PacketDistributor.sendToPlayer(player, VeilCraftingPreviewPayload.denied(result.reason()));
            } else {
                if (evaluation.transmutation() != null) {
                    for (ItemStack stack : evaluation.deliveries()) deliverRepeated(player, stack, evaluation.craftQuantity());
                    try {
                        VeilStackKey resultKey = NeoForgeVeilStackBridge.toKey(evaluation.resultResource(), player.registryAccess());
                        if (resultKey.componentData().isEmpty() && evaluation.transmutation().knows(resultKey.itemId())) {
                            evaluation.transmutation().recordRecent(resultKey.itemId());
                        }
                    } catch (RuntimeException ignored) { }
                }
                inventoryController.sendSnapshot(player, payload.page());
                sendPreview(player, evaluate(player, payload.grid(), payload.quantity()));
            }
            return;
        }
        sendPreview(player, evaluation);
    }

    private static void deliver(ServerPlayer player, ItemStack stack) {
        if (stack == null || stack.isEmpty()) return;
        player.getInventory().add(stack);
        if (!stack.isEmpty()) player.drop(stack, false);
    }

    private static void deliverRepeated(ServerPlayer player, ItemStack template, int times) {
        if (template == null || template.isEmpty() || times <= 0) return;
        long total;
        try {
            total = Math.multiplyExact((long) template.getCount(), times);
        } catch (ArithmeticException overflow) {
            throw new IllegalStateException("Craft delivery count overflow", overflow);
        }
        int max = Math.max(1, template.getMaxStackSize());
        while (total > 0) {
            int count = (int) Math.min(total, max);
            ItemStack next = template.copyWithCount(count);
            deliver(player, next);
            total -= count;
        }
    }

    private void sendPreview(ServerPlayer player, Evaluation evaluation) {
        if (!evaluation.craftable()) {
            PacketDistributor.sendToPlayer(player, VeilCraftingPreviewPayload.denied(evaluation.reason()));
            return;
        }
        PacketDistributor.sendToPlayer(player, new VeilCraftingPreviewPayload(
                true, "ok", evaluation.resultResource(), evaluation.resultCount()));
    }

    private Evaluation evaluate(ServerPlayer player, List<ItemResource> proposedGrid, int craftQuantity) {
        var access = runtime.veilInventoryAccess().ownerAccess(player.getUUID(), player.getUUID());
        if (!access.allowed()) return Evaluation.denied(access.reason());

        var record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null) return Evaluation.denied("domain_not_found");
        DomainState state = record.state();
        if (!state.hasFeature(DomainFeature.VEIL_CRAFTING)) return Evaluation.denied("veil_crafting_locked");
        if (proposedGrid == null || proposedGrid.size() != VeilCraftingRequestPayload.GRID_SIZE) {
            return Evaluation.denied("invalid_grid");
        }
        MatterTransmutationState transmutation = state.hasFeature(DomainFeature.VEIL_TRANSMUTATION)
                ? record.matterTransmutation()
                : null;

        List<ItemStack> stacks = new ArrayList<>(VeilCraftingRequestPayload.GRID_SIZE);
        List<VeilCraftingService.IngredientRequest> ingredients = new ArrayList<>();
        for (ItemResource resource : proposedGrid) {
            ItemResource normalized = resource == null ? ItemResource.EMPTY : resource;
            if (normalized.isEmpty()) {
                stacks.add(ItemStack.EMPTY);
                continue;
            }
            ItemStack stack = normalized.toStack(1);
            if (stack.isEmpty()) return Evaluation.denied("invalid_grid_item");
            stacks.add(stack);
            VeilStackKey key;
            try {
                key = NeoForgeVeilStackBridge.toKey(normalized, player.registryAccess());
            } catch (RuntimeException malformed) {
                return Evaluation.denied("invalid_grid_item");
            }

            List<VeilCraftingService.SynthesisCandidate> synthesis = List.of();
            if (transmutation != null && key.componentData().isEmpty()) {
                // Only genuinely valued canonical item identities can be synthesized. Unvalued
                // items remain physical inventory ingredients and component-bearing variants are
                // never recreated from a base pattern.
                var value = runtime.matter().amount(key.itemId());
                if (value.isPresent() && value.getAsLong() > 0) {
                    synthesis = List.of(new VeilCraftingService.SynthesisCandidate(
                            VeilStackKey.plain(key.itemId()), value.getAsLong()));
                }
            }
            ingredients.add(new VeilCraftingService.IngredientRequest(List.of(key), craftQuantity, synthesis));
        }
        if (ingredients.isEmpty()) return Evaluation.denied("empty_grid");

        CraftingInput input = CraftingInput.ofPositioned(3, 3, stacks).input();
        RecipeHolder<? extends CraftingRecipe> holder = player.level().recipeAccess()
                .getRecipeFor(RecipeType.CRAFTING, input, player.level())
                .orElse(null);
        if (holder == null) return Evaluation.denied("no_recipe");

        CraftingRecipe recipe = holder.value();
        ItemStack result = recipe.assemble(input);
        if (result == null || result.isEmpty() || result.getCount() <= 0) return Evaluation.denied("empty_result");

        List<VeilCraftingService.ProducedStack> returned = new ArrayList<>();
        List<ItemStack> deliveries = new ArrayList<>();
        ItemResource resultResource = ItemResource.of(result);
        VeilStackKey resultKey;
        try {
            resultKey = NeoForgeVeilStackBridge.toKey(resultResource, player.registryAccess());
        } catch (RuntimeException malformed) {
            return Evaluation.denied("invalid_result");
        }
        if (transmutation == null) returned.add(new VeilCraftingService.ProducedStack(resultKey, result.getCount()));
        else deliveries.add(result.copy());

        NonNullList<ItemStack> remainders = recipe.getRemainingItems(input);
        if (remainders != null) {
            for (ItemStack remainder : remainders) {
                if (remainder == null || remainder.isEmpty() || remainder.getCount() <= 0) continue;
                if (transmutation != null) {
                    deliveries.add(remainder.copy());
                    continue;
                }
                ItemResource remainderResource = ItemResource.of(remainder);
                try {
                    returned.add(new VeilCraftingService.ProducedStack(
                            NeoForgeVeilStackBridge.toKey(remainderResource, player.registryAccess()),
                            remainder.getCount()));
                } catch (RuntimeException malformed) {
                    return Evaluation.denied("invalid_remainder");
                }
            }
        }

        var preview = transmutation == null
                ? crafting.preview(state, access.inventory(), access.capacity(), ingredients, returned)
                : crafting.previewWithMatter(state, access.inventory(), access.capacity(), ingredients, List.of(), transmutation);
        if (!preview.crafted()) return Evaluation.denied(preview.reason());
        int previewCount;
        try {
            previewCount = Math.multiplyExact(result.getCount(), craftQuantity);
        } catch (ArithmeticException overflow) {
            return Evaluation.denied("result_count_overflow");
        }
        return new Evaluation(
                true, "ok", state, access.inventory(), access.capacity(), transmutation,
                ingredients, returned, List.copyOf(deliveries), resultResource, previewCount, craftQuantity);
    }

    private record Evaluation(
            boolean craftable,
            String reason,
            DomainState state,
            dev.futurae.veilbound.inventory.VeilInventory inventory,
            dev.futurae.veilbound.inventory.VeilStorageCapacity capacity,
            MatterTransmutationState transmutation,
            List<VeilCraftingService.IngredientRequest> ingredients,
            List<VeilCraftingService.ProducedStack> returnedStacks,
            List<ItemStack> deliveries,
            ItemResource resultResource,
            int resultCount,
            int craftQuantity) {
        private static Evaluation denied(String reason) {
            return new Evaluation(false, reason, null, null, null, null,
                    List.of(), List.of(), List.of(), ItemResource.EMPTY, 0, 1);
        }
    }
}
