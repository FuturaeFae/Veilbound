package dev.futurae.veilbound.platform.neoforge.world;

import dev.futurae.veilbound.domain.DomainState;
import dev.futurae.veilbound.law.LawRuntimeSemantics;
import dev.futurae.veilbound.memory.DomainSkyLightProfile;
import dev.futurae.veilbound.memory.MemoryRuntimeSemantics;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.Executor;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.CustomSpawner;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.LevelStem;
import net.minecraft.world.attribute.EnvironmentAttributeSystem;
import net.minecraft.world.attribute.EnvironmentAttributes;
import net.minecraft.world.level.gamerules.GameRule;
import net.minecraft.world.level.gamerules.GameRules;
import net.minecraft.world.level.saveddata.WeatherData;
import net.minecraft.world.level.storage.LevelStorageSource;
import net.minecraft.world.level.storage.ServerLevelData;

/**
 * A live personal Domain with its sovereign mutable rule/environment facade.
 *
 * <p>Minecraft 26.2 owns clocks on {@code ServerClockManager} and weather countdowns on the
 * server. A Domain must not mutate those global objects. Instead this level exposes a private
 * gamerule copy, a permanently-clear private {@link WeatherData} shield, a Domain-local default
 * clock value, and explicitly driven remembered rain strength. This keeps vanilla gameplay reads
 * level-local without making an Orrery change leak into the Overworld or another player's Domain.</p>
 */
public final class VeilboundServerLevel extends ServerLevel {
    private static final Set<GameRule<?>> LAW_CONTROLLED_RULES = Set.of(
            GameRules.ADVANCE_TIME,
            GameRules.ADVANCE_WEATHER,
            GameRules.FALL_DAMAGE,
            GameRules.KEEP_INVENTORY,
            GameRules.MOB_GRIEFING,
            GameRules.PVP,
            GameRules.SPAWN_MOBS,
            GameRules.SPAWN_MONSTERS,
            GameRules.FIRE_SPREAD_RADIUS_AROUND_PLAYER);

    private DomainState domainState;
    private GameRules localRules;
    /**
     * Vanilla 26.2 weather countdowns are server-owned. Keep this local facade clear and drive
     * remembered precipitation ourselves so vanilla cannot broadcast this Domain's storm globally.
     */
    private WeatherData weatherShield;
    private long rememberedDayTime;
    private boolean naturalDaylightEnabled;
    private boolean overworldDayCycleEnabled;

    public VeilboundServerLevel(
            MinecraftServer server,
            Executor executor,
            LevelStorageSource.LevelStorageAccess levelStorage,
            ServerLevelData levelData,
            ResourceKey<Level> dimension,
            LevelStem levelStem,
            boolean isDebug,
            long biomeZoomSeed,
            List<CustomSpawner> customSpawners,
            boolean tickTime,
            DomainState domainState) {
        super(server, executor, levelStorage, levelData, dimension, levelStem, isDebug,
                biomeZoomSeed, customSpawners, tickTime);
        this.domainState = Objects.requireNonNull(domainState, "domainState");
        this.localRules = server.overworld().getGameRules().copy(server.getWorldData().enabledFeatures());
        this.weatherShield = new WeatherData(0, 0, 0, false, false);
        this.rememberedDayTime = domainState.dayTime();
        this.naturalDaylightEnabled = false;
        this.overworldDayCycleEnabled = false;
        installDomainEnvironmentAttributeProjection();
        setRainLevel(domainState.raining() ? 1.0F : 0.0F);
        setThunderLevel(domainState.thundering() ? 1.0F : 0.0F);
    }

    public DomainState domainState() { return domainState; }

    @Override
    public GameRules getGameRules() {
        // ServerLevel construction may dispatch through this method before our fields initialize.
        return localRules != null ? localRules : super.getGameRules();
    }

    @Override
    public WeatherData getWeatherData() {
        return weatherShield != null ? weatherShield : super.getWeatherData();
    }

    @Override
    public long getDefaultClockTime() {
        return domainState != null ? rememberedDayTime : super.getDefaultClockTime();
    }

    @Override
    public boolean isPvpAllowed() {
        return localRules != null ? localRules.get(GameRules.PVP) : super.isPvpAllowed();
    }

    /**
     * Refresh all sovereign mechanics. Time/weather advancement are deliberately disabled in
     * vanilla because their 26.2 backing stores are server-global; Veilbound advances those two
     * remembered states explicitly instead.
     */
    public void applyEnvironmentLaws(
            LawRuntimeSemantics.Snapshot laws,
            boolean hasDayCycleMemory,
            boolean hasWeatherMemory) {
        Objects.requireNonNull(laws, "laws");
        MinecraftServer server = getServer();
        GameRules inherited = server.overworld().getGameRules();
        inherited.availableRules()
                .filter(rule -> !LAW_CONTROLLED_RULES.contains(rule))
                .forEach(rule -> copyInheritedRule(server, inherited, rule));

        setRule(server, GameRules.ADVANCE_TIME, false);
        setRule(server, GameRules.ADVANCE_WEATHER, false);
        setRule(server, GameRules.FALL_DAMAGE, laws.descent());
        setRule(server, GameRules.KEEP_INVENTORY, laws.preservation());
        setRule(server, GameRules.MOB_GRIEFING, laws.grief());
        setRule(server, GameRules.PVP, laws.conflict());
        setRule(server, GameRules.SPAWN_MOBS, laws.anyNaturalSpawning());
        setRule(server, GameRules.SPAWN_MONSTERS, laws.hostility());

        int fireRadius = laws.flame()
                ? inherited.get(GameRules.FIRE_SPREAD_RADIUS_AROUND_PLAYER)
                : 0;
        setRule(server, GameRules.FIRE_SPREAD_RADIUS_AROUND_PLAYER, fireRadius);

        if (!laws.weather() || !hasWeatherMemory) setRememberedRain(false, 0);
    }

    /** Advance the Domain-owned remembered clock without touching the server's WorldClock. */
    public void tickRememberedClock(boolean advancing) {
        if (!advancing) return;
        rememberedDayTime++;
        // This clock is intentionally not Minecraft's shared server clock. Refresh the per-level
        // attribute cache/derived sky brightness immediately so daylight mechanics track this
        // Domain's remembered cycle on the same tick.
        environmentAttributes().invalidateTickCache();
        updateSkyBrightness();
    }

    public long rememberedDayTime() { return rememberedDayTime; }

    /**
     * Updates the Domain-owned illumination substrate. The installed environment-attribute system
     * remains attached to this ServerLevel and reads these flags plus the remembered clock every
     * tick, so enabling Open Sky never mutates another Domain or the Overworld.
     */
    public void applyMemoryIllumination(MemoryRuntimeSemantics.Snapshot memories) {
        Objects.requireNonNull(memories, "memories");
        boolean nextNaturalDaylight = memories.naturalDaylight();
        boolean nextDayCycle = memories.overworldDayCycle();
        if (naturalDaylightEnabled == nextNaturalDaylight
                && overworldDayCycleEnabled == nextDayCycle) return;
        naturalDaylightEnabled = nextNaturalDaylight;
        overworldDayCycleEnabled = nextDayCycle;
        environmentAttributes().invalidateTickCache();
        updateSkyBrightness();
    }

    public DomainSkyLightProfile.Sample currentSkyLightProfile() {
        return DomainSkyLightProfile.sample(
                naturalDaylightEnabled, overworldDayCycleEnabled, rememberedDayTime);
    }

    /**
     * Minecraft 26.2 exposes a mutable per-ServerLevel EnvironmentAttributeSystem. Veilbound uses
     * that narrow runtime seam rather than changing the shared DimensionType. The base datapack
     * remains fail-closed at zero; these last time-based layers are authoritative for this one
     * personal Domain and intentionally ignore the shared Overworld clock.
     */
    @SuppressWarnings("deprecation")
    private void installDomainEnvironmentAttributeProjection() {
        EnvironmentAttributeSystem system = EnvironmentAttributeSystem.builder()
                .addDefaultLayers(this)
                .addTimeBasedLayer(EnvironmentAttributes.SKY_LIGHT_LEVEL,
                        (baseValue, cacheTickId) -> currentSkyLightProfile().gameplaySkyLightLevel())
                .addTimeBasedLayer(EnvironmentAttributes.SKY_LIGHT_FACTOR,
                        (baseValue, cacheTickId) -> currentSkyLightProfile().visualSkyLightFactor())
                .build();
        setEnvironmentAttributes(system);
    }

    /**
     * Drive Domain-local rain through the Level rain-strength fields used by gameplay and render
     * state. The private WeatherData shield itself stays clear so vanilla emits no global weather
     * transition for this personal Domain.
     */
    public void setRememberedRain(boolean raining, int refreshTicks) {
        int ticks = raining ? Math.max(1, refreshTicks) : 0;
        domainState.setWeatherState(0, raining, ticks, false, 0);
        setRainLevel(raining ? 1.0F : 0.0F);
        setThunderLevel(0.0F);
        if (weatherShield != null) {
            weatherShield.setClearWeatherTime(0);
            weatherShield.setRaining(false);
            weatherShield.setRainTime(0);
            weatherShield.setThundering(false);
            weatherShield.setThunderTime(0);
        }
    }

    /** Re-assert the persisted environment before save/unload. */
    public void persistEnvironmentState() {
        domainState.setDayTime(rememberedDayTime);
        // Remembered weather mutates DomainState directly; clamp the live mechanics projection too.
        setRainLevel(domainState.raining() ? 1.0F : 0.0F);
        setThunderLevel(domainState.thundering() ? 1.0F : 0.0F);
    }

    private <T> void copyInheritedRule(MinecraftServer server, GameRules inherited, GameRule<T> rule) {
        setRule(server, rule, inherited.get(rule));
    }

    private <T> void setRule(MinecraftServer server, GameRule<T> rule, T value) {
        if (!Objects.equals(localRules.get(rule), value)) localRules.set(rule, value, server);
    }
}
