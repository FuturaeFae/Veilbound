package dev.futurae.veilbound.platform.neoforge.threshold;

import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import dev.futurae.veilbound.threshold.ThresholdAccess;
import dev.futurae.veilbound.threshold.ThresholdDefinition;
import dev.futurae.veilbound.threshold.ThresholdFrameActivationService;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/** Server-authoritative activation of connected Threshold frame structures. */
public final class NeoForgeThresholdFrameCoordinator {
    private static final int MAX_CONNECTED_STRUCTURE = 512;
    private final VeilboundRuntime runtime;

    public NeoForgeThresholdFrameCoordinator(VeilboundRuntime runtime) {
        this.runtime = java.util.Objects.requireNonNull(runtime, "runtime");
    }

    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (event.getLevel().isClientSide()) return;
        if (!player.isShiftKeyDown()) return;

        Level level = event.getLevel();
        BlockPos clicked = event.getPos();
        BlockState clickedState = level.getBlockState(clicked);
        if (!clickedState.is(VeilboundBlocks.THRESHOLD_FRAME.get())) return;

        boolean hasBoundDomain = runtime.domains().getRecord(player.getUUID()).isPresent();
        Set<BlockPos> component = collectConnectedFrames(level, clicked, MAX_CONNECTED_STRUCTURE);
        Set<DomainPosition> neutralPositions = component.stream()
                .map(pos -> new DomainPosition(pos.getX(), pos.getY(), pos.getZ()))
                .collect(java.util.stream.Collectors.toCollection(LinkedHashSet::new));

        ThresholdFrameActivationService.ActivationDecision decision = ThresholdFrameActivationService.activate(
                player.getUUID(), hasBoundDomain, neutralPositions,
                new DomainPosition(clicked.getX(), clicked.getY(), clicked.getZ()), MAX_CONNECTED_STRUCTURE);
        if (!decision.allowed()) {
            event.setCancellationResult(InteractionResult.FAIL);
            event.setCanceled(true);
            return;
        }

        java.util.List<ConvertedCell> converted = new java.util.ArrayList<>(decision.connectedStructure().size());
        BlockState portalState = VeilboundBlocks.THRESHOLD_PORTAL.get().defaultBlockState();
        for (DomainPosition position : decision.connectedStructure()) {
            BlockPos pos = new BlockPos(position.x(), position.y(), position.z());
            BlockState oldState = level.getBlockState(pos);
            if (!oldState.is(VeilboundBlocks.THRESHOLD_FRAME.get()) || !level.setBlockAndUpdate(pos, portalState)) {
                rollbackActivation(level, converted);
                event.setCancellationResult(InteractionResult.FAIL);
                event.setCanceled(true);
                return;
            }
            converted.add(new ConvertedCell(pos, oldState));
        }

        // Every activated structure is a persistent Threshold binding. The source can be outside
        // the Domain (normal entrance) or inside it (controlled exit point). Arrival defaults to
        // the canonical Domain origin; the safe-arrival resolver may move a player nearby if that
        // exact point is obstructed. Registration is the final commit; a rejected binding restores
        // every converted cell to its original frame state.
        try {
            runtime.thresholds().add(new ThresholdDefinition(
                    decision.structureId(),
                    player.getUUID(),
                    level.dimension().identifier().toString(),
                    decision.connectedStructure(),
                    DomainPosition.ORIGIN,
                    new ThresholdAccess()));
        } catch (RuntimeException registrationFailure) {
            rollbackActivation(level, converted);
            event.setCancellationResult(InteractionResult.FAIL);
            event.setCanceled(true);
            return;
        }

        event.setCancellationResult(InteractionResult.SUCCESS);
        event.setCanceled(true);
    }

    private static void rollbackActivation(Level level, java.util.List<ConvertedCell> converted) {
        for (int i = converted.size() - 1; i >= 0; i--) {
            ConvertedCell cell = converted.get(i);
            level.setBlockAndUpdate(cell.pos(), cell.oldState());
        }
    }

    private record ConvertedCell(BlockPos pos, BlockState oldState) {}

    private static Set<BlockPos> collectConnectedFrames(Level level, BlockPos start, int maxStructureBlocks) {
        Set<BlockPos> visited = new LinkedHashSet<>();
        if (!level.getBlockState(start).is(VeilboundBlocks.THRESHOLD_FRAME.get())) return visited;

        Deque<BlockPos> queue = new ArrayDeque<>();
        visited.add(start);
        queue.add(start);
        while (!queue.isEmpty()) {
            BlockPos current = queue.removeFirst();
            for (BlockPos neighbor : neighbors(current)) {
                if (!visited.contains(neighbor) && level.getBlockState(neighbor).is(VeilboundBlocks.THRESHOLD_FRAME.get())) {
                    visited.add(neighbor);
                    if (visited.size() > maxStructureBlocks) {
                        throw new IllegalArgumentException("Connected Threshold frame structure exceeds cap of " + maxStructureBlocks + " blocks");
                    }
                    queue.addLast(neighbor);
                }
            }
        }
        return Set.copyOf(visited);
    }

    private static Set<BlockPos> neighbors(BlockPos pos) {
        return Set.of(
                new BlockPos(pos.getX() + 1, pos.getY(), pos.getZ()),
                new BlockPos(pos.getX() - 1, pos.getY(), pos.getZ()),
                new BlockPos(pos.getX(), pos.getY() + 1, pos.getZ()),
                new BlockPos(pos.getX(), pos.getY() - 1, pos.getZ()),
                new BlockPos(pos.getX(), pos.getY(), pos.getZ() + 1),
                new BlockPos(pos.getX(), pos.getY(), pos.getZ() - 1));
    }
}
