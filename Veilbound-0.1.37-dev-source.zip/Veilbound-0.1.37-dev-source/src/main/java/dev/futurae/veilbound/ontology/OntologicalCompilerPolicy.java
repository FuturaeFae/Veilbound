package dev.futurae.veilbound.ontology;

/** Potential + Core DE -> Veil Inventory Matter. The Core itself still stores DE only. */
public record OntologicalCompilerPolicy(long matterPerPotential, long dimensionalEnergyPerPotential, long maxPotentialPerCycle) {
    public OntologicalCompilerPolicy {
        if (matterPerPotential <= 0 || dimensionalEnergyPerPotential <= 0 || maxPotentialPerCycle <= 0) throw new IllegalArgumentException("invalid compiler policy");
    }
    public static OntologicalCompilerPolicy defaults() { return new OntologicalCompilerPolicy(256, 32, 256); }
}
