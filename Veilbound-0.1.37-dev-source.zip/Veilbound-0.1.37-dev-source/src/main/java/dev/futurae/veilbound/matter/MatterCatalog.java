package dev.futurae.veilbound.matter;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalLong;

/**
 * Matter-value layers, highest priority first: live admin override -> datapack -> ProjectE/built-in
 * baseline -> inferred recipe cache. A zero authoritative value deliberately makes an item unvalued.
 */
public final class MatterCatalog {
    private final Map<String, MatterValue> builtIn = new LinkedHashMap<>();
    private final Map<String, MatterValue> datapack = new LinkedHashMap<>();
    private final Map<String, MatterValue> admin = new LinkedHashMap<>();
    private final Map<String, MatterValue> inferred = new LinkedHashMap<>();
    private Runnable adminMutationListener = () -> {};

    public synchronized void putBuiltIn(String itemId, long amount, String provenance) {
        builtIn.put(requireId(itemId), new MatterValue(amount, MatterValue.Source.BUILTIN, provenance));
        inferred.remove(itemId);
    }

    public synchronized void putDatapack(String itemId, long amount, String provenance) {
        datapack.put(requireId(itemId), new MatterValue(amount, MatterValue.Source.DATAPACK, provenance));
        inferred.remove(itemId);
    }

    /** Compatibility API: explicit values are treated as datapack-level authoritative values. */
    public synchronized void putExplicit(String itemId, long amount, String provenance) {
        datapack.put(requireId(itemId), new MatterValue(amount, MatterValue.Source.EXPLICIT, provenance));
        inferred.remove(itemId);
    }

    /** Immediate command/operator override. Zero means deliberately unvalued. */
    public synchronized void putAdmin(String itemId, long amount, String provenance) {
        admin.put(requireId(itemId), new MatterValue(amount, MatterValue.Source.ADMIN, provenance));
        inferred.remove(itemId);
        adminMutationListener.run();
    }

    public synchronized boolean removeAdmin(String itemId) {
        boolean removed = admin.remove(Objects.requireNonNull(itemId, "itemId")) != null;
        if (removed) adminMutationListener.run();
        return removed;
    }

    /** Used only while attaching persisted world data; intentionally does not dirty that data again. */
    public synchronized void replaceAdminSilently(Map<String, Long> values, String provenancePrefix) {
        admin.clear();
        for (var entry : Objects.requireNonNull(values, "values").entrySet()) {
            String id = requireId(entry.getKey());
            long amount = Objects.requireNonNull(entry.getValue(), "amount");
            admin.put(id, new MatterValue(amount, MatterValue.Source.ADMIN,
                    (provenancePrefix == null ? "" : provenancePrefix) + id));
        }
        inferred.keySet().removeAll(admin.keySet());
    }

    public synchronized void setAdminMutationListener(Runnable listener) {
        adminMutationListener = Objects.requireNonNull(listener, "listener");
    }

    public synchronized Map<String, Long> adminAmountSnapshot() {
        LinkedHashMap<String, Long> result = new LinkedHashMap<>();
        admin.forEach((id, value) -> result.put(id, value.amount()));
        return Collections.unmodifiableMap(result);
    }

    public synchronized void clearBuiltIn() { builtIn.clear(); inferred.clear(); }
    public synchronized void clearDatapack() { datapack.clear(); inferred.clear(); }
    /** Compatibility behavior from the first slice: clears explicit/datapack overrides + inference. */
    public void clearExplicit() { clearDatapack(); }

    public synchronized void clearAll() {
        builtIn.clear(); datapack.clear(); admin.clear(); inferred.clear();
        adminMutationListener.run();
    }

    public synchronized Optional<MatterValue> get(String itemId) {
        MatterValue operator = admin.get(itemId);
        if (operator != null) return Optional.of(operator);
        MatterValue override = datapack.get(itemId);
        if (override != null) return Optional.of(override);
        MatterValue baseline = builtIn.get(itemId);
        if (baseline != null) return Optional.of(baseline);
        return Optional.ofNullable(inferred.get(itemId));
    }

    public OptionalLong amount(String itemId) {
        return get(itemId).filter(value -> value.amount() > 0)
                .map(value -> OptionalLong.of(value.amount())).orElseGet(OptionalLong::empty);
    }

    public OptionalLong resolvedAmount(String itemId) { return amount(itemId); }

    public synchronized boolean hasAuthoritative(String itemId) {
        return admin.containsKey(itemId) || datapack.containsKey(itemId) || builtIn.containsKey(itemId);
    }
    public boolean hasExplicit(String itemId) { return hasAuthoritative(itemId); }

    synchronized void replaceInferred(Map<String, MatterValue> values) {
        inferred.clear();
        values.forEach((id, value) -> { if (!hasAuthoritative(id)) inferred.put(id, value); });
    }

    synchronized void replaceInferredSubset(java.util.Set<String> affected, Map<String, MatterValue> values) {
        for (String id : affected) inferred.remove(id);
        values.forEach((id, value) -> {
            if (affected.contains(id) && !hasAuthoritative(id)) inferred.put(id, value);
        });
    }

    public synchronized Map<String, MatterValue> authoritativeSnapshot() {
        Map<String, MatterValue> result = new LinkedHashMap<>(builtIn);
        result.putAll(datapack);
        result.putAll(admin);
        return Collections.unmodifiableMap(result);
    }

    public synchronized Map<String, MatterValue> inferredSnapshot() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(inferred));
    }

    public synchronized Map<String, MatterValue> snapshot() {
        Map<String, MatterValue> result = new LinkedHashMap<>(inferred);
        result.putAll(builtIn); result.putAll(datapack); result.putAll(admin);
        return Collections.unmodifiableMap(result);
    }

    private static String requireId(String id) {
        Objects.requireNonNull(id, "itemId");
        if (id.isBlank()) throw new IllegalArgumentException("itemId may not be blank");
        return id;
    }
}
