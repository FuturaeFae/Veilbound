package dev.futurae.veilbound.client;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.network.DomainTravelRequestPayload;
import dev.futurae.veilbound.domain.DomainIdentity;
import dev.futurae.veilbound.memory.DomainSkyLightProfile;
import dev.futurae.veilbound.platform.neoforge.mixin.ClientLevelEnvironmentAccessor;
import dev.futurae.veilbound.network.MemoryEnvironmentSnapshotPayload;
import dev.futurae.veilbound.network.VeilInventoryActionPayload;
import dev.futurae.veilbound.network.VeilCraftingPreviewPayload;
import dev.futurae.veilbound.network.VeilCraftablesSnapshotPayload;
import dev.futurae.veilbound.network.VeilInventorySnapshotPayload;
import dev.futurae.veilbound.client.screen.VeilInventoryScreen;
import dev.futurae.veilbound.client.screen.SpatialGeneratorScreen;
import dev.futurae.veilbound.client.screen.MemoryManagementScreen;
import dev.futurae.veilbound.client.screen.DomainControlsScreen;
import dev.futurae.veilbound.client.screen.EngineeringStationScreen;
import dev.futurae.veilbound.client.screen.OntologyMachineScreen;
import dev.futurae.veilbound.client.screen.EngineeringCodexScreen;
import dev.futurae.veilbound.network.SpatialGeneratorSnapshotPayload;
import dev.futurae.veilbound.network.MemoryManagementSnapshotPayload;
import dev.futurae.veilbound.network.DomainControlsSnapshotPayload;
import dev.futurae.veilbound.network.EngineeringStationSnapshotPayload;
import dev.futurae.veilbound.network.OntologyMachineSnapshotPayload;
import net.neoforged.neoforge.transfer.item.ItemResource;
import dev.futurae.veilbound.client.render.ThresholdPortalRenderer;
import dev.futurae.veilbound.client.render.entity.VoidCrawlerRenderer;
import dev.futurae.veilbound.client.render.entity.RiftStalkerRenderer;
import dev.futurae.veilbound.client.render.entity.NullWraithRenderer;
import dev.futurae.veilbound.client.render.MemorySkyboxGateRenderer;
import dev.futurae.veilbound.registry.VeilboundBlockEntities;
import dev.futurae.veilbound.registry.VeilboundEntities;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.resources.Identifier;
import net.minecraft.world.attribute.EnvironmentAttributeSystem;
import net.minecraft.world.attribute.EnvironmentAttributes;
import net.minecraft.core.particles.ParticleTypes;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RegisterCustomEnvironmentEffectRendererEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import net.neoforged.neoforge.common.NeoForge;
import org.lwjgl.glfw.GLFW;

/** Physical-client-only input bootstrap. */
public final class VeilboundClient {
    private static final KeyMapping.Category CATEGORY = new KeyMapping.Category(
            Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "veilbound"));
    private static final KeyMapping DOMAIN_TRAVEL = new KeyMapping(
            "key.veilbound.domain_travel", GLFW.GLFW_KEY_V, CATEGORY);
    private static final KeyMapping VEIL_INVENTORY = new KeyMapping(
            "key.veilbound.veil_inventory", GLFW.GLFW_KEY_B, CATEGORY);
    private static ClientLevel illuminationProjectionLevel;

    private VeilboundClient() {}

    public static void init(IEventBus modBus) {
        modBus.addListener(VeilboundClient::registerKeyMappings);
        modBus.addListener(VeilboundClient::registerRenderers);
        modBus.addListener(VeilboundClient::registerEnvironmentRenderers);
        NeoForge.EVENT_BUS.addListener(VeilboundClient::onClientTick);
    }

    private static void registerEnvironmentRenderers(RegisterCustomEnvironmentEffectRendererEvent event) {
        event.registerSkyboxRenderer(
                Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "memory_sky_gate"),
                new MemorySkyboxGateRenderer());
    }

    private static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(
                VeilboundBlockEntities.THRESHOLD_PORTAL.get(),
                context -> new ThresholdPortalRenderer());
        // Locomotion/model silhouettes remain inherited from their stable vanilla parent contracts,
        // but every Breach creature now has a dedicated Veilbound renderer/texture identity.
        event.registerEntityRenderer(VeilboundEntities.VOID_CRAWLER.get(), VoidCrawlerRenderer::new);
        event.registerEntityRenderer(VeilboundEntities.RIFT_STALKER.get(), RiftStalkerRenderer::new);
        event.registerEntityRenderer(VeilboundEntities.NULL_WRAITH.get(), NullWraithRenderer::new);
    }

    private static void registerKeyMappings(RegisterKeyMappingsEvent event) {
        event.registerCategory(CATEGORY);
        event.register(DOMAIN_TRAVEL);
        event.register(VEIL_INVENTORY);
    }

    private static void onClientTick(ClientTickEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            MemoryClientEnvironmentState.clear();
            illuminationProjectionLevel = null;
        } else {
            MemoryClientEnvironmentState.clearIfDimensionChanged(
                    minecraft.level.dimension().identifier().toString());
            ensureDomainIlluminationProjection(minecraft.level);
            MemoryClientEnvironmentState.tick();
            var memoryEnvironment = MemoryClientEnvironmentState.snapshot();
            if (memoryEnvironment.active()) {
                // Weather packets in 26.2 are server-global at the countdown layer. Orrery rain is
                // projected from Veilbound's per-Domain payload instead, so other worlds never own it.
                minecraft.level.setRainLevel(memoryEnvironment.rememberedRainActive() ? 1.0F : 0.0F);
                minecraft.level.setThunderLevel(0.0F);
            }
            if (minecraft.player != null
                    && memoryEnvironment.active()
                    && memoryEnvironment.semantics().verdantFloraVisual()
                    && minecraft.player.tickCount % 8 == 0) {
                var random = minecraft.level.getRandom();
                double x = minecraft.player.getX() + (random.nextDouble() - 0.5D) * 12.0D;
                double y = minecraft.player.getY() + random.nextDouble() * 4.0D;
                double z = minecraft.player.getZ() + (random.nextDouble() - 0.5D) * 12.0D;
                minecraft.level.addParticle(ParticleTypes.SPORE_BLOSSOM_AIR, x, y, z, 0.0D, 0.0D, 0.0D);
            }
        }
        while (VEIL_INVENTORY.consumeClick()) {
            if (minecraft.player != null && minecraft.getConnection() != null) {
                ClientPacketDistributor.sendToServer(new VeilInventoryActionPayload(
                        VeilInventoryActionPayload.Action.OPEN_OR_PAGE, 0, ItemResource.EMPTY));
            }
        }
        while (DOMAIN_TRAVEL.consumeClick()) {
            if (minecraft.player != null && minecraft.getConnection() != null) {
                ClientPacketDistributor.sendToServer(DomainTravelRequestPayload.INSTANCE);
            }
        }
    }

    public static void handleMemoryEnvironmentSnapshot(MemoryEnvironmentSnapshotPayload snapshot) {
        MemoryClientEnvironmentState.accept(snapshot);
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level != null) {
            ensureDomainIlluminationProjection(minecraft.level);
            minecraft.level.environmentAttributes().invalidateTickCache();
            minecraft.level.updateSkyBrightness();
        }
    }

    /**
     * ClientLevel keeps its EnvironmentAttributeSystem in a final field and exposes no runtime
     * setter. A client-only Mixin accessor replaces that one field once per personal Domain level.
     * The installed time-based layers read the synchronized Memory snapshot every client tick, so
     * Open Sky can brighten/darken without reconstructing the ClientLevel or leaking into another
     * dimension. The static DimensionType remains zero-lit as a safe fallback until this installs.
     */
    private static void ensureDomainIlluminationProjection(ClientLevel level) {
        if (illuminationProjectionLevel == level) return;
        illuminationProjectionLevel = level;
        String dimensionId = level.dimension().identifier().toString();
        if (DomainIdentity.ownerFromDimensionId(dimensionId).isEmpty()) return;

        EnvironmentAttributeSystem system = EnvironmentAttributeSystem.builder()
                .addDefaultLayers(level)
                .addTimeBasedLayer(EnvironmentAttributes.SKY_LIGHT_LEVEL, (baseValue, cacheTickId) -> {
                    var snapshot = MemoryClientEnvironmentState.snapshot();
                    if (!dimensionId.equals(snapshot.dimensionId())) return 0.0F;
                    return clientSkyLightSample(snapshot).gameplaySkyLightLevel();
                })
                .addTimeBasedLayer(EnvironmentAttributes.SKY_LIGHT_FACTOR, (baseValue, cacheTickId) -> {
                    var snapshot = MemoryClientEnvironmentState.snapshot();
                    if (!dimensionId.equals(snapshot.dimensionId())) return 0.0F;
                    return clientSkyLightSample(snapshot).visualSkyLightFactor();
                })
                .build();
        ((ClientLevelEnvironmentAccessor) (Object) level).veilbound$setEnvironmentAttributes(system);
    }

    private static DomainSkyLightProfile.Sample clientSkyLightSample(
            MemoryClientEnvironmentState.Snapshot snapshot) {
        return DomainSkyLightProfile.sample(
                snapshot.active() && snapshot.semantics().naturalDaylight(),
                snapshot.active() && snapshot.semantics().overworldDayCycle(),
                snapshot.domainDayTime());
    }

    public static void handleVeilInventorySnapshot(VeilInventorySnapshotPayload snapshot) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.gui.screen() instanceof VeilInventoryScreen screen) {
            screen.acceptSnapshot(snapshot);
        } else {
            minecraft.gui.setScreen(new VeilInventoryScreen(snapshot));
        }
    }

    public static void handleVeilCraftingPreview(VeilCraftingPreviewPayload preview) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.gui.screen() instanceof VeilInventoryScreen screen) {
            screen.acceptCraftingPreview(preview);
        }
    }

    public static void handleVeilCraftablesSnapshot(VeilCraftablesSnapshotPayload snapshot) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.gui.screen() instanceof VeilInventoryScreen screen) {
            screen.acceptCraftablesSnapshot(snapshot);
        }
    }

    public static void handleDomainControlsSnapshot(DomainControlsSnapshotPayload snapshot) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.gui.screen() instanceof DomainControlsScreen screen) screen.acceptSnapshot(snapshot);
        else minecraft.gui.setScreen(new DomainControlsScreen(snapshot));
    }

    public static void handleMemoryManagementSnapshot(MemoryManagementSnapshotPayload snapshot) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.gui.screen() instanceof MemoryManagementScreen screen) screen.acceptSnapshot(snapshot);
        else minecraft.gui.setScreen(new MemoryManagementScreen(snapshot));
    }

    public static void handleEngineeringStationSnapshot(EngineeringStationSnapshotPayload snapshot) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.gui.screen() instanceof EngineeringStationScreen screen) screen.acceptSnapshot(snapshot);
        else minecraft.gui.setScreen(new EngineeringStationScreen(snapshot));
    }

    public static void handleOntologyMachineSnapshot(OntologyMachineSnapshotPayload snapshot) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.gui.screen() instanceof OntologyMachineScreen screen) screen.acceptSnapshot(snapshot);
        else minecraft.gui.setScreen(new OntologyMachineScreen(snapshot));
    }

    public static void openEngineeringCodex() {
        Minecraft.getInstance().gui.setScreen(new EngineeringCodexScreen());
    }

    public static void handleSpatialGeneratorSnapshot(SpatialGeneratorSnapshotPayload snapshot) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.gui.screen() instanceof SpatialGeneratorScreen screen) screen.acceptSnapshot(snapshot);
        else minecraft.gui.setScreen(new SpatialGeneratorScreen(snapshot));
    }
}
