package dev.futurae.veilbound.law;

import java.util.Objects;

/** Pure attunement rules for the consumed Law-specific Axiom item. */
public final class LawAxiomAttunementService {
    private LawAxiomAttunementService() {}

    public static Result plan(String currentLawId, String heldItemId, LawRegistry registry) {
        Objects.requireNonNull(registry, "registry");
        if (currentLawId != null && !currentLawId.isBlank()) return Result.denied("permanently_attuned");
        if (heldItemId == null || heldItemId.isBlank()) return Result.denied("requires_axiom");

        LawDefinition match = null;
        for (LawDefinition law : registry.all()) {
            if (!law.hasAxiomItem() || !law.axiomItemId().equals(heldItemId)) continue;
            if (match != null) return Result.denied("ambiguous_axiom_item");
            match = law;
        }
        if (match == null) return Result.denied("invalid_axiom");
        return Result.allowed(match);
    }

    public record Result(boolean allowed, LawDefinition law, int itemsConsumed, String reason) {
        public static Result denied(String reason) { return new Result(false, null, 0, reason); }
        public static Result allowed(LawDefinition law) { return new Result(true, Objects.requireNonNull(law), 1, "ok"); }
    }
}
