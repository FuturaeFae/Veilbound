package dev.futurae.veilbound.upgrade;

import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.domain.DomainState;
import java.util.Map;
import java.util.Objects;

/** Server-authoritative incremental fed-item + Dimensional Energy Core-tier progression. */
public final class CoreTierUpgradeService {
    public FeedResult feed(DomainState state, CoreUpgradeRegistry registry, String itemId, long offeredCount) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(registry, "registry");
        Objects.requireNonNull(itemId, "itemId");
        if (!state.coreActive()) return FeedResult.denied("core_inactive");
        CoreUpgradeDefinition definition = registry.from(state.coreTier()).orElse(null);
        if (definition == null) return FeedResult.denied("no_upgrade_definition");

        UpgradeIngredient requirement = definition.ingredients().stream()
                .filter(candidate -> candidate.itemId().equals(itemId))
                .findFirst().orElse(null);
        if (requirement == null) return FeedResult.denied("not_upgrade_ingredient");

        long accepted = state.feedCoreUpgradeItem(itemId, offeredCount, requirement.count());
        Progress progress = progress(state, definition);
        UpgradeAttempt attempt = tryFinalize(state, definition, progress);
        return new FeedResult(true, accepted, attempt.upgraded(), attempt.reason(), definition.from(), definition.to(),
                progress.fedItems(), progress.requiredItems(), state.dimensionalEnergy(), definition.to().upgradeCostFromPrevious());
    }

    public UpgradeAttempt tryFinalize(DomainState state, CoreUpgradeDefinition definition) {
        return tryFinalize(state, definition, progress(state, definition));
    }

    public Progress progress(DomainState state, CoreUpgradeDefinition definition) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(definition, "definition");
        Map<String, Long> fed = state.coreUpgradeFedItems();
        long fedItems = 0L;
        long requiredItems = 0L;
        boolean complete = true;
        for (UpgradeIngredient requirement : definition.ingredients()) {
            long amount = Math.min(requirement.count(), fed.getOrDefault(requirement.itemId(), 0L));
            fedItems = Math.addExact(fedItems, amount);
            requiredItems = Math.addExact(requiredItems, requirement.count());
            if (amount < requirement.count()) complete = false;
        }
        return new Progress(complete, fedItems, requiredItems);
    }

    private UpgradeAttempt tryFinalize(DomainState state, CoreUpgradeDefinition definition, Progress progress) {
        if (!progress.complete()) return UpgradeAttempt.pending("requirements_incomplete");
        if (state.coreTier() != definition.from()) return UpgradeAttempt.pending("wrong_core_tier");
        long energyCost = definition.to().upgradeCostFromPrevious();
        if (state.dimensionalEnergy() < energyCost) return UpgradeAttempt.pending("insufficient_dimensional_energy");
        if (!state.consumeDimensionalEnergy(energyCost)) return UpgradeAttempt.pending("insufficient_dimensional_energy");
        CoreTier from = state.coreTier();
        state.setCoreTier(definition.to()); // also clears fed-item progress
        return UpgradeAttempt.upgraded(from, definition.to());
    }

    public record Progress(boolean complete, long fedItems, long requiredItems) {}

    public record UpgradeAttempt(boolean upgraded, CoreTier from, CoreTier to, String reason) {
        public static UpgradeAttempt pending(String reason) { return new UpgradeAttempt(false, null, null, reason); }
        public static UpgradeAttempt upgraded(CoreTier from, CoreTier to) { return new UpgradeAttempt(true, from, to, "ok"); }
    }

    public record FeedResult(
            boolean recognized,
            long consumed,
            boolean upgraded,
            String reason,
            CoreTier from,
            CoreTier to,
            long fedItems,
            long requiredItems,
            long dimensionalEnergy,
            long dimensionalEnergyRequired) {
        public static FeedResult denied(String reason) {
            return new FeedResult(false, 0L, false, reason, null, null, 0L, 0L, 0L, 0L);
        }
    }
}
