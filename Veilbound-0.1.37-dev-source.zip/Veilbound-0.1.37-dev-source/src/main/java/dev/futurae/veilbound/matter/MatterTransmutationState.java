package dev.futurae.veilbound.matter;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * Persistent owner Matter reserve + learned transmutation patterns + terminal preferences.
 *
 * Patterns are item ids rather than arbitrary component payloads. This deliberately prevents a
 * learned base item from becoming a source of copied enchantments, custom data, damage state, or
 * other component-bearing variants. Platform code may synthesize only the canonical/default stack
 * for a learned id unless an explicit safe-component rule says otherwise.
 */
public final class MatterTransmutationState {
    public static final int MAX_RECENT_PATTERNS = 36;

    private long storedMatter;
    private final LinkedHashSet<String> learnedItemIds = new LinkedHashSet<>();
    private final LinkedHashSet<String> favoriteItemIds = new LinkedHashSet<>();
    /** Most-recent first. */
    private final ArrayList<String> recentItemIds = new ArrayList<>();
    private Runnable mutationListener = () -> {};

    public long storedMatter() { return storedMatter; }
    public Set<String> learnedItemIds() { return Set.copyOf(learnedItemIds); }
    public Set<String> favoriteItemIds() { return Set.copyOf(favoriteItemIds); }
    public List<String> recentItemIds() { return List.copyOf(recentItemIds); }
    public boolean knows(String itemId) { return learnedItemIds.contains(normalize(itemId)); }
    public boolean favorite(String itemId) { return favoriteItemIds.contains(normalize(itemId)); }

    public boolean learn(String itemId) {
        String normalized = normalize(itemId);
        boolean changed = learnedItemIds.add(normalized);
        if (changed) changed();
        return changed;
    }

    public boolean toggleFavorite(String itemId) {
        String normalized = normalize(itemId);
        if (!learnedItemIds.contains(normalized)) return false;
        boolean nowFavorite;
        if (favoriteItemIds.remove(normalized)) nowFavorite = false;
        else {
            favoriteItemIds.add(normalized);
            nowFavorite = true;
        }
        changed();
        return nowFavorite;
    }

    /** Records successful synthesis/crafting use without changing whether the pattern is learned. */
    public void recordRecent(String itemId) {
        String normalized = normalize(itemId);
        if (!learnedItemIds.contains(normalized)) return;
        recentItemIds.remove(normalized);
        recentItemIds.add(0, normalized);
        while (recentItemIds.size() > MAX_RECENT_PATTERNS) recentItemIds.remove(recentItemIds.size() - 1);
        changed();
    }

    public long addMatter(long amount) {
        if (amount <= 0) return 0L;
        long accepted;
        try {
            accepted = Math.addExact(storedMatter, amount);
        } catch (ArithmeticException overflow) {
            accepted = Long.MAX_VALUE;
        }
        long delta = accepted - storedMatter;
        if (delta > 0) {
            storedMatter = accepted;
            changed();
        }
        return delta;
    }

    public boolean consumeMatter(long amount) {
        if (amount < 0) throw new IllegalArgumentException("amount must be >= 0");
        if (storedMatter < amount) return false;
        if (amount > 0) {
            storedMatter -= amount;
            changed();
        }
        return true;
    }

    /** Compatibility replacement used by older transaction code. */
    public void replace(long matter, Set<String> learned) {
        replace(matter, learned, favoriteItemIds, recentItemIds);
    }

    /** Transaction/persistence hook after the caller has validated the complete new state. */
    public void replace(long matter, Set<String> learned, Set<String> favorites, List<String> recent) {
        if (matter < 0) throw new IllegalArgumentException("matter must be >= 0");
        Objects.requireNonNull(learned, "learned");
        Objects.requireNonNull(favorites, "favorites");
        Objects.requireNonNull(recent, "recent");

        LinkedHashSet<String> normalizedLearned = new LinkedHashSet<>();
        for (String itemId : learned) normalizedLearned.add(normalize(itemId));
        LinkedHashSet<String> normalizedFavorites = new LinkedHashSet<>();
        for (String itemId : favorites) {
            String normalized = normalize(itemId);
            if (normalizedLearned.contains(normalized)) normalizedFavorites.add(normalized);
        }
        ArrayList<String> normalizedRecent = new ArrayList<>();
        for (String itemId : recent) {
            String normalized = normalize(itemId);
            if (!normalizedLearned.contains(normalized) || normalizedRecent.contains(normalized)) continue;
            normalizedRecent.add(normalized);
            if (normalizedRecent.size() >= MAX_RECENT_PATTERNS) break;
        }

        boolean changed = storedMatter != matter
                || !learnedItemIds.equals(normalizedLearned)
                || !favoriteItemIds.equals(normalizedFavorites)
                || !recentItemIds.equals(normalizedRecent);
        storedMatter = matter;
        learnedItemIds.clear();
        learnedItemIds.addAll(normalizedLearned);
        favoriteItemIds.clear();
        favoriteItemIds.addAll(normalizedFavorites);
        recentItemIds.clear();
        recentItemIds.addAll(normalizedRecent);
        if (changed) changed();
    }

    public void setMutationListener(Runnable listener) {
        this.mutationListener = Objects.requireNonNull(listener, "listener");
    }

    private static String normalize(String itemId) {
        Objects.requireNonNull(itemId, "itemId");
        String normalized = itemId.trim();
        if (normalized.isEmpty()) throw new IllegalArgumentException("itemId may not be blank");
        return normalized;
    }

    private void changed() { mutationListener.run(); }
}
