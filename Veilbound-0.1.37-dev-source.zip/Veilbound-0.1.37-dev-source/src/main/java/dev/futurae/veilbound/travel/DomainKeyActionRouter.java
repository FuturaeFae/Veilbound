package dev.futurae.veilbound.travel;

import dev.futurae.veilbound.domain.DomainIdentity;
import dev.futurae.veilbound.threshold.GuestThresholdSession;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Loader-neutral interpretation of the single Domain travel key.
 *
 * <p>The key always exits the Domain the player is currently visiting before it can be used to
 * enter their own Domain. A tracked guest therefore returns to their guest-entry anchor; it never
 * nests an owner-return anchor from inside somebody else's Domain.</p>
 */
public final class DomainKeyActionRouter {
    private DomainKeyActionRouter() {}

    public static Decision decide(
            UUID playerId,
            String currentDimensionId,
            Optional<GuestThresholdSession> guestSession) {
        Objects.requireNonNull(playerId, "playerId");
        Objects.requireNonNull(currentDimensionId, "currentDimensionId");
        Objects.requireNonNull(guestSession, "guestSession");

        boolean staleGuestSession = false;
        if (guestSession.isPresent()) {
            GuestThresholdSession session = guestSession.get();
            String visitedDomain = DomainIdentity.dimensionIdFor(session.ownerId());
            if (currentDimensionId.equals(visitedDomain)) {
                return new Decision(Action.EXIT_GUEST_DOMAIN, false, "guest_session");
            }
            // Commands, another mod, or recovery logic may have moved the player without going
            // through Veilbound. Do not let an obsolete guest anchor hijack future V presses.
            staleGuestSession = true;
        }

        String ownDomain = DomainIdentity.dimensionIdFor(playerId);
        if (currentDimensionId.equals(ownDomain)) {
            return new Decision(Action.EXIT_OWN_DOMAIN, staleGuestSession, "own_domain");
        }
        if (isDomainDimension(currentDimensionId)) {
            // A foreign Domain without a matching guest session is not enough information to know
            // where this player entered from. Refuse to invent a return anchor.
            return new Decision(Action.DENY_UNTRACKED_FOREIGN_DOMAIN, staleGuestSession, "untracked_foreign_domain");
        }
        return new Decision(Action.ENTER_OWN_DOMAIN, staleGuestSession, "outside_domain");
    }

    public static boolean isDomainDimension(String dimensionId) {
        Objects.requireNonNull(dimensionId, "dimensionId");
        return dimensionId.startsWith(
                DomainIdentity.DIMENSION_NAMESPACE + ":" + DomainIdentity.DIMENSION_PATH_PREFIX);
    }

    public enum Action {
        ENTER_OWN_DOMAIN,
        EXIT_OWN_DOMAIN,
        EXIT_GUEST_DOMAIN,
        DENY_UNTRACKED_FOREIGN_DOMAIN
    }

    public record Decision(Action action, boolean clearStaleGuestSession, String reason) {
        public Decision {
            Objects.requireNonNull(action, "action");
            Objects.requireNonNull(reason, "reason");
        }
    }
}
