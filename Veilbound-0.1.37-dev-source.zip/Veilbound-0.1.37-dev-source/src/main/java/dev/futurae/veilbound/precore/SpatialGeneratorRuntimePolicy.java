package dev.futurae.veilbound.precore;

/**
 * Reloadable balance around the settled pre-Core rules. Efficiency and ritual requirement are
 * authoritative; FE/Matter and expansion prices remain intentionally data-tunable.
 */
public record SpatialGeneratorRuntimePolicy(
        int efficiencyBasisPoints,
        long forgeEnergyPerRawMatter,
        long condensedChargePerNewBlock,
        long awakeningChargeRequirement) {
    public static final int SETTLED_EFFICIENCY_BPS = 3_500;
    public static final long SETTLED_AWAKENING_CHARGE = 50_000L;
    public static final int ITEM_FE_CAPACITY = 1_000_000;
    public static final int ITEM_MAX_FE_INSERT = 100_000;

    /** Development tuning for values not yet balance-locked. */
    public static final SpatialGeneratorRuntimePolicy DEVELOPMENT_DEFAULT =
            new SpatialGeneratorRuntimePolicy(SETTLED_EFFICIENCY_BPS, 20L, 1L, SETTLED_AWAKENING_CHARGE);

    public SpatialGeneratorRuntimePolicy {
        if (efficiencyBasisPoints != SETTLED_EFFICIENCY_BPS)
            throw new IllegalArgumentException("Spatial Generator efficiency is fixed at 35%");
        if (forgeEnergyPerRawMatter <= 0) throw new IllegalArgumentException("FE/Matter must be > 0");
        if (condensedChargePerNewBlock < 0) throw new IllegalArgumentException("charge/block must be >= 0");
        if (awakeningChargeRequirement != SETTLED_AWAKENING_CHARGE)
            throw new IllegalArgumentException("Core awakening charge is fixed at 50,000");
    }

    public SpatialGeneratorCostPolicy expansionCosts() {
        return new SpatialGeneratorCostPolicy(condensedChargePerNewBlock);
    }
}
