package dev.futurae.veilbound.platform.neoforge.inventory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.inventory.VeilStackKey;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.transfer.item.ItemResource;

/** Converts exact Minecraft item resources to/from Veilbound's loader-neutral persisted key. */
public final class NeoForgeVeilStackBridge {
    private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().create();

    private NeoForgeVeilStackBridge() {}

    public static VeilStackKey toKey(ItemResource resource, HolderLookup.Provider registries) {
        if (resource == null || resource.isEmpty()) throw new IllegalArgumentException("Cannot store an empty item resource");
        String itemId = BuiltInRegistries.ITEM.getKey(resource.getItem()).toString();
        DataComponentPatch patch = resource.getComponentsPatch();
        if (patch.isEmpty()) return VeilStackKey.plain(itemId);
        JsonElement json = DataComponentPatch.CODEC
                .encodeStart(registries.createSerializationContext(JsonOps.INSTANCE), patch)
                .getOrThrow(error -> new IllegalArgumentException("Cannot encode Veil item components: " + error));
        return new VeilStackKey(itemId, GSON.toJson(json));
    }

    public static ItemResource toResource(VeilStackKey key, HolderLookup.Provider registries) {
        Identifier id = Identifier.tryParse(key.itemId());
        if (id == null || !BuiltInRegistries.ITEM.containsKey(id)) return ItemResource.EMPTY;
        Item item = BuiltInRegistries.ITEM.getValue(id);
        if (item == Items.AIR) return ItemResource.EMPTY;
        if (key.componentData().isEmpty()) return ItemResource.of(item);
        try {
            JsonElement json = JsonParser.parseString(key.componentData());
            DataComponentPatch patch = DataComponentPatch.CODEC
                    .parse(registries.createSerializationContext(JsonOps.INSTANCE), json)
                    .getOrThrow(error -> new IllegalArgumentException("Cannot decode Veil item components: " + error));
            return ItemResource.of(item, patch);
        } catch (RuntimeException malformed) {
            Veilbound.LOGGER.error("Unable to restore Veil Inventory item {}", key.itemId(), malformed);
            return ItemResource.EMPTY;
        }
    }
}
