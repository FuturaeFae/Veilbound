package dev.futurae.veilbound.travel;

import dev.futurae.veilbound.domain.DomainIdentity;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.domain.DomainRepository;
import java.util.Objects;
import java.util.UUID;

/**
 * Authoritative owner keybind flow. A Domain must already have been bound through the Genesis Seed
 * ritual; once it exists, the key simply toggles between that Domain and the exact most-recent
 * outside anchor. There is deliberately no cost/cooldown/combat/blacklist gate here.
 */
public final class OwnerDomainTravelService {
    private final DomainRepository domains;

    public OwnerDomainTravelService(DomainRepository domains) {
        this.domains = Objects.requireNonNull(domains, "domains");
    }

    public TravelDecision request(UUID ownerId, ReturnAnchor currentLocation) {
        Objects.requireNonNull(ownerId, "ownerId");
        Objects.requireNonNull(currentLocation, "currentLocation");
        String ownDomainId = DomainIdentity.dimensionIdFor(ownerId);
        DomainRecord record = domains.getRecord(ownerId).orElse(null);

        if (currentLocation.dimensionId().equals(ownDomainId)) {
            if (record == null) return TravelDecision.denied("domain_record_missing");
            ReturnAnchor outside = record.ownerReturnAnchor().orElse(null);
            if (outside == null) return TravelDecision.denied("missing_return_anchor");
            return TravelDecision.exit(record, outside);
        }

        if (record == null) return TravelDecision.denied("domain_not_bound");
        record.setOwnerReturnAnchor(currentLocation);
        return TravelDecision.enter(record, false);
    }

    /** Call only after the platform confirms a safe exit teleport completed. */
    public void completeExit(UUID ownerId) {
        domains.getRecord(Objects.requireNonNull(ownerId)).ifPresent(DomainRecord::clearOwnerReturnAnchor);
    }

    public record TravelDecision(
            boolean allowed,
            boolean enteringDomain,
            boolean domainCreated,
            DomainRecord domain,
            String targetDimensionId,
            DomainPosition targetDomainPosition,
            ReturnAnchor outsideReturnAnchor,
            String reason) {
        static TravelDecision denied(String reason) {
            return new TravelDecision(false, false, false, null, null, null, null, reason);
        }
        static TravelDecision enter(DomainRecord domain, boolean created) {
            return new TravelDecision(true, true, created, domain, domain.identity().dimensionId(), DomainPosition.ORIGIN, null, "ok");
        }
        static TravelDecision exit(DomainRecord domain, ReturnAnchor anchor) {
            return new TravelDecision(true, false, false, domain, anchor.dimensionId(), null, anchor, "ok");
        }
    }
}
