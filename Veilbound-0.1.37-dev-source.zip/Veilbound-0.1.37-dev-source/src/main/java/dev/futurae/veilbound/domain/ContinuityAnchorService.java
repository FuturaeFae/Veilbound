package dev.futurae.veilbound.domain;

import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

/**
 * Authoritative placement/removal rules for Continuity Anchors.
 *
 * <p>An Anchor is a one-chunk loader, not a travel anchor. Multiple physical Anchors may exist in
 * the same chunk (and each still contributes Stability Load), but the platform loader collapses
 * them to one chunk ticket. Anchors are Core-era devices and are capped per Domain.</p>
 */
public final class ContinuityAnchorService {
    public static final int DEFAULT_MAX_ANCHORS = 25;

    private ContinuityAnchorService() {}

    public static PlacementResult place(DomainState state, DomainPosition position, int maxAnchors) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(position, "position");
        if (maxAnchors < 1) return PlacementResult.denied("invalid_anchor_cap");
        if (!state.coreActive()) return PlacementResult.denied("core_inactive");
        if (!state.bounds().contains(position)) return PlacementResult.denied("outside_domain");
        if (state.continuityAnchors().contains(position)) return PlacementResult.denied("already_registered");
        if (state.continuityAnchors().size() >= maxAnchors) return PlacementResult.denied("anchor_cap_reached");
        state.addContinuityAnchor(position);
        return PlacementResult.allowed(DomainChunkPosition.containing(position), state.continuityAnchors().size());
    }

    public static RemovalResult remove(DomainState state, DomainPosition position) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(position, "position");
        if (!state.continuityAnchors().contains(position)) return RemovalResult.notRegistered();
        DomainChunkPosition chunk = DomainChunkPosition.containing(position);
        state.removeContinuityAnchor(position);
        boolean chunkStillAnchored = state.continuityAnchors().stream()
                .map(DomainChunkPosition::containing)
                .anyMatch(chunk::equals);
        return new RemovalResult(true, chunk, chunkStillAnchored);
    }

    /** Unique chunks that should receive loader tickets while the owner is online. */
    public static Set<DomainChunkPosition> anchoredChunks(DomainState state) {
        Objects.requireNonNull(state, "state");
        Set<DomainChunkPosition> chunks = new LinkedHashSet<>();
        for (DomainPosition position : state.continuityAnchors()) chunks.add(DomainChunkPosition.containing(position));
        return Set.copyOf(chunks);
    }

    public record PlacementResult(boolean placed, String reason, DomainChunkPosition chunk, int anchorCount) {
        public static PlacementResult denied(String reason) { return new PlacementResult(false, reason, null, 0); }
        public static PlacementResult allowed(DomainChunkPosition chunk, int count) { return new PlacementResult(true, "ok", chunk, count); }
    }

    public record RemovalResult(boolean removed, DomainChunkPosition chunk, boolean chunkStillAnchored) {
        public static RemovalResult notRegistered() { return new RemovalResult(false, null, false); }
    }
}
