package dev.futurae.veilbound.law;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Immutable resolved view of the effect handlers requested by the Domain's currently imposed Laws.
 *
 * <p>Definitions remain data-driven, while platform gameplay adapters consume only registered,
 * namespaced effect ids. Missing definitions are reported separately and never create phantom
 * effects.</p>
 */
public record ActiveLawEffects(
        Set<String> effectIds,
        Map<String, Set<String>> sourceLawIdsByEffect,
        List<String> missingLawDefinitionIds) {

    public ActiveLawEffects {
        effectIds = Collections.unmodifiableSet(new LinkedHashSet<>(effectIds == null ? Set.of() : effectIds));
        LinkedHashMap<String, Set<String>> sources = new LinkedHashMap<>();
        if (sourceLawIdsByEffect != null) {
            sourceLawIdsByEffect.forEach((effectId, lawIds) -> sources.put(
                    effectId, Collections.unmodifiableSet(new LinkedHashSet<>(lawIds))));
        }
        sourceLawIdsByEffect = Collections.unmodifiableMap(sources);
        missingLawDefinitionIds = List.copyOf(missingLawDefinitionIds == null ? List.of() : missingLawDefinitionIds);
    }

    public boolean has(String effectId) {
        return effectIds.contains(effectId);
    }
}
