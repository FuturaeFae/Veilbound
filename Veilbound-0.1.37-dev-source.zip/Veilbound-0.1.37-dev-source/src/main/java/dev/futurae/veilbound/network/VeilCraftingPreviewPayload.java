package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.neoforged.neoforge.transfer.item.ItemResource;

/** Server-authoritative result preview for the current wireless crafting-grid proposal. */
public record VeilCraftingPreviewPayload(
        boolean craftable,
        String reason,
        ItemResource result,
        int resultCount) implements CustomPacketPayload {

    public static final Type<VeilCraftingPreviewPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "veil_crafting_preview"));

    public static final StreamCodec<RegistryFriendlyByteBuf, VeilCraftingPreviewPayload> STREAM_CODEC =
            new StreamCodec<>() {
                @Override
                public VeilCraftingPreviewPayload decode(RegistryFriendlyByteBuf buffer) {
                    return new VeilCraftingPreviewPayload(
                            buffer.readBoolean(),
                            buffer.readUtf(128),
                            ItemResource.STREAM_CODEC.decode(buffer),
                            buffer.readVarInt());
                }

                @Override
                public void encode(RegistryFriendlyByteBuf buffer, VeilCraftingPreviewPayload payload) {
                    buffer.writeBoolean(payload.craftable());
                    buffer.writeUtf(payload.reason(), 128);
                    ItemResource.STREAM_CODEC.encode(buffer, payload.result());
                    buffer.writeVarInt(payload.resultCount());
                }
            };

    public VeilCraftingPreviewPayload {
        reason = reason == null ? "unknown" : reason;
        if (result == null) result = ItemResource.EMPTY;
        if (resultCount < 0) throw new IllegalArgumentException("resultCount must be >= 0");
        if (result.isEmpty()) resultCount = 0;
    }

    public static VeilCraftingPreviewPayload denied(String reason) {
        return new VeilCraftingPreviewPayload(false, reason, ItemResource.EMPTY, 0);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
