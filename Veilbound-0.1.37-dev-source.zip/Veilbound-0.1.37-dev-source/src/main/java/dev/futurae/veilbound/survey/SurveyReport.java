package dev.futurae.veilbound.survey;

import dev.futurae.veilbound.breach.Breach;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import java.util.List;
import java.util.Map;

/** Informational-only output for the Survey Lens. */
public record SurveyReport(
        DomainBounds inspectedBounds,
        List<DomainPosition> voidAnchorPositions,
        List<Breach> hazards,
        List<String> structureIds,
        Map<String, Long> resourceCounts,
        List<String> hiddenFeatureIds) {
    public SurveyReport {
        voidAnchorPositions = List.copyOf(voidAnchorPositions);
        hazards = List.copyOf(hazards);
        structureIds = List.copyOf(structureIds);
        resourceCounts = Map.copyOf(resourceCounts);
        hiddenFeatureIds = List.copyOf(hiddenFeatureIds);
    }
}
