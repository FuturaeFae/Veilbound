package dev.futurae.veilbound.precore;

/** Reloadable pre-Core expansion cost, expressed only in already-created Condensed Charge. */
public record SpatialGeneratorCostPolicy(long condensedChargePerNewBlock) {
    public SpatialGeneratorCostPolicy {
        if (condensedChargePerNewBlock < 0) throw new IllegalArgumentException("cost must be >= 0");
    }

    public long milliChargePerNewBlock() {
        return Math.multiplyExact(condensedChargePerNewBlock, CondensedCharge.SCALE);
    }
}
