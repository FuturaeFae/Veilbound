package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.matter.MatterPatternPageService;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.neoforged.neoforge.transfer.item.ItemResource;

/** Client request for a bounded, server-authoritative Veil Inventory operation/view. */
public record VeilInventoryActionPayload(
        Action action,
        int page,
        ItemResource resource,
        int quantity,
        String query,
        MatterPatternPageService.SortMode sortMode,
        MatterPatternPageService.FilterMode filterMode) implements CustomPacketPayload {
    public static final int MAX_QUERY_LENGTH = 64;
    public static final int MAX_SYNTHESIS_QUANTITY = 64;

    public enum Action {
        OPEN_OR_PAGE,
        DEPOSIT_HELD,
        WITHDRAW_ONE,
        WITHDRAW_STACK,
        SYNTHESIZE_QUANTITY,
        TOGGLE_FAVORITE,
        TRANSMUTE_ONE,
        TRANSMUTE_STACK
    }

    public static final Type<VeilInventoryActionPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "veil_inventory_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, VeilInventoryActionPayload> STREAM_CODEC =
            new StreamCodec<>() {
                @Override
                public VeilInventoryActionPayload decode(RegistryFriendlyByteBuf buffer) {
                    int ordinal = buffer.readVarInt();
                    if (ordinal < 0 || ordinal >= Action.values().length) ordinal = 0;
                    int page = Math.max(0, buffer.readVarInt());
                    ItemResource resource = ItemResource.STREAM_CODEC.decode(buffer);
                    int quantity = Math.max(1, Math.min(MAX_SYNTHESIS_QUANTITY, buffer.readVarInt()));
                    String query = buffer.readUtf(MAX_QUERY_LENGTH);
                    int sortOrdinal = buffer.readVarInt();
                    int filterOrdinal = buffer.readVarInt();
                    MatterPatternPageService.SortMode sort = enumOrDefault(
                            MatterPatternPageService.SortMode.values(), sortOrdinal, MatterPatternPageService.SortMode.NAME_ASC);
                    MatterPatternPageService.FilterMode filter = enumOrDefault(
                            MatterPatternPageService.FilterMode.values(), filterOrdinal, MatterPatternPageService.FilterMode.ALL);
                    return new VeilInventoryActionPayload(Action.values()[ordinal], page, resource, quantity, query, sort, filter);
                }

                @Override
                public void encode(RegistryFriendlyByteBuf buffer, VeilInventoryActionPayload payload) {
                    buffer.writeVarInt(payload.action().ordinal());
                    buffer.writeVarInt(payload.page());
                    ItemResource.STREAM_CODEC.encode(buffer, payload.resource());
                    buffer.writeVarInt(payload.quantity());
                    buffer.writeUtf(payload.query(), MAX_QUERY_LENGTH);
                    buffer.writeVarInt(payload.sortMode().ordinal());
                    buffer.writeVarInt(payload.filterMode().ordinal());
                }
            };

    public VeilInventoryActionPayload {
        if (action == null) action = Action.OPEN_OR_PAGE;
        page = Math.max(0, page);
        if (resource == null) resource = ItemResource.EMPTY;
        quantity = Math.max(1, Math.min(MAX_SYNTHESIS_QUANTITY, quantity));
        query = query == null ? "" : query.trim();
        if (query.length() > MAX_QUERY_LENGTH) query = query.substring(0, MAX_QUERY_LENGTH);
        if (sortMode == null) sortMode = MatterPatternPageService.SortMode.NAME_ASC;
        if (filterMode == null) filterMode = MatterPatternPageService.FilterMode.ALL;
    }

    /** Compatibility constructor for old call sites; defaults to the normal terminal view. */
    public VeilInventoryActionPayload(Action action, int page, ItemResource resource) {
        this(action, page, resource, 1, "", MatterPatternPageService.SortMode.NAME_ASC, MatterPatternPageService.FilterMode.ALL);
    }

    private static <E> E enumOrDefault(E[] values, int ordinal, E fallback) {
        return ordinal >= 0 && ordinal < values.length ? values[ordinal] : fallback;
    }

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
