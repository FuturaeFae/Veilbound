package dev.futurae.veilbound.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Veilbound's angel-block equivalent.
 *
 * <p>The block is intentionally disposable as scaffolding: it breaks instantly, has no loot
 * table, and on a survival-player break it returns itself directly to the player's inventory.
 * If the inventory cannot accept it, it falls back to a normal player drop rather than deleting
 * the utility block.</p>
 */
public final class VoidAnchorBlock extends Block {
    public VoidAnchorBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide() && !player.hasInfiniteMaterials()) {
            ItemStack returned = new ItemStack(this);
            if (!player.getInventory().add(returned)) {
                player.drop(returned, false);
            }
        }
        return super.playerWillDestroy(level, pos, state, player);
    }
}
