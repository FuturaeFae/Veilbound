package dev.futurae.veilbound.precore;

/**
 * Single pre-Core energy-like resource produced by the Spatial Generator.
 * Stored as milli-charge so the settled 35% conversion rate is lossless even for 1-Matter items.
 */
public record CondensedCharge(long milliUnits) {
    public static final long SCALE = 1_000L;
    public static final CondensedCharge EMPTY = new CondensedCharge(0L);

    public CondensedCharge {
        if (milliUnits < 0) throw new IllegalArgumentException("Condensed Charge must be >= 0");
    }

    public static CondensedCharge whole(long units) {
        if (units < 0) throw new IllegalArgumentException("Condensed Charge must be >= 0");
        return new CondensedCharge(Math.multiplyExact(units, SCALE));
    }

    public long wholeUnits() { return milliUnits / SCALE; }
    public long fractionalMilliUnits() { return milliUnits % SCALE; }
    public boolean canPayMilli(long requiredMilli) { return requiredMilli >= 0 && milliUnits >= requiredMilli; }
    public boolean canPayWhole(long requiredWhole) {
        return requiredWhole >= 0 && canPayMilli(Math.multiplyExact(requiredWhole, SCALE));
    }
    public CondensedCharge plusMilli(long amount) {
        if (amount < 0) throw new IllegalArgumentException("amount must be >= 0");
        return new CondensedCharge(Math.addExact(milliUnits, amount));
    }
    public CondensedCharge spendMilli(long amount) {
        if (!canPayMilli(amount)) throw new IllegalStateException("insufficient Condensed Charge");
        return new CondensedCharge(milliUnits - amount);
    }
    public CondensedCharge spendWhole(long amount) {
        if (amount < 0) throw new IllegalArgumentException("amount must be >= 0");
        return spendMilli(Math.multiplyExact(amount, SCALE));
    }
}
