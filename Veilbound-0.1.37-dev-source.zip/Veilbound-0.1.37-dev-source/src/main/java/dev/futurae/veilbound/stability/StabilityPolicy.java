package dev.futurae.veilbound.stability;

/**
 * Configurable load weights and thresholds. Expansion pylons, permanent Thresholds and
 * Continuity Anchors contribute to load; no balance values are hard-coded here.
 */
public record StabilityPolicy(
        double capacity,
        double activePylonLoad,
        double thresholdLoad,
        double continuityAnchorLoad,
        double strainedRatio,
        double criticalRatio,
        double rupturingRatio) {

    public StabilityPolicy {
        if (!(capacity > 0) || !Double.isFinite(capacity)) throw new IllegalArgumentException("capacity must be finite and > 0");
        if (!Double.isFinite(activePylonLoad) || !Double.isFinite(thresholdLoad) || !Double.isFinite(continuityAnchorLoad)
                || activePylonLoad < 0 || thresholdLoad < 0 || continuityAnchorLoad < 0) {
            throw new IllegalArgumentException("loads must be >= 0");
        }
        if (!Double.isFinite(strainedRatio) || !Double.isFinite(criticalRatio) || !Double.isFinite(rupturingRatio)
                || strainedRatio < 0 || strainedRatio > criticalRatio
                || criticalRatio > rupturingRatio || rupturingRatio <= 0) {
            throw new IllegalArgumentException("stability ratios must be ordered and non-negative");
        }
    }
}
