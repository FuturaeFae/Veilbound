package dev.futurae.veilbound.stability;

import dev.futurae.veilbound.breach.BreachRuntimePolicy;
import dev.futurae.veilbound.breach.BreachHazardPolicy;
import dev.futurae.veilbound.breach.BreachSeverity;
import dev.futurae.veilbound.breach.BreachSpawnPolicy;
import dev.futurae.veilbound.domain.ContinuityAnchorService;
import dev.futurae.veilbound.domain.CoreTier;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;

/**
 * Reloadable Domain stability policy. The settled defaults live here rather than in the calculator,
 * so datapacks can replace balance without changing deterministic gameplay rules.
 */
public final class StabilityRuntimePolicy {
    private final EnumMap<CoreTier, Double> capacities;
    private final double activePylonLoad;
    private final double thresholdLoad;
    private final double continuityAnchorLoad;
    private final double strainedLoadRatio;
    private final double criticalLoadRatio;
    private final double rupturingLoadRatio;
    private final int evaluationTicks;
    private final int maxContinuityAnchors;
    private final BreachRuntimePolicy breachPolicy;

    public static final StabilityRuntimePolicy DEVELOPMENT_DEFAULT = developmentDefault();

    public StabilityRuntimePolicy(
            Map<CoreTier, Double> capacities,
            double activePylonLoad,
            double thresholdLoad,
            double continuityAnchorLoad,
            double strainedLoadRatio,
            double criticalLoadRatio,
            double rupturingLoadRatio,
            int evaluationTicks,
            int maxContinuityAnchors,
            BreachRuntimePolicy breachPolicy) {
        Objects.requireNonNull(capacities, "capacities");
        this.capacities = new EnumMap<>(CoreTier.class);
        for (CoreTier tier : CoreTier.values()) {
            Double capacity = Objects.requireNonNull(capacities.get(tier), "Missing stability capacity for " + tier);
            if (!(capacity > 0) || !Double.isFinite(capacity)) throw new IllegalArgumentException("stability capacities must be finite and > 0");
            this.capacities.put(tier, capacity);
        }
        if (!Double.isFinite(activePylonLoad) || !Double.isFinite(thresholdLoad) || !Double.isFinite(continuityAnchorLoad)
                || activePylonLoad < 0 || thresholdLoad < 0 || continuityAnchorLoad < 0) {
            throw new IllegalArgumentException("stability loads must be >= 0");
        }
        if (!Double.isFinite(strainedLoadRatio) || !Double.isFinite(criticalLoadRatio) || !Double.isFinite(rupturingLoadRatio)
                || strainedLoadRatio < 0 || strainedLoadRatio > criticalLoadRatio
                || criticalLoadRatio > rupturingLoadRatio || rupturingLoadRatio <= 0) {
            throw new IllegalArgumentException("stability ratios must be ordered and non-negative");
        }
        if (evaluationTicks < 1) throw new IllegalArgumentException("evaluationTicks must be >= 1");
        if (maxContinuityAnchors < 1) throw new IllegalArgumentException("maxContinuityAnchors must be >= 1");
        this.activePylonLoad = activePylonLoad;
        this.thresholdLoad = thresholdLoad;
        this.continuityAnchorLoad = continuityAnchorLoad;
        this.strainedLoadRatio = strainedLoadRatio;
        this.criticalLoadRatio = criticalLoadRatio;
        this.rupturingLoadRatio = rupturingLoadRatio;
        this.evaluationTicks = evaluationTicks;
        this.maxContinuityAnchors = maxContinuityAnchors;
        this.breachPolicy = Objects.requireNonNull(breachPolicy, "breachPolicy");
    }

    public StabilityPolicy forTier(CoreTier tier) {
        return new StabilityPolicy(
                capacities.get(Objects.requireNonNull(tier, "tier")),
                activePylonLoad,
                thresholdLoad,
                continuityAnchorLoad,
                strainedLoadRatio,
                criticalLoadRatio,
                rupturingLoadRatio);
    }

    public double capacity(CoreTier tier) { return capacities.get(tier); }
    public Map<CoreTier, Double> capacities() { return Map.copyOf(capacities); }
    public double activePylonLoad() { return activePylonLoad; }
    public double thresholdLoad() { return thresholdLoad; }
    public double continuityAnchorLoad() { return continuityAnchorLoad; }
    public double strainedLoadRatio() { return strainedLoadRatio; }
    public double criticalLoadRatio() { return criticalLoadRatio; }
    public double rupturingLoadRatio() { return rupturingLoadRatio; }
    public int evaluationTicks() { return evaluationTicks; }
    public int maxContinuityAnchors() { return maxContinuityAnchors; }
    public BreachRuntimePolicy breachPolicy() { return breachPolicy; }

    private static StabilityRuntimePolicy developmentDefault() {
        EnumMap<CoreTier, Double> capacities = new EnumMap<>(CoreTier.class);
        capacities.put(CoreTier.NASCENT, 100.0);
        capacities.put(CoreTier.ANCHORED, 160.0);
        capacities.put(CoreTier.RESONANT, 240.0);
        capacities.put(CoreTier.ASCENDANT, 360.0);
        capacities.put(CoreTier.TRANSCENDENT, 520.0);

        EnumMap<StabilityBand, Double> deltas = new EnumMap<>(StabilityBand.class);
        deltas.put(StabilityBand.STABLE, -2.0);
        deltas.put(StabilityBand.STRAINED, 0.5);
        deltas.put(StabilityBand.CRITICAL, 2.0);
        deltas.put(StabilityBand.RUPTURING, 5.0);

        EnumMap<BreachSeverity, Long> stitcherCosts = new EnumMap<>(BreachSeverity.class);
        stitcherCosts.put(BreachSeverity.MINOR, 1_000L);
        stitcherCosts.put(BreachSeverity.SEVERE, 5_000L);
        stitcherCosts.put(BreachSeverity.EXTREME, 25_000L);

        EnumMap<BreachSeverity, BreachSpawnPolicy.SpawnBand> spawnBands = new EnumMap<>(BreachSeverity.class);
        spawnBands.put(BreachSeverity.MINOR, new BreachSpawnPolicy.SpawnBand(600, 1_200));
        spawnBands.put(BreachSeverity.SEVERE, new BreachSpawnPolicy.SpawnBand(300, 700));
        spawnBands.put(BreachSeverity.EXTREME, new BreachSpawnPolicy.SpawnBand(120, 360));
        BreachSpawnPolicy spawnPolicy = new BreachSpawnPolicy(
                spawnBands, 8, 24.0, 2.5, BreachSpawnPolicy.developmentPools());
        BreachRuntimePolicy breach = new BreachRuntimePolicy(
                deltas, 100.0, 300.0, 3, 6.0, stitcherCosts, spawnPolicy, BreachHazardPolicy.developmentDefault());

        // Settled stability defaults: Pylon +4, permanent Threshold +6, Continuity Anchor +4.
        // Stability percentages map to load ratios: Stable <=35%, Strained 35-65%, Critical
        // 65-85%, Rupturing >=85%.
        return new StabilityRuntimePolicy(
                capacities, 4.0, 6.0, 4.0,
                0.35, 0.65, 0.85,
                20, ContinuityAnchorService.DEFAULT_MAX_ANCHORS, breach);
    }
}
