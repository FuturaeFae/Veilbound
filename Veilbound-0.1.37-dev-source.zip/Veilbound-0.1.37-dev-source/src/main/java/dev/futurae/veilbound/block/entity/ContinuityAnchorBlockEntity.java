package dev.futurae.veilbound.block.entity;

import dev.futurae.veilbound.registry.VeilboundBlockEntities;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jspecify.annotations.Nullable;

/** Persistent owner binding for a physical Continuity Anchor. */
public final class ContinuityAnchorBlockEntity extends BlockEntity {
    private UUID ownerId;

    public ContinuityAnchorBlockEntity(BlockPos pos, BlockState state) {
        super(VeilboundBlockEntities.CONTINUITY_ANCHOR.get(), pos, state);
    }

    public void bindOwner(UUID ownerId) {
        UUID candidate = Objects.requireNonNull(ownerId, "ownerId");
        if (this.ownerId == null) {
            this.ownerId = candidate;
            setChanged();
        }
    }

    public @Nullable UUID ownerId() { return ownerId; }

    @Override
    protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        if (ownerId != null) output.putString("owner", ownerId.toString());
    }

    @Override
    protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        ownerId = input.getString("owner").flatMap(raw -> {
            try { return java.util.Optional.of(UUID.fromString(raw)); }
            catch (IllegalArgumentException ignored) { return java.util.Optional.empty(); }
        }).orElse(null);
    }
}
