package dev.futurae.veilbound.engineering;

import java.util.LinkedHashMap;
import java.util.Map;

/** Loader-neutral exact-count input/output buffer used by advanced fabrication machines. */
public final class EngineeringInventory {
    private final LinkedHashMap<String, Long> counts = new LinkedHashMap<>();
    public long count(String itemId) { return counts.getOrDefault(itemId, 0L); }
    public void insert(String itemId, long count) {
        if (count <= 0) return;
        counts.merge(itemId, count, (a,b) -> {
            try { return Math.addExact(a,b); } catch (ArithmeticException e) { return Long.MAX_VALUE; }
        });
    }
    public boolean extract(String itemId, long count) {
        if (count < 0) throw new IllegalArgumentException("count must be >= 0");
        long current = count(itemId);
        if (current < count) return false;
        if (count == 0) return true;
        long left = current - count;
        if (left == 0) counts.remove(itemId); else counts.put(itemId, left);
        return true;
    }
    public Map<String,Long> snapshot() { return Map.copyOf(counts); }
    public void replace(Map<String, Long> replacement) {
        counts.clear();
        if (replacement == null) return;
        replacement.forEach((itemId, count) -> {
            if (itemId == null || itemId.isBlank() || count == null || count <= 0) return;
            counts.put(itemId, count);
        });
    }
}
