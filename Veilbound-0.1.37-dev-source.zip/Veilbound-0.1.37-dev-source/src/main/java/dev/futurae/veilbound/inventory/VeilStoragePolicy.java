package dev.futurae.veilbound.inventory;

import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainState;
import java.util.Objects;

/** Finalized late-game capacity progression for the Core-backed Veil Inventory. */
public final class VeilStoragePolicy {
    public static final VeilStorageCapacity RESONANT = new VeilStorageCapacity(65_536L, 256);
    public static final VeilStorageCapacity ASCENDANT = new VeilStorageCapacity(1_048_576L, 1_024);
    public static final VeilStorageCapacity TRANSCENDENT = new VeilStorageCapacity(16_777_216L, 4_096);

    public VeilStorageCapacity capacityFor(DomainState state) {
        Objects.requireNonNull(state, "state");
        if (!state.coreActive() || !state.hasFeature(DomainFeature.VEIL_INVENTORY)) {
            return VeilStorageCapacity.LOCKED;
        }
        if (state.sovereigntyUnlocked()) return VeilStorageCapacity.EFFECTIVELY_UNLIMITED;
        return switch (state.coreTier()) {
            case NASCENT, ANCHORED -> VeilStorageCapacity.LOCKED;
            case RESONANT -> RESONANT;
            case ASCENDANT -> ASCENDANT;
            case TRANSCENDENT -> TRANSCENDENT;
        };
    }
}
