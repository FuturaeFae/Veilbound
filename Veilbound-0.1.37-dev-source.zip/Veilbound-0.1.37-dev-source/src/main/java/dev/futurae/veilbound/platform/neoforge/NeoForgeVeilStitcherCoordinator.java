package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.breach.Breach;
import dev.futurae.veilbound.breach.BreachService;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.registry.VeilboundItems;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.Comparator;
import java.util.Objects;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/** Server-authoritative Veil Stitcher targeting and Dimensional-Energy breach repair. */
public final class NeoForgeVeilStitcherCoordinator {
    private final VeilboundRuntime runtime;

    public NeoForgeVeilStitcherCoordinator(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    public void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getLevel().isClientSide()) return;
        if (!event.getItemStack().is(VeilboundItems.VEIL_STITCHER.get())) return;

        DomainRecord record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null || !record.identity().dimensionId().equals(event.getLevel().dimension().identifier().toString())) {
            message(player, "message.veilbound.stitcher.not_owner_domain");
            consume(event, InteractionResult.FAIL);
            return;
        }
        if (!record.state().coreActive()) {
            message(player, "message.veilbound.stitcher.core_inactive");
            consume(event, InteractionResult.FAIL);
            return;
        }

        double range = runtime.stabilityPolicy().policy().breachPolicy().stitcherRange();
        double rangeSquared = range * range;
        Breach nearest = record.state().breaches().stream()
                .filter(Breach::open)
                .filter(breach -> distanceSquared(player, breach) <= rangeSquared)
                .min(Comparator.comparingDouble(breach -> distanceSquared(player, breach)))
                .orElse(null);
        if (nearest == null) {
            player.displayClientMessage(Component.translatable("message.veilbound.stitcher.no_breach_nearby", range), true);
            consume(event, InteractionResult.FAIL);
            return;
        }

        long cost = runtime.stabilityPolicy().policy().breachPolicy()
                .stitcherDimensionalEnergyCost(nearest.severity());
        BreachService.SealResult result = BreachService.sealWithStitcher(record.state(), nearest.id(), cost);
        if (!result.sealed()) {
            if ("insufficient_dimensional_energy".equals(result.reason())) {
                player.displayClientMessage(Component.translatable(
                        "message.veilbound.stitcher.insufficient_de", cost, record.state().dimensionalEnergy()), true);
            } else {
                message(player, "message.veilbound.stitcher.repair_failed");
            }
            consume(event, InteractionResult.FAIL);
            return;
        }

        long remaining = record.state().breaches().stream().filter(Breach::open).count();
        player.displayClientMessage(Component.translatable(
                "message.veilbound.stitcher.sealed",
                nearest.severity().name(), result.dimensionalEnergySpent(), remaining), false);
        consume(event, InteractionResult.SUCCESS);
    }

    private static double distanceSquared(ServerPlayer player, Breach breach) {
        double dx = player.getX() - (breach.position().x() + 0.5D);
        double dy = player.getY() - (breach.position().y() + 0.5D);
        double dz = player.getZ() - (breach.position().z() + 0.5D);
        return dx * dx + dy * dy + dz * dz;
    }

    private static void message(ServerPlayer player, String key) {
        player.displayClientMessage(Component.translatable(key), true);
    }

    private static void consume(PlayerInteractEvent.RightClickItem event, InteractionResult result) {
        event.setCancellationResult(result);
        event.setCanceled(true);
    }
}
