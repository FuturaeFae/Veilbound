package dev.futurae.veilbound.domain;

/**
 * Settled Boundary Pylon growth modes. Rate scales linearly while Dimensional Energy and Stability
 * load scale with the square of the multiplier, making aggressive reality growth progressively
 * harder to sustain instead of being a free throughput upgrade.
 */
public enum BoundaryPylonSpeed {
    GENTLE(1, 2),
    STABLE(1, 1),
    DRIVEN(2, 1),
    FORCED(4, 1),
    RUPTURE(8, 1);

    private final int numerator;
    private final int denominator;

    BoundaryPylonSpeed(int numerator, int denominator) {
        this.numerator = numerator;
        this.denominator = denominator;
    }

    public int numerator() { return numerator; }
    public int denominator() { return denominator; }
    public double multiplier() { return (double) numerator / denominator; }

    /** Scale an integral Stable-mode cost/load by multiplier squared without floating-point drift. */
    public long scaleSquared(long stableValue) {
        if (stableValue < 0) throw new IllegalArgumentException("stableValue must be >= 0");
        long n2 = Math.multiplyExact((long) numerator, numerator);
        long d2 = Math.multiplyExact((long) denominator, denominator);
        long scaledNumerator = Math.multiplyExact(stableValue, n2);
        if (scaledNumerator % d2 != 0) {
            throw new IllegalArgumentException("Stable value " + stableValue + " is not exactly representable at " + name());
        }
        return scaledNumerator / d2;
    }

    public double scaleSquared(double stableValue) {
        if (!Double.isFinite(stableValue) || stableValue < 0) throw new IllegalArgumentException("stableValue must be finite and >= 0");
        double m = multiplier();
        return stableValue * m * m;
    }

    /** Base interval is the Stable-mode interval. */
    public int intervalTicks(int stableIntervalTicks) {
        if (stableIntervalTicks < 1) throw new IllegalArgumentException("stableIntervalTicks must be >= 1");
        long numeratorTicks = Math.multiplyExact((long) stableIntervalTicks, denominator);
        if (numeratorTicks % numerator != 0) {
            throw new IllegalArgumentException("Stable interval " + stableIntervalTicks + " does not divide cleanly for " + name());
        }
        long result = numeratorTicks / numerator;
        if (result < 1 || result > Integer.MAX_VALUE) throw new IllegalArgumentException("Invalid derived Pylon interval");
        return (int) result;
    }

    public BoundaryPylonSpeed next() {
        BoundaryPylonSpeed[] values = values();
        return values[(ordinal() + 1) % values.length];
    }
}
