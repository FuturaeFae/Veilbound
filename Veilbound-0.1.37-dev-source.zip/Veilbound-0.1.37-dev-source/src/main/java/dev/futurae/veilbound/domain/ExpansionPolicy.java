package dev.futurae.veilbound.domain;

/**
 * Server/datapack supplied expansion policy. Balance numbers live outside the state model.
 * A horizontal cap of 0 means unlimited. Vertical span can never exceed the design hard
 * ceiling of 4,064 blocks even if configuration asks for more.
 */
public record ExpansionPolicy(
        long dimensionalEnergyPerNewBlock,
        int verticalSpanCap,
        int transcendentHorizontalCap) {

    public static final int ABSOLUTE_MAX_VERTICAL_SPAN = 4_064;

    public ExpansionPolicy {
        if (dimensionalEnergyPerNewBlock < 0) {
            throw new IllegalArgumentException("dimensionalEnergyPerNewBlock must be >= 0");
        }
        if (verticalSpanCap < 1 || verticalSpanCap > ABSOLUTE_MAX_VERTICAL_SPAN) {
            throw new IllegalArgumentException("verticalSpanCap must be between 1 and 4,064");
        }
        if (transcendentHorizontalCap < 0) {
            throw new IllegalArgumentException("transcendentHorizontalCap must be >= 0");
        }
    }
}
