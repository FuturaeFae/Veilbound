package dev.futurae.veilbound.breach;

import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import java.util.Objects;
import java.util.UUID;

/** Server-authoritative commit rule for a Veil Lance shot. FE is handled by the physical machine. */
public final class ForcedBreachService {
    private ForcedBreachService() {}

    public static Result open(
            DomainState state,
            DomainPosition impact,
            AxisDirection face,
            VeilLanceMode mode,
            VeilLancePolicy policy,
            long gameTick,
            UUID breachId,
            double maximumFractureMeter) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(impact, "impact");
        Objects.requireNonNull(face, "face");
        Objects.requireNonNull(mode, "mode");
        Objects.requireNonNull(policy, "policy");
        Objects.requireNonNull(breachId, "breachId");
        if (!state.coreActive()) return Result.denied("core_inactive");
        if (state.coreTier().ordinal() < policy.minimumTier().ordinal()) return Result.denied("core_tier_too_low");
        if (!isOnFace(state.bounds(), impact, face)) return Result.denied("invalid_boundary_target");
        long open = state.breaches().stream().filter(Breach::open).count();
        if (open >= policy.maxOpenBreaches()) return Result.denied("open_breach_cap");
        if (state.dimensionalEnergy() < mode.dimensionalEnergyCost()) return Result.denied("insufficient_dimensional_energy");

        // DE is committed only after every structural check succeeds.
        if (!state.consumeDimensionalEnergy(mode.dimensionalEnergyCost())) {
            return Result.denied("insufficient_dimensional_energy");
        }
        Breach breach = new Breach(breachId, impact, face, mode.severity(), true, gameTick);
        state.addBreach(breach);
        state.setFractureMeter(Math.min(maximumFractureMeter, state.fractureMeter() + mode.fractureShock()));
        return new Result(true, breach, mode.dimensionalEnergyCost(), mode.fractureShock(), "breach_formed");
    }

    public static boolean isOnFace(DomainBounds bounds, DomainPosition p, AxisDirection face) {
        if (!bounds.contains(p)) return false;
        return switch (face) {
            case POSITIVE_X -> p.x() == bounds.maxX();
            case NEGATIVE_X -> p.x() == bounds.minX();
            case POSITIVE_Y -> p.y() == bounds.maxY();
            case NEGATIVE_Y -> p.y() == bounds.minY();
            case POSITIVE_Z -> p.z() == bounds.maxZ();
            case NEGATIVE_Z -> p.z() == bounds.minZ();
        };
    }

    public record Result(boolean opened, Breach breach, long dimensionalEnergySpent, double fractureAdded, String reason) {
        public static Result denied(String reason) { return new Result(false, null, 0L, 0.0, reason); }
    }
}
