package dev.futurae.veilbound.memory;

import dev.futurae.veilbound.domain.DomainState;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** Validates and persists the active earned-Memory selection used by a Domain Orrery. */
public final class DomainOrreryService {
    private final MemoryProfileBlendService blender = new MemoryProfileBlendService();

    public SelectionResult select(
            DomainState state,
            MemoryProgressState progress,
            MemoryRegistry registry,
            Collection<String> requestedIds) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(progress, "progress");
        Objects.requireNonNull(registry, "registry");
        Objects.requireNonNull(requestedIds, "requestedIds");

        if (requestedIds.isEmpty()) {
            progress.clearActiveOrreryMemories();
            return SelectionResult.allowed(List.of(), Map.of());
        }
        List<MemoryDefinition> selected = new ArrayList<>();
        for (String id : requestedIds) {
            MemoryDefinition memory = registry.get(id).orElse(null);
            if (memory == null) return SelectionResult.denied("memory_definition_missing");
            selected.add(memory);
        }
        var blend = blender.blend(selected, state.unlockedMemoryIds());
        if (!blend.compatible()) return SelectionResult.denied(blend.reason());
        progress.setActiveOrreryMemoryIds(blend.memoryIds());
        return SelectionResult.allowed(blend.memoryIds(), blend.environmentalProfile());
    }

    public SelectionResult current(DomainState state, MemoryProgressState progress, MemoryRegistry registry) {
        return selectPreview(state, progress.activeOrreryMemoryIds(), registry);
    }

    private SelectionResult selectPreview(DomainState state, Collection<String> ids, MemoryRegistry registry) {
        if (ids.isEmpty()) return SelectionResult.allowed(List.of(), Map.of());
        List<MemoryDefinition> selected = new ArrayList<>();
        for (String id : ids) {
            MemoryDefinition memory = registry.get(id).orElse(null);
            if (memory == null) return SelectionResult.denied("memory_definition_missing");
            selected.add(memory);
        }
        var blend = blender.blend(selected, state.unlockedMemoryIds());
        return blend.compatible()
                ? SelectionResult.allowed(blend.memoryIds(), blend.environmentalProfile())
                : SelectionResult.denied(blend.reason());
    }

    public record SelectionResult(boolean selected, String reason, List<String> memoryIds, Map<String, String> environmentalProfile) {
        public static SelectionResult denied(String reason) { return new SelectionResult(false, reason, List.of(), Map.of()); }
        public static SelectionResult allowed(List<String> ids, Map<String, String> profile) {
            return new SelectionResult(true, "ok", List.copyOf(ids), Map.copyOf(profile));
        }
    }
}
