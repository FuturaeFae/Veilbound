package dev.futurae.veilbound.ontology;

import dev.futurae.veilbound.domain.DomainState;
import dev.futurae.veilbound.matter.MatterTransmutationState;

public final class OntologicalCompilerService {
    public CompileResult compile(DomainState domain, MatterTransmutationState matter, PotentialReservoir potential,
                                 long requestedPotential, OntologicalCompilerPolicy policy) {
        if (!domain.coreActive()) return new CompileResult(false, "core_inactive", 0, 0, 0);
        long requested = Math.max(0, Math.min(requestedPotential, policy.maxPotentialPerCycle()));
        long byPotential = Math.min(requested, potential.stored());
        long byEnergy = domain.dimensionalEnergy() / policy.dimensionalEnergyPerPotential();
        long used = Math.min(byPotential, byEnergy);
        if (used <= 0) return new CompileResult(false, byPotential <= 0 ? "potential_empty" : "insufficient_de", 0, 0, 0);
        long de = Math.multiplyExact(used, policy.dimensionalEnergyPerPotential());
        long produced;
        try { produced = Math.multiplyExact(used, policy.matterPerPotential()); }
        catch (ArithmeticException e) { produced = Long.MAX_VALUE; }
        if (!potential.consume(used)) throw new IllegalStateException("Potential changed during compile");
        if (!domain.consumeDimensionalEnergy(de)) throw new IllegalStateException("DE changed during compile");
        long accepted = matter.addMatter(produced);
        return new CompileResult(true, "ok", used, de, accepted);
    }
    public record CompileResult(boolean compiled, String reason, long potentialConsumed, long dimensionalEnergyConsumed, long matterProduced) {}
}
