package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.environment.EnvironmentZoneService;
import dev.futurae.veilbound.memory.DomainOrreryService;
import dev.futurae.veilbound.memory.MemoryDefinition;
import dev.futurae.veilbound.network.MemoryManagementActionPayload;
import dev.futurae.veilbound.network.MemoryManagementSnapshotPayload;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

/** Server authority for the combined Archive/Orrery/Environmental Zone management screen. */
public final class NeoForgeMemoryManagementController {
    private static final int MIN_PRIORITY = -100;
    private static final int MAX_PRIORITY = 100;
    private static final int MAX_ZONE_NAME_LENGTH = 48;

    private final VeilboundRuntime runtime;
    private final DomainOrreryService orrery = new DomainOrreryService();

    public NeoForgeMemoryManagementController(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    public void open(ServerPlayer player, MemoryManagementSnapshotPayload.View view) {
        send(player, view, "ok");
    }

    public void handle(ServerPlayer player, MemoryManagementActionPayload payload) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(payload, "payload");
        MemoryManagementSnapshotPayload.View view = viewFor(payload.action());
        DomainRecord record = ownerRecordInCurrentDomain(player);
        if (record == null) {
            PacketDistributor.sendToPlayer(player, MemoryManagementSnapshotPayload.denied(view, "not_owner_domain"));
            return;
        }

        String reason = switch (payload.action()) {
            case OPEN_ARCHIVE, OPEN_ORRERY, OPEN_ZONES -> "ok";
            case TOGGLE_ORRERY_MEMORY -> toggleMemory(record, payload.targetId());
            case CLEAR_ORRERY -> clearOrrery(record);
            case ZONE_DELETE -> deleteZone(record, payload.targetId());
            case ZONE_PRIORITY_UP -> changePriority(record, payload.targetId(), 1);
            case ZONE_PRIORITY_DOWN -> changePriority(record, payload.targetId(), -1);
            case ZONE_TOGGLE_BLEND -> toggleBlend(record, payload.targetId());
            case ZONE_RETUNE -> retune(record, payload.targetId(), payload.value());
            case ZONE_RENAME -> rename(record, payload.targetId(), payload.value());
        };
        send(player, view, reason);
    }

    private String toggleMemory(DomainRecord record, String memoryId) {
        if (memoryId == null || memoryId.isBlank()) return "invalid_memory";
        if (!record.state().unlockedMemoryIds().contains(memoryId)) return "memory_not_archived";
        LinkedHashSet<String> requested = new LinkedHashSet<>(record.memoryProgress().activeOrreryMemoryIds());
        if (!requested.remove(memoryId)) requested.add(memoryId);
        var result = orrery.select(record.state(), record.memoryProgress(), runtime.memories(), requested);
        return result.selected() ? "ok" : result.reason();
    }

    private String clearOrrery(DomainRecord record) {
        var result = orrery.select(record.state(), record.memoryProgress(), runtime.memories(), List.of());
        return result.selected() ? "ok" : result.reason();
    }

    private String deleteZone(DomainRecord record, String zoneId) {
        if (!record.state().hasFeature(DomainFeature.ENVIRONMENTAL_MASTERY)) return "environmental_mastery_locked";
        UUID id = parseUuid(zoneId);
        if (id == null) return "zone_not_found";
        return EnvironmentZoneService.delete(record.state(), id) ? "ok" : "zone_not_found";
    }

    private String changePriority(DomainRecord record, String zoneId, int delta) {
        if (!record.state().hasFeature(DomainFeature.ENVIRONMENTAL_MASTERY)) return "environmental_mastery_locked";
        UUID id = parseUuid(zoneId);
        if (id == null) return "zone_not_found";
        var zone = record.state().environmentZones().stream().filter(z -> z.id().equals(id)).findFirst().orElse(null);
        if (zone == null) return "zone_not_found";
        int next = Math.max(MIN_PRIORITY, Math.min(MAX_PRIORITY, zone.priority() + delta));
        var result = EnvironmentZoneService.configure(record.state(), id, next, zone.blendWithLowerPriority());
        return result.updated() ? "ok" : result.reason();
    }

    private String toggleBlend(DomainRecord record, String zoneId) {
        if (!record.state().hasFeature(DomainFeature.ENVIRONMENTAL_MASTERY)) return "environmental_mastery_locked";
        UUID id = parseUuid(zoneId);
        if (id == null) return "zone_not_found";
        var zone = record.state().environmentZones().stream().filter(z -> z.id().equals(id)).findFirst().orElse(null);
        if (zone == null) return "zone_not_found";
        var result = EnvironmentZoneService.configure(record.state(), id, zone.priority(), !zone.blendWithLowerPriority());
        return result.updated() ? "ok" : result.reason();
    }

    private String retune(DomainRecord record, String zoneId, String memoryId) {
        if (!record.state().hasFeature(DomainFeature.ENVIRONMENTAL_MASTERY)) return "environmental_mastery_locked";
        UUID id = parseUuid(zoneId);
        if (id == null) return "zone_not_found";
        var result = EnvironmentZoneService.retuneMemory(record.state(), id, memoryId);
        return result.updated() ? "ok" : result.reason();
    }

    private String rename(DomainRecord record, String zoneId, String requestedName) {
        if (!record.state().hasFeature(DomainFeature.ENVIRONMENTAL_MASTERY)) return "environmental_mastery_locked";
        UUID id = parseUuid(zoneId);
        if (id == null) return "zone_not_found";
        String name = requestedName == null ? "" : requestedName.trim();
        if (name.length() > MAX_ZONE_NAME_LENGTH) name = name.substring(0, MAX_ZONE_NAME_LENGTH).trim();
        var result = EnvironmentZoneService.rename(record.state(), id, name);
        return result.updated() ? "ok" : result.reason();
    }

    private void send(ServerPlayer player, MemoryManagementSnapshotPayload.View view, String reason) {
        DomainRecord record = ownerRecordInCurrentDomain(player);
        if (record == null) {
            PacketDistributor.sendToPlayer(player, MemoryManagementSnapshotPayload.denied(view, "not_owner_domain"));
            return;
        }
        List<MemoryManagementSnapshotPayload.MemoryEntry> memories = runtime.memories().all().stream()
                .sorted(Comparator.comparing(MemoryDefinition::displayName, String.CASE_INSENSITIVE_ORDER)
                        .thenComparing(MemoryDefinition::id))
                .limit(MemoryManagementSnapshotPayload.MAX_MEMORIES)
                .map(definition -> new MemoryManagementSnapshotPayload.MemoryEntry(
                        definition.id(),
                        definition.displayName(),
                        record.state().unlockedMemoryIds().contains(definition.id()),
                        record.memoryProgress().activeOrreryMemoryIds().contains(definition.id()),
                        record.state().unlockedMemoryIds().containsAll(definition.prerequisites()),
                        definition.tags().stream().sorted().limit(MemoryManagementSnapshotPayload.MAX_TAGS).toList(),
                        captureSummary(definition.captureConditions())))
                .toList();

        List<MemoryManagementSnapshotPayload.ZoneEntry> zones = record.state().environmentZones().stream()
                .sorted(Comparator.comparingInt(dev.futurae.veilbound.environment.EnvironmentZone::priority).reversed()
                        .thenComparing(dev.futurae.veilbound.environment.EnvironmentZone::name, String.CASE_INSENSITIVE_ORDER))
                .limit(MemoryManagementSnapshotPayload.MAX_ZONES)
                .map(zone -> new MemoryManagementSnapshotPayload.ZoneEntry(
                        zone.id().toString(), zone.name(), zone.memoryProfileId(),
                        runtime.memories().get(zone.memoryProfileId()).map(MemoryDefinition::displayName).orElse(zone.memoryProfileId()),
                        zone.bounds().minX(), zone.bounds().minY(), zone.bounds().minZ(),
                        zone.bounds().maxX(), zone.bounds().maxY(), zone.bounds().maxZ(),
                        zone.priority(), zone.blendWithLowerPriority()))
                .toList();

        PacketDistributor.sendToPlayer(player, new MemoryManagementSnapshotPayload(
                view, true, reason == null ? "ok" : reason,
                record.state().hasFeature(DomainFeature.ENVIRONMENTAL_MASTERY), memories, zones));
    }

    private DomainRecord ownerRecordInCurrentDomain(ServerPlayer player) {
        DomainRecord record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null) return null;
        return record.identity().dimensionId().equals(player.level().dimension().identifier().toString()) ? record : null;
    }

    private static MemoryManagementSnapshotPayload.View viewFor(MemoryManagementActionPayload.Action action) {
        return switch (action) {
            case OPEN_ARCHIVE -> MemoryManagementSnapshotPayload.View.ARCHIVE;
            case OPEN_ORRERY, TOGGLE_ORRERY_MEMORY, CLEAR_ORRERY -> MemoryManagementSnapshotPayload.View.ORRERY;
            default -> MemoryManagementSnapshotPayload.View.ZONES;
        };
    }

    private static String captureSummary(Map<String, String> conditions) {
        if (conditions == null || conditions.isEmpty()) return "No automatic capture conditions";
        List<String> parts = new ArrayList<>();
        conditions.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(entry ->
                parts.add(entry.getKey().replace('_', ' ') + "=" + entry.getValue()));
        return String.join(" • ", parts);
    }

    private static UUID parseUuid(String raw) {
        try { return UUID.fromString(raw); }
        catch (IllegalArgumentException | NullPointerException ignored) { return null; }
    }
}
