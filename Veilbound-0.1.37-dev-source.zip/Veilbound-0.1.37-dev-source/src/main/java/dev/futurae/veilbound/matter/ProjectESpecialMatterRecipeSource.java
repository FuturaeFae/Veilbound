package dev.futurae.veilbound.matter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Loader-neutral copies of ProjectE's vanilla conversions that are not ordinary recipe-manager
 * recipes (world interactions, fluid filling, mob/environment transformations, and a few legacy
 * equivalences). The values themselves still come from the normal fixed-point Matter graph.
 *
 * <p>This intentionally models the ProjectE 1.1.0 / Minecraft 1.21.1 generated defaults without
 * depending on ProjectE at runtime. Normal crafting/smelting recipes are supplied separately by
 * the NeoForge recipe adapter.</p>
 */
public final class ProjectESpecialMatterRecipeSource implements MatterRecipeSource {
    public static final ProjectESpecialMatterRecipeSource INSTANCE = new ProjectESpecialMatterRecipeSource();
    private final List<RecipeMatterModel> recipes = build();

    private ProjectESpecialMatterRecipeSource() {}

    @Override
    public Collection<RecipeMatterModel> normalizedRecipes() {
        return recipes;
    }

    private static List<RecipeMatterModel> build() {
        List<RecipeMatterModel> r = new ArrayList<>();

        // World conversion / growth equivalences.
        add(r, "grass_block", 1, "minecraft:grass_block", i("minecraft:dirt", 2));
        add(r, "podzol", 1, "minecraft:podzol", i("minecraft:dirt", 2));
        add(r, "rooted_dirt", 1, "minecraft:rooted_dirt", i("minecraft:dirt"), i("minecraft:hanging_roots"));
        add(r, "mycelium", 1, "minecraft:mycelium", i("minecraft:dirt", 2));
        add(r, "crimson_nylium", 1, "minecraft:crimson_nylium", i("minecraft:netherrack", 2));
        add(r, "warped_nylium", 1, "minecraft:warped_nylium", i("minecraft:netherrack", 2));
        for (String input : List.of("minecraft:grass_block", "minecraft:dirt", "minecraft:podzol",
                "minecraft:coarse_dirt", "minecraft:mycelium", "minecraft:rooted_dirt")) {
            add(r, "dirt_path_from_" + path(input), 1, "minecraft:dirt_path", i(input));
        }

        // Armor/world conversions ProjectE explicitly supplies because vanilla has no recipes.
        add(r, "iron_horse_armor", 1, "minecraft:iron_horse_armor", i("minecraft:iron_ingot", 8));
        add(r, "golden_horse_armor", 1, "minecraft:golden_horse_armor", i("minecraft:gold_ingot", 8));
        add(r, "diamond_horse_armor", 1, "minecraft:diamond_horse_armor", i("minecraft:diamond", 8));
        add(r, "carved_pumpkin", 1, "minecraft:carved_pumpkin", i("minecraft:pumpkin"));
        add(r, "torchflower_seeds", 1, "minecraft:torchflower_seeds", i("minecraft:torchflower"));
        add(r, "pitcher_pod", 1, "minecraft:pitcher_pod", i("minecraft:pitcher_plant"));
        add(r, "written_book", 1, "minecraft:written_book", i("minecraft:writable_book"));
        add(r, "enchanted_book", 1, "minecraft:enchanted_book", i("minecraft:book"));
        add(r, "enchanted_golden_apple", 1, "minecraft:enchanted_golden_apple",
                i("minecraft:apple"), i("minecraft:gold_block", 8));
        add(r, "stripped_bamboo_block", 1, "minecraft:stripped_bamboo_block", i("minecraft:bamboo_block"));
        add(r, "globe_banner_pattern", 1, "minecraft:globe_banner_pattern", i("minecraft:emerald", 3));
        addWithReturns(r, "skull_banner_pattern", 3, "minecraft:skull_banner_pattern",
                List.of(i("minecraft:paper", 3), i("minecraft:nether_star")),
                List.of(o("minecraft:soul_sand", 4)));
        add(r, "firework_star", 1, "minecraft:firework_star", i("minecraft:gunpowder"));
        add(r, "firework_rocket", 1, "minecraft:firework_rocket", i("minecraft:paper"), i("minecraft:gunpowder"));
        add(r, "suspicious_gravel", 1, "minecraft:suspicious_gravel", i("minecraft:gravel"));
        add(r, "suspicious_sand", 1, "minecraft:suspicious_sand", i("minecraft:sand"));
        add(r, "wet_sponge", 1, "minecraft:wet_sponge", i("minecraft:sponge"));
        add(r, "bell", 1, "minecraft:bell", i("minecraft:gold_ingot", 7));
        add(r, "honeycomb", 3, "minecraft:honeycomb", i("minecraft:honey_bottle"));
        add(r, "powder_snow_bucket", 1, "minecraft:powder_snow_bucket",
                i("minecraft:bucket"), i("minecraft:snow_block", 4));
        add(r, "glow_ink_sac", 1, "minecraft:glow_ink_sac", i("minecraft:ink_sac"), i("minecraft:glowstone_dust"));
        add(r, "hanging_roots", 1, "minecraft:hanging_roots", i("minecraft:stick"));
        add(r, "suspicious_stew", 1, "minecraft:suspicious_stew",
                i("minecraft:bowl"), i("minecraft:brown_mushroom"), i("minecraft:red_mushroom"), i("minecraft:dandelion"));

        // Filled containers and ProjectE's virtual one-EMC constant/fluid conversions.
        add(r, "water_bucket", 1, "minecraft:water_bucket", i("minecraft:bucket"), i("projecte:fluid/water_bucket_content"));
        add(r, "lava_bucket", 1, "minecraft:lava_bucket", i("minecraft:bucket"), i("projecte:fluid/lava_bucket_content"));
        add(r, "milk_bucket", 1, "minecraft:milk_bucket", i("minecraft:bucket"), i("projecte:fluid/milk_bucket_content"));
        for (String fish : List.of("pufferfish", "salmon", "cod", "tropical_fish")) {
            add(r, fish + "_bucket", 1, "minecraft:" + fish + "_bucket",
                    i("minecraft:water_bucket"), i("minecraft:" + fish));
        }
        add(r, "dragon_breath", 1, "minecraft:dragon_breath",
                i("minecraft:glass_bottle"), i("projecte:fake/single_emc"));

        add(r, "soul_soil", 1, "minecraft:soul_soil", i("minecraft:soul_sand"));
        add(r, "warped_wart_block", 1, "minecraft:warped_wart_block", i("minecraft:nether_wart_block"));
        // c:mushrooms contains multiple valid ProjectE alternatives; the two 32-EMC vanilla
        // mushrooms give the same cheapest result without overvaluing the output.
        r.add(new RecipeMatterModel("projecte:shroomlight", "projecte:special",
                List.of(slot("minecraft:glowstone_dust"), alternatives("minecraft:red_mushroom", "minecraft:brown_mushroom")),
                o("minecraft:shroomlight", 1), List.of()));
        for (String color : List.of("ochre", "pearlescent", "verdant")) {
            add(r, color + "_froglight", 3, "minecraft:" + color + "_froglight", i("minecraft:magma_cream"));
        }
        add(r, "sculk", 1, "minecraft:sculk", i("minecraft:sculk_vein", 4));
        add(r, "sculk_sensor", 1, "minecraft:sculk_sensor",
                i("minecraft:comparator", 4), i("minecraft:repeater", 4), i("minecraft:sculk"));
        add(r, "sculk_shrieker", 1, "minecraft:sculk_shrieker", i("minecraft:sculk_catalyst", 4));

        // Chainmail is explicitly pegged to the equivalent iron armor in ProjectE.
        for (String part : List.of("helmet", "chestplate", "leggings", "boots")) {
            add(r, "chainmail_" + part, 1, "minecraft:chainmail_" + part, i("minecraft:iron_" + part));
        }

        // Concrete hydration is value-neutral in ProjectE.
        for (String color : List.of("white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray",
                "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black")) {
            add(r, color + "_concrete", 1, "minecraft:" + color + "_concrete", i("minecraft:" + color + "_concrete_powder"));
        }

        // ProjectE models an anvil surviving an average number of uses before each damage stage.
        add(r, "chipped_anvil", 25, "minecraft:chipped_anvil", i("minecraft:anvil", 16));
        add(r, "damaged_anvil", 25, "minecraft:damaged_anvil", i("minecraft:anvil", 7));

        return List.copyOf(r);
    }

    private static void add(List<RecipeMatterModel> out, String id, int count, String output, ItemAmountSpec... inputs) {
        List<RecipeMatterModel.IngredientSlot> slots = new ArrayList<>();
        for (ItemAmountSpec input : inputs) slots.add(slot(input.itemId(), input.count()));
        out.add(new RecipeMatterModel("projecte:" + id, "projecte:special", slots, o(output, count), List.of()));
    }

    private static void addWithReturns(List<RecipeMatterModel> out, String id, int count, String output,
            List<ItemAmountSpec> inputs, List<RecipeMatterModel.OutputStack> returned) {
        List<RecipeMatterModel.IngredientSlot> slots = new ArrayList<>();
        for (ItemAmountSpec input : inputs) slots.add(slot(input.itemId(), input.count()));
        out.add(new RecipeMatterModel("projecte:" + id, "projecte:special", slots, o(output, count), returned));
    }

    private static ItemAmountSpec i(String itemId) { return new ItemAmountSpec(itemId, 1); }
    private static ItemAmountSpec i(String itemId, int count) { return new ItemAmountSpec(itemId, count); }
    private static RecipeMatterModel.OutputStack o(String itemId, int count) { return new RecipeMatterModel.OutputStack(itemId, count); }
    private static RecipeMatterModel.IngredientSlot slot(String itemId) { return slot(itemId, 1); }
    private static RecipeMatterModel.IngredientSlot slot(String itemId, int count) {
        return new RecipeMatterModel.IngredientSlot(List.of(new RecipeMatterModel.ItemAmount(itemId, count)));
    }
    private static RecipeMatterModel.IngredientSlot alternatives(String... ids) {
        List<RecipeMatterModel.ItemAmount> values = new ArrayList<>();
        for (String id : ids) values.add(new RecipeMatterModel.ItemAmount(id, 1));
        return new RecipeMatterModel.IngredientSlot(values);
    }
    private static String path(String id) { return id.substring(id.indexOf(':') + 1); }
    private record ItemAmountSpec(String itemId, int count) {}
}
