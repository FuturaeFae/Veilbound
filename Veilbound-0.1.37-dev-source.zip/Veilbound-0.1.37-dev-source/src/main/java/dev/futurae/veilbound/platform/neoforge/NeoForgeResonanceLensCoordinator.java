package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.registry.VeilboundItems;
import dev.futurae.veilbound.upgrade.CoreTierUpgradeService;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import dev.futurae.veilbound.stability.StabilityCalculator;
import java.util.Objects;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/** Compact in-world diagnostics for the owner's Domain; intentionally not a management GUI. */
public final class NeoForgeResonanceLensCoordinator {
    private final VeilboundRuntime runtime;

    public NeoForgeResonanceLensCoordinator(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    public void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getLevel().isClientSide()) return;
        if (!event.getItemStack().is(VeilboundItems.RESONANCE_LENS.get())) return;
        // Sneak-use is reserved for temporary Environmental Zone editing.
        if (player.isShiftKeyDown()) return;

        DomainRecord record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null) {
            player.displayClientMessage(Component.translatable("message.veilbound.lens.no_domain"), false);
            consume(event, InteractionResult.FAIL);
            return;
        }
        var state = record.state();
        if (!state.coreActive()) {
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.lens.pre_core",
                    state.bounds().sizeX(), state.bounds().sizeY(), state.bounds().sizeZ(),
                    dev.futurae.veilbound.precore.SpatialGeneratorPlanner.MAX_AXIS_SPAN), false);
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.lens.awakening",
                    runtime.spatialGeneratorPolicy().policy().awakeningChargeRequirement()), false);
            consume(event, InteractionResult.SUCCESS);
            return;
        }
        int activePylons = (int) state.pylons().values().stream()
                .filter(pylon -> pylon.online() && pylon.expansionEnabled())
                .count();
        long openBreaches = state.breaches().stream().filter(dev.futurae.veilbound.breach.Breach::open).count();
        player.displayClientMessage(Component.translatable(
                "message.veilbound.lens.domain_status",
                state.bounds().sizeX(), state.bounds().sizeY(), state.bounds().sizeZ(),
                state.coreTier().name(), state.dimensionalEnergy(), state.coreTier().dimensionalEnergyCapacity(),
                record.matterTransmutation().storedMatter(), state.unlockedMemoryIds().size(), activePylons, openBreaches), false);

        if (state.coreActive()) {
            var policy = runtime.stabilityPolicy().policy();
            var stability = StabilityCalculator.calculate(
                    state, runtime.thresholds().permanentCountForOwner(record.ownerId()),
                    state.continuityAnchors().size(), policy.forTier(state.coreTier()));
            int stabilityPercent = (int) Math.round(Math.max(0.0, Math.min(1.0, 1.0 - stability.loadRatio())) * 100.0);
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.lens.stability",
                    stabilityPercent, stability.band().name(), Math.round(stability.load()),
                    Math.round(stability.capacity()), Math.round(state.fractureMeter()),
                    state.continuityAnchors().size()), false);
        }

        player.displayClientMessage(Component.translatable(
                "message.veilbound.lens.core_controls",
                state.globalExpansionEnabled() ? "ON" : "PAUSED"), false);

        var milestoneDefinitions = runtime.milestones().all();
        if (!milestoneDefinitions.isEmpty()) {
            java.util.Set<String> registeredMilestoneIds = milestoneDefinitions.stream()
                    .map(definition -> definition.id())
                    .collect(java.util.stream.Collectors.toSet());
            int completed = (int) state.completedMilestoneIds().stream().filter(registeredMilestoneIds::contains).count();
            String next = milestoneDefinitions.stream()
                    .filter(definition -> !state.completedMilestoneIds().contains(definition.id()))
                    .filter(definition -> state.completedMilestoneIds().containsAll(definition.prerequisiteMilestoneIds()))
                    .map(definition -> definition.displayName())
                    .findFirst().orElse("All current milestones complete");
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.lens.milestones", completed, milestoneDefinitions.size(), next), false);
        }

        runtime.coreUpgrades().from(state.coreTier()).ifPresentOrElse(definition -> {
            var progress = new CoreTierUpgradeService().progress(state, definition);
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.lens.core_upgrade", definition.to().name(),
                    progress.fedItems(), progress.requiredItems(),
                    state.dimensionalEnergy(), definition.to().upgradeCostFromPrevious()), false);
        }, () -> {
            if (state.coreTier() != dev.futurae.veilbound.domain.CoreTier.TRANSCENDENT) {
                player.displayClientMessage(Component.translatable(
                        "message.veilbound.lens.core_upgrade_unconfigured", state.coreTier().name()), false);
            }
        });

        var active = record.memoryProgress().activeOrreryMemoryIds();
        if (!active.isEmpty()) {
            String names = active.stream()
                    .map(id -> runtime.memories().get(id).map(def -> def.displayName()).orElse(id))
                    .reduce((a, b) -> a + ", " + b)
                    .orElse("");
            player.displayClientMessage(Component.translatable("message.veilbound.lens.orrery", names), false);
        }

        var pos = player.blockPosition();
        var local = runtime.memoryEnvironment().resolveAt(
                state, record.memoryProgress(), runtime.memories(),
                new DomainPosition(pos.getX(), pos.getY(), pos.getZ()));
        if (!local.zoneName().isBlank()) {
            state.environmentZones().stream()
                    .filter(zone -> zone.name().equals(local.zoneName()))
                    .findFirst()
                    .ifPresent(zone -> player.displayClientMessage(Component.translatable(
                            "message.veilbound.lens.zone_current", zone.name(),
                            runtime.memories().get(zone.memoryProfileId()).map(def -> def.displayName()).orElse(zone.memoryProfileId()),
                            zone.priority(), zone.blendWithLowerPriority() ? "ON" : "OFF"), false));
        } else if (!state.environmentZones().isEmpty()) {
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.lens.zone_count", state.environmentZones().size()), false);
        }
        consume(event, InteractionResult.SUCCESS);
    }

    private static void consume(PlayerInteractEvent.RightClickItem event, InteractionResult result) {
        event.setCancellationResult(result);
        event.setCanceled(true);
    }
}
