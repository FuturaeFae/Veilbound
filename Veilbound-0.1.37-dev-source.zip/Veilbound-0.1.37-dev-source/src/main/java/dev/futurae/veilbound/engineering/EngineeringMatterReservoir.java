package dev.futurae.veilbound.engineering;

/** Machine-local fabrication Matter; deliberately separate from Veil Inventory Matter. */
public final class EngineeringMatterReservoir {
    private long stored;
    private final long capacity;
    public EngineeringMatterReservoir(long capacity) { if(capacity<=0) throw new IllegalArgumentException("capacity must be positive"); this.capacity=capacity; }
    public long stored(){return stored;} public long capacity(){return capacity;}
    public long insert(long amount){ if(amount<=0)return 0; long a=Math.min(amount,capacity-stored); stored+=a; return a; }
    public boolean consume(long amount){ if(amount<0)throw new IllegalArgumentException("amount"); if(stored<amount)return false; stored-=amount; return true; }
    public void setStored(long amount) { if (amount < 0 || amount > capacity) throw new IllegalArgumentException("stored outside capacity"); stored = amount; }
}
