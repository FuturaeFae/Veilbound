package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Owner-only requests from the Ontological Harvester/Compiler console. */
public record OntologyMachineActionPayload(Action action, int x, int y, int z, String value) implements CustomPacketPayload {
    public enum Action { REFRESH, SET_MODE }
    public static final Type<OntologyMachineActionPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "ontology_machine_action"));
    public static final StreamCodec<RegistryFriendlyByteBuf, OntologyMachineActionPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override public OntologyMachineActionPayload decode(RegistryFriendlyByteBuf b) {
            int ordinal=b.readVarInt(); Action[] values=Action.values();
            Action action=ordinal>=0&&ordinal<values.length?values[ordinal]:Action.REFRESH;
            return new OntologyMachineActionPayload(action,b.readInt(),b.readInt(),b.readInt(),b.readUtf(64));
        }
        @Override public void encode(RegistryFriendlyByteBuf b, OntologyMachineActionPayload p) {
            b.writeVarInt(p.action().ordinal()); b.writeInt(p.x()); b.writeInt(p.y()); b.writeInt(p.z()); b.writeUtf(p.value(),64);
        }
    };
    public OntologyMachineActionPayload { if(action==null)action=Action.REFRESH; if(value==null)value=""; }
    @Override public Type<? extends CustomPacketPayload> type(){ return TYPE; }
}
