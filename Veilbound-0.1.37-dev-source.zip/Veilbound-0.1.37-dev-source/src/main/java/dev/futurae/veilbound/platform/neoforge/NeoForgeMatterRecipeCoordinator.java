package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.matter.MatterDatapackSnapshot;
import dev.futurae.veilbound.matter.RecipeMatterInferenceEngine;
import dev.futurae.veilbound.matter.ProjectESpecialMatterRecipeSource;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.Objects;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.neoforged.neoforge.event.AddServerReloadListenersEvent;
import net.neoforged.neoforge.event.OnDatapackSyncEvent;
import net.neoforged.neoforge.resource.VanillaServerListeners;

/**
 * Owns the NeoForge reload boundary for Matter data.
 *
 * The resource listener stages exact datapack overrides during reload. Once NeoForge reports
 * the corresponding successful full datapack sync, this coordinator atomically replaces the
 * catalog's datapack layer and rebuilds recipe-derived values from the server's now-current
 * RecipeManager and tag-aware display context.
 *
 * Player-join sync events are ignored after the first initialization so large modpacks do not
 * recompute the entire recipe graph for every login.
 */
public final class NeoForgeMatterRecipeCoordinator {
    public static final Identifier OVERRIDE_LISTENER_ID =
            Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "matter_values");

    private final VeilboundRuntime runtime;
    private volatile MatterDatapackSnapshot stagedOverrides = MatterDatapackSnapshot.empty();
    private MatterDatapackSnapshot activeOverrides = MatterDatapackSnapshot.empty();
    private boolean initialized;
    private RecipeMatterInferenceEngine.InferenceReport lastReport;

    public NeoForgeMatterRecipeCoordinator(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    public void onAddReloadListeners(AddServerReloadListenersEvent event) {
        Objects.requireNonNull(event, "event");
        event.addListener(
                OVERRIDE_LISTENER_ID,
                new NeoForgeMatterOverrideReloadListener(snapshot -> stagedOverrides = snapshot));
        // The loader only parses our JSON, but keeping it after recipes makes the dependency
        // explicit and ensures its apply phase belongs to the same server-data generation.
        event.addDependency(VanillaServerListeners.RECIPES, OVERRIDE_LISTENER_ID);
    }

    public void onDatapackSync(OnDatapackSyncEvent event) {
        Objects.requireNonNull(event, "event");
        boolean fullReload = event.getPlayer() == null;
        if (!fullReload && initialized) return;

        MinecraftServer server = event.getPlayerList().getServer();
        // Rebuild ProjectE-compatible concrete/tag seeds after tags are fully reloaded so datapacks
        // that add members to common material tags inherit the same baseline EMC scale.
        NeoForgeProjectEMatterSeeder.rebuild(server, runtime.matter());
        MatterDatapackSnapshot nextOverrides = stagedOverrides;
        nextOverrides.applyTo(runtime.matter());
        activeOverrides = nextOverrides;

        for (String warning : nextOverrides.warnings()) {
            Veilbound.LOGGER.warn("{}", warning);
        }

        runtime.matterReload().clearRecipeSources();
        runtime.matterReload().addRecipeSource(ProjectESpecialMatterRecipeSource.INSTANCE);
        runtime.matterReload().addRecipeSource(
                new NeoForgeRecipeMatterSource(server.getRecipeManager(), server.overworld()));
        lastReport = runtime.matterReload().reload();
        initialized = true;

        Veilbound.LOGGER.info(
                "Matter catalog rebuilt: {} datapack overrides, {} inferred items, {} unresolved recipes",
                activeOverrides.values().size(),
                lastReport.inferredItemCount(),
                lastReport.unresolvedRecipeCount());
    }

    public boolean initialized() { return initialized; }
    public MatterDatapackSnapshot activeOverrides() { return activeOverrides; }
    public RecipeMatterInferenceEngine.InferenceReport lastReport() { return lastReport; }
}
