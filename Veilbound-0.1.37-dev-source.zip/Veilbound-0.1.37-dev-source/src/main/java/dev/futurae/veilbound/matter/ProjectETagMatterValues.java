package dev.futurae.veilbound.matter;

import java.util.LinkedHashMap;
import java.util.Map;

/** ProjectE mc1.21.1 tag seeds and metal equivalences, expanded by the NeoForge reload bridge. */
public final class ProjectETagMatterValues {
    private static final Map<String, Long> VALUES = build();
    private ProjectETagMatterValues() {}
    public static Map<String, Long> snapshot() { return Map.copyOf(VALUES); }

    private static Map<String, Long> build() {
        Map<String, Long> v = new LinkedHashMap<>();
        put(v, "minecraft:small_flowers", 16);
        put(v, "minecraft:tall_flowers", 32);
        put(v, "c:seeds/wheat", 16);
        put(v, "c:seeds/beetroot", 16);
        put(v, "c:crops/wheat", 24);
        put(v, "c:crops/nether_wart", 24);
        put(v, "c:pumpkins/normal", 144);
        put(v, "c:crops/carrot", 64);
        put(v, "c:crops/beetroot", 64);
        put(v, "c:crops/potato", 64);
        put(v, "c:rods/blaze", 1_536);
        put(v, "c:rods/breeze", 2_304);
        put(v, "minecraft:decorated_pot_sherds", 216);
        put(v, "minecraft:creeper_drop_music_discs", 2_048);
        put(v, "minecraft:logs", 32);
        put(v, "minecraft:planks", 8);
        put(v, "minecraft:saplings", 32);
        put(v, "c:rods/wooden", 4);
        put(v, "minecraft:leaves", 1);
        put(v, "minecraft:wool", 48);
        put(v, "c:gems/emerald", 16_384);
        put(v, "c:nether_stars", 139_264);
        put(v, "c:gems/diamond", 8_192);
        put(v, "c:dusts/redstone", 64);
        put(v, "c:dusts/glowstone", 384);
        put(v, "c:gems/quartz", 256);
        put(v, "c:ingots/iron", 256);
        put(v, "c:ingots/uranium", 4_096);
        put(v, "c:gems/amethyst", 32);
        put(v, "c:gems/ruby", 2_048);
        put(v, "c:gems/sapphire", 2_048);
        put(v, "c:gems/peridot", 2_048);

        // Exact values implied by ProjectE's generated metals.json conversions.
        put(v, "c:ingots/gold", 2_048);
        put(v, "c:ingots/copper", 128);
        put(v, "c:ingots/tin", 256);
        put(v, "c:ingots/bronze", 160);
        put(v, "c:ingots/silver", 512);
        put(v, "c:ingots/lead", 512);
        put(v, "c:ingots/osmium", 512);
        put(v, "c:ingots/nickel", 1_024);
        put(v, "c:ingots/aluminum", 128);
        put(v, "c:ingots/platinum", 4_096);
        put(v, "c:ingots/cyanite", 1_024);
        return v;
    }

    private static void put(Map<String, Long> values, String tag, long amount) {
        if (values.put(tag, amount) != null) throw new IllegalStateException("Duplicate ProjectE tag value: " + tag);
    }
}
