package dev.futurae.veilbound.ontology;

/** Machine-local Potential. Potential is neither FE nor Matter and is never stored by the Core. */
public final class PotentialReservoir {
    private long stored;
    private final long capacity;
    public PotentialReservoir(long capacity) {
        if (capacity <= 0) throw new IllegalArgumentException("capacity must be positive");
        this.capacity = capacity;
    }
    public long stored() { return stored; }
    public long capacity() { return capacity; }
    public long insert(long amount) {
        if (amount <= 0) return 0;
        long accepted = Math.min(amount, capacity - stored);
        stored += accepted;
        return accepted;
    }
    public boolean consume(long amount) {
        if (amount < 0) throw new IllegalArgumentException("amount must be >= 0");
        if (stored < amount) return false;
        stored -= amount;
        return true;
    }
    public void setStored(long amount) {
        if (amount < 0 || amount > capacity) throw new IllegalArgumentException("stored outside capacity");
        stored = amount;
    }
}
