package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.matter.DefaultMatterValues;
import dev.futurae.veilbound.matter.MatterCatalog;
import dev.futurae.veilbound.matter.ProjectETagMatterValues;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;

/** Expands ProjectE's tag-based EMC seeds against the live server item registry. */
public final class NeoForgeProjectEMatterSeeder {
    private NeoForgeProjectEMatterSeeder() {}

    public static int rebuild(MinecraftServer server, MatterCatalog catalog) {
        catalog.clearBuiltIn();
        DefaultMatterValues.installInto(catalog);
        var items = server.registryAccess().lookupOrThrow(Registries.ITEM);
        int assignments = 0;
        for (Map.Entry<String, Long> entry : ProjectETagMatterValues.snapshot().entrySet()) {
            Identifier id = Identifier.parse(entry.getKey());
            TagKey<Item> tag = TagKey.create(Registries.ITEM, id);
            var members = items.get(tag);
            if (members.isEmpty()) continue;
            for (var holder : members.get()) {
                catalog.putBuiltIn(
                        holder.key().identifier().toString(),
                        entry.getValue(),
                        "veilbound:projecte_tag/" + entry.getKey());
                assignments++;
            }
        }
        Veilbound.LOGGER.info(
                "Installed ProjectE-compatible Matter baseline: {} direct seed/constants, {} tag assignments",
                DefaultMatterValues.snapshot().size(), assignments);
        return assignments;
    }
}
