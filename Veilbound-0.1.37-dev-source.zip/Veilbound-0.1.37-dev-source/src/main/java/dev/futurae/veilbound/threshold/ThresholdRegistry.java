package dev.futurae.veilbound.threshold;

import dev.futurae.veilbound.domain.DomainPosition;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/** Owner-authoritative registry for permanent Thresholds. */
public final class ThresholdRegistry {
    private final Map<UUID, ThresholdDefinition> byId = new LinkedHashMap<>();
    /** Hot-path source-cell index used by portal touch/deactivation. */
    private final Map<SourceKey, UUID> bySourceCell = new LinkedHashMap<>();
    private Runnable mutationListener = () -> {};

    public void add(ThresholdDefinition definition) {
        Objects.requireNonNull(definition, "definition");
        if (byId.containsKey(definition.id())) {
            throw new IllegalArgumentException("Threshold id already exists: " + definition.id());
        }
        validateSourceCellsAvailable(definition);
        byId.put(definition.id(), definition);
        index(definition);
        attach(definition);
        changed();
    }

    public Optional<ThresholdDefinition> get(UUID id) { return Optional.ofNullable(byId.get(id)); }

    /** Resolve an active portal block back to its persistent Threshold binding in O(1). */
    public Optional<ThresholdDefinition> findAt(String dimensionId, DomainPosition position) {
        Objects.requireNonNull(dimensionId, "dimensionId");
        Objects.requireNonNull(position, "position");
        UUID id = bySourceCell.get(new SourceKey(dimensionId, position));
        return id == null ? Optional.empty() : Optional.ofNullable(byId.get(id));
    }

    public boolean remove(UUID id, UUID actorOwnerId, boolean actorIsAdministrator) {
        ThresholdDefinition existing = byId.get(id);
        if (existing == null) return false;
        if (!actorIsAdministrator && !existing.ownerId().equals(actorOwnerId)) return false;
        removeIndexed(existing);
        changed();
        return true;
    }

    /** Internal lifecycle removal after a platform-level deactivation transaction has completed. */
    public boolean removeSystem(UUID id) {
        Objects.requireNonNull(id, "id");
        ThresholdDefinition existing = byId.get(id);
        if (existing == null) return false;
        removeIndexed(existing);
        changed();
        return true;
    }

    public List<ThresholdDefinition> forOwner(UUID ownerId) {
        List<ThresholdDefinition> result = new ArrayList<>();
        for (ThresholdDefinition definition : byId.values()) {
            if (definition.ownerId().equals(ownerId)) result.add(definition);
        }
        return List.copyOf(result);
    }

    public int permanentCountForOwner(UUID ownerId) { return forOwner(ownerId).size(); }
    public List<ThresholdDefinition> all() { return List.copyOf(byId.values()); }

    public void replaceFromPersistence(Collection<ThresholdDefinition> definitions) {
        Objects.requireNonNull(definitions, "definitions");
        Map<UUID, ThresholdDefinition> rebuiltById = new LinkedHashMap<>();
        Map<SourceKey, UUID> rebuiltBySource = new LinkedHashMap<>();

        for (ThresholdDefinition definition : definitions) {
            if (rebuiltById.put(definition.id(), definition) != null) {
                throw new IllegalArgumentException("Duplicate Threshold id in persistence: " + definition.id());
            }
            for (DomainPosition source : definition.sourcePositions()) {
                SourceKey key = new SourceKey(definition.sourceDimensionId(), source);
                UUID conflicting = rebuiltBySource.putIfAbsent(key, definition.id());
                if (conflicting != null && !conflicting.equals(definition.id())) {
                    throw new IllegalArgumentException(
                            "Overlapping persisted Threshold source cell " + key + " between " + conflicting + " and " + definition.id());
                }
            }
        }

        byId.clear();
        bySourceCell.clear();
        byId.putAll(rebuiltById);
        bySourceCell.putAll(rebuiltBySource);
        for (ThresholdDefinition definition : byId.values()) attach(definition);
    }

    public void setMutationListener(Runnable listener) {
        mutationListener = Objects.requireNonNull(listener, "listener");
        for (ThresholdDefinition definition : byId.values()) attach(definition);
    }

    private void validateSourceCellsAvailable(ThresholdDefinition definition) {
        for (DomainPosition source : definition.sourcePositions()) {
            SourceKey key = new SourceKey(definition.sourceDimensionId(), source);
            UUID existing = bySourceCell.get(key);
            if (existing != null) {
                throw new IllegalArgumentException(
                        "Threshold source cell already belongs to " + existing + ": " + key);
            }
        }
    }

    private void index(ThresholdDefinition definition) {
        for (DomainPosition source : definition.sourcePositions()) {
            bySourceCell.put(new SourceKey(definition.sourceDimensionId(), source), definition.id());
        }
    }

    private void removeIndexed(ThresholdDefinition definition) {
        byId.remove(definition.id());
        for (DomainPosition source : definition.sourcePositions()) {
            SourceKey key = new SourceKey(definition.sourceDimensionId(), source);
            bySourceCell.remove(key, definition.id());
        }
    }

    private void attach(ThresholdDefinition definition) { definition.access().setMutationListener(this::changed); }
    private void changed() { mutationListener.run(); }

    private record SourceKey(String dimensionId, DomainPosition position) {
        private SourceKey {
            Objects.requireNonNull(dimensionId, "dimensionId");
            Objects.requireNonNull(position, "position");
        }
    }
}
