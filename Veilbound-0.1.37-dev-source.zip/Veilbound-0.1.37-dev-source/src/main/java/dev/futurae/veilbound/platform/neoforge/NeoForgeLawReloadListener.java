package dev.futurae.veilbound.platform.neoforge;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.law.LawDefinition;
import dev.futurae.veilbound.law.LawRegistry;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

/** Loads data/<namespace>/veilbound/laws/<path>.json into the runtime Law registry. */
public final class NeoForgeLawReloadListener
        extends SimplePreparableReloadListener<DatapackDefinitionSnapshot<LawDefinition>> {
    public static final Identifier LISTENER_ID = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "laws");
    public static final String DIRECTORY = "veilbound/laws";

    private final Gson gson = new Gson();
    private final LawRegistry registry;

    public NeoForgeLawReloadListener(LawRegistry registry) {
        this.registry = Objects.requireNonNull(registry, "registry");
    }

    @Override
    protected DatapackDefinitionSnapshot<LawDefinition> prepare(ResourceManager resourceManager, ProfilerFiller profiler) {
        List<LawDefinition> definitions = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        List<Map.Entry<Identifier, Resource>> resources = resourceManager
                .listResources(DIRECTORY, id -> id.getPath().endsWith(".json"))
                .entrySet().stream()
                .sorted(Map.Entry.comparingByKey(Comparator.comparing(Identifier::toString)))
                .toList();

        for (Map.Entry<Identifier, Resource> entry : resources) {
            Identifier resourceId = entry.getKey();
            String id = NeoForgeDefinitionJson.idFromResource(resourceId, DIRECTORY);
            if (id == null) {
                warnings.add("Ignored malformed Law path: " + resourceId);
                continue;
            }
            try (Reader reader = entry.getValue().openAsReader()) {
                JsonObject object = NeoForgeDefinitionJson.requireObject(gson.fromJson(reader, JsonElement.class));
                definitions.add(new LawDefinition(
                        id,
                        NeoForgeDefinitionJson.requiredString(object, "display_name"),
                        NeoForgeDefinitionJson.optionalNonNegativeInt(object, "progression_weight", 0),
                        NeoForgeDefinitionJson.optionalStringSet(object, "prerequisites"),
                        NeoForgeDefinitionJson.optionalStringSet(object, "incompatible_laws"),
                        NeoForgeDefinitionJson.optionalStringSet(object, "effects"),
                        NeoForgeDefinitionJson.optionalString(object, "axiom_item", "")));
            } catch (IOException | JsonParseException | IllegalArgumentException ex) {
                warnings.add("Ignored Law " + resourceId + ": " + ex.getMessage());
            }
        }
        return new DatapackDefinitionSnapshot<>(definitions, warnings);
    }

    @Override
    protected void apply(DatapackDefinitionSnapshot<LawDefinition> snapshot, ResourceManager manager, ProfilerFiller profiler) {
        registry.replaceAll(snapshot.definitions());
        snapshot.warnings().forEach(warning -> Veilbound.LOGGER.warn("{}", warning));
        Veilbound.LOGGER.info("Loaded {} Veilbound Laws", snapshot.definitions().size());
    }
}
