package dev.futurae.veilbound.breach;

import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import dev.futurae.veilbound.stability.StabilityBand;
import dev.futurae.veilbound.stability.StabilitySnapshot;
import java.util.Objects;
import java.util.UUID;
import java.util.random.RandomGenerator;

/** Persistent fracture-meter evolution and deterministic breach formation rules. */
public final class BreachRuntimeService {
    private BreachRuntimeService() {}

    public static Evaluation evaluate(
            DomainState state,
            StabilitySnapshot stability,
            BreachRuntimePolicy policy,
            long gameTick,
            RandomGenerator random) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(stability, "stability");
        Objects.requireNonNull(policy, "policy");
        Objects.requireNonNull(random, "random");
        if (gameTick < 0) throw new IllegalArgumentException("gameTick must be >= 0");
        if (!state.coreActive()) return new Evaluation(state.fractureMeter(), null, "core_inactive");

        double next = clamp(
                state.fractureMeter() + policy.fractureDelta(stability.band()),
                0.0,
                policy.maximumFractureMeter());
        state.setFractureMeter(next);

        if (next < policy.fractureThreshold()) return new Evaluation(next, null, "meter_below_threshold");
        long openBreaches = state.breaches().stream().filter(Breach::open).count();
        if (openBreaches >= policy.maxOpenBreaches()) return new Evaluation(next, null, "open_breach_cap");
        if (stability.band() == StabilityBand.STABLE) return new Evaluation(next, null, "stable_no_breach");

        AxisDirection face = AxisDirection.values()[random.nextInt(AxisDirection.values().length)];
        DomainPosition position = randomFacePosition(state.bounds(), face, random);
        BreachSeverity severity = switch (stability.band()) {
            case STABLE, STRAINED -> BreachSeverity.MINOR;
            case CRITICAL -> BreachSeverity.SEVERE;
            case RUPTURING -> BreachSeverity.EXTREME;
        };
        Breach breach = new Breach(new UUID(random.nextLong(), random.nextLong()), position, face, severity, true, gameTick);
        state.addBreach(breach);
        double remaining = Math.max(0.0, state.fractureMeter() - policy.fractureThreshold());
        state.setFractureMeter(remaining);
        return new Evaluation(remaining, breach, "breach_formed");
    }

    static DomainPosition randomFacePosition(DomainBounds bounds, AxisDirection face, RandomGenerator random) {
        int x = between(random, bounds.minX(), bounds.maxX());
        int y = between(random, bounds.minY(), bounds.maxY());
        int z = between(random, bounds.minZ(), bounds.maxZ());
        return switch (face) {
            case POSITIVE_X -> new DomainPosition(bounds.maxX(), y, z);
            case NEGATIVE_X -> new DomainPosition(bounds.minX(), y, z);
            case POSITIVE_Y -> new DomainPosition(x, bounds.maxY(), z);
            case NEGATIVE_Y -> new DomainPosition(x, bounds.minY(), z);
            case POSITIVE_Z -> new DomainPosition(x, y, bounds.maxZ());
            case NEGATIVE_Z -> new DomainPosition(x, y, bounds.minZ());
        };
    }

    private static int between(RandomGenerator random, int min, int max) {
        if (min == max) return min;
        long span = (long) max - (long) min + 1L;
        return (int) ((long) min + random.nextLong(span));
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    public record Evaluation(double fractureMeter, Breach formedBreach, String reason) {
        public boolean hasFormedBreach() { return formedBreach != null; }
    }
}
