package dev.futurae.veilbound.environment;

import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import dev.futurae.veilbound.memory.MemoryDefinition;
import dev.futurae.veilbound.memory.MemoryRegistry;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** Resolves named overlapping Environmental Zones without mutating Domain state. */
public final class EnvironmentZoneResolver {
    private static final Comparator<EnvironmentZone> ORDER = Comparator
            .comparingInt(EnvironmentZone::priority).reversed()
            .thenComparing(EnvironmentZone::name)
            .thenComparing(zone -> zone.id().toString());

    public Resolution resolve(
            DomainState state,
            DomainPosition position,
            MemoryRegistry registry,
            Map<String, String> baseProfile,
            List<String> baseMemoryIds) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(position, "position");
        Objects.requireNonNull(registry, "registry");
        Objects.requireNonNull(baseProfile, "baseProfile");
        Objects.requireNonNull(baseMemoryIds, "baseMemoryIds");

        List<EnvironmentZone> candidates = state.environmentZones().stream()
                .filter(zone -> zone.bounds().contains(position))
                .sorted(ORDER)
                .toList();
        if (candidates.isEmpty()) return Resolution.base(baseMemoryIds, baseProfile);

        EnvironmentZone primary = firstUsable(candidates, state, registry);
        if (primary == null) return Resolution.base(baseMemoryIds, baseProfile);
        MemoryDefinition primaryMemory = registry.get(primary.memoryProfileId()).orElseThrow();

        LinkedHashMap<String, String> profile = new LinkedHashMap<>(primaryMemory.environmentalProfile());
        LinkedHashSet<String> memoryIds = new LinkedHashSet<>();
        memoryIds.add(primaryMemory.id());
        List<String> contributingZones = new ArrayList<>();
        contributingZones.add(primary.name());

        if (primary.blendWithLowerPriority()) {
            boolean afterPrimary = false;
            for (EnvironmentZone zone : candidates) {
                if (!afterPrimary) {
                    if (zone.id().equals(primary.id())) afterPrimary = true;
                    continue;
                }
                MemoryDefinition memory = usableMemory(zone, state, registry);
                if (memory == null) continue;
                mergeLowerPriority(profile, memory.environmentalProfile());
                memoryIds.add(memory.id());
                contributingZones.add(zone.name());
            }
            // The global Orrery is the lowest-priority substrate: fill holes, never override zones.
            mergeLowerPriority(profile, baseProfile);
            memoryIds.addAll(baseMemoryIds);
        }

        return new Resolution(
                true, primary.id().toString(), primary.name(), primary.priority(), primary.blendWithLowerPriority(),
                List.copyOf(contributingZones), List.copyOf(memoryIds), Map.copyOf(profile));
    }

    private static EnvironmentZone firstUsable(
            List<EnvironmentZone> candidates, DomainState state, MemoryRegistry registry) {
        for (EnvironmentZone zone : candidates) {
            if (usableMemory(zone, state, registry) != null) return zone;
        }
        return null;
    }

    private static MemoryDefinition usableMemory(
            EnvironmentZone zone, DomainState state, MemoryRegistry registry) {
        if (!state.unlockedMemoryIds().contains(zone.memoryProfileId())) return null;
        return registry.get(zone.memoryProfileId()).orElse(null);
    }

    /** Higher-priority values win. Lower-priority profiles can only contribute unclaimed keys. */
    private static void mergeLowerPriority(Map<String, String> target, Map<String, String> lower) {
        lower.forEach(target::putIfAbsent);
    }

    public record Resolution(
            boolean zoned,
            String primaryZoneId,
            String primaryZoneName,
            int priority,
            boolean blending,
            List<String> contributingZoneNames,
            List<String> memoryIds,
            Map<String, String> environmentalProfile) {
        public Resolution {
            contributingZoneNames = List.copyOf(contributingZoneNames);
            memoryIds = List.copyOf(memoryIds);
            environmentalProfile = Map.copyOf(environmentalProfile);
        }

        public static Resolution base(List<String> memoryIds, Map<String, String> profile) {
            return new Resolution(false, "", "", Integer.MIN_VALUE, false, List.of(), memoryIds, profile);
        }
    }
}
