package dev.futurae.veilbound.memory;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Durable per-Domain Orrery selection plus the legacy v7-v10 pending-capture field.
 * New Mnemonic Vessel captures live on the actual item stack; capturedMemoryId exists only so old saves can migrate losslessly.
 */
public final class MemoryProgressState {
    private String capturedMemoryId;
    private final LinkedHashSet<String> activeOrreryMemoryIds = new LinkedHashSet<>();
    private Runnable mutationListener = () -> {};

    public Optional<String> capturedMemoryId() { return Optional.ofNullable(capturedMemoryId); }
    public List<String> activeOrreryMemoryIds() { return List.copyOf(activeOrreryMemoryIds); }
    public boolean vesselOccupied() { return capturedMemoryId != null; }

    public CaptureResult capture(String memoryId) {
        Objects.requireNonNull(memoryId, "memoryId");
        if (capturedMemoryId != null) return CaptureResult.denied("vessel_occupied");
        capturedMemoryId = memoryId;
        changed();
        return CaptureResult.allowed(memoryId);
    }

    public Optional<String> clearCapturedMemory() {
        if (capturedMemoryId == null) return Optional.empty();
        String previous = capturedMemoryId;
        capturedMemoryId = null;
        changed();
        return Optional.of(previous);
    }

    public void restoreCapturedMemory(String memoryId) {
        capturedMemoryId = memoryId == null || memoryId.isBlank() ? null : memoryId;
    }

    public void setActiveOrreryMemoryIds(Collection<String> memoryIds) {
        Objects.requireNonNull(memoryIds, "memoryIds");
        LinkedHashSet<String> replacement = new LinkedHashSet<>();
        for (String id : memoryIds) replacement.add(Objects.requireNonNull(id, "memoryId"));
        if (!activeOrreryMemoryIds.equals(replacement)) {
            activeOrreryMemoryIds.clear();
            activeOrreryMemoryIds.addAll(replacement);
            changed();
        }
    }

    public void clearActiveOrreryMemories() { setActiveOrreryMemoryIds(List.of()); }

    public void setMutationListener(Runnable listener) { this.mutationListener = Objects.requireNonNull(listener, "listener"); }
    private void changed() { mutationListener.run(); }

    public record CaptureResult(boolean captured, String memoryId, String reason) {
        public static CaptureResult denied(String reason) { return new CaptureResult(false, null, reason); }
        public static CaptureResult allowed(String memoryId) { return new CaptureResult(true, memoryId, "ok"); }
    }
}
