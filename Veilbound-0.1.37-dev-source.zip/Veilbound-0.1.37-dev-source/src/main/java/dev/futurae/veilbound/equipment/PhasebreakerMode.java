package dev.futurae.veilbound.equipment;

/** Persisted Phasebreaker operating mode. Advanced modes are intentionally bounded for server safety. */
public enum PhasebreakerMode {
    NORMAL(0, 0, 0),
    VEIN(1, 16, 25),
    PLANE(2, 8, 50),
    PHASE(3, 4, 100);
    private final int id, maxExtraBlocks;
    private final long dePerExtraBlock;
    PhasebreakerMode(int id,int maxExtraBlocks,long dePerExtraBlock){this.id=id;this.maxExtraBlocks=maxExtraBlocks;this.dePerExtraBlock=dePerExtraBlock;}
    public int id(){return id;} public int maxExtraBlocks(){return maxExtraBlocks;} public long dePerExtraBlock(){return dePerExtraBlock;}
    public PhasebreakerMode next(){PhasebreakerMode[] v=values();return v[(ordinal()+1)%v.length];}
    public static PhasebreakerMode fromId(int id){for(var mode:values())if(mode.id==id)return mode;return NORMAL;}
}
