package dev.futurae.veilbound.milestone;

import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainState;
import java.util.Objects;
import java.util.Set;

/** Loader-neutral, datapack-friendly facts that can complete a progression milestone. */
public record MilestoneCriteria(
        boolean coreActive,
        CoreTier minimumCoreTier,
        int minimumArchivedMemories,
        int minimumBoundPylons,
        int minimumEnvironmentZones,
        int minimumPermanentThresholds,
        int minimumImposedLaws,
        int minimumSizeX,
        int minimumSizeY,
        int minimumSizeZ,
        boolean sovereigntyUnlocked,
        Set<DomainFeature> requiredFeatures) {

    public static final MilestoneCriteria NONE = new MilestoneCriteria(
            false, null, 0, 0, 0, 0, 0, 0, 0, 0, false, Set.of());

    public MilestoneCriteria {
        if (minimumArchivedMemories < 0
                || minimumBoundPylons < 0
                || minimumEnvironmentZones < 0
                || minimumPermanentThresholds < 0
                || minimumImposedLaws < 0
                || minimumSizeX < 0
                || minimumSizeY < 0
                || minimumSizeZ < 0) {
            throw new IllegalArgumentException("Milestone criteria counts/sizes must be non-negative");
        }
        requiredFeatures = Set.copyOf(Objects.requireNonNull(requiredFeatures, "requiredFeatures"));
    }

    public boolean matches(DomainState state, int permanentThresholdCount) {
        Objects.requireNonNull(state, "state");
        if (permanentThresholdCount < 0) throw new IllegalArgumentException("permanentThresholdCount must be >= 0");
        if (coreActive && !state.coreActive()) return false;
        if (minimumCoreTier != null && (!state.coreActive() || state.coreTier().ordinal() < minimumCoreTier.ordinal())) return false;
        if (state.unlockedMemoryIds().size() < minimumArchivedMemories) return false;
        long boundPylons = state.pylons().values().stream()
                .filter(pylon -> pylon.online() && pylon.blockPosition() != null)
                .count();
        if (boundPylons < minimumBoundPylons) return false;
        if (state.environmentZones().size() < minimumEnvironmentZones) return false;
        if (permanentThresholdCount < minimumPermanentThresholds) return false;
        if (state.imposedLawIds().size() < minimumImposedLaws) return false;
        if (state.bounds().sizeX() < minimumSizeX
                || state.bounds().sizeY() < minimumSizeY
                || state.bounds().sizeZ() < minimumSizeZ) return false;
        if (sovereigntyUnlocked && !state.sovereigntyUnlocked()) return false;
        return state.unlockedFeatures().containsAll(requiredFeatures);
    }
}
