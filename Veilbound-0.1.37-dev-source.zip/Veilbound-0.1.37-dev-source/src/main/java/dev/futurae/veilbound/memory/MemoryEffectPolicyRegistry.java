package dev.futurae.veilbound.memory;

import java.util.Objects;

/** Replace-all holder for datapack-reloadable Memory runtime tuning. */
public final class MemoryEffectPolicyRegistry {
    private MemoryEffectPolicy policy = MemoryEffectPolicy.DEVELOPMENT_DEFAULT;

    public MemoryEffectPolicy policy() { return policy; }
    public void replace(MemoryEffectPolicy policy) { this.policy = Objects.requireNonNull(policy, "policy"); }
}
