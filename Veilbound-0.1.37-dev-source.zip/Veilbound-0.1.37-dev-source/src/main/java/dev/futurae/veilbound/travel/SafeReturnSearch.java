package dev.futurae.veilbound.travel;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Loader-neutral ordering for nearby return-position probes.
 *
 * <p>The exact saved anchor is always attempted separately by the platform first. These offsets
 * are only fallback probes when the exact player-sized box has become obstructed. Candidates are
 * deterministic, prefer the saved Y level before moving vertically, and then favor minimal
 * horizontal displacement.</p>
 */
public final class SafeReturnSearch {
    public static final int HORIZONTAL_RADIUS = 3;
    public static final int VERTICAL_RADIUS = 2;

    private static final List<BlockOffset> CANDIDATES = buildCandidates();

    private SafeReturnSearch() {}

    public static List<BlockOffset> candidates() {
        return CANDIDATES;
    }

    private static List<BlockOffset> buildCandidates() {
        List<BlockOffset> offsets = new ArrayList<>();
        for (int dy = -VERTICAL_RADIUS; dy <= VERTICAL_RADIUS; dy++) {
            for (int dx = -HORIZONTAL_RADIUS; dx <= HORIZONTAL_RADIUS; dx++) {
                for (int dz = -HORIZONTAL_RADIUS; dz <= HORIZONTAL_RADIUS; dz++) {
                    if (dx == 0 && dy == 0 && dz == 0) continue;
                    offsets.add(new BlockOffset(dx, dy, dz));
                }
            }
        }
        offsets.sort(Comparator
                .comparingInt((BlockOffset offset) -> verticalPreference(offset.dy()))
                .thenComparingInt(BlockOffset::horizontalDistanceSquared)
                .thenComparingInt(BlockOffset::distanceSquared)
                .thenComparingInt(BlockOffset::dx)
                .thenComparingInt(BlockOffset::dz));
        return List.copyOf(offsets);
    }

    private static int verticalPreference(int dy) {
        if (dy == 0) return 0;
        // Prefer moving upward before downward when the distance is otherwise equal. This avoids
        // selecting a cavity below the saved location ahead of open space immediately above it.
        return Math.abs(dy) * 2 + (dy < 0 ? 1 : 0);
    }

    public record BlockOffset(int dx, int dy, int dz) {
        public int horizontalDistanceSquared() { return dx * dx + dz * dz; }
        public int distanceSquared() { return horizontalDistanceSquared() + dy * dy; }
    }
}
