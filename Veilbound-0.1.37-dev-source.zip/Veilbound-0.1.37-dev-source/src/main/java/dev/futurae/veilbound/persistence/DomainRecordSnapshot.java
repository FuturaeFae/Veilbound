package dev.futurae.veilbound.persistence;

import dev.futurae.veilbound.domain.DomainIdentity;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.travel.ReturnAnchor;
import java.util.Objects;
import java.util.UUID;

/** Persisted identity + gameplay snapshot + digital storage/transmutation + owner recall destination for one Domain. */
public record DomainRecordSnapshot(
        UUID ownerId,
        String dimensionId,
        long seed,
        boolean starterPocketInitialized,
        DomainSnapshot domain,
        VeilInventorySnapshot veilInventory,
        MatterTransmutationSnapshot matterTransmutation,
        MemoryProgressSnapshot memoryProgress,
        ReturnAnchor ownerReturnAnchor) {
    public DomainRecordSnapshot {
        Objects.requireNonNull(ownerId, "ownerId");
        Objects.requireNonNull(dimensionId, "dimensionId");
        Objects.requireNonNull(domain, "domain");
        Objects.requireNonNull(veilInventory, "veilInventory");
        Objects.requireNonNull(matterTransmutation, "matterTransmutation");
        Objects.requireNonNull(memoryProgress, "memoryProgress");
        if (!ownerId.equals(domain.ownerId())) throw new IllegalArgumentException("Snapshot owner mismatch");
        if (!dimensionId.equals(DomainIdentity.dimensionIdFor(ownerId))) {
            throw new IllegalArgumentException("Snapshot dimension id does not match owner UUID");
        }
    }

    public static DomainRecordSnapshot capture(DomainRecord record) {
        return new DomainRecordSnapshot(
                record.ownerId(),
                record.identity().dimensionId(),
                record.identity().seed(),
                record.starterPocketInitialized(),
                DomainSnapshot.capture(record.state()),
                VeilInventorySnapshot.capture(record.veilInventory()),
                MatterTransmutationSnapshot.capture(record.matterTransmutation()),
                MemoryProgressSnapshot.capture(record.memoryProgress()),
                record.ownerReturnAnchor().orElse(null));
    }

    public DomainRecord restore() {
        DomainRecord record = new DomainRecord(new DomainIdentity(ownerId, dimensionId, seed), domain.restore());
        if (starterPocketInitialized) record.markStarterPocketInitialized();
        veilInventory.restoreInto(record.veilInventory());
        matterTransmutation.restoreInto(record.matterTransmutation());
        memoryProgress.restoreInto(record.memoryProgress());
        if (ownerReturnAnchor != null) record.setOwnerReturnAnchor(ownerReturnAnchor);
        return record;
    }
}
