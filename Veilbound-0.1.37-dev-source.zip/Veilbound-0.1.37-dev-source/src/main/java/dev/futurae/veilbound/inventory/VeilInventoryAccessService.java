package dev.futurae.veilbound.inventory;

import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.domain.DomainRepository;
import java.util.Objects;
import java.util.UUID;

/** Central authorization boundary for wireless owner access and physical Interface automation. */
public final class VeilInventoryAccessService {
    private final DomainRepository domains;
    private final VeilStoragePolicy policy;

    public VeilInventoryAccessService(DomainRepository domains, VeilStoragePolicy policy) {
        this.domains = Objects.requireNonNull(domains, "domains");
        this.policy = Objects.requireNonNull(policy, "policy");
    }

    public AccessResult ownerAccess(UUID viewerId, UUID ownerId) {
        Objects.requireNonNull(viewerId, "viewerId");
        Objects.requireNonNull(ownerId, "ownerId");
        if (!viewerId.equals(ownerId)) return AccessResult.denied("owner_only");
        return resolve(ownerId);
    }

    /** Interface transfer is independent of Domain-level loading, but only runs while the owner is online. */
    public AccessResult interfaceAccess(UUID ownerId, boolean ownerOnline) {
        Objects.requireNonNull(ownerId, "ownerId");
        if (!ownerOnline) return AccessResult.denied("owner_offline");
        return resolve(ownerId);
    }

    private AccessResult resolve(UUID ownerId) {
        DomainRecord record = domains.getRecord(ownerId).orElse(null);
        if (record == null) return AccessResult.denied("domain_not_found");
        VeilStorageCapacity capacity = policy.capacityFor(record.state());
        if (!capacity.unlocked()) return AccessResult.denied("veil_inventory_locked");
        return AccessResult.allowed(record.veilInventory(), capacity);
    }

    public record AccessResult(boolean allowed, VeilInventory inventory, VeilStorageCapacity capacity, String reason) {
        public static AccessResult denied(String reason) {
            return new AccessResult(false, null, VeilStorageCapacity.LOCKED, reason);
        }
        public static AccessResult allowed(VeilInventory inventory, VeilStorageCapacity capacity) {
            return new AccessResult(true, inventory, capacity, "ok");
        }
    }
}
