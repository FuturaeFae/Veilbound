package dev.futurae.veilbound.engineering;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class EngineeringRecipeRegistry {
    private final Map<String, EngineeringRecipe> recipes = new LinkedHashMap<>();
    public synchronized void replaceAll(Collection<EngineeringRecipe> next) {
        recipes.clear();
        for (EngineeringRecipe recipe : next) {
            if (recipes.put(recipe.id(), recipe) != null) throw new IllegalArgumentException("Duplicate engineering recipe: " + recipe.id());
        }
    }
    public synchronized Optional<EngineeringRecipe> get(String id) { return Optional.ofNullable(recipes.get(id)); }
    public synchronized List<EngineeringRecipe> all() {
        ArrayList<EngineeringRecipe> out = new ArrayList<>(recipes.values());
        out.sort(Comparator.comparing(EngineeringRecipe::id));
        return List.copyOf(out);
    }
    public synchronized List<EngineeringRecipe> forStation(EngineeringStation station) {
        return recipes.values().stream().filter(r -> r.station() == station).sorted(Comparator.comparing(EngineeringRecipe::id)).toList();
    }
}
