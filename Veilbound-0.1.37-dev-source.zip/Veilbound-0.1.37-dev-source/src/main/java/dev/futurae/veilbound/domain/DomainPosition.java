package dev.futurae.veilbound.domain;

/** Loader-neutral integer position used by Domain persistence and rules. */
public record DomainPosition(int x, int y, int z) {
    public static final DomainPosition ORIGIN = new DomainPosition(0, 0, 0);
}
