package dev.futurae.veilbound.platform.neoforge.inventory;

import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.inventory.VeilInventoryPageService;
import dev.futurae.veilbound.inventory.VeilInventoryTerminalPageService;
import dev.futurae.veilbound.inventory.VeilStackKey;
import dev.futurae.veilbound.matter.MatterPatternPageService;
import dev.futurae.veilbound.matter.MatterTransmutationService;
import dev.futurae.veilbound.network.VeilInventoryActionPayload;
import dev.futurae.veilbound.network.VeilInventorySnapshotPayload;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.transfer.item.ItemResource;

/** Server-authoritative mutation, paging, search and preference boundary for the wireless Veil terminal. */
public final class NeoForgeVeilInventoryController {
    public static final int PAGE_SIZE = 36;
    private final VeilboundRuntime runtime;
    private final VeilInventoryPageService pages = new VeilInventoryPageService();
    private final VeilInventoryTerminalPageService terminalPages = new VeilInventoryTerminalPageService();
    private final MatterTransmutationService transmutation = new MatterTransmutationService();

    public NeoForgeVeilInventoryController(VeilboundRuntime runtime) {
        this.runtime = java.util.Objects.requireNonNull(runtime, "runtime");
    }

    public void handle(ServerPlayer player, VeilInventoryActionPayload payload) {
        var access = runtime.veilInventoryAccess().ownerAccess(player.getUUID(), player.getUUID());
        if (!access.allowed()) {
            PacketDistributor.sendToPlayer(player, VeilInventorySnapshotPayload.denied(access.reason()));
            return;
        }
        var record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null) {
            PacketDistributor.sendToPlayer(player, VeilInventorySnapshotPayload.denied("domain_not_found"));
            return;
        }

        ensureTerminalMigration(record);
        boolean terminal = record.state().hasFeature(DomainFeature.VEIL_TRANSMUTATION);
        switch (payload.action()) {
            case OPEN_OR_PAGE -> { }
            case DEPOSIT_HELD -> {
                if (terminal) depositOrTransmuteHeld(player, record, access.inventory(), access.capacity());
                else depositHeld(player, record, access.inventory(), access.capacity());
            }
            case WITHDRAW_ONE -> {
                if (terminal && isMatterPattern(record, payload.resource(), player)) synthesize(player, record, payload.resource(), 1);
                else withdrawStored(player, access.inventory(), access.capacity(), payload.resource(), 1);
            }
            case WITHDRAW_STACK -> {
                int requested = payload.resource().isEmpty() ? 0 : payload.resource().getMaxStackSize();
                if (terminal && isMatterPattern(record, payload.resource(), player)) synthesize(player, record, payload.resource(), requested);
                else withdrawStored(player, access.inventory(), access.capacity(), payload.resource(), requested);
            }
            case SYNTHESIZE_QUANTITY -> {
                if (terminal) synthesize(player, record, payload.resource(), payload.quantity());
            }
            case TOGGLE_FAVORITE -> {
                if (terminal) toggleFavorite(player, record, payload.resource());
            }
            // Compatibility no-ops. In terminal mode conversion is performed by DEPOSIT_HELD.
            case TRANSMUTE_ONE, TRANSMUTE_STACK -> { }
        }
        sendSnapshot(player, payload.page(), payload.query(), payload.sortMode(), payload.filterMode());
    }

    private void ensureTerminalMigration(dev.futurae.veilbound.domain.DomainRecord record) {
        if (!record.state().hasFeature(DomainFeature.VEIL_TRANSMUTATION) || record.veilInventory().totalItems() == 0) return;
        var result = transmutation.migrateLegacyInventory(
                record.state(), record.veilInventory(), record.matterTransmutation(), runtime.matter());
        if (!result.migrated()) {
            throw new IllegalStateException("Unable to migrate legacy Veil Inventory into Matter terminal: " + result.reason());
        }
    }

    private void depositOrTransmuteHeld(
            ServerPlayer player,
            dev.futurae.veilbound.domain.DomainRecord record,
            dev.futurae.veilbound.inventory.VeilInventory inventory,
            dev.futurae.veilbound.inventory.VeilStorageCapacity capacity) {
        ItemStack held = player.getMainHandItem();
        if (held.isEmpty()) return;
        ItemResource resource = ItemResource.of(held);
        VeilStackKey key;
        try {
            key = NeoForgeVeilStackBridge.toKey(resource, player.registryAccess());
        } catch (RuntimeException malformed) {
            return;
        }
        var value = runtime.matter().amount(key.itemId());
        if (value.isPresent() && value.getAsLong() > 0) {
            var absorbed = transmutation.absorb(
                    record.state(), record.matterTransmutation(), runtime.matter(), key, held.getCount());
            if (absorbed.absorbed()) held.shrink((int) absorbed.itemCount());
            return;
        }
        long accepted = inventory.insert(key, held.getCount(), capacity);
        if (accepted > 0) held.shrink((int) accepted);
    }

    private boolean isMatterPattern(
            dev.futurae.veilbound.domain.DomainRecord record,
            ItemResource resource,
            ServerPlayer player) {
        if (resource == null || resource.isEmpty()) return false;
        VeilStackKey key;
        try {
            key = NeoForgeVeilStackBridge.toKey(resource, player.registryAccess());
        } catch (RuntimeException malformed) {
            return false;
        }
        return key.componentData().isEmpty()
                && record.matterTransmutation().knows(key.itemId())
                && runtime.matter().amount(key.itemId()).isPresent();
    }

    private void depositHeld(ServerPlayer player, dev.futurae.veilbound.domain.DomainRecord record,
            dev.futurae.veilbound.inventory.VeilInventory inventory,
            dev.futurae.veilbound.inventory.VeilStorageCapacity capacity) {
        ItemStack held = player.getMainHandItem();
        if (held.isEmpty()) return;
        ItemResource resource = ItemResource.of(held);
        VeilStackKey key = NeoForgeVeilStackBridge.toKey(resource, player.registryAccess());
        long accepted = inventory.insert(key, held.getCount(), capacity);
        if (accepted > 0) held.shrink((int) accepted);
    }

    private void toggleFavorite(ServerPlayer player, dev.futurae.veilbound.domain.DomainRecord record, ItemResource resource) {
        if (resource == null || resource.isEmpty()) return;
        VeilStackKey key;
        try {
            key = NeoForgeVeilStackBridge.toKey(resource, player.registryAccess());
        } catch (RuntimeException malformed) {
            return;
        }
        if (!key.componentData().isEmpty() || !record.matterTransmutation().knows(key.itemId())
                || runtime.matter().amount(key.itemId()).isEmpty()) return;
        record.matterTransmutation().toggleFavorite(key.itemId());
    }

    private void synthesize(ServerPlayer player, dev.futurae.veilbound.domain.DomainRecord record,
            ItemResource requestedResource, int requested) {
        if (requestedResource == null || requestedResource.isEmpty() || requested <= 0) return;
        VeilStackKey requestedKey;
        try {
            requestedKey = NeoForgeVeilStackBridge.toKey(requestedResource, player.registryAccess());
        } catch (RuntimeException malformed) {
            return;
        }
        if (!requestedKey.componentData().isEmpty()) return;
        ItemResource canonical = NeoForgeVeilStackBridge.toResource(VeilStackKey.plain(requestedKey.itemId()), player.registryAccess());
        if (canonical.isEmpty()) return;

        int desired = Math.min(Math.min(requested, VeilInventoryActionPayload.MAX_SYNTHESIS_QUANTITY), canonical.getMaxStackSize());
        var synthesized = transmutation.synthesize(
                record.state(), record.matterTransmutation(), runtime.matter(), requestedKey.itemId(), desired);
        if (!synthesized.synthesized()) return;

        ItemStack delivered = canonical.toStack((int) synthesized.itemCount());
        int before = delivered.getCount();
        player.getInventory().add(delivered);
        int undelivered = delivered.getCount();
        int actuallyDelivered = before - undelivered;
        if (undelivered > 0) {
            long refund;
            try {
                refund = Math.multiplyExact((long) undelivered, synthesized.matterPerItem());
            } catch (ArithmeticException impossible) {
                throw new IllegalStateException("Matter refund overflow", impossible);
            }
            long restored = record.matterTransmutation().addMatter(refund);
            if (restored != refund) throw new IllegalStateException("Could not refund undelivered Matter synthesis");
        }
        if (actuallyDelivered > 0) record.matterTransmutation().recordRecent(requestedKey.itemId());
    }

    private void withdrawStored(ServerPlayer player, dev.futurae.veilbound.inventory.VeilInventory inventory,
            dev.futurae.veilbound.inventory.VeilStorageCapacity capacity, ItemResource resource, int requested) {
        if (resource == null || resource.isEmpty() || requested <= 0) return;
        VeilStackKey key = NeoForgeVeilStackBridge.toKey(resource, player.registryAccess());
        long extracted = inventory.extract(key, Math.min(requested, Integer.MAX_VALUE));
        if (extracted <= 0) return;

        ItemStack delivered = resource.toStack((int) extracted);
        player.getInventory().add(delivered);
        int remainder = delivered.getCount();
        if (remainder > 0) {
            long restored = inventory.insert(key, remainder, capacity);
            if (restored != remainder) {
                throw new IllegalStateException("Could not atomically restore undelivered Veil Inventory items");
            }
        }
    }

    public void sendSnapshot(ServerPlayer player, int requestedPage) {
        sendSnapshot(player, requestedPage, "", MatterPatternPageService.SortMode.NAME_ASC, MatterPatternPageService.FilterMode.ALL);
    }

    public void sendSnapshot(
            ServerPlayer player,
            int requestedPage,
            String query,
            MatterPatternPageService.SortMode sortMode,
            MatterPatternPageService.FilterMode filterMode) {
        var access = runtime.veilInventoryAccess().ownerAccess(player.getUUID(), player.getUUID());
        if (!access.allowed()) {
            PacketDistributor.sendToPlayer(player, VeilInventorySnapshotPayload.denied(access.reason()));
            return;
        }
        var record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null) {
            PacketDistributor.sendToPlayer(player, VeilInventorySnapshotPayload.denied("domain_not_found"));
            return;
        }
        ensureTerminalMigration(record);

        boolean crafting = record.state().hasFeature(DomainFeature.VEIL_CRAFTING);
        boolean terminal = record.state().hasFeature(DomainFeature.VEIL_TRANSMUTATION);
        if (terminal) {
            Map<String, String> patternDisplayNames = new LinkedHashMap<>();
            for (String itemId : record.matterTransmutation().learnedItemIds()) {
                if (runtime.matter().amount(itemId).isEmpty()) continue;
                ItemResource resource = NeoForgeVeilStackBridge.toResource(VeilStackKey.plain(itemId), player.registryAccess());
                if (!resource.isEmpty()) patternDisplayNames.put(itemId, resource.getHoverName().getString());
            }
            Map<VeilStackKey, String> storedDisplayNames = new LinkedHashMap<>();
            for (VeilStackKey key : record.veilInventory().contents().keySet()) {
                if (runtime.matter().amount(key.itemId()).isPresent()) continue;
                ItemResource resource = NeoForgeVeilStackBridge.toResource(key, player.registryAccess());
                if (!resource.isEmpty()) storedDisplayNames.put(key, resource.getHoverName().getString());
            }
            var page = terminalPages.page(
                    record.veilInventory(), record.matterTransmutation().learnedItemIds(), runtime.matter(),
                    record.matterTransmutation().storedMatter(), record.matterTransmutation().favoriteItemIds(),
                    record.matterTransmutation().recentItemIds(), storedDisplayNames, patternDisplayNames,
                    query, sortMode, filterMode, requestedPage, PAGE_SIZE);
            var entries = new ArrayList<VeilInventorySnapshotPayload.Entry>(page.entries().size());
            for (var entry : page.entries()) {
                ItemResource resource = NeoForgeVeilStackBridge.toResource(entry.key(), player.registryAccess());
                if (!resource.isEmpty()) {
                    entries.add(new VeilInventorySnapshotPayload.Entry(
                            resource, entry.storedCount(), entry.matterCost(), entry.affordableCount(),
                            entry.favorite(), entry.recentRank() != Integer.MAX_VALUE));
                }
            }
            int activePatterns = patternDisplayNames.size();
            PacketDistributor.sendToPlayer(player, new VeilInventorySnapshotPayload(
                    true, "ok", page.page(), page.pageCount(), record.veilInventory().totalItems(), access.capacity().maxItems(),
                    record.veilInventory().distinctTypes(), access.capacity().maxTypes(),
                    crafting, true, record.matterTransmutation().storedMatter(),
                    activePatterns, page.matchingEntries(), entries));
            return;
        }

        var page = pages.page(access.inventory(), requestedPage, PAGE_SIZE);
        var entries = new ArrayList<VeilInventorySnapshotPayload.Entry>(page.entries().size());
        for (var entry : page.entries()) {
            ItemResource resource = NeoForgeVeilStackBridge.toResource(entry.key(), player.registryAccess());
            if (!resource.isEmpty()) entries.add(new VeilInventorySnapshotPayload.Entry(resource, entry.count(), 0L, 0L));
        }
        PacketDistributor.sendToPlayer(player, new VeilInventorySnapshotPayload(
                true, "ok", page.page(), page.pageCount(), page.totalItems(), access.capacity().maxItems(),
                page.distinctTypes(), access.capacity().maxTypes(), crafting, false, 0L, 0, page.distinctTypes(), entries));
    }
}
