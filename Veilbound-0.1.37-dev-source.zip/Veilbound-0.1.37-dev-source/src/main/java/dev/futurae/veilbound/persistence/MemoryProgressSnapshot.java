package dev.futurae.veilbound.persistence;

import dev.futurae.veilbound.memory.MemoryProgressState;
import java.util.List;

/**
 * Durable active Domain Orrery selection plus the legacy v7-v10 Domain-global pending-capture field.
 * New Mnemonic Vessel captures are item-stack data components and are not stored here.
 */
public record MemoryProgressSnapshot(String capturedMemoryId, List<String> activeOrreryMemoryIds) {
    public static final MemoryProgressSnapshot EMPTY = new MemoryProgressSnapshot(null, List.of());

    public MemoryProgressSnapshot {
        capturedMemoryId = capturedMemoryId == null || capturedMemoryId.isBlank() ? null : capturedMemoryId;
        activeOrreryMemoryIds = List.copyOf(activeOrreryMemoryIds == null ? List.of() : activeOrreryMemoryIds);
    }

    public static MemoryProgressSnapshot capture(MemoryProgressState state) {
        return new MemoryProgressSnapshot(state.capturedMemoryId().orElse(null), state.activeOrreryMemoryIds());
    }

    public void restoreInto(MemoryProgressState state) {
        state.restoreCapturedMemory(capturedMemoryId);
        state.setActiveOrreryMemoryIds(activeOrreryMemoryIds);
    }
}
