package dev.futurae.veilbound.domain;

import dev.futurae.veilbound.inventory.VeilInventory;
import dev.futurae.veilbound.matter.MatterTransmutationState;
import dev.futurae.veilbound.memory.MemoryProgressState;
import dev.futurae.veilbound.travel.ReturnAnchor;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/** Persisted server-wide record for one personal Domain. */
public final class DomainRecord {
    private final DomainIdentity identity;
    private final DomainState state;
    private ReturnAnchor ownerReturnAnchor;
    private final VeilInventory veilInventory = new VeilInventory();
    private final MatterTransmutationState matterTransmutation = new MatterTransmutationState();
    private final MemoryProgressState memoryProgress = new MemoryProgressState();
    private boolean starterPocketInitialized;
    private Runnable mutationListener = () -> {};

    public DomainRecord(DomainIdentity identity, DomainState state) {
        this.identity = Objects.requireNonNull(identity, "identity");
        this.state = Objects.requireNonNull(state, "state");
        if (!identity.ownerId().equals(state.ownerId())) {
            throw new IllegalArgumentException("Domain identity owner and state owner must match");
        }
    }

    public UUID ownerId() { return identity.ownerId(); }
    public DomainIdentity identity() { return identity; }
    public DomainState state() { return state; }
    public Optional<ReturnAnchor> ownerReturnAnchor() { return Optional.ofNullable(ownerReturnAnchor); }
    public boolean starterPocketInitialized() { return starterPocketInitialized; }
    public VeilInventory veilInventory() { return veilInventory; }
    public MatterTransmutationState matterTransmutation() { return matterTransmutation; }
    public MemoryProgressState memoryProgress() { return memoryProgress; }

    /** Mark only after the platform has successfully created the one-time physical starter floor. */
    public void markStarterPocketInitialized() {
        if (!starterPocketInitialized) {
            starterPocketInitialized = true;
            changed();
        }
    }

    public void setOwnerReturnAnchor(ReturnAnchor anchor) {
        this.ownerReturnAnchor = Objects.requireNonNull(anchor, "anchor");
        changed();
    }

    public void clearOwnerReturnAnchor() {
        if (ownerReturnAnchor != null) {
            ownerReturnAnchor = null;
            changed();
        }
    }

    public void setMutationListener(Runnable listener) {
        this.mutationListener = Objects.requireNonNull(listener, "listener");
        state.setMutationListener(listener);
        veilInventory.setMutationListener(listener);
        matterTransmutation.setMutationListener(listener);
        memoryProgress.setMutationListener(listener);
    }

    private void changed() { mutationListener.run(); }
}
