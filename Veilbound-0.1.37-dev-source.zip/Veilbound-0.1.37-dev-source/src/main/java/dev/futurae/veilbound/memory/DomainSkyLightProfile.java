package dev.futurae.veilbound.memory;

/**
 * Pure projection of Veilbound's Domain-owned illumination onto Minecraft 26.2 sky-light
 * attributes.
 *
 * <p>The base Domain dimension stays fail-closed at zero sky light. When the Open Sky Memory's
 * natural-daylight mechanic is active this projection restores normal daylight. If the Celestial
 * Cycle mechanic is also active, the values follow the vanilla 26.2 overworld day timeline using
 * the Domain's remembered clock rather than the server Overworld clock.</p>
 */
public final class DomainSkyLightProfile {
    public static final float FULL_GAMEPLAY_SKY_LIGHT = 15.0F;
    public static final float FULL_VISUAL_SKY_LIGHT = 1.0F;

    // Minecraft 26.2 data/minecraft/timeline/day.json keyframes.
    private static final long[] GAMEPLAY_TICKS = {133L, 11_867L, 13_670L, 22_330L};
    private static final float[] GAMEPLAY_MULTIPLIERS = {1.0F, 1.0F, 0.26666668F, 0.26666668F};
    private static final long[] VISUAL_TICKS = {730L, 11_270L, 13_140L, 22_860L};
    private static final float[] VISUAL_FACTORS = {1.0F, 1.0F, 0.24F, 0.24F};
    private static final long DAY_TICKS = 24_000L;

    private DomainSkyLightProfile() {}

    public static Sample sample(boolean naturalDaylight, boolean overworldDayCycle, long domainDayTime) {
        if (!naturalDaylight) return Sample.dark();
        if (!overworldDayCycle) return new Sample(FULL_GAMEPLAY_SKY_LIGHT, FULL_VISUAL_SKY_LIGHT);

        float gameplayMultiplier = periodicLinear(domainDayTime, GAMEPLAY_TICKS, GAMEPLAY_MULTIPLIERS);
        float visualFactor = periodicLinear(domainDayTime, VISUAL_TICKS, VISUAL_FACTORS);
        return new Sample(FULL_GAMEPLAY_SKY_LIGHT * gameplayMultiplier, visualFactor);
    }

    private static float periodicLinear(long time, long[] ticks, float[] values) {
        long normalized = Math.floorMod(time, DAY_TICKS);
        for (int i = 0; i < ticks.length - 1; i++) {
            if (normalized >= ticks[i] && normalized <= ticks[i + 1]) {
                return lerp(normalized, ticks[i], ticks[i + 1], values[i], values[i + 1]);
            }
        }

        // Periodic wrap: last keyframe -> first keyframe in the next day.
        long wrapped = normalized < ticks[0] ? normalized + DAY_TICKS : normalized;
        return lerp(wrapped, ticks[ticks.length - 1], ticks[0] + DAY_TICKS,
                values[values.length - 1], values[0]);
    }

    private static float lerp(long time, long startTick, long endTick, float startValue, float endValue) {
        if (endTick <= startTick || startValue == endValue) return startValue;
        float progress = (float) (time - startTick) / (float) (endTick - startTick);
        progress = Math.max(0.0F, Math.min(1.0F, progress));
        return startValue + (endValue - startValue) * progress;
    }

    public record Sample(float gameplaySkyLightLevel, float visualSkyLightFactor) {
        public Sample {
            if (!Float.isFinite(gameplaySkyLightLevel) || gameplaySkyLightLevel < 0.0F || gameplaySkyLightLevel > 15.0F) {
                throw new IllegalArgumentException("gameplaySkyLightLevel must be finite and within 0..15");
            }
            if (!Float.isFinite(visualSkyLightFactor) || visualSkyLightFactor < 0.0F || visualSkyLightFactor > 1.0F) {
                throw new IllegalArgumentException("visualSkyLightFactor must be finite and within 0..1");
            }
        }

        public static Sample dark() { return new Sample(0.0F, 0.0F); }
    }
}
