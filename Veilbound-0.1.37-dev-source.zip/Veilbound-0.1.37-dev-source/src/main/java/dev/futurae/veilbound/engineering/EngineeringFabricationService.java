package dev.futurae.veilbound.engineering;

import dev.futurae.veilbound.domain.DomainState;
import dev.futurae.veilbound.ontology.PotentialReservoir;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** Transactional planner/committer for Fabricator and Foundry jobs. */
public final class EngineeringFabricationService {
    public FabricationPlan plan(
            EngineeringRecipe recipe, EngineeringStation station, DomainState domain,
            EngineeringMatterReservoir matter, PotentialReservoir potential, EngineeringInventory inventory) {
        Objects.requireNonNull(recipe); Objects.requireNonNull(station); Objects.requireNonNull(domain);
        Objects.requireNonNull(matter); Objects.requireNonNull(potential); Objects.requireNonNull(inventory);
        List<String> missing = new ArrayList<>();
        if (recipe.station() != station) missing.add("wrong_station");
        if (!domain.coreActive()) missing.add("core_inactive");
        else if (domain.coreTier().ordinal() < recipe.minimumCoreTier().ordinal()) missing.add("core_tier:" + recipe.minimumCoreTier());
        for (String memory : recipe.requiredMemoryIds()) if (!domain.unlockedMemoryIds().contains(memory)) missing.add("memory:" + memory);
        for (String law : recipe.requiredLawIds()) if (!domain.imposedLawIds().contains(law)) missing.add("law:" + law);
        for (EngineeringIngredient ingredient : recipe.inputs()) {
            long have = inventory.count(ingredient.itemId());
            if (have < ingredient.count()) missing.add("item:" + ingredient.itemId() + ":" + (ingredient.count() - have));
        }
        if (matter.stored() < recipe.matterCost()) missing.add("matter:" + (recipe.matterCost() - matter.stored()));
        if (!domain.coreActive() || domain.dimensionalEnergy() < recipe.dimensionalEnergyCost())
            missing.add("de:" + Math.max(0, recipe.dimensionalEnergyCost() - domain.dimensionalEnergy()));
        if (potential.stored() < recipe.potentialCost()) missing.add("potential:" + (recipe.potentialCost() - potential.stored()));
        return new FabricationPlan(missing.isEmpty(), List.copyOf(missing), recipe.processTicks());
    }

    public FabricationResult execute(
            EngineeringRecipe recipe, EngineeringStation station, DomainState domain,
            EngineeringMatterReservoir matter, PotentialReservoir potential, EngineeringInventory inventory) {
        return execute(recipe, station, domain, matter, potential, inventory, inventory);
    }

    public FabricationResult execute(
            EngineeringRecipe recipe, EngineeringStation station, DomainState domain,
            EngineeringMatterReservoir matter, PotentialReservoir potential,
            EngineeringInventory inputInventory, EngineeringInventory outputInventory) {
        FabricationPlan plan = plan(recipe, station, domain, matter, potential, inputInventory);
        if (!plan.ready()) return new FabricationResult(false, plan.missing(), recipe.outputItemId(), 0);
        // Commit only after every resource/prerequisite has been checked. Outputs are separated from
        // the component inventory so automation can safely pull finished work without stealing inputs.
        for (EngineeringIngredient ingredient : recipe.inputs()) {
            if (!inputInventory.extract(ingredient.itemId(), ingredient.count())) throw new IllegalStateException("validated inventory changed during commit");
        }
        if (!matter.consume(recipe.matterCost())) throw new IllegalStateException("validated Matter changed during commit");
        if (!potential.consume(recipe.potentialCost())) throw new IllegalStateException("validated Potential changed during commit");
        if (!domain.consumeDimensionalEnergy(recipe.dimensionalEnergyCost())) throw new IllegalStateException("validated DE changed during commit");
        outputInventory.insert(recipe.outputItemId(), recipe.outputCount());
        return new FabricationResult(true, List.of(), recipe.outputItemId(), recipe.outputCount());
    }

    public record FabricationPlan(boolean ready, List<String> missing, int processTicks) {}
    public record FabricationResult(boolean crafted, List<String> missing, String outputItemId, int outputCount) {}
}
