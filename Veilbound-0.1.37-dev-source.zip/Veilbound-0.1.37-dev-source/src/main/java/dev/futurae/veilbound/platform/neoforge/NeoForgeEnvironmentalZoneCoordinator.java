package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.environment.EnvironmentZoneSelectionService;
import dev.futurae.veilbound.registry.VeilboundItems;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Temporary Resonance Lens Environmental Zone editor. Selection lives only in memory and is
 * projected with particles; confirmation is the only operation that persists a zone.
 */
public final class NeoForgeEnvironmentalZoneCoordinator {
    private final VeilboundRuntime runtime;
    private final EnvironmentZoneSelectionService selections = new EnvironmentZoneSelectionService();
    private long ticks;

    public NeoForgeEnvironmentalZoneCoordinator(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    /** Sneak-use in air starts edit mode; once both corners exist it confirms the selection. */
    public void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getLevel().isClientSide()) return;
        if (!event.getItemStack().is(VeilboundItems.RESONANCE_LENS.get()) || !player.isShiftKeyDown()) return;
        handleSneakUse(player);
        consume(event, InteractionResult.SUCCESS);
    }

    /** Normal Lens block-use marks A then B. Sneak-use confirms once both corners exist. */
    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getLevel().isClientSide()) return;
        if (!event.getItemStack().is(VeilboundItems.RESONANCE_LENS.get())) return;
        if (player.isShiftKeyDown()) {
            handleSneakUse(player);
            consume(event, InteractionResult.SUCCESS);
            return;
        }
        var session = selections.selection(player.getUUID()).orElse(null);
        if (session == null) return;
        DomainRecord record = ownerRecordInCurrentDomain(player);
        if (record == null) {
            player.displayClientMessage(Component.translatable("message.veilbound.zone.not_owner_domain"), true);
            selections.cancel(player.getUUID());
            consume(event, InteractionResult.FAIL);
            return;
        }
        DomainPosition position = new DomainPosition(event.getPos().getX(), event.getPos().getY(), event.getPos().getZ());
        var marked = selections.markCorner(player.getUUID(), record.state(), position);
        if (!marked.marked()) {
            player.displayClientMessage(Component.translatable("message.veilbound.zone." + marked.reason()), true);
            consume(event, InteractionResult.FAIL);
            return;
        }
        player.displayClientMessage(Component.translatable(
                marked.corner() == 1 ? "message.veilbound.zone.corner_a" : "message.veilbound.zone.corner_b",
                position.x(), position.y(), position.z()), true);
        consume(event, InteractionResult.SUCCESS);
    }

    public void onServerTick(ServerTickEvent.Post event) {
        ticks++;
        if (ticks % 10L != 0L) return;
        Set<UUID> online = new HashSet<>();
        for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) {
            online.add(player.getUUID());
            var selection = selections.selection(player.getUUID()).orElse(null);
            if (selection == null) continue;
            DomainRecord record = ownerRecordInCurrentDomain(player);
            if (record == null) {
                selections.cancel(player.getUUID());
                continue;
            }
            projectSelection((ServerLevel) player.level(), selection);
        }
        // Selection sessions are deliberately ephemeral; logout/restart never persists half-built zones.
        selections.retainPlayers(online);
    }

    private void handleSneakUse(ServerPlayer player) {
        DomainRecord record = ownerRecordInCurrentDomain(player);
        if (record == null) {
            player.displayClientMessage(Component.translatable("message.veilbound.zone.not_owner_domain"), true);
            selections.cancel(player.getUUID());
            return;
        }
        var current = selections.selection(player.getUUID()).orElse(null);
        if (current != null) {
            if (!current.complete()) {
                player.displayClientMessage(Component.translatable("message.veilbound.zone.selection_incomplete"), true);
                return;
            }
            var confirmed = selections.confirm(player.getUUID(), record.state());
            if (!confirmed.created()) {
                player.displayClientMessage(Component.translatable("message.veilbound.zone." + confirmed.reason()), true);
                return;
            }
            var zone = confirmed.zone();
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.zone.created", zone.name(), zone.memoryProfileId(),
                    zone.bounds().sizeX(), zone.bounds().sizeY(), zone.bounds().sizeZ()), false);
            return;
        }
        if (!record.state().hasFeature(DomainFeature.ENVIRONMENTAL_MASTERY)) {
            player.displayClientMessage(Component.translatable("message.veilbound.zone.environmental_mastery_locked"), true);
            return;
        }
        var active = record.memoryProgress().activeOrreryMemoryIds();
        if (active.isEmpty()) {
            player.displayClientMessage(Component.translatable("message.veilbound.zone.memory_profile_missing"), true);
            return;
        }
        if (active.size() != 1) {
            player.displayClientMessage(Component.translatable("message.veilbound.zone.multiple_profiles"), true);
            return;
        }
        String memoryId = active.getFirst();
        String baseName = runtime.memories().get(memoryId)
                .map(def -> simplifyName(def.displayName()))
                .orElse("Environmental") + " Zone";
        String name = nextAvailableName(record, baseName);
        selections.begin(player.getUUID(), memoryId, name);
        player.displayClientMessage(Component.translatable(
                "message.veilbound.zone.edit_started", name,
                runtime.memories().get(memoryId).map(def -> def.displayName()).orElse(memoryId)), false);
    }

    private DomainRecord ownerRecordInCurrentDomain(ServerPlayer player) {
        DomainRecord record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null) return null;
        return record.identity().dimensionId().equals(player.level().dimension().identifier().toString()) ? record : null;
    }

    private static String simplifyName(String displayName) {
        String prefix = "Memory of ";
        return displayName.startsWith(prefix) ? displayName.substring(prefix.length()) : displayName;
    }

    private static String nextAvailableName(DomainRecord record, String base) {
        int index = 1;
        while (true) {
            String candidate = base + " " + index;
            boolean exists = record.state().environmentZones().stream()
                    .anyMatch(zone -> zone.name().equalsIgnoreCase(candidate));
            if (!exists) return candidate;
            index++;
        }
    }

    private static void projectSelection(ServerLevel level, EnvironmentZoneSelectionService.Selection selection) {
        if (selection.cornerA() == null) return;
        if (!selection.complete()) {
            particle(level, selection.cornerA().x(), selection.cornerA().y(), selection.cornerA().z());
            return;
        }
        var b = selection.bounds();
        int stepX = Math.max(1, b.sizeX() / 8);
        int stepY = Math.max(1, b.sizeY() / 8);
        int stepZ = Math.max(1, b.sizeZ() / 8);
        for (int x = b.minX(); x <= b.maxX(); x += stepX) {
            particle(level, x, b.minY(), b.minZ()); particle(level, x, b.minY(), b.maxZ());
            particle(level, x, b.maxY(), b.minZ()); particle(level, x, b.maxY(), b.maxZ());
        }
        for (int y = b.minY(); y <= b.maxY(); y += stepY) {
            particle(level, b.minX(), y, b.minZ()); particle(level, b.minX(), y, b.maxZ());
            particle(level, b.maxX(), y, b.minZ()); particle(level, b.maxX(), y, b.maxZ());
        }
        for (int z = b.minZ(); z <= b.maxZ(); z += stepZ) {
            particle(level, b.minX(), b.minY(), z); particle(level, b.minX(), b.maxY(), z);
            particle(level, b.maxX(), b.minY(), z); particle(level, b.maxX(), b.maxY(), z);
        }
    }

    private static void particle(ServerLevel level, int x, int y, int z) {
        level.sendParticles(ParticleTypes.END_ROD, x + 0.5, y + 0.5, z + 0.5, 1, 0.0, 0.0, 0.0, 0.0);
    }

    private static void consume(PlayerInteractEvent.RightClickItem event, InteractionResult result) {
        event.setCancellationResult(result);
        event.setCanceled(true);
    }

    private static void consume(PlayerInteractEvent.RightClickBlock event, InteractionResult result) {
        event.setCancellationResult(result);
        event.setCanceled(true);
    }
}
