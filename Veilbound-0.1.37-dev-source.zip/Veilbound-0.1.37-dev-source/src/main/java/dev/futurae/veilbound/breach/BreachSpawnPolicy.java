package dev.futurae.veilbound.breach;

import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import java.util.random.RandomGenerator;

/** Data/config-driven creature cadence, local cap, spawn radius, and weighted breach fauna. */
public final class BreachSpawnPolicy {
    private final EnumMap<BreachSeverity, SpawnBand> bands;
    private final EnumMap<BreachSeverity, WeightedCreaturePool> creaturePools;
    private final int localCreatureCap;
    private final double localCreatureRadius;
    private final double emergenceRadius;

    /** Backward-compatible constructor used by older tests/datapacks; creature pools use development defaults. */
    public BreachSpawnPolicy(Map<BreachSeverity, SpawnBand> bands, int localCreatureCap) {
        this(bands, localCreatureCap, 24.0, 2.5, developmentPools());
    }

    public BreachSpawnPolicy(
            Map<BreachSeverity, SpawnBand> bands,
            int localCreatureCap,
            double localCreatureRadius,
            double emergenceRadius,
            Map<BreachSeverity, WeightedCreaturePool> creaturePools) {
        Objects.requireNonNull(bands, "bands");
        Objects.requireNonNull(creaturePools, "creaturePools");
        if (localCreatureCap < 1) throw new IllegalArgumentException("localCreatureCap must be >= 1");
        if (!(localCreatureRadius > 0.0) || !Double.isFinite(localCreatureRadius)) {
            throw new IllegalArgumentException("localCreatureRadius must be finite and > 0");
        }
        if (!(emergenceRadius >= 0.0) || !Double.isFinite(emergenceRadius)) {
            throw new IllegalArgumentException("emergenceRadius must be finite and >= 0");
        }
        this.bands = new EnumMap<>(BreachSeverity.class);
        this.creaturePools = new EnumMap<>(BreachSeverity.class);
        for (BreachSeverity severity : BreachSeverity.values()) {
            this.bands.put(severity, Objects.requireNonNull(bands.get(severity), "Missing spawn band for " + severity));
            this.creaturePools.put(severity, Objects.requireNonNull(creaturePools.get(severity), "Missing creature pool for " + severity));
        }
        this.localCreatureCap = localCreatureCap;
        this.localCreatureRadius = localCreatureRadius;
        this.emergenceRadius = emergenceRadius;
    }

    public SpawnBand band(BreachSeverity severity) { return bands.get(Objects.requireNonNull(severity)); }
    public WeightedCreaturePool creaturePool(BreachSeverity severity) { return creaturePools.get(Objects.requireNonNull(severity)); }
    public int localCreatureCap() { return localCreatureCap; }
    public double localCreatureRadius() { return localCreatureRadius; }
    public double emergenceRadius() { return emergenceRadius; }

    public int nextDelayTicks(BreachSeverity severity, RandomGenerator random) {
        Objects.requireNonNull(random, "random");
        SpawnBand band = band(severity);
        if (band.minTicks() == band.maxTicks()) return band.minTicks();
        return random.nextInt(band.minTicks(), band.maxTicks() + 1);
    }

    public VoidCreatureType selectCreature(BreachSeverity severity, RandomGenerator random) {
        return creaturePool(severity).select(random);
    }

    public record SpawnBand(int minTicks, int maxTicks) {
        public SpawnBand {
            if (minTicks < 1 || maxTicks < minTicks) throw new IllegalArgumentException("Invalid breach spawn interval");
        }
    }

    /** Positive integer weights; absent/zero entries are simply not part of the pool. */
    public static final class WeightedCreaturePool {
        private final EnumMap<VoidCreatureType, Integer> weights = new EnumMap<>(VoidCreatureType.class);
        private final int totalWeight;

        public WeightedCreaturePool(Map<VoidCreatureType, Integer> configured) {
            Objects.requireNonNull(configured, "configured");
            int total = 0;
            for (VoidCreatureType type : VoidCreatureType.values()) {
                int weight = configured.getOrDefault(type, 0);
                if (weight < 0) throw new IllegalArgumentException("Creature weights must be >= 0");
                if (weight > 0) {
                    weights.put(type, weight);
                    total = Math.addExact(total, weight);
                }
            }
            if (total < 1) throw new IllegalArgumentException("At least one creature weight must be > 0");
            totalWeight = total;
        }

        public int weight(VoidCreatureType type) { return weights.getOrDefault(Objects.requireNonNull(type), 0); }
        public Map<VoidCreatureType, Integer> weights() { return Map.copyOf(weights); }
        public int totalWeight() { return totalWeight; }

        public VoidCreatureType select(RandomGenerator random) {
            Objects.requireNonNull(random, "random");
            int roll = random.nextInt(totalWeight);
            int cursor = 0;
            for (VoidCreatureType type : VoidCreatureType.values()) {
                cursor += weight(type);
                if (roll < cursor) return type;
            }
            throw new IllegalStateException("Creature pool selection fell through");
        }
    }

    public static Map<BreachSeverity, WeightedCreaturePool> developmentPools() {
        EnumMap<BreachSeverity, WeightedCreaturePool> result = new EnumMap<>(BreachSeverity.class);
        result.put(BreachSeverity.MINOR, pool(100, 0, 0));
        result.put(BreachSeverity.SEVERE, pool(70, 30, 0));
        result.put(BreachSeverity.EXTREME, pool(45, 35, 20));
        return result;
    }

    private static WeightedCreaturePool pool(int crawler, int stalker, int wraith) {
        EnumMap<VoidCreatureType, Integer> weights = new EnumMap<>(VoidCreatureType.class);
        weights.put(VoidCreatureType.VOID_CRAWLER, crawler);
        weights.put(VoidCreatureType.RIFT_STALKER, stalker);
        weights.put(VoidCreatureType.NULL_WRAITH, wraith);
        return new WeightedCreaturePool(weights);
    }
}
