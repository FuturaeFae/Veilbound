package dev.futurae.veilbound.ontology;

import java.util.Objects;

/** Reloadable balance bundle for Veilbound's boundary-observation Matter industry. */
public record OntologyRuntimePolicy(
        OntologicalHarvesterPolicy harvester,
        OntologicalCompilerPolicy compiler) {
    public static final OntologyRuntimePolicy DEVELOPMENT_DEFAULT = new OntologyRuntimePolicy(
            OntologicalHarvesterPolicy.defaults(), OntologicalCompilerPolicy.defaults());

    public OntologyRuntimePolicy {
        Objects.requireNonNull(harvester, "harvester");
        Objects.requireNonNull(compiler, "compiler");
    }
}
