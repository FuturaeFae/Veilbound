package dev.futurae.veilbound.platform.neoforge.travel;

import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.domain.DomainRuntimeTracker;
import dev.futurae.veilbound.domain.StarterPocketLayout;
import dev.futurae.veilbound.platform.neoforge.world.NeoForgeDomainLevelService;
import dev.futurae.veilbound.platform.neoforge.world.NeoForgeStarterPocketService;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import dev.futurae.veilbound.threshold.GuestThresholdSession;
import dev.futurae.veilbound.travel.DomainKeyActionRouter;
import dev.futurae.veilbound.travel.OwnerDomainTravelService;
import dev.futurae.veilbound.travel.ReturnAnchor;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Relative;

/**
 * Server-authoritative execution of owner travel after the input layer has decided whether the
 * request means enter or exit. Keeping that input decision separate avoids baking an unresolved
 * policy for using the owner key while visiting somebody else's Domain into the travel engine.
 */
public final class NeoForgeDomainTravelExecutor {
    private final VeilboundRuntime runtime;
    private final NeoForgeDomainLevelService domainLevels;
    private final NeoForgeStarterPocketService starterPocket;
    private final NeoForgeReturnAnchorResolver returnResolver;

    public NeoForgeDomainTravelExecutor(
            VeilboundRuntime runtime,
            NeoForgeDomainLevelService domainLevels,
            NeoForgeStarterPocketService starterPocket,
            NeoForgeReturnAnchorResolver returnResolver) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        this.domainLevels = Objects.requireNonNull(domainLevels, "domainLevels");
        this.starterPocket = Objects.requireNonNull(starterPocket, "starterPocket");
        this.returnResolver = Objects.requireNonNull(returnResolver, "returnResolver");
    }

    /**
     * Interprets the single player-facing Domain key. V exits the Domain currently being visited
     * before it can ever enter the player's own Domain.
     */
    public TravelResult handleDomainKey(MinecraftServer server, ServerPlayer player) {
        Objects.requireNonNull(server, "server");
        Objects.requireNonNull(player, "player");
        UUID playerId = player.getUUID();
        var guestSession = runtime.thresholdSessions().session(playerId);
        DomainKeyActionRouter.Decision route = DomainKeyActionRouter.decide(
                playerId, player.level().dimension().identifier().toString(), guestSession);

        if (route.clearStaleGuestSession()) {
            runtime.thresholdSessions().endGuestSession(playerId);
        }

        return switch (route.action()) {
            case ENTER_OWN_DOMAIN -> enterFromOutside(server, player);
            case EXIT_OWN_DOMAIN -> exitOwnDomain(server, player);
            case EXIT_GUEST_DOMAIN -> exitGuestDomain(server, player, guestSession.orElseThrow());
            case DENY_UNTRACKED_FOREIGN_DOMAIN -> TravelResult.denied(route.reason());
        };
    }

    /** Enter from a location the caller has already classified as a valid outside location. */
    public TravelResult enterFromOutside(MinecraftServer server, ServerPlayer owner) {
        Objects.requireNonNull(server, "server");
        Objects.requireNonNull(owner, "owner");
        UUID ownerId = owner.getUUID();
        ReturnAnchor outside = capture(owner);
        OwnerDomainTravelService.TravelDecision decision = runtime.ownerTravel().request(ownerId, outside);
        if (!decision.allowed() || !decision.enteringDomain()) {
            return TravelResult.denied(decision.reason());
        }

        DomainRecord record = decision.domain();
        ServerLevel domain = domainLevels.load(server, ownerId);
        if (!record.starterPocketInitialized()) {
            if (!starterPocket.create(domain)) return TravelResult.denied("starter_pocket_obstructed");
            // Mark only after the physical Void Anchor exists. A crash before this point leaves the
            // flag false; a crash immediately after placement is recovered by create() recognizing
            // the already-present Void Anchor on the next entry.
            record.markStarterPocketInitialized();
        }

        double arrivalX = record.state().coreActive() ? record.state().corePosition().x() + 0.5D : StarterPocketLayout.ARRIVAL_X;
        double arrivalY = record.state().coreActive() ? record.state().corePosition().y() + 1.0D : StarterPocketLayout.ARRIVAL_Y;
        double arrivalZ = record.state().coreActive() ? record.state().corePosition().z() + 0.5D : StarterPocketLayout.ARRIVAL_Z;
        boolean moved = NeoForgeTransitGuard.run(ownerId, () -> owner.teleportTo(
                domain, arrivalX, arrivalY, arrivalZ, Set.of(), outside.yaw(), outside.pitch(), true));
        if (!moved) return TravelResult.denied("owner_enter_teleport_failed");

        DomainRuntimeTracker tracker = runtime.domainRuntime();
        tracker.setOwnerOnline(ownerId, true);
        tracker.setOwnerInside(ownerId, true);
        tracker.setLoaded(ownerId, true);
        tracker.setPlayersInside(ownerId, domain.players().size());
        return TravelResult.entered(decision.domainCreated());
    }

    /**
     * Exit the owner's own Domain. Every active Threshold guest is returned first. If any online
     * guest cannot be moved safely, owner exit is refused and that guest session remains active.
     */
    public TravelResult exitOwnDomain(MinecraftServer server, ServerPlayer owner) {
        Objects.requireNonNull(server, "server");
        Objects.requireNonNull(owner, "owner");
        UUID ownerId = owner.getUUID();
        OwnerDomainTravelService.TravelDecision decision = runtime.ownerTravel().request(ownerId, capture(owner));
        if (!decision.allowed() || decision.enteringDomain()) return TravelResult.denied(decision.reason());

        List<GuestThresholdSession> guests = runtime.domainPresence().guestsRequiringEvacuation(ownerId);
        DomainRuntimeTracker tracker = runtime.domainRuntime();
        tracker.setPendingTransits(ownerId, guests.size() + 1);
        try {
            for (GuestThresholdSession session : guests) {
                ServerPlayer guest = server.getPlayerList().getPlayer(session.guestId());
                if (guest == null) {
                    // Transit sessions are runtime-only; an offline guest cannot physically remain
                    // in the level, so the stale session is safe to close.
                    runtime.domainPresence().completeGuestEvacuation(ownerId, session.guestId());
                    continue;
                }

                NeoForgeReturnAnchorResolver.ResolvedReturn destination =
                        returnResolver.resolve(server, guest, session.returnAnchor());
                if (!teleport(guest, destination)) {
                    return TravelResult.denied("guest_evacuation_failed:" + session.guestId());
                }
                runtime.domainPresence().completeGuestEvacuation(ownerId, session.guestId());
            }

            NeoForgeReturnAnchorResolver.ResolvedReturn ownerDestination =
                    returnResolver.resolve(server, owner, decision.outsideReturnAnchor());
            if (!teleport(owner, ownerDestination)) return TravelResult.denied("owner_exit_teleport_failed");

            runtime.ownerTravel().completeExit(ownerId);
            tracker.setOwnerOnline(ownerId, true);
            tracker.setOwnerInside(ownerId, false);
            tracker.setPendingTransits(ownerId, 0);

            NeoForgeDomainLevelService.UnloadResult unload = domainLevels.unloadIfSafe(server, ownerId);
            return TravelResult.exited(ownerDestination.resolution(), unload.reason());
        } finally {
            // Failure paths must never leave a phantom pending transit that permanently pins the
            // Domain in memory. Actual guest sessions remain independently tracked until completed.
            tracker.setPendingTransits(ownerId, 0);
        }
    }

    /** Return a tracked guest to the exact anchor captured when they entered this Domain. */
    public TravelResult exitGuestDomain(
            MinecraftServer server, ServerPlayer guest, GuestThresholdSession session) {
        Objects.requireNonNull(server, "server");
        Objects.requireNonNull(guest, "guest");
        Objects.requireNonNull(session, "session");
        if (!session.guestId().equals(guest.getUUID())) return TravelResult.denied("guest_session_mismatch");

        String expectedDomain = dev.futurae.veilbound.domain.DomainIdentity.dimensionIdFor(session.ownerId());
        if (!guest.level().dimension().identifier().toString().equals(expectedDomain)) {
            return TravelResult.denied("guest_not_in_expected_domain");
        }

        UUID ownerId = session.ownerId();
        DomainRuntimeTracker tracker = runtime.domainRuntime();
        int previousPending = tracker.state(ownerId).pendingTransits();
        tracker.setPendingTransits(ownerId, previousPending + 1);
        try {
            NeoForgeReturnAnchorResolver.ResolvedReturn destination =
                    returnResolver.resolve(server, guest, session.returnAnchor());
            if (!teleport(guest, destination)) return TravelResult.denied("guest_exit_teleport_failed");

            if (!runtime.domainPresence().completeGuestEvacuation(ownerId, guest.getUUID())) {
                // The teleport succeeded, so a missing session is no longer a safety problem; log it
                // through the result rather than attempting to pull the player back into the Domain.
                return TravelResult.guestExited(destination.resolution(), "guest_session_already_closed");
            }

            domainLevels.liveLevel(server, ownerId).ifPresent(level ->
                    tracker.setPlayersInside(ownerId, level.players().size()));
            return TravelResult.guestExited(destination.resolution(), "ok");
        } finally {
            tracker.setPendingTransits(ownerId, previousPending);
        }
    }

    /**
     * Pre-save disconnect safety. Called from the PlayerList.remove HEAD mixin, before vanilla writes
     * the player .dat. A player inside any tracked Domain is returned first so the save never points
     * at a Domain that may become dormant before the next login.
     */
    public TravelResult prepareForPlayerRemoval(MinecraftServer server, ServerPlayer player) {
        Objects.requireNonNull(server, "server");
        Objects.requireNonNull(player, "player");
        UUID playerId = player.getUUID();
        String currentDimension = player.level().dimension().identifier().toString();

        var guestSession = runtime.thresholdSessions().session(playerId);
        if (guestSession.isPresent()) {
            GuestThresholdSession session = guestSession.get();
            String expected = dev.futurae.veilbound.domain.DomainIdentity.dimensionIdFor(session.ownerId());
            if (currentDimension.equals(expected)) {
                return exitGuestDomain(server, player, session);
            }
            // Out-of-band movement already removed the guest from the visited Domain. The old
            // return anchor must not hijack a later login or V press.
            runtime.thresholdSessions().endGuestSession(playerId);
        }

        String ownDimension = dev.futurae.veilbound.domain.DomainIdentity.dimensionIdFor(playerId);
        if (currentDimension.equals(ownDimension)) {
            return exitOwnDomain(server, player);
        }

        // An owner can only have guests while physically inside their Domain. If stale sessions are
        // present because another mod moved the owner without emitting a normal transition path,
        // evacuate those guests before the owner becomes offline.
        if (!runtime.domainPresence().guestsRequiringEvacuation(playerId).isEmpty()) {
            TravelResult evacuation = evacuateGuestsForOwner(server, playerId);
            if (!evacuation.success()) return evacuation;
        }
        return TravelResult.noop("outside_domain");
    }

    /** Evacuate every current guest without moving the owner. Used for external owner departures. */
    public TravelResult evacuateGuestsForOwner(MinecraftServer server, UUID ownerId) {
        Objects.requireNonNull(server, "server");
        Objects.requireNonNull(ownerId, "ownerId");
        List<GuestThresholdSession> guests = runtime.domainPresence().guestsRequiringEvacuation(ownerId);
        if (guests.isEmpty()) return TravelResult.noop("no_guests");

        DomainRuntimeTracker tracker = runtime.domainRuntime();
        int previousPending = tracker.state(ownerId).pendingTransits();
        tracker.setPendingTransits(ownerId, previousPending + guests.size());
        try {
            for (GuestThresholdSession session : guests) {
                ServerPlayer guest = server.getPlayerList().getPlayer(session.guestId());
                if (guest == null) {
                    // Offline players cannot physically occupy the level. Keep a failed pre-save
                    // session intact only if they still exist here; normal disconnect preparation
                    // removes it after returning them before their player data is saved.
                    runtime.domainPresence().completeGuestEvacuation(ownerId, session.guestId());
                    continue;
                }
                NeoForgeReturnAnchorResolver.ResolvedReturn destination =
                        returnResolver.resolve(server, guest, session.returnAnchor());
                if (!teleport(guest, destination)) {
                    return TravelResult.denied("guest_evacuation_failed:" + session.guestId());
                }
                runtime.domainPresence().completeGuestEvacuation(ownerId, session.guestId());
            }
            return TravelResult.noop("guests_evacuated");
        } finally {
            tracker.setPendingTransits(ownerId, previousPending);
        }
    }

    /**
     * Reconcile an owner who was moved out of their Domain by a command/another mod instead of V.
     * The owner is already outside, so only guests, recall state and Domain lifecycle are touched.
     */
    public TravelResult handleExternalOwnerDeparture(MinecraftServer server, UUID ownerId) {
        Objects.requireNonNull(server, "server");
        Objects.requireNonNull(ownerId, "ownerId");
        TravelResult evacuation = evacuateGuestsForOwner(server, ownerId);
        if (!evacuation.success()) return evacuation;

        runtime.ownerTravel().completeExit(ownerId);
        DomainRuntimeTracker tracker = runtime.domainRuntime();
        tracker.setOwnerInside(ownerId, false);
        domainLevels.liveLevel(server, ownerId).ifPresent(level -> tracker.setPlayersInside(ownerId, level.players().size()));
        NeoForgeDomainLevelService.UnloadResult unload = domainLevels.unloadIfSafe(server, ownerId);
        return TravelResult.externalDeparture(unload.reason());
    }

    public static ReturnAnchor capture(ServerPlayer player) {
        Objects.requireNonNull(player, "player");
        return new ReturnAnchor(
                player.level().dimension().identifier().toString(),
                player.getX(), player.getY(), player.getZ(), player.getYRot(), player.getXRot());
    }

    private static boolean teleport(
            ServerPlayer player,
            NeoForgeReturnAnchorResolver.ResolvedReturn destination) {
        return NeoForgeTransitGuard.run(player.getUUID(), () -> player.teleportTo(
                destination.level(), destination.x(), destination.y(), destination.z(), Set.<Relative>of(),
                destination.yaw(), destination.pitch(), true));
    }

    public record TravelResult(
            boolean success,
            boolean entered,
            boolean domainCreated,
            NeoForgeReturnAnchorResolver.Resolution returnResolution,
            String unloadReason,
            String reason) {
        static TravelResult denied(String reason) {
            return new TravelResult(false, false, false, null, null, reason);
        }
        static TravelResult entered(boolean created) {
            return new TravelResult(true, true, created, null, null, "ok");
        }
        static TravelResult exited(NeoForgeReturnAnchorResolver.Resolution resolution, String unloadReason) {
            return new TravelResult(true, false, false, resolution, unloadReason, "ok");
        }
        static TravelResult guestExited(NeoForgeReturnAnchorResolver.Resolution resolution, String detail) {
            return new TravelResult(true, false, false, resolution, null, detail);
        }
        static TravelResult noop(String detail) {
            return new TravelResult(true, false, false, null, null, detail);
        }
        static TravelResult externalDeparture(String unloadReason) {
            return new TravelResult(true, false, false, null, unloadReason, "external_departure");
        }
    }
}
