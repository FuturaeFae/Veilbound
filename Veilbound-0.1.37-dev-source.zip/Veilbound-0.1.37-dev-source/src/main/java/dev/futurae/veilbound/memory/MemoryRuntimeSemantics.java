package dev.futurae.veilbound.memory;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Typed interpretation of the built-in Memory profile contract.
 *
 * <p>Unknown profile keys and unknown values are retained in the raw visual/mechanic maps but are
 * deliberately inert in the base mod. This keeps third-party profile extensions data-compatible
 * without Veilbound guessing what an add-on's identifier is supposed to do.</p>
 */
public final class MemoryRuntimeSemantics {
    public Snapshot snapshot(Map<String, String> environmentalProfile) {
        Objects.requireNonNull(environmentalProfile, "environmentalProfile");
        LinkedHashMap<String, String> visual = new LinkedHashMap<>();
        LinkedHashMap<String, String> mechanic = new LinkedHashMap<>();
        for (Map.Entry<String, String> entry : environmentalProfile.entrySet()) {
            if (entry.getKey().startsWith("visual.")) visual.put(entry.getKey(), entry.getValue());
            else if (entry.getKey().startsWith("mechanic.")) mechanic.put(entry.getKey(), entry.getValue());
        }
        return new Snapshot(
                matches(visual, MemoryEffectIds.VISUAL_SKY, MemoryEffectIds.OPEN_SKY),
                matches(mechanic, MemoryEffectIds.MECHANIC_ILLUMINATION, MemoryEffectIds.NATURAL_DAYLIGHT),
                matches(visual, MemoryEffectIds.VISUAL_WEATHER, MemoryEffectIds.GENTLE_RAIN),
                matches(mechanic, MemoryEffectIds.MECHANIC_WEATHER, MemoryEffectIds.RAIN),
                matches(mechanic, MemoryEffectIds.MECHANIC_FERTILITY, MemoryEffectIds.VERDANT),
                matches(visual, MemoryEffectIds.VISUAL_FLORA, MemoryEffectIds.VERDANT),
                matches(visual, MemoryEffectIds.VISUAL_CELESTIAL_CYCLE, MemoryEffectIds.OVERWORLD),
                matches(mechanic, MemoryEffectIds.MECHANIC_DAY_CYCLE, MemoryEffectIds.OVERWORLD),
                visual,
                mechanic);
    }

    private static boolean matches(Map<String, String> profile, String key, String value) {
        return value.equals(profile.get(key));
    }

    public record Snapshot(
            boolean openSky,
            boolean naturalDaylight,
            boolean gentleRainVisual,
            boolean rainWeather,
            boolean verdantFertility,
            boolean verdantFloraVisual,
            boolean overworldCelestialCycle,
            boolean overworldDayCycle,
            Map<String, String> visualProfile,
            Map<String, String> mechanicProfile) {
        public Snapshot {
            visualProfile = Collections.unmodifiableMap(new LinkedHashMap<>(visualProfile));
            mechanicProfile = Collections.unmodifiableMap(new LinkedHashMap<>(mechanicProfile));
        }

        /**
         * Higher-order weather/celestial Memories require Open Sky to be earned, but the current
         * physical Orrery selects one Memory at a time. Treat those visible profiles as carrying
         * their prerequisite firmament for rendering without silently activating Open Sky's
         * separate mechanical illumination profile.
         */
        public boolean visibleFirmament() {
            return openSky || gentleRainVisual || overworldCelestialCycle;
        }

        public static Snapshot empty() {
            return new Snapshot(false, false, false, false, false, false, false, false, Map.of(), Map.of());
        }
    }
}
