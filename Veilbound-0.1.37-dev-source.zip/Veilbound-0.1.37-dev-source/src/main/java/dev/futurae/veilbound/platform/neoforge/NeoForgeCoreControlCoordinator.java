package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.domain.CoreControlService;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.network.DomainControlsSnapshotPayload;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import dev.futurae.veilbound.registry.VeilboundItems;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.Objects;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * Implements the settled physical Core controls.
 *
 * <p>Empty-hand normal use toggles global expansion. Sneak + empty-hand use opens the detailed
 * Domain Controls screen. The Core stores Dimensional Energy only; it has no Matter intake path.</p>
 */
public final class NeoForgeCoreControlCoordinator {
    private final VeilboundRuntime runtime;
    private final NeoForgeDomainControlsController controls;

    public NeoForgeCoreControlCoordinator(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        this.controls = new NeoForgeDomainControlsController(runtime);
    }

    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.isCanceled() || !(event.getEntity() instanceof ServerPlayer player) || event.getLevel().isClientSide()) return;
        if (!event.getLevel().getBlockState(event.getPos()).is(VeilboundBlocks.DIMENSIONAL_CORE.get())) return;

        boolean emptyHand = event.getItemStack().isEmpty();
        boolean lens = event.getItemStack().is(VeilboundItems.RESONANCE_LENS.get());
        if (!emptyHand && !lens) return;

        DomainRecord record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        DomainPosition clicked = new DomainPosition(event.getPos().getX(), event.getPos().getY(), event.getPos().getZ());
        if (record == null
                || !record.identity().dimensionId().equals(event.getLevel().dimension().identifier().toString())
                || !record.state().corePosition().equals(clicked)) {
            player.displayClientMessage(Component.translatable("message.veilbound.core_controls.not_owner_core"), true);
            consume(event, InteractionResult.FAIL);
            return;
        }
        if (!record.state().coreActive()) {
            player.displayClientMessage(Component.translatable("message.veilbound.core_controls.core_inactive"), true);
            consume(event, InteractionResult.FAIL);
            return;
        }

        if (lens) {
            controls.open(player, DomainControlsSnapshotPayload.View.CORE);
            consume(event, InteractionResult.SUCCESS);
            return;
        }

        if (player.isShiftKeyDown()) {
            controls.open(player, DomainControlsSnapshotPayload.View.CORE);
            consume(event, InteractionResult.SUCCESS);
            return;
        }

        CoreControlService.ToggleResult result = CoreControlService.toggleExpansion(record.state());
        if (!result.toggled()) {
            player.displayClientMessage(Component.translatable("message.veilbound.core_controls." + result.reason()), true);
            consume(event, InteractionResult.FAIL);
            return;
        }

        String key = result.enabled()
                ? "message.veilbound.core_controls.expansion_on"
                : "message.veilbound.core_controls.expansion_off";
        player.displayClientMessage(Component.translatable(key), true);
        consume(event, InteractionResult.SUCCESS);
    }

    private static void consume(PlayerInteractEvent.RightClickBlock event, InteractionResult result) {
        event.setCancellationResult(result);
        event.setCanceled(true);
    }
}
