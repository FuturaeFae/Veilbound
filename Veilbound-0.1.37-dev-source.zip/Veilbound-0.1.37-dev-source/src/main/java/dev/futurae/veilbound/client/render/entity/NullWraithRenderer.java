package dev.futurae.veilbound.client.render.entity;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.VexRenderer;
import net.minecraft.client.renderer.entity.state.VexRenderState;
import net.minecraft.resources.Identifier;

/** Dedicated Null Wraith skin over the inherited phasing/flying Vex silhouette. */
public final class NullWraithRenderer extends VexRenderer {
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "textures/entity/breach/null_wraith.png");
    public NullWraithRenderer(EntityRendererProvider.Context context) { super(context); }
    @Override public Identifier getTextureLocation(VexRenderState state) { return TEXTURE; }
}
