package dev.futurae.veilbound.energy;

/** Reloadable machine cadence/buffer limits plus physical Matter+FE -> Dimensional Energy ratio. */
public record TransductionRuntimePolicy(
        int cycleTicks,
        int forgeEnergyCapacity,
        int maxForgeEnergyInput,
        long matterCapacity,
        TransductionPolicy conversion) {

    /** Development defaults only; authoritative balance remains datapack-reloadable. */
    public static final TransductionRuntimePolicy DEVELOPMENT_DEFAULT =
            new TransductionRuntimePolicy(20, 1_000_000, 100_000, 32_000_000L, new TransductionPolicy(3L, 32L));

    public TransductionRuntimePolicy {
        if (cycleTicks < 1) throw new IllegalArgumentException("cycleTicks must be >= 1");
        if (forgeEnergyCapacity < 1) throw new IllegalArgumentException("forgeEnergyCapacity must be >= 1");
        if (maxForgeEnergyInput < 1) throw new IllegalArgumentException("maxForgeEnergyInput must be >= 1");
        if (maxForgeEnergyInput > forgeEnergyCapacity) throw new IllegalArgumentException("maxForgeEnergyInput may not exceed capacity");
        if (matterCapacity < 1) throw new IllegalArgumentException("matterCapacity must be >= 1");
        if (conversion == null) throw new IllegalArgumentException("conversion may not be null");
    }
}
