package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.matter.MatterPatternPageService;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Requests one bounded page of the server-built Veil crafting catalog. */
public record VeilCraftablesRequestPayload(
        boolean allCrafts,
        int page,
        String query,
        MatterPatternPageService.SortMode sortMode) implements CustomPacketPayload {
    public static final int MAX_QUERY_LENGTH = 64;
    public static final Type<VeilCraftablesRequestPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "veil_craftables_request"));

    public static final StreamCodec<RegistryFriendlyByteBuf, VeilCraftablesRequestPayload> STREAM_CODEC =
            new StreamCodec<>() {
                @Override
                public VeilCraftablesRequestPayload decode(RegistryFriendlyByteBuf buffer) {
                    boolean all = buffer.readBoolean();
                    int page = Math.max(0, buffer.readVarInt());
                    String query = buffer.readUtf(MAX_QUERY_LENGTH);
                    int sortOrdinal = buffer.readVarInt();
                    MatterPatternPageService.SortMode[] values = MatterPatternPageService.SortMode.values();
                    MatterPatternPageService.SortMode sort = sortOrdinal >= 0 && sortOrdinal < values.length
                            ? values[sortOrdinal] : MatterPatternPageService.SortMode.NAME_ASC;
                    return new VeilCraftablesRequestPayload(all, page, query, sort);
                }

                @Override
                public void encode(RegistryFriendlyByteBuf buffer, VeilCraftablesRequestPayload payload) {
                    buffer.writeBoolean(payload.allCrafts());
                    buffer.writeVarInt(payload.page());
                    buffer.writeUtf(payload.query(), MAX_QUERY_LENGTH);
                    buffer.writeVarInt(payload.sortMode().ordinal());
                }
            };

    public VeilCraftablesRequestPayload {
        page = Math.max(0, page);
        query = query == null ? "" : query.trim();
        if (query.length() > MAX_QUERY_LENGTH) query = query.substring(0, MAX_QUERY_LENGTH);
        if (sortMode == null) sortMode = MatterPatternPageService.SortMode.NAME_ASC;
    }

    /** Compatibility constructor for 0.1.17 callers. */
    public VeilCraftablesRequestPayload(boolean allCrafts, int page) {
        this(allCrafts, page, "", MatterPatternPageService.SortMode.NAME_ASC);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
