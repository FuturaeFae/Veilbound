package dev.futurae.veilbound.domain;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.LongSupplier;

/** One persisted Domain record per owner. Backing storage is supplied by the NeoForge SavedData layer. */
public final class DomainRepository {
    private final Map<UUID, DomainRecord> byOwner = new LinkedHashMap<>();
    private Runnable mutationListener = () -> {};
    private LongSupplier seedSupplier = () -> java.util.concurrent.ThreadLocalRandom.current().nextLong();

    /** Compatibility creation path. Runtime code should use createRecord when it needs the identity. */
    public DomainState create(UUID ownerId) {
        return createRecord(ownerId, seedSupplier.getAsLong()).state();
    }

    public DomainRecord createRecord(UUID ownerId) {
        return createRecord(ownerId, seedSupplier.getAsLong());
    }

    public DomainRecord createRecord(UUID ownerId, long seed) {
        Objects.requireNonNull(ownerId, "ownerId");
        if (byOwner.containsKey(ownerId)) throw new IllegalStateException("Owner already has a Domain");
        DomainRecord record = new DomainRecord(DomainIdentity.create(ownerId, seed), new DomainState(ownerId));
        attach(record);
        byOwner.put(ownerId, record);
        changed();
        return record;
    }

    public DomainState getOrCreate(UUID ownerId) {
        DomainRecord existing = byOwner.get(Objects.requireNonNull(ownerId));
        return existing != null ? existing.state() : create(ownerId);
    }

    public Optional<DomainState> get(UUID ownerId) {
        DomainRecord record = byOwner.get(ownerId);
        return record == null ? Optional.empty() : Optional.of(record.state());
    }

    public Optional<DomainRecord> getRecord(UUID ownerId) { return Optional.ofNullable(byOwner.get(ownerId)); }
    public Collection<DomainState> all() { return byOwner.values().stream().map(DomainRecord::state).toList(); }
    public Collection<DomainRecord> records() { return List.copyOf(byOwner.values()); }

    /** Domain deletion is intentionally unavailable to ordinary player actions. */
    public DeleteResult delete(UUID ownerId, boolean actorIsAdministrator) {
        if (!actorIsAdministrator) return DeleteResult.denied("administrator_required");
        DomainRecord removed = byOwner.remove(ownerId);
        if (removed == null) return DeleteResult.denied("domain_not_found");
        changed();
        return DeleteResult.allowed(ownerId);
    }

    public void replaceRecordsFromPersistence(Collection<DomainRecord> records) {
        byOwner.clear();
        for (DomainRecord record : records) {
            if (byOwner.put(record.ownerId(), record) != null) {
                throw new IllegalArgumentException("Duplicate Domain owner in persistence: " + record.ownerId());
            }
            attach(record);
        }
    }

    /** Compatibility loader for older snapshots that predate persisted dimension identity/seed. */
    public void replaceFromPersistence(Collection<DomainState> states) {
        byOwner.clear();
        for (DomainState state : states) {
            DomainRecord record = new DomainRecord(DomainIdentity.create(state.ownerId(), stableLegacySeed(state.ownerId())), state);
            if (byOwner.put(state.ownerId(), record) != null) {
                throw new IllegalArgumentException("Duplicate Domain owner in persistence: " + state.ownerId());
            }
            attach(record);
        }
    }

    public void setMutationListener(Runnable listener) {
        this.mutationListener = Objects.requireNonNull(listener, "listener");
        for (DomainRecord record : byOwner.values()) attach(record);
    }

    public void setSeedSupplier(LongSupplier seedSupplier) {
        this.seedSupplier = Objects.requireNonNull(seedSupplier, "seedSupplier");
    }

    private void attach(DomainRecord record) { record.setMutationListener(this::changed); }
    private void changed() { mutationListener.run(); }

    private static long stableLegacySeed(UUID ownerId) {
        long x = ownerId.getMostSignificantBits() ^ Long.rotateLeft(ownerId.getLeastSignificantBits(), 17);
        x ^= (x >>> 33);
        x *= 0xff51afd7ed558ccdl;
        x ^= (x >>> 33);
        x *= 0xc4ceb9fe1a85ec53l;
        return x ^ (x >>> 33);
    }

    public record DeleteResult(boolean deleted, UUID ownerId, String reason) {
        public static DeleteResult denied(String reason) { return new DeleteResult(false, null, reason); }
        public static DeleteResult allowed(UUID owner) { return new DeleteResult(true, owner, "ok"); }
    }
}
