package dev.futurae.veilbound.energy;

import dev.futurae.veilbound.domain.DomainState;
import java.util.Objects;

/**
 * Converts Transducer-local Matter plus FE into DE and wirelessly inserts it into the Core.
 * Matter never enters or remains stored by the Core itself, and Veil Inventory Matter is never
 * consulted by this machine.
 */
public final class DimensionalTransducer {
    private DimensionalTransducer() {}

    public static Plan plan(
            DomainState targetDomain,
            long offeredMatter,
            long availableForgeEnergy,
            TransductionPolicy policy,
            boolean ownerOnline) {
        Objects.requireNonNull(targetDomain, "targetDomain");
        Objects.requireNonNull(policy, "policy");
        if (!ownerOnline) return Plan.denied("owner_offline");
        if (!targetDomain.coreActive()) return Plan.denied("core_inactive");
        if (offeredMatter <= 0) return Plan.denied("no_matter");
        if (availableForgeEnergy < 0) return Plan.denied("invalid_forge_energy");

        long matterPerDe = policy.matterPerDimensionalEnergy();
        long maxByFe = policy.forgeEnergyPerMatter() == 0
                ? offeredMatter
                : availableForgeEnergy / policy.forgeEnergyPerMatter();
        long coreSpace = targetDomain.coreTier().dimensionalEnergyCapacity() - targetDomain.dimensionalEnergy();
        long maxByCore = saturatedMultiply(coreSpace, matterPerDe);
        long availableMatter = Math.min(offeredMatter, Math.min(maxByFe, maxByCore));
        long deProduced = availableMatter / matterPerDe;
        if (deProduced <= 0) {
            if (coreSpace <= 0) return Plan.denied("core_full");
            if (maxByFe < matterPerDe) return Plan.denied("insufficient_forge_energy");
            return Plan.denied("insufficient_matter");
        }

        try {
            long matterConsumed = Math.multiplyExact(deProduced, matterPerDe);
            long feConsumed = Math.multiplyExact(matterConsumed, policy.forgeEnergyPerMatter());
            return Plan.allowed(matterConsumed, feConsumed, deProduced);
        } catch (ArithmeticException overflow) {
            return Plan.denied("conversion_overflow");
        }
    }

    public static Result transduce(
            DomainState targetDomain,
            long offeredMatter,
            long availableForgeEnergy,
            TransductionPolicy policy,
            boolean ownerOnline) {
        Plan plan = plan(targetDomain, offeredMatter, availableForgeEnergy, policy, ownerOnline);
        if (!plan.allowed()) return Result.denied(plan.reason());
        long accepted = targetDomain.insertDimensionalEnergy(plan.dimensionalEnergyProduced());
        if (accepted != plan.dimensionalEnergyProduced()) return Result.denied("core_capacity_changed");
        return Result.allowed(plan.matterConsumed(), plan.forgeEnergyConsumed(), plan.dimensionalEnergyProduced());
    }

    private static long saturatedMultiply(long a, long b) {
        if (a <= 0 || b <= 0) return 0;
        if (a > Long.MAX_VALUE / b) return Long.MAX_VALUE;
        return a * b;
    }

    public record Plan(
            boolean allowed, long matterConsumed, long forgeEnergyConsumed, long dimensionalEnergyProduced, String reason) {
        public static Plan denied(String reason) { return new Plan(false, 0L, 0L, 0L, reason); }
        public static Plan allowed(long matter, long fe, long de) { return new Plan(true, matter, fe, de, "ok"); }
    }

    public record Result(
            boolean converted,
            long matterConsumed,
            long forgeEnergyConsumed,
            long dimensionalEnergyProduced,
            String reason) {
        public static Result denied(String reason) { return new Result(false, 0, 0, 0, reason); }
        public static Result allowed(long matter, long fe, long de) { return new Result(true, matter, fe, de, "ok"); }
    }
}
