package dev.futurae.veilbound.registry;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.item.VoidAnchorBlockItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Settled Veilbound tools/devices. Gameplay behavior is attached in vertical slices. */
public final class VeilboundItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(Veilbound.MOD_ID);

    public static final DeferredItem<BlockItem> DIMENSIONAL_CORE = ITEMS.registerSimpleBlockItem(VeilboundBlocks.DIMENSIONAL_CORE);
    public static final DeferredItem<BlockItem> DIMENSIONAL_TRANSDUCER = ITEMS.registerSimpleBlockItem(VeilboundBlocks.DIMENSIONAL_TRANSDUCER);
    public static final DeferredItem<BlockItem> BOUNDARY_PYLON = ITEMS.registerSimpleBlockItem(VeilboundBlocks.BOUNDARY_PYLON);
    public static final DeferredItem<BlockItem> DOMAIN_ORRERY = ITEMS.registerSimpleBlockItem(VeilboundBlocks.DOMAIN_ORRERY);
    public static final DeferredItem<BlockItem> MEMORY_ARCHIVE = ITEMS.registerSimpleBlockItem(VeilboundBlocks.MEMORY_ARCHIVE);
    public static final DeferredItem<BlockItem> AXIOM_MONOLITH = ITEMS.registerSimpleBlockItem(VeilboundBlocks.AXIOM_MONOLITH);
    /** Law-specific Axiom items are consumed once to permanently attune a fresh Axiom Monolith. */
    public static final DeferredItem<Item> AXIOM_OF_HOSTILITY = ITEMS.registerSimpleItem("axiom_of_hostility");
    public static final DeferredItem<Item> AXIOM_OF_FAUNA = ITEMS.registerSimpleItem("axiom_of_fauna");
    public static final DeferredItem<Item> AXIOM_OF_FLAME = ITEMS.registerSimpleItem("axiom_of_flame");
    public static final DeferredItem<Item> AXIOM_OF_RUIN = ITEMS.registerSimpleItem("axiom_of_ruin");
    public static final DeferredItem<Item> AXIOM_OF_GRIEF = ITEMS.registerSimpleItem("axiom_of_grief");
    public static final DeferredItem<Item> AXIOM_OF_CONFLICT = ITEMS.registerSimpleItem("axiom_of_conflict");
    public static final DeferredItem<Item> AXIOM_OF_DESCENT = ITEMS.registerSimpleItem("axiom_of_descent");
    public static final DeferredItem<Item> AXIOM_OF_PRESERVATION = ITEMS.registerSimpleItem("axiom_of_preservation");
    public static final DeferredItem<Item> AXIOM_OF_TIME = ITEMS.registerSimpleItem("axiom_of_time");
    public static final DeferredItem<Item> AXIOM_OF_WEATHER = ITEMS.registerSimpleItem("axiom_of_weather");
    public static final DeferredItem<BlockItem> CONTINUITY_ANCHOR = ITEMS.registerSimpleBlockItem(VeilboundBlocks.CONTINUITY_ANCHOR);
    public static final DeferredItem<BlockItem> THRESHOLD_FRAME = ITEMS.registerSimpleBlockItem(VeilboundBlocks.THRESHOLD_FRAME);
    public static final DeferredItem<BlockItem> VEIL_INTERFACE = ITEMS.registerSimpleBlockItem(VeilboundBlocks.VEIL_INTERFACE);

    /** Fed to a Resonant-or-better Core to unlock owner-only wireless digital storage. */
    public static final DeferredItem<Item> VEIL_INVENTORY_UPGRADE = ITEMS.registerSimpleItem("veil_inventory_upgrade");
    /** Fed to the Core after Veil Inventory to unlock wireless crafting against stored contents. */
    public static final DeferredItem<Item> VEIL_CRAFTING_UPGRADE = ITEMS.registerSimpleItem("veil_crafting_upgrade");
    /** Adds native Matter storage/pattern transmutation to the Veil Inventory crafting terminal. */
    public static final DeferredItem<Item> VEIL_TRANSMUTATION_UPGRADE = ITEMS.registerSimpleItem("veil_transmutation_upgrade");

    /** One-use ritual item that binds exactly one personal Domain to the player. */
    public static final DeferredItem<Item> GENESIS_SEED = ITEMS.registerSimpleItem("genesis_seed");

    /** Handheld pre-Core Matter + FE generator with persistent FE and Condensed Charge. */
    public static final DeferredItem<Item> SPATIAL_GENERATOR = ITEMS.registerItem(
            "spatial_generator", properties -> new Item(properties.stacksTo(1)
                    .component(VeilboundDataComponents.SPATIAL_GENERATOR_FE.get(), 0)
                    .component(VeilboundDataComponents.SPATIAL_GENERATOR_CHARGE.get(), 0L)));
    /** Consumed with 50,000 Condensed Charge by the fixed origin Core-awakening ritual. */
    public static final DeferredItem<Item> NUCLEUS_CATALYST = ITEMS.registerSimpleItem("nucleus_catalyst");
    /** Air-placeable reusable construction foothold. */
    public static final DeferredItem<VoidAnchorBlockItem> VOID_ANCHOR = ITEMS.registerItem(
            "void_anchor", properties -> new VoidAnchorBlockItem(VeilboundBlocks.VOID_ANCHOR.get(), properties.useBlockDescriptionPrefix()));
    /** Captures an eligible environmental Memory before it is stored/selected through the Archive. */
    public static final DeferredItem<Item> MNEMONIC_VESSEL = ITEMS.registerItem(
            "mnemonic_vessel", properties -> new Item(properties.stacksTo(1)));
    /** Informational scanner and in-world selection/preview tool. */
    public static final DeferredItem<Item> RESONANCE_LENS = ITEMS.registerSimpleItem("resonance_lens");
    /** DE-consuming breach-sealing tool. */
    public static final DeferredItem<Item> VEIL_STITCHER = ITEMS.registerSimpleItem("veil_stitcher");


    // Dimensional engineering resources, machines, and manufactured materials.
    public static final DeferredItem<BlockItem> RESONANT_ORE = ITEMS.registerSimpleBlockItem(VeilboundBlocks.RESONANT_ORE);
    public static final DeferredItem<BlockItem> PHASE_ORE = ITEMS.registerSimpleBlockItem(VeilboundBlocks.PHASE_ORE);
    public static final DeferredItem<BlockItem> MNEMONIC_CRYSTAL_ORE = ITEMS.registerSimpleBlockItem(VeilboundBlocks.MNEMONIC_CRYSTAL_ORE);
    public static final DeferredItem<BlockItem> CAUSALITE_ORE = ITEMS.registerSimpleBlockItem(VeilboundBlocks.CAUSALITE_ORE);
    public static final DeferredItem<BlockItem> AXIOMITE_ORE = ITEMS.registerSimpleBlockItem(VeilboundBlocks.AXIOMITE_ORE);
    public static final DeferredItem<BlockItem> PARADOX_ORE = ITEMS.registerSimpleBlockItem(VeilboundBlocks.PARADOX_ORE);
    public static final DeferredItem<BlockItem> DIMENSIONAL_FABRICATOR = ITEMS.registerSimpleBlockItem(VeilboundBlocks.DIMENSIONAL_FABRICATOR);
    public static final DeferredItem<BlockItem> VEIL_FOUNDRY = ITEMS.registerSimpleBlockItem(VeilboundBlocks.VEIL_FOUNDRY);
    public static final DeferredItem<BlockItem> PROBABILITY_VANE = ITEMS.registerSimpleBlockItem(VeilboundBlocks.PROBABILITY_VANE);
    public static final DeferredItem<BlockItem> ONTOLOGICAL_HARVESTER = ITEMS.registerSimpleBlockItem(VeilboundBlocks.ONTOLOGICAL_HARVESTER);
    public static final DeferredItem<BlockItem> ONTOLOGICAL_COMPILER = ITEMS.registerSimpleBlockItem(VeilboundBlocks.ONTOLOGICAL_COMPILER);
    public static final DeferredItem<BlockItem> VEIL_LANCE = ITEMS.registerSimpleBlockItem(VeilboundBlocks.VEIL_LANCE);
    public static final DeferredItem<BlockItem> FOLDED_MATTER_BLOCK = ITEMS.registerSimpleBlockItem(VeilboundBlocks.FOLDED_MATTER_BLOCK);
    public static final DeferredItem<BlockItem> CAUSAL_STEEL_BLOCK = ITEMS.registerSimpleBlockItem(VeilboundBlocks.CAUSAL_STEEL_BLOCK);
    public static final DeferredItem<BlockItem> AXIOMATIC_GLASS_BLOCK = ITEMS.registerSimpleBlockItem(VeilboundBlocks.AXIOMATIC_GLASS_BLOCK);
    public static final DeferredItem<BlockItem> CONTINUITY_CRYSTAL_BLOCK = ITEMS.registerSimpleBlockItem(VeilboundBlocks.CONTINUITY_CRYSTAL_BLOCK);
    public static final DeferredItem<BlockItem> SOVEREIGN_ALLOY_BLOCK = ITEMS.registerSimpleBlockItem(VeilboundBlocks.SOVEREIGN_ALLOY_BLOCK);
    public static final DeferredItem<BlockItem> WORLDLINE_LATTICE_BLOCK = ITEMS.registerSimpleBlockItem(VeilboundBlocks.WORLDLINE_LATTICE_BLOCK);
    public static final DeferredItem<BlockItem> PARADOX_CONTAINMENT_BLOCK = ITEMS.registerSimpleBlockItem(VeilboundBlocks.PARADOX_CONTAINMENT_BLOCK);
    public static final DeferredItem<BlockItem> SOVEREIGN_CONDUIT_BLOCK = ITEMS.registerSimpleBlockItem(VeilboundBlocks.SOVEREIGN_CONDUIT_BLOCK);
    public static final DeferredItem<BlockItem> CROWNED_SINGULARITY_BLOCK = ITEMS.registerSimpleBlockItem(VeilboundBlocks.CROWNED_SINGULARITY_BLOCK);
    public static final DeferredItem<Item> RESONANT_CRYSTAL = ITEMS.registerSimpleItem("resonant_crystal");
    public static final DeferredItem<Item> PHASE_CRYSTAL = ITEMS.registerSimpleItem("phase_crystal");
    public static final DeferredItem<Item> MNEMONIC_CRYSTAL = ITEMS.registerSimpleItem("mnemonic_crystal");
    public static final DeferredItem<Item> CAUSALITE_SHARD = ITEMS.registerSimpleItem("causalite_shard");
    public static final DeferredItem<Item> AXIOMITE_SHARD = ITEMS.registerSimpleItem("axiomite_shard");
    public static final DeferredItem<Item> PARADOX_CRYSTAL = ITEMS.registerSimpleItem("paradox_crystal");
    public static final DeferredItem<Item> VEIL_RESIDUE = ITEMS.registerSimpleItem("veil_residue");
    public static final DeferredItem<Item> FRACTURED_ESSENCE = ITEMS.registerSimpleItem("fractured_essence");
    public static final DeferredItem<Item> CAUSAL_SHARD = ITEMS.registerSimpleItem("causal_shard");
    public static final DeferredItem<Item> UNRESOLVED_MATTER = ITEMS.registerSimpleItem("unresolved_matter");
    public static final DeferredItem<Item> RESONANT_FRAME_SEGMENT = ITEMS.registerSimpleItem("resonant_frame_segment");
    public static final DeferredItem<Item> PHASE_LOGIC_ARRAY = ITEMS.registerSimpleItem("phase_logic_array");
    public static final DeferredItem<Item> DIMENSIONAL_CAPACITOR = ITEMS.registerSimpleItem("dimensional_capacitor");
    public static final DeferredItem<Item> PHASE_COIL = ITEMS.registerSimpleItem("phase_coil");
    public static final DeferredItem<Item> CAUSAL_LATTICE = ITEMS.registerSimpleItem("causal_lattice");
    public static final DeferredItem<Item> MNEMONIC_MATRIX = ITEMS.registerSimpleItem("mnemonic_matrix");
    public static final DeferredItem<Item> CONTINUITY_INDUCTOR = ITEMS.registerSimpleItem("continuity_inductor");
    public static final DeferredItem<Item> PATTERN_MATRIX = ITEMS.registerSimpleItem("pattern_matrix");
    public static final DeferredItem<Item> TRANSMUTATION_LATTICE = ITEMS.registerSimpleItem("transmutation_lattice");
    public static final DeferredItem<Item> MATERIAL_PHASE_REGULATOR = ITEMS.registerSimpleItem("material_phase_regulator");
    public static final DeferredItem<Item> BOUNDARY_SKELETON = ITEMS.registerSimpleItem("boundary_skeleton");
    public static final DeferredItem<Item> CAUSAL_PROCESSOR = ITEMS.registerSimpleItem("causal_processor");
    public static final DeferredItem<Item> AXIOMATIC_CONTROLLER = ITEMS.registerSimpleItem("axiomatic_controller");
    public static final DeferredItem<Item> LAW_KERNEL = ITEMS.registerSimpleItem("law_kernel");
    public static final DeferredItem<Item> ONTOLOGICAL_MATRIX = ITEMS.registerSimpleItem("ontological_matrix");
    public static final DeferredItem<Item> SINGULARITY_REGULATOR = ITEMS.registerSimpleItem("singularity_regulator");
    public static final DeferredItem<Item> FOLDED_SPACE_BRACE = ITEMS.registerSimpleItem("folded_space_brace");
    public static final DeferredItem<Item> TRANSCENDENT_FRAMEWORK = ITEMS.registerSimpleItem("transcendent_framework");
    public static final DeferredItem<Item> SOVEREIGN_COMPUTATION_CORE = ITEMS.registerSimpleItem("sovereign_computation_core");
    public static final DeferredItem<Item> CONTINUITY_SPINDLE = ITEMS.registerSimpleItem("continuity_spindle");
    public static final DeferredItem<Item> WORLDLINE_BEARING = ITEMS.registerSimpleItem("worldline_bearing");
    public static final DeferredItem<Item> AXIOM_BUS = ITEMS.registerSimpleItem("axiom_bus");
    public static final DeferredItem<Item> MNEMONIC_PRISM = ITEMS.registerSimpleItem("mnemonic_prism");
    public static final DeferredItem<Item> CAUSAL_MANIFOLD = ITEMS.registerSimpleItem("causal_manifold");
    public static final DeferredItem<Item> PARADOX_GOVERNOR = ITEMS.registerSimpleItem("paradox_governor");
    public static final DeferredItem<Item> HORIZON_LENS = ITEMS.registerSimpleItem("horizon_lens");
    public static final DeferredItem<Item> TRANSFINITE_LOGIC_ARRAY = ITEMS.registerSimpleItem("transfinite_logic_array");
    public static final DeferredItem<Item> REALITY_LATTICE = ITEMS.registerSimpleItem("reality_lattice");
    public static final DeferredItem<Item> DOMAIN_SPINE = ITEMS.registerSimpleItem("domain_spine");
    public static final DeferredItem<Item> SINGULARITY_CROWN = ITEMS.registerSimpleItem("singularity_crown");
    public static final DeferredItem<Item> INVARIANT_MESH = ITEMS.registerSimpleItem("invariant_mesh");
    public static final DeferredItem<Item> ONTOLOGY_PUMP = ITEMS.registerSimpleItem("ontology_pump");
    public static final DeferredItem<Item> PHASE_COMPRESSION_RING = ITEMS.registerSimpleItem("phase_compression_ring");
    public static final DeferredItem<Item> CONTINUITY_FLYWHEEL = ITEMS.registerSimpleItem("continuity_flywheel");
    public static final DeferredItem<Item> CAUSAL_CLOCK = ITEMS.registerSimpleItem("causal_clock");
    public static final DeferredItem<Item> AXIOM_SHUNT = ITEMS.registerSimpleItem("axiom_shunt");
    public static final DeferredItem<Item> MEMORY_REFRACTOR = ITEMS.registerSimpleItem("memory_refractor");
    public static final DeferredItem<Item> VOID_PRESSURE_REGULATOR = ITEMS.registerSimpleItem("void_pressure_regulator");
    public static final DeferredItem<Item> SOVEREIGN_SERVO = ITEMS.registerSimpleItem("sovereign_servo");
    public static final DeferredItem<Item> REGALIA_CORE = ITEMS.registerSimpleItem("regalia_core");
    public static final DeferredItem<Item> EVENTIDE_PLATE = ITEMS.registerSimpleItem("eventide_plate");
    public static final DeferredItem<Item> ABSOLUTE_BOUNDARY_NODE = ITEMS.registerSimpleItem("absolute_boundary_node");
    public static final DeferredItem<Item> FOLDED_MATTER = ITEMS.registerSimpleItem("folded_matter");
    public static final DeferredItem<Item> CAUSAL_STEEL = ITEMS.registerSimpleItem("causal_steel");
    public static final DeferredItem<Item> AXIOMATIC_GLASS = ITEMS.registerSimpleItem("axiomatic_glass");
    public static final DeferredItem<Item> CONTINUITY_CRYSTAL = ITEMS.registerSimpleItem("continuity_crystal");
    public static final DeferredItem<Item> SOVEREIGN_ALLOY = ITEMS.registerSimpleItem("sovereign_alloy");
    public static final DeferredItem<Item> ANCHORED_CORE_ASSEMBLY = ITEMS.registerSimpleItem("anchored_core_assembly");
    public static final DeferredItem<Item> RESONANT_CORE_ASSEMBLY = ITEMS.registerSimpleItem("resonant_core_assembly");
    public static final DeferredItem<Item> ASCENDANT_CORE_ASSEMBLY = ITEMS.registerSimpleItem("ascendant_core_assembly");
    public static final DeferredItem<Item> TRANSCENDENT_CORE_ASSEMBLY = ITEMS.registerSimpleItem("transcendent_core_assembly");
    public static final DeferredItem<Item> VEIL_ENGINEERING_CODEX = ITEMS.registerItem("veil_engineering_codex", p -> new Item(p.stacksTo(1)));
    public static final DeferredItem<Item> PHASEBREAKER = ITEMS.registerItem("phasebreaker", p -> new Item(p.stacksTo(1).durability(4096).pickaxe(ToolMaterial.NETHERITE, 2.0F, -2.6F).component(VeilboundDataComponents.VEIL_TOOL_MODE.get(), 0)));
    public static final DeferredItem<Item> RIFT_CUTTER = ITEMS.registerItem("rift_cutter", p -> new Item(p.stacksTo(1).durability(4096).sword(ToolMaterial.NETHERITE, 5.0F, -2.2F)));
    public static final DeferredItem<Item> BOUNDARY_SPADE = ITEMS.registerItem("boundary_spade", p -> new Item(p.stacksTo(1).durability(4096).shovel(ToolMaterial.NETHERITE, 2.5F, -2.8F)));
    public static final DeferredItem<Item> RESONANCE_MULTITOOL = ITEMS.registerItem("resonance_multitool", p -> new Item(p.stacksTo(1).durability(6144).pickaxe(ToolMaterial.NETHERITE, 1.0F, -2.4F)));
    public static final DeferredItem<Item> PHASEWEAVE_HELMET = ITEMS.registerItem("phaseweave_helmet", p -> new Item(p.humanoidArmor(VeilboundArmorMaterials.PHASEWEAVE, ArmorType.HELMET).durability(768)));
    public static final DeferredItem<Item> PHASEWEAVE_CHESTPLATE = ITEMS.registerItem("phaseweave_chestplate", p -> new Item(p.humanoidArmor(VeilboundArmorMaterials.PHASEWEAVE, ArmorType.CHESTPLATE).durability(1024)));
    public static final DeferredItem<Item> PHASEWEAVE_LEGGINGS = ITEMS.registerItem("phaseweave_leggings", p -> new Item(p.humanoidArmor(VeilboundArmorMaterials.PHASEWEAVE, ArmorType.LEGGINGS).durability(960)));
    public static final DeferredItem<Item> PHASEWEAVE_BOOTS = ITEMS.registerItem("phaseweave_boots", p -> new Item(p.humanoidArmor(VeilboundArmorMaterials.PHASEWEAVE, ArmorType.BOOTS).durability(832)));
    public static final DeferredItem<Item> CAUSAL_HELMET = ITEMS.registerItem("causal_helmet", p -> new Item(p.humanoidArmor(VeilboundArmorMaterials.CAUSAL, ArmorType.HELMET).durability(1280)));
    public static final DeferredItem<Item> CAUSAL_CHESTPLATE = ITEMS.registerItem("causal_chestplate", p -> new Item(p.humanoidArmor(VeilboundArmorMaterials.CAUSAL, ArmorType.CHESTPLATE).durability(1664)));
    public static final DeferredItem<Item> CAUSAL_LEGGINGS = ITEMS.registerItem("causal_leggings", p -> new Item(p.humanoidArmor(VeilboundArmorMaterials.CAUSAL, ArmorType.LEGGINGS).durability(1536)));
    public static final DeferredItem<Item> CAUSAL_BOOTS = ITEMS.registerItem("causal_boots", p -> new Item(p.humanoidArmor(VeilboundArmorMaterials.CAUSAL, ArmorType.BOOTS).durability(1408)));
    public static final DeferredItem<Item> SOVEREIGN_HELMET = ITEMS.registerItem("sovereign_helmet", p -> new Item(p.humanoidArmor(VeilboundArmorMaterials.SOVEREIGN, ArmorType.HELMET).durability(4096).fireResistant()));
    public static final DeferredItem<Item> SOVEREIGN_CHESTPLATE = ITEMS.registerItem("sovereign_chestplate", p -> new Item(p.humanoidArmor(VeilboundArmorMaterials.SOVEREIGN, ArmorType.CHESTPLATE).durability(5120).fireResistant()));
    public static final DeferredItem<Item> SOVEREIGN_LEGGINGS = ITEMS.registerItem("sovereign_leggings", p -> new Item(p.humanoidArmor(VeilboundArmorMaterials.SOVEREIGN, ArmorType.LEGGINGS).durability(4608).fireResistant()));
    public static final DeferredItem<Item> SOVEREIGN_BOOTS = ITEMS.registerItem("sovereign_boots", p -> new Item(p.humanoidArmor(VeilboundArmorMaterials.SOVEREIGN, ArmorType.BOOTS).durability(4352).fireResistant()));

    private VeilboundItems() {}

    public static void register(IEventBus modBus) {
        ITEMS.register(modBus);
    }
}
