package dev.futurae.veilbound.matter;

import java.util.List;

/**
 * Loader-neutral normalized recipe representation.
 * A NeoForge adapter converts recipes/recipe displays into this form.
 */
public record RecipeMatterModel(
        String recipeId,
        String recipeType,
        List<IngredientSlot> inputs,
        OutputStack primaryOutput,
        List<OutputStack> returnedOrByproductOutputs) {

    public RecipeMatterModel {
        inputs = List.copyOf(inputs);
        returnedOrByproductOutputs = List.copyOf(returnedOrByproductOutputs);
        if (primaryOutput.count() <= 0) throw new IllegalArgumentException("primary output count must be > 0");
    }

    public record IngredientSlot(List<ItemAmount> alternatives) {
        public IngredientSlot {
            alternatives = List.copyOf(alternatives);
            if (alternatives.isEmpty()) throw new IllegalArgumentException("ingredient alternatives may not be empty");
        }
    }

    public record ItemAmount(String itemId, int count) {
        public ItemAmount {
            if (count <= 0) throw new IllegalArgumentException("count must be > 0");
        }
    }

    public record OutputStack(String itemId, int count) {
        public OutputStack {
            if (count <= 0) throw new IllegalArgumentException("count must be > 0");
        }
    }
}
