package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.BoundaryPylonBindingService;
import dev.futurae.veilbound.domain.BoundaryPylonState;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.domain.ExpansionGovernor;
import dev.futurae.veilbound.domain.ExpansionRuntimePolicy;
import dev.futurae.veilbound.platform.neoforge.world.NeoForgeDomainLevelService;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** Executes independently paced moving-face Boundary Pylon expansion while owners are online. */
public final class NeoForgeExpansionCoordinator {
    private final VeilboundRuntime runtime;
    private final NeoForgeDomainLevelService domainLevels;
    private long ticks;

    public NeoForgeExpansionCoordinator(VeilboundRuntime runtime, NeoForgeDomainLevelService domainLevels) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        this.domainLevels = Objects.requireNonNull(domainLevels, "domainLevels");
    }

    public void onServerTick(ServerTickEvent.Post event) {
        ExpansionRuntimePolicy runtimePolicy = runtime.expansionPolicy().policy();
        ticks++;

        for (DomainRecord record : runtime.domains().records()) {
            boolean ownerOnline = runtime.domainRuntime().state(record.ownerId()).ownerOnline();
            if (!ownerOnline || !record.state().coreActive()) continue;
            ServerLevel level = domainLevels.liveLevel(event.getServer(), record.ownerId()).orElse(null);
            if (level == null) continue; // Expansion never wakes a dormant personal Domain.

            reconcilePylons(record, level);
            for (AxisDirection direction : AxisDirection.values()) {
                BoundaryPylonState pylon = record.state().pylons().get(direction);
                if (pylon == null || !pylon.online() || !pylon.expansionEnabled() || !pylon.bound()) continue;
                int interval = pylon.speed().intervalTicks(runtimePolicy.cycleTicks());
                if (ticks % interval != 0) continue;
                expandOne(record, level, direction, runtimePolicy);
            }
        }
    }

    private void expandOne(DomainRecord record, ServerLevel level, AxisDirection direction, ExpansionRuntimePolicy runtimePolicy) {
        var state = record.state();
        BoundaryPylonState pylon = state.pylons().get(direction);
        if (pylon == null || pylon.blockPosition() == null) return;

        if (BoundaryPylonBindingService.directionForFacePosition(state, pylon.blockPosition())
                .filter(direction::equals).isEmpty()) return; // Reconciliation failed; fail closed.

        ExpansionGovernor.ExpansionDecision decision =
                ExpansionGovernor.planOneBlock(state, direction, runtimePolicy.expansionPolicy(), true);
        if (!decision.allowed()) return;

        DomainPosition nextPylon;
        try { nextPylon = BoundaryPylonBindingService.advance(pylon.blockPosition(), direction); }
        catch (ArithmeticException overflow) { return; }
        BlockPos oldPos = blockPos(pylon.blockPosition());
        BlockPos newPos = blockPos(nextPylon);
        if (!level.getBlockState(oldPos).is(VeilboundBlocks.BOUNDARY_PYLON.get())) return;
        if (!level.getBlockState(newPos).isAir()) return; // Never overwrite owner/mod blocks at the new Veil face.

        if (!level.setBlockAndUpdate(newPos, VeilboundBlocks.BOUNDARY_PYLON.get().defaultBlockState())) return;
        if (!level.setBlockAndUpdate(oldPos, Blocks.AIR.defaultBlockState())) {
            level.setBlockAndUpdate(newPos, Blocks.AIR.defaultBlockState());
            return;
        }
        if (!ExpansionGovernor.apply(state, decision)) {
            // Defensive rollback; the server thread normally makes this unreachable after a valid plan.
            level.setBlockAndUpdate(newPos, Blocks.AIR.defaultBlockState());
            level.setBlockAndUpdate(oldPos, VeilboundBlocks.BOUNDARY_PYLON.get().defaultBlockState());
            return;
        }
        if (!BoundaryPylonBindingService.moveBoundPylon(state, direction, pylon.blockPosition(), nextPylon)) {
            Veilbound.LOGGER.error("Expanded Domain {} but failed to advance {} Boundary Pylon binding", record.ownerId(), direction);
        }
        seedVeilAccretions(record, level, direction, pylon.blockPosition());
    }

    /**
     * v11/v12 saves stored stationary in-bounds bindings. Reconcile them to the authoritative moving
     * face without deleting the owner's Pylon; if the target is obstructed, leave the face paused.
     */
    private void reconcilePylons(DomainRecord record, ServerLevel level) {
        var state = record.state();
        for (AxisDirection direction : AxisDirection.values()) {
            BoundaryPylonState pylon = state.pylons().get(direction);
            if (pylon == null || !pylon.bound() || pylon.blockPosition() == null) continue;
            if (BoundaryPylonBindingService.directionForFacePosition(state, pylon.blockPosition())
                    .filter(direction::equals).isPresent()) continue;
            DomainPosition expected;
            try { expected = BoundaryPylonBindingService.projectToFace(state, direction, pylon.blockPosition()); }
            catch (ArithmeticException overflow) { continue; }
            BlockPos oldPos = blockPos(pylon.blockPosition());
            BlockPos newPos = blockPos(expected);
            if (!level.getBlockState(oldPos).is(VeilboundBlocks.BOUNDARY_PYLON.get()) || !level.getBlockState(newPos).isAir()) {
                if (pylon.expansionEnabled()) state.setPylon(pylon.withExpansionEnabled(false));
                continue;
            }
            if (level.setBlockAndUpdate(newPos, VeilboundBlocks.BOUNDARY_PYLON.get().defaultBlockState())
                    && level.setBlockAndUpdate(oldPos, Blocks.AIR.defaultBlockState())) {
                state.setPylon(pylon.moveTo(expected));
            } else {
                level.setBlockAndUpdate(newPos, Blocks.AIR.defaultBlockState());
                if (pylon.expansionEnabled()) state.setPylon(pylon.withExpansionEnabled(false));
            }
        }
    }


    /**
     * Expansion exposes a fresh slice of the Veil. Sample only a bounded number of cells so very
     * large faces never turn one Pylon tick into a plane-sized scan. These are accretion nodes, not
     * conventional Overworld ore veins. Paradox Ore is deliberately excluded: Breaches create it.
     */
    private void seedVeilAccretions(DomainRecord record, ServerLevel level, AxisDirection direction, DomainPosition newSliceMarker) {
        var bounds = record.state().bounds();
        long area = switch (direction) {
            case POSITIVE_X, NEGATIVE_X -> (long) bounds.sizeY() * bounds.sizeZ();
            case POSITIVE_Y, NEGATIVE_Y -> (long) bounds.sizeX() * bounds.sizeZ();
            case POSITIVE_Z, NEGATIVE_Z -> (long) bounds.sizeX() * bounds.sizeY();
        };
        int attempts = Math.max(1, Math.min(8, 1 + (int) Math.sqrt(Math.max(1L, area)) / 16));
        java.util.concurrent.ThreadLocalRandom random = java.util.concurrent.ThreadLocalRandom.current();
        for (int i = 0; i < attempts; i++) {
            BlockPos pos = randomPointOnSlice(bounds, direction, newSliceMarker, random);
            if (!level.getBlockState(pos).isAir()) continue;
            int roll = random.nextInt(10_000);
            net.minecraft.world.level.block.Block ore = null;
            if (roll < 420) ore = VeilboundBlocks.RESONANT_ORE.get();
            else if (roll < 690) ore = VeilboundBlocks.PHASE_ORE.get();
            else if (roll < 850) ore = VeilboundBlocks.MNEMONIC_CRYSTAL_ORE.get();
            else if (roll < 950 && record.state().coreTier().ordinal() >= dev.futurae.veilbound.domain.CoreTier.RESONANT.ordinal()) ore = VeilboundBlocks.CAUSALITE_ORE.get();
            else if (roll < 990 && record.state().coreTier().ordinal() >= dev.futurae.veilbound.domain.CoreTier.ASCENDANT.ordinal()) ore = VeilboundBlocks.AXIOMITE_ORE.get();
            if (ore != null) level.setBlockAndUpdate(pos, ore.defaultBlockState());
        }
    }

    private static BlockPos randomPointOnSlice(dev.futurae.veilbound.domain.DomainBounds b, AxisDirection d, DomainPosition marker, java.util.concurrent.ThreadLocalRandom r) {
        int x = r.nextInt(b.minX(), b.maxX() + 1);
        int y = r.nextInt(b.minY(), b.maxY() + 1);
        int z = r.nextInt(b.minZ(), b.maxZ() + 1);
        return switch (d) {
            case POSITIVE_X, NEGATIVE_X -> new BlockPos(marker.x(), y, z);
            case POSITIVE_Y, NEGATIVE_Y -> new BlockPos(x, marker.y(), z);
            case POSITIVE_Z, NEGATIVE_Z -> new BlockPos(x, y, marker.z());
        };
    }

    private static BlockPos blockPos(DomainPosition p) { return new BlockPos(p.x(), p.y(), p.z()); }
}
