package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Owner requests from the Core/Pylon/Threshold management surface. */
public record DomainControlsActionPayload(Action action, String targetId, String value) implements CustomPacketPayload {
    public static final int MAX_TEXT = 128;

    public enum Action {
        OPEN_CORE,
        OPEN_PYLONS,
        OPEN_THRESHOLDS,
        TOGGLE_GLOBAL_EXPANSION,
        TOGGLE_PYLON,
        CYCLE_PYLON_SPEED,
        TOGGLE_THRESHOLD_PUBLIC,
        TOGGLE_THRESHOLD_INVITE
    }

    public static final Type<DomainControlsActionPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "domain_controls_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, DomainControlsActionPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override public DomainControlsActionPayload decode(RegistryFriendlyByteBuf buffer) {
            int ordinal = buffer.readVarInt();
            Action[] actions = Action.values();
            Action action = ordinal >= 0 && ordinal < actions.length ? actions[ordinal] : Action.OPEN_CORE;
            return new DomainControlsActionPayload(action, buffer.readUtf(MAX_TEXT), buffer.readUtf(MAX_TEXT));
        }

        @Override public void encode(RegistryFriendlyByteBuf buffer, DomainControlsActionPayload payload) {
            buffer.writeVarInt(payload.action().ordinal());
            buffer.writeUtf(payload.targetId(), MAX_TEXT);
            buffer.writeUtf(payload.value(), MAX_TEXT);
        }
    };

    public DomainControlsActionPayload {
        if (action == null) action = Action.OPEN_CORE;
        targetId = targetId == null ? "" : targetId;
        value = value == null ? "" : value;
        if (targetId.length() > MAX_TEXT) targetId = targetId.substring(0, MAX_TEXT);
        if (value.length() > MAX_TEXT) value = value.substring(0, MAX_TEXT);
    }

    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
