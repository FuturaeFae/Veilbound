package dev.futurae.veilbound.matter;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/** Deterministic paging/search/sort/filter for the Matter-backed learned-pattern terminal. */
public final class MatterPatternPageService {
    public static final int DEFAULT_PAGE_SIZE = 45;
    public static final int MAX_PAGE_SIZE = 90;

    /** Compatibility overload retained for existing callers/tests. */
    public Page page(
            Set<String> learnedItemIds,
            MatterCatalog catalog,
            long storedMatter,
            String query,
            SortMode sortMode,
            int requestedPage,
            int requestedPageSize) {
        return page(learnedItemIds, catalog, storedMatter, Set.of(), List.of(), Map.of(), query,
                sortMode, FilterMode.ALL, requestedPage, requestedPageSize);
    }

    public Page page(
            Set<String> learnedItemIds,
            MatterCatalog catalog,
            long storedMatter,
            Set<String> favorites,
            List<String> recents,
            Map<String, String> displayNames,
            String query,
            SortMode sortMode,
            FilterMode filterMode,
            int requestedPage,
            int requestedPageSize) {
        Objects.requireNonNull(learnedItemIds, "learnedItemIds");
        Objects.requireNonNull(catalog, "catalog");
        Objects.requireNonNull(favorites, "favorites");
        Objects.requireNonNull(recents, "recents");
        Objects.requireNonNull(displayNames, "displayNames");
        if (storedMatter < 0) throw new IllegalArgumentException("storedMatter must be >= 0");
        String normalizedQuery = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        SortMode mode = sortMode == null ? SortMode.NAME_ASC : sortMode;
        FilterMode filter = filterMode == null ? FilterMode.ALL : filterMode;
        int pageSize = Math.max(1, Math.min(MAX_PAGE_SIZE, requestedPageSize));

        Map<String, Integer> recentRank = new HashMap<>();
        for (int i = 0; i < recents.size(); i++) recentRank.putIfAbsent(recents.get(i), i);

        List<Entry> all = new ArrayList<>();
        for (String id : learnedItemIds) {
            if (!matchesFilter(id, favorites, recentRank, filter)) continue;
            String displayName = displayNames.getOrDefault(id, id);
            if (!matches(id, displayName, normalizedQuery)) continue;
            var resolved = catalog.amount(id);
            if (resolved.isEmpty() || resolved.getAsLong() <= 0) continue;
            long cost = resolved.getAsLong();
            all.add(new Entry(id, displayName, cost, storedMatter / cost, favorites.contains(id), recentRank.getOrDefault(id, Integer.MAX_VALUE)));
        }
        all.sort(comparator(mode, filter));

        int pageCount = Math.max(1, (all.size() + pageSize - 1) / pageSize);
        int page = Math.max(0, Math.min(requestedPage, pageCount - 1));
        int from = Math.min(all.size(), page * pageSize);
        int to = Math.min(all.size(), from + pageSize);
        return new Page(page, pageCount, pageSize, all.size(), storedMatter, List.copyOf(all.subList(from, to)));
    }

    private static boolean matchesFilter(String id, Set<String> favorites, Map<String, Integer> recentRank, FilterMode filter) {
        return switch (filter) {
            case ALL -> true;
            case FAVORITES -> favorites.contains(id);
            case RECENT -> recentRank.containsKey(id);
        };
    }

    private static boolean matches(String itemId, String displayName, String query) {
        if (query.isEmpty()) return true;
        String id = itemId.toLowerCase(Locale.ROOT);
        if (query.startsWith("@")) {
            int colon = id.indexOf(':');
            String namespace = colon < 0 ? "minecraft" : id.substring(0, colon);
            return namespace.contains(query.substring(1));
        }
        return id.contains(query) || displayName.toLowerCase(Locale.ROOT).contains(query);
    }

    private static Comparator<Entry> comparator(SortMode mode, FilterMode filter) {
        if (filter == FilterMode.RECENT) {
            return Comparator.comparingInt(Entry::recentRank)
                    .thenComparing(Entry::displayName, String.CASE_INSENSITIVE_ORDER)
                    .thenComparing(Entry::itemId);
        }
        Comparator<Entry> name = Comparator.comparing(Entry::displayName, String.CASE_INSENSITIVE_ORDER)
                .thenComparing(Entry::itemId);
        Comparator<Entry> cost = Comparator.comparingLong(Entry::matterCost)
                .thenComparing(Entry::displayName, String.CASE_INSENSITIVE_ORDER)
                .thenComparing(Entry::itemId);
        return switch (mode) {
            case NAME_ASC -> name;
            case NAME_DESC -> name.reversed();
            case COST_ASC -> cost;
            case COST_DESC -> cost.reversed();
        };
    }

    public enum SortMode { NAME_ASC, NAME_DESC, COST_ASC, COST_DESC }
    public enum FilterMode { ALL, FAVORITES, RECENT }

    public record Entry(
            String itemId,
            String displayName,
            long matterCost,
            long affordableCount,
            boolean favorite,
            int recentRank) {
        public Entry {
            Objects.requireNonNull(itemId, "itemId");
            displayName = displayName == null || displayName.isBlank() ? itemId : displayName;
            if (matterCost <= 0) throw new IllegalArgumentException("matterCost must be > 0");
            if (affordableCount < 0) throw new IllegalArgumentException("affordableCount must be >= 0");
        }

        /** Compatibility constructor. */
        public Entry(String itemId, long matterCost, long affordableCount) {
            this(itemId, itemId, matterCost, affordableCount, false, Integer.MAX_VALUE);
        }
    }

    public record Page(
            int page,
            int pageCount,
            int pageSize,
            int matchingPatterns,
            long storedMatter,
            List<Entry> entries) {
        public Page { entries = List.copyOf(entries); }
    }
}
