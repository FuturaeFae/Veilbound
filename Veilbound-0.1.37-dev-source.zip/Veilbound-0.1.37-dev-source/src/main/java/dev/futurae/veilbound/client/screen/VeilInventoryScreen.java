package dev.futurae.veilbound.client.screen;

import dev.futurae.veilbound.matter.MatterPatternPageService;
import dev.futurae.veilbound.network.VeilCraftablesRequestPayload;
import dev.futurae.veilbound.network.VeilCraftablesSnapshotPayload;
import dev.futurae.veilbound.network.VeilCraftingPreviewPayload;
import dev.futurae.veilbound.network.VeilCraftingRequestPayload;
import dev.futurae.veilbound.network.VeilInventoryActionPayload;
import dev.futurae.veilbound.network.VeilInventorySnapshotPayload;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import net.neoforged.neoforge.transfer.item.ItemResource;

/**
 * Magic-storage-style wireless Veil terminal.
 *
 * <p>There are deliberately only two top-level views: Inventory and Craftables. After
 * Transmutation the Inventory view is hybrid: valued identities are learned Matter patterns while
 * unvalued items remain exact stored stacks. The server remains authoritative for all mutations.</p>
 */
public final class VeilInventoryScreen extends Screen {
    private static final int GRID_COLUMNS = 9;
    private static final int GRID_ROWS = 4;
    private static final int SLOT_STEP = 23;
    private static final int SLOT_SIZE = 20;
    private static final int PANEL_WIDTH = 520;
    private static final int PANEL_HEIGHT = 244;
    private static final int SEARCH_DEBOUNCE_TICKS = 6;
    private static final int[] SYNTHESIS_QUANTITIES = {1, 4, 8, 16, 32, 64};
    private static final int[] CRAFT_QUANTITIES = {1, 4, 8, 16, 32, 64};

    private enum Tab { INVENTORY, CRAFTABLES }

    private VeilInventorySnapshotPayload snapshot;
    private VeilCraftablesSnapshotPayload craftables =
            VeilCraftablesSnapshotPayload.denied("not_requested", false);
    private VeilCraftingPreviewPayload craftingPreview = VeilCraftingPreviewPayload.denied("empty_grid");
    private final ArrayList<ItemResource> craftingGrid = new ArrayList<>(VeilCraftingRequestPayload.GRID_SIZE);

    private Tab tab = Tab.INVENTORY;
    private ItemResource selectedPattern = ItemResource.EMPTY;
    private int selectedRecipe = -1;

    private String inventoryQuery = "";
    private String craftablesQuery = "";
    private MatterPatternPageService.SortMode inventorySort = MatterPatternPageService.SortMode.NAME_ASC;
    private MatterPatternPageService.SortMode craftablesSort = MatterPatternPageService.SortMode.NAME_ASC;
    private MatterPatternPageService.FilterMode inventoryFilter = MatterPatternPageService.FilterMode.ALL;
    private int synthesisQuantity = 1;
    private int craftQuantity = 1;
    private EditBox searchBox;
    private int searchDebounce;

    public VeilInventoryScreen(VeilInventorySnapshotPayload snapshot) {
        super(Component.translatable("screen.veilbound.veil_inventory"));
        this.snapshot = snapshot;
        for (int i = 0; i < VeilCraftingRequestPayload.GRID_SIZE; i++) craftingGrid.add(ItemResource.EMPTY);
    }

    public void acceptSnapshot(VeilInventorySnapshotPayload next) {
        this.snapshot = next;
        if (!containsPattern(next, selectedPattern)) selectedPattern = ItemResource.EMPTY;
        if (tab == Tab.CRAFTABLES && canBrowseCraftables()) {
            requestCraftables(craftables.allCrafts(), craftables.page());
        }
        if (minecraft != null) rebuildWidgets();
    }

    public void acceptCraftablesSnapshot(VeilCraftablesSnapshotPayload next) {
        this.craftables = next;
        selectedRecipe = -1;
        clearCraftGridLocal();
        if (minecraft != null) rebuildWidgets();
    }

    public void acceptCraftingPreview(VeilCraftingPreviewPayload preview) {
        this.craftingPreview = preview;
        if (minecraft != null) rebuildWidgets();
    }

    private boolean canBrowseCraftables() {
        return snapshot.allowed() && snapshot.craftingUnlocked() && snapshot.transmutationUnlocked();
    }

    private void rebuildWidgets() {
        clearWidgets();
        init();
    }

    @Override
    protected void init() {
        super.init();
        int left = Math.max(8, width / 2 - PANEL_WIDTH / 2);
        int top = Math.max(24, height / 2 - PANEL_HEIGHT / 2);

        Button inventoryTab = Button.builder(Component.translatable("screen.veilbound.veil_inventory.tab.inventory"),
                button -> switchTab(Tab.INVENTORY)).bounds(left + 8, top + 8, 96, 20).build();
        inventoryTab.active = tab != Tab.INVENTORY;
        addRenderableWidget(inventoryTab);

        if (canBrowseCraftables()) {
            Button craftablesTab = Button.builder(Component.translatable("screen.veilbound.veil_inventory.tab.craftables"),
                    button -> switchTab(Tab.CRAFTABLES)).bounds(left + 108, top + 8, 96, 20).build();
            craftablesTab.active = tab != Tab.CRAFTABLES;
            addRenderableWidget(craftablesTab);
        }

        if (!snapshot.allowed()) return;

        searchBox = new EditBox(font, 174, 20, Component.translatable("screen.veilbound.veil_inventory.search"));
        searchBox.setMaxLength(VeilInventoryActionPayload.MAX_QUERY_LENGTH);
        searchBox.setValue(activeQuery());
        searchBox.setHint(Component.translatable("screen.veilbound.veil_inventory.search_hint"));
        searchBox.setResponder(value -> {
            if (tab == Tab.INVENTORY) inventoryQuery = value == null ? "" : value;
            else craftablesQuery = value == null ? "" : value;
            searchDebounce = SEARCH_DEBOUNCE_TICKS;
        });
        searchBox.setPosition(left + 214, top + 8);
        addRenderableWidget(searchBox);

        addRenderableWidget(Button.builder(sortLabel(activeSort()), button -> cycleSort())
                .bounds(left + 394, top + 8, 118, 20).build());

        if (tab == Tab.CRAFTABLES && canBrowseCraftables()) initCraftables(left, top);
        else initInventory(left, top);
    }

    private void initInventory(int left, int top) {
        int controlsY = top + 34;
        if (snapshot.transmutationUnlocked()) {
            addRenderableWidget(Button.builder(filterLabel(inventoryFilter), button -> cycleInventoryFilter())
                    .bounds(left + 8, controlsY, 108, 20).build());
            addRenderableWidget(Button.builder(Component.translatable(
                            "screen.veilbound.veil_inventory.quantity", synthesisQuantity),
                    button -> {
                        synthesisQuantity = nextQuantity(SYNTHESIS_QUANTITIES, synthesisQuantity);
                        rebuildWidgets();
                    }).bounds(left + 120, controlsY, 88, 20).build());
        }

        addRenderableWidget(Button.builder(Component.literal("<"), button -> {
                    selectedPattern = ItemResource.EMPTY;
                    sendInventory(VeilInventoryActionPayload.Action.OPEN_OR_PAGE,
                            Math.max(0, snapshot.page() - 1), ItemResource.EMPTY, 1);
                }).bounds(left + 214, controlsY, 28, 20).build());
        addRenderableWidget(Button.builder(Component.literal(">"), button -> {
                    selectedPattern = ItemResource.EMPTY;
                    sendInventory(VeilInventoryActionPayload.Action.OPEN_OR_PAGE,
                            Math.min(snapshot.pageCount() - 1, snapshot.page() + 1), ItemResource.EMPTY, 1);
                }).bounds(left + 246, controlsY, 28, 20).build());

        int gridLeft = left + 8;
        int gridTop = top + 62;
        int index = 0;
        for (VeilInventorySnapshotPayload.Entry entry : snapshot.entries()) {
            int col = index % GRID_COLUMNS;
            int row = index / GRID_COLUMNS;
            if (row >= GRID_ROWS) break;
            ItemResource resource = entry.resource();
            addRenderableWidget(Button.builder(Component.literal(""), button -> selectPattern(resource))
                    .bounds(gridLeft + col * SLOT_STEP, gridTop + row * SLOT_STEP, SLOT_SIZE, SLOT_SIZE).build());
            index++;
        }

        VeilInventorySnapshotPayload.Entry selected = selectedPatternEntry();
        if (selected != null) {
            int detailX = left + 232;
            if (snapshot.transmutationUnlocked() && selected.matterCost() > 0) {
                addRenderableWidget(Button.builder(Component.translatable(
                                selected.favorite()
                                        ? "screen.veilbound.veil_inventory.favorite.remove"
                                        : "screen.veilbound.veil_inventory.favorite.add"),
                        button -> sendInventory(VeilInventoryActionPayload.Action.TOGGLE_FAVORITE,
                                snapshot.page(), selectedPattern, 1))
                        .bounds(detailX, top + 102, 130, 20).build());

                Button pull = Button.builder(Component.translatable(
                                "screen.veilbound.veil_inventory.pull_quantity", synthesisQuantity),
                        button -> sendInventory(VeilInventoryActionPayload.Action.SYNTHESIZE_QUANTITY,
                                snapshot.page(), selectedPattern, synthesisQuantity))
                        .bounds(detailX, top + 128, 130, 20).build();
                pull.active = selected.affordableCount() > 0;
                addRenderableWidget(pull);

                Button stack = Button.builder(Component.translatable("screen.veilbound.veil_inventory.pull_stack"),
                        button -> sendInventory(VeilInventoryActionPayload.Action.WITHDRAW_STACK,
                                snapshot.page(), selectedPattern, 64))
                        .bounds(detailX + 136, top + 128, 130, 20).build();
                stack.active = selected.affordableCount() > 0;
                addRenderableWidget(stack);
            } else {
                Button one = Button.builder(Component.translatable("screen.veilbound.veil_inventory.pull_one"),
                        button -> sendInventory(VeilInventoryActionPayload.Action.WITHDRAW_ONE,
                                snapshot.page(), selectedPattern, 1))
                        .bounds(detailX, top + 128, 110, 20).build();
                Button stack = Button.builder(Component.translatable("screen.veilbound.veil_inventory.pull_stack"),
                        button -> sendInventory(VeilInventoryActionPayload.Action.WITHDRAW_STACK,
                                snapshot.page(), selectedPattern, 64))
                        .bounds(detailX + 116, top + 128, 120, 20).build();
                addRenderableWidget(one);
                addRenderableWidget(stack);
            }
        }

        Component depositLabel = snapshot.transmutationUnlocked()
                ? Component.translatable("screen.veilbound.veil_inventory.deposit_or_transmute_held")
                : Component.translatable("screen.veilbound.veil_inventory.deposit_held");
        addRenderableWidget(Button.builder(depositLabel,
                button -> sendInventory(VeilInventoryActionPayload.Action.DEPOSIT_HELD,
                        snapshot.page(), ItemResource.EMPTY, 1))
                .bounds(left + 8, top + 206, 166, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.veilbound.veil_inventory.refresh"),
                button -> sendInventory(VeilInventoryActionPayload.Action.OPEN_OR_PAGE,
                        snapshot.page(), ItemResource.EMPTY, 1))
                .bounds(left + 180, top + 206, 72, 20).build());
    }

    private void initCraftables(int left, int top) {
        int controlsY = top + 34;
        addRenderableWidget(Button.builder(Component.translatable(craftables.allCrafts()
                        ? "screen.veilbound.veil_inventory.crafts.all"
                        : "screen.veilbound.veil_inventory.crafts.current"),
                button -> toggleCraftableMode()).bounds(left + 8, controlsY, 142, 20).build());
        addRenderableWidget(Button.builder(Component.translatable(
                        "screen.veilbound.veil_inventory.quantity", craftQuantity),
                button -> {
                    craftQuantity = nextQuantity(CRAFT_QUANTITIES, craftQuantity);
                    if (selectedRecipe >= 0) requestPreview();
                    rebuildWidgets();
                }).bounds(left + 154, controlsY, 88, 20).build());
        addRenderableWidget(Button.builder(Component.literal("<"),
                button -> requestCraftables(craftables.allCrafts(), Math.max(0, craftables.page() - 1)))
                .bounds(left + 248, controlsY, 28, 20).build());
        addRenderableWidget(Button.builder(Component.literal(">"),
                button -> requestCraftables(craftables.allCrafts(),
                        Math.min(craftables.pageCount() - 1, craftables.page() + 1)))
                .bounds(left + 280, controlsY, 28, 20).build());

        int gridLeft = left + 8;
        int gridTop = top + 62;
        int index = 0;
        for (VeilCraftablesSnapshotPayload.Entry entry : craftables.entries()) {
            final int recipeIndex = index;
            int col = index % GRID_COLUMNS;
            int row = index / GRID_COLUMNS;
            if (row >= GRID_ROWS) break;
            addRenderableWidget(Button.builder(Component.literal(""), button -> selectRecipe(recipeIndex))
                    .bounds(gridLeft + col * SLOT_STEP, gridTop + row * SLOT_STEP, SLOT_SIZE, SLOT_SIZE).build());
            index++;
        }

        if (selectedRecipe >= 0 && selectedRecipe < craftables.entries().size()) {
            VeilCraftablesSnapshotPayload.Entry entry = craftables.entries().get(selectedRecipe);
            int craftLeft = left + 316;
            int craftTop = top + 92;
            for (int i = 0; i < VeilCraftingRequestPayload.GRID_SIZE; i++) {
                Button cell = Button.builder(Component.literal(""), button -> { })
                        .bounds(craftLeft + (i % 3) * SLOT_STEP, craftTop + (i / 3) * SLOT_STEP,
                                SLOT_SIZE, SLOT_SIZE).build();
                cell.active = false;
                addRenderableWidget(cell);
            }
            Button craft = Button.builder(Component.translatable(
                            "screen.veilbound.veil_inventory.craft_quantity", craftQuantity),
                    button -> sendCraft(VeilCraftingRequestPayload.Action.CRAFT_ONCE))
                    .bounds(left + 402, top + 114, 104, 20).build();
            craft.active = entry.craftable() && entry.affordableCrafts() >= craftQuantity;
            addRenderableWidget(craft);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (searchDebounce > 0 && --searchDebounce == 0) {
            if (tab == Tab.INVENTORY) {
                selectedPattern = ItemResource.EMPTY;
                sendInventory(VeilInventoryActionPayload.Action.OPEN_OR_PAGE, 0, ItemResource.EMPTY, 1);
            } else if (canBrowseCraftables()) {
                selectedRecipe = -1;
                clearCraftGridLocal();
                requestCraftables(craftables.allCrafts(), 0);
            }
        }
    }

    private void selectPattern(ItemResource resource) {
        selectedPattern = resource == null ? ItemResource.EMPTY : resource;
        rebuildWidgets();
    }

    private void switchTab(Tab next) {
        if (next == Tab.CRAFTABLES && !canBrowseCraftables()) return;
        tab = next;
        selectedPattern = ItemResource.EMPTY;
        selectedRecipe = -1;
        clearCraftGridLocal();
        searchDebounce = 0;
        if (next == Tab.CRAFTABLES) requestCraftables(craftables.allCrafts(), 0);
        else sendInventory(VeilInventoryActionPayload.Action.OPEN_OR_PAGE, 0, ItemResource.EMPTY, 1);
        rebuildWidgets();
    }

    private void toggleCraftableMode() {
        selectedRecipe = -1;
        clearCraftGridLocal();
        requestCraftables(!craftables.allCrafts(), 0);
    }

    private void selectRecipe(int index) {
        if (index < 0 || index >= craftables.entries().size()) return;
        selectedRecipe = index;
        List<ItemResource> proposal = craftables.entries().get(index).grid();
        for (int i = 0; i < craftingGrid.size(); i++) craftingGrid.set(i, proposal.get(i));
        requestPreview();
        rebuildWidgets();
    }

    private void cycleSort() {
        MatterPatternPageService.SortMode[] values = MatterPatternPageService.SortMode.values();
        if (tab == Tab.INVENTORY) inventorySort = values[(inventorySort.ordinal() + 1) % values.length];
        else craftablesSort = values[(craftablesSort.ordinal() + 1) % values.length];
        selectedPattern = ItemResource.EMPTY;
        selectedRecipe = -1;
        if (tab == Tab.INVENTORY) {
            sendInventory(VeilInventoryActionPayload.Action.OPEN_OR_PAGE, 0, ItemResource.EMPTY, 1);
        } else {
            clearCraftGridLocal();
            requestCraftables(craftables.allCrafts(), 0);
        }
        rebuildWidgets();
    }

    private void cycleInventoryFilter() {
        MatterPatternPageService.FilterMode[] values = MatterPatternPageService.FilterMode.values();
        inventoryFilter = values[(inventoryFilter.ordinal() + 1) % values.length];
        selectedPattern = ItemResource.EMPTY;
        sendInventory(VeilInventoryActionPayload.Action.OPEN_OR_PAGE, 0, ItemResource.EMPTY, 1);
        rebuildWidgets();
    }

    private VeilInventorySnapshotPayload.Entry selectedPatternEntry() {
        for (VeilInventorySnapshotPayload.Entry entry : snapshot.entries()) {
            if (entry.resource().equals(selectedPattern)) return entry;
        }
        return null;
    }

    private static boolean containsPattern(VeilInventorySnapshotPayload snapshot, ItemResource resource) {
        if (resource == null || resource.isEmpty()) return false;
        for (VeilInventorySnapshotPayload.Entry entry : snapshot.entries()) {
            if (entry.resource().equals(resource)) return true;
        }
        return false;
    }

    private void clearCraftGridLocal() {
        for (int i = 0; i < craftingGrid.size(); i++) craftingGrid.set(i, ItemResource.EMPTY);
        craftingPreview = VeilCraftingPreviewPayload.denied("empty_grid");
    }

    private void requestPreview() {
        if (snapshot.craftingUnlocked()) sendCraft(VeilCraftingRequestPayload.Action.PREVIEW);
    }

    private void sendCraft(VeilCraftingRequestPayload.Action action) {
        ClientPacketDistributor.sendToServer(new VeilCraftingRequestPayload(
                action, craftables.page(), craftQuantity, List.copyOf(craftingGrid)));
    }

    private void sendInventory(VeilInventoryActionPayload.Action action, int page, ItemResource resource, int quantity) {
        ClientPacketDistributor.sendToServer(new VeilInventoryActionPayload(
                action, Math.max(0, page), resource, quantity,
                inventoryQuery, inventorySort, inventoryFilter));
    }

    private void requestCraftables(boolean allCrafts, int page) {
        ClientPacketDistributor.sendToServer(new VeilCraftablesRequestPayload(
                allCrafts, Math.max(0, page), craftablesQuery, craftablesSort));
    }

    private String activeQuery() {
        return tab == Tab.INVENTORY ? inventoryQuery : craftablesQuery;
    }

    private MatterPatternPageService.SortMode activeSort() {
        return tab == Tab.INVENTORY ? inventorySort : craftablesSort;
    }

    private static int nextQuantity(int[] allowed, int current) {
        for (int i = 0; i < allowed.length; i++) {
            if (allowed[i] == current) return allowed[(i + 1) % allowed.length];
        }
        return allowed[0];
    }

    private static Component sortLabel(MatterPatternPageService.SortMode mode) {
        String key = switch (mode) {
            case NAME_ASC -> "screen.veilbound.veil_inventory.sort.name_asc";
            case NAME_DESC -> "screen.veilbound.veil_inventory.sort.name_desc";
            case COST_ASC -> "screen.veilbound.veil_inventory.sort.cost_asc";
            case COST_DESC -> "screen.veilbound.veil_inventory.sort.cost_desc";
        };
        return Component.translatable(key);
    }

    private static Component filterLabel(MatterPatternPageService.FilterMode mode) {
        String key = switch (mode) {
            case ALL -> "screen.veilbound.veil_inventory.filter.all";
            case FAVORITES -> "screen.veilbound.veil_inventory.filter.favorites";
            case RECENT -> "screen.veilbound.veil_inventory.filter.recent";
        };
        return Component.translatable(key);
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        extractTransparentBackground(graphics);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
        int left = Math.max(8, width / 2 - PANEL_WIDTH / 2);
        int top = Math.max(24, height / 2 - PANEL_HEIGHT / 2);

        // A restrained terminal shell: dark void glass, violet header and thin cyan dividers.
        graphics.fill(left, top, left + PANEL_WIDTH, top + PANEL_HEIGHT, 0xE6151220);
        graphics.fill(left, top, left + PANEL_WIDTH, top + 32, 0xF0221732);
        graphics.fill(left, top + 31, left + PANEL_WIDTH, top + 32, 0xFF8A69B8);
        graphics.fill(left + 220, top + 58, left + 221, top + 196, 0xFF4C3A65);

        graphics.centeredText(font, title, width / 2, top - 12, 0xFFF1E9FF);

        if (!snapshot.allowed()) {
            graphics.centeredText(font, Component.translatable(
                            "screen.veilbound.veil_inventory.locked", snapshot.reason()),
                    width / 2, top + 86, 0xFFFF8080);
            return;
        }

        graphics.text(font, Component.translatable("screen.veilbound.veil_inventory.matter", snapshot.storedMatter()),
                left + 318, top + 38, 0xFFE5B7FF, false);
        graphics.text(font, Component.translatable("screen.veilbound.veil_inventory.patterns", snapshot.learnedPatterns()),
                left + 410, top + 38, 0xFFC6B0DB, false);

        if (tab == Tab.CRAFTABLES && canBrowseCraftables()) renderCraftables(graphics, left, top, mouseX, mouseY);
        else renderInventory(graphics, left, top, mouseX, mouseY);
    }

    private void renderInventory(GuiGraphicsExtractor graphics, int left, int top, int mouseX, int mouseY) {
        if (!snapshot.transmutationUnlocked()) {
            String capacity = snapshot.maxItems() == Long.MAX_VALUE
                    ? snapshot.totalItems() + " / ∞"
                    : snapshot.totalItems() + " / " + snapshot.maxItems();
            graphics.text(font, Component.translatable("screen.veilbound.veil_inventory.items", capacity),
                    left + 8, top + 40, 0xFFB8D8FF, false);
        } else {
            graphics.text(font, Component.translatable(
                            "screen.veilbound.veil_inventory.inventory_matches", snapshot.matchingPatterns()),
                    left + 8, top + 40, 0xFFB8D8FF, false);
        }

        int gridLeft = left + 8;
        int gridTop = top + 62;
        int index = 0;
        for (VeilInventorySnapshotPayload.Entry entry : snapshot.entries()) {
            int col = index % GRID_COLUMNS;
            int row = index / GRID_COLUMNS;
            if (row >= GRID_ROWS) break;
            int x = gridLeft + col * SLOT_STEP;
            int y = gridTop + row * SLOT_STEP;
            ItemStack stack = entry.resource().toStack(1);
            graphics.item(stack, x + 2, y + 2);
            if (entry.favorite()) graphics.text(font, Component.literal("★"), x + 11, y + 1, 0xFFFFD76A, false);
            else if (entry.recent()) graphics.text(font, Component.literal("•"), x + 14, y + 1, 0xFF9EDCFF, false);
            if (mouseX >= x && mouseX < x + SLOT_SIZE && mouseY >= y && mouseY < y + SLOT_SIZE) {
                Component hint = snapshot.transmutationUnlocked() && entry.matterCost() > 0
                        ? Component.translatable("screen.veilbound.veil_inventory.tooltip.pattern",
                                entry.resource().getHoverName(), entry.matterCost(), entry.affordableCount())
                        : snapshot.transmutationUnlocked()
                                ? Component.translatable("screen.veilbound.veil_inventory.tooltip.stored_unvalued",
                                        entry.resource().getHoverName(), entry.storedCount())
                                : entry.resource().getHoverName();
                graphics.setTooltipForNextFrame(font, hint, mouseX, mouseY);
            }
            index++;
        }

        VeilInventorySnapshotPayload.Entry selected = selectedPatternEntry();
        int detailX = left + 232;
        if (selected != null) {
            ItemStack stack = selected.resource().toStack(1);
            graphics.item(stack, detailX, top + 66);
            graphics.text(font, selected.resource().getHoverName(), detailX + 22, top + 69, 0xFFFFFFFF, false);
            if (snapshot.transmutationUnlocked() && selected.matterCost() > 0) {
                graphics.text(font, Component.translatable(
                                "screen.veilbound.veil_inventory.pattern_cost", selected.matterCost()),
                        detailX, top + 88, 0xFFE5B7FF, false);
                graphics.text(font, Component.translatable(
                                "screen.veilbound.veil_inventory.affordable", selected.affordableCount()),
                        detailX, top + 100, 0xFFD0D0D0, false);
                if (selected.recent()) graphics.text(font, Component.translatable(
                                "screen.veilbound.veil_inventory.recent_marker"),
                        detailX + 278, top + 69, 0xFF9EDCFF, false);
            } else {
                graphics.text(font, Component.literal("× " + selected.storedCount()),
                        detailX, top + 90, 0xFFD0D0D0, false);
            }
        } else {
            graphics.text(font, Component.translatable("screen.veilbound.veil_inventory.pattern_select_hint"),
                    detailX, top + 72, 0xFFA0A0A0, false);
        }

        graphics.centeredText(font, Component.translatable(
                        "screen.veilbound.veil_inventory.page", snapshot.page() + 1, snapshot.pageCount()),
                left + 110, top + 160, 0xFFFFFFFF);
        graphics.text(font, Component.translatable("screen.veilbound.veil_inventory.search_tip"),
                detailX, top + 174, 0xFF8F8798, false);
    }

    private void renderCraftables(GuiGraphicsExtractor graphics, int left, int top, int mouseX, int mouseY) {
        if (!craftables.allowed()) {
            graphics.text(font, craftReason(craftables.reason()), left + 8, top + 70, 0xFFFFA080, false);
            return;
        }

        graphics.text(font, Component.translatable(
                        "screen.veilbound.veil_inventory.recipe_matches", craftables.matchingRecipes()),
                left + 318, top + 64, 0xFFB8D8FF, false);

        int gridLeft = left + 8;
        int gridTop = top + 62;
        int index = 0;
        for (VeilCraftablesSnapshotPayload.Entry entry : craftables.entries()) {
            int col = index % GRID_COLUMNS;
            int row = index / GRID_COLUMNS;
            if (row >= GRID_ROWS) break;
            int x = gridLeft + col * SLOT_STEP;
            int y = gridTop + row * SLOT_STEP;
            ItemStack stack = entry.result().toStack(Math.max(1, entry.resultCount()));
            graphics.item(stack, x + 2, y + 2);
            graphics.text(font, Component.literal(entry.craftable() ? "✓" : "×"), x + 12, y + 11,
                    entry.craftable() ? 0xFF80FFB0 : 0xFFFF8080, false);
            if (mouseX >= x && mouseX < x + SLOT_SIZE && mouseY >= y && mouseY < y + SLOT_SIZE) {
                graphics.setTooltipForNextFrame(font, Component.translatable(
                                "screen.veilbound.veil_inventory.tooltip.recipe",
                                entry.result().getHoverName(), entry.matterCost(), entry.affordableCrafts()),
                        mouseX, mouseY);
            }
            index++;
        }

        graphics.centeredText(font, Component.translatable(
                        "screen.veilbound.veil_inventory.page", craftables.page() + 1, craftables.pageCount()),
                left + 110, top + 160, 0xFFFFFFFF);

        if (selectedRecipe >= 0 && selectedRecipe < craftables.entries().size()) {
            VeilCraftablesSnapshotPayload.Entry entry = craftables.entries().get(selectedRecipe);
            int detailX = left + 232;
            ItemStack resultStack = entry.result().toStack(Math.max(1, entry.resultCount()));
            graphics.item(resultStack, detailX, top + 66);
            graphics.text(font, entry.result().getHoverName(), detailX + 22, top + 69,
                    entry.craftable() ? 0xFFFFFFFF : 0xFFB0B0B0, false);
            graphics.text(font, Component.translatable(
                            "screen.veilbound.veil_inventory.recipe_cost", entry.matterCost()),
                    detailX, top + 88, entry.craftable() ? 0xFFE5B7FF : 0xFF9A829A, false);
            graphics.text(font, Component.translatable(
                            "screen.veilbound.veil_inventory.affordable_crafts", entry.affordableCrafts()),
                    detailX, top + 100, 0xFFD0D0D0, false);

            int craftLeft = left + 316;
            int craftTop = top + 92;
            for (int i = 0; i < entry.grid().size(); i++) {
                ItemResource resource = entry.grid().get(i);
                if (resource.isEmpty()) continue;
                int x = craftLeft + (i % 3) * SLOT_STEP;
                int y = craftTop + (i / 3) * SLOT_STEP;
                ItemStack stack = resource.toStack(1);
                graphics.item(stack, x + 2, y + 2);
                if (!entry.learnedGrid().get(i)) {
                    graphics.text(font, Component.literal("?"), x + 13, y + 10, 0xFFFF7070, false);
                }
                if (mouseX >= x && mouseX < x + SLOT_SIZE && mouseY >= y && mouseY < y + SLOT_SIZE) {
                    Component tip = entry.learnedGrid().get(i)
                            ? stack.getHoverName()
                            : Component.translatable("screen.veilbound.veil_inventory.tooltip.pattern_missing",
                                    stack.getHoverName());
                    graphics.setTooltipForNextFrame(font, tip, mouseX, mouseY);
                }
            }
            if (!entry.patternsKnown()) {
                graphics.text(font, Component.translatable(
                                "screen.veilbound.veil_inventory.craft_reason.pattern_missing"),
                        detailX, top + 176, 0xFFFFA080, false);
            } else if (entry.affordableCrafts() < craftQuantity) {
                graphics.text(font, Component.translatable(
                                "screen.veilbound.veil_inventory.craft_reason.matter_missing"),
                        detailX, top + 176, 0xFFFFA080, false);
            } else if (!craftingPreview.craftable()) {
                graphics.text(font, craftReason(craftingPreview.reason()), detailX, top + 176, 0xFFFFA080, false);
            }
        } else {
            graphics.text(font, Component.translatable("screen.veilbound.veil_inventory.crafts.select_hint"),
                    left + 232, top + 76, 0xFFA0A0A0, false);
        }
    }

    private static Component craftReason(String reason) {
        return switch (reason) {
            case "empty_grid" -> Component.translatable("screen.veilbound.veil_inventory.craft_reason.empty_grid");
            case "no_recipe" -> Component.translatable("screen.veilbound.veil_inventory.craft_reason.no_recipe");
            case "ingredients_missing" -> Component.translatable("screen.veilbound.veil_inventory.craft_reason.ingredients_missing");
            case "matter_missing" -> Component.translatable("screen.veilbound.veil_inventory.craft_reason.matter_missing");
            case "pattern_missing" -> Component.translatable("screen.veilbound.veil_inventory.craft_reason.pattern_missing");
            case "veil_crafting_locked" -> Component.translatable("screen.veilbound.veil_inventory.crafting_locked");
            case "veil_transmutation_locked" -> Component.translatable("screen.veilbound.veil_inventory.transmutation_locked");
            default -> Component.translatable("screen.veilbound.veil_inventory.craft_reason.unavailable");
        };
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
