package dev.futurae.veilbound.platform.neoforge;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.memory.MemoryDefinition;
import dev.futurae.veilbound.memory.MemoryRegistry;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

/** Loads data/<namespace>/veilbound/memories/<path>.json into the runtime Memory registry. */
public final class NeoForgeMemoryReloadListener
        extends SimplePreparableReloadListener<DatapackDefinitionSnapshot<MemoryDefinition>> {
    public static final Identifier LISTENER_ID = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "memories");
    public static final String DIRECTORY = "veilbound/memories";

    private final Gson gson = new Gson();
    private final MemoryRegistry registry;

    public NeoForgeMemoryReloadListener(MemoryRegistry registry) {
        this.registry = Objects.requireNonNull(registry, "registry");
    }

    @Override
    protected DatapackDefinitionSnapshot<MemoryDefinition> prepare(ResourceManager resourceManager, ProfilerFiller profiler) {
        List<MemoryDefinition> definitions = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        List<Map.Entry<Identifier, Resource>> resources = resourceManager
                .listResources(DIRECTORY, id -> id.getPath().endsWith(".json"))
                .entrySet().stream()
                .sorted(Map.Entry.comparingByKey(Comparator.comparing(Identifier::toString)))
                .toList();

        for (Map.Entry<Identifier, Resource> entry : resources) {
            Identifier resourceId = entry.getKey();
            String id = NeoForgeDefinitionJson.idFromResource(resourceId, DIRECTORY);
            if (id == null) {
                warnings.add("Ignored malformed Memory path: " + resourceId);
                continue;
            }
            try (Reader reader = entry.getValue().openAsReader()) {
                JsonObject object = NeoForgeDefinitionJson.requireObject(gson.fromJson(reader, JsonElement.class));
                Set<String> featureNames = NeoForgeDefinitionJson.optionalStringSet(object, "unlocked_features");
                EnumSet<DomainFeature> features = EnumSet.noneOf(DomainFeature.class);
                for (String feature : featureNames) {
                    try {
                        features.add(DomainFeature.valueOf(feature.toUpperCase(Locale.ROOT)));
                    } catch (IllegalArgumentException ex) {
                        throw new JsonParseException("unknown Domain feature '" + feature + "'");
                    }
                }
                definitions.add(new MemoryDefinition(
                        id,
                        NeoForgeDefinitionJson.requiredString(object, "display_name"),
                        NeoForgeDefinitionJson.optionalStringSet(object, "tags"),
                        NeoForgeDefinitionJson.optionalStringMap(object, "environmental_profile"),
                        NeoForgeDefinitionJson.optionalStringMap(object, "capture_conditions"),
                        NeoForgeDefinitionJson.optionalStringSet(object, "prerequisites"),
                        features));
            } catch (IOException | JsonParseException | IllegalArgumentException ex) {
                warnings.add("Ignored Memory " + resourceId + ": " + ex.getMessage());
            }
        }
        return new DatapackDefinitionSnapshot<>(definitions, warnings);
    }

    @Override
    protected void apply(DatapackDefinitionSnapshot<MemoryDefinition> snapshot, ResourceManager manager, ProfilerFiller profiler) {
        registry.replaceAll(snapshot.definitions());
        snapshot.warnings().forEach(warning -> Veilbound.LOGGER.warn("{}", warning));
        Veilbound.LOGGER.info("Loaded {} Veilbound Memories", snapshot.definitions().size());
    }
}
