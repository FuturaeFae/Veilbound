package dev.futurae.veilbound.precore;

import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainLifecycle;
import dev.futurae.veilbound.domain.DomainState;
import java.util.Objects;

/** Planner for the handheld Spatial Generator. This is the only pre-Core expansion path. */
public final class SpatialGeneratorPlanner {
    public static final int MAX_AXIS_SPAN = 10;

    private SpatialGeneratorPlanner() {}

    public static Plan plan(DomainState state, int targetSizeX, int targetSizeY, int targetSizeZ,
            SpatialGeneratorCostPolicy costs, CondensedCharge availableCharge) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(costs, "costs");
        Objects.requireNonNull(availableCharge, "availableCharge");
        if (state.lifecycle() != DomainLifecycle.PRE_CORE) return Plan.denied("core_already_active");
        if (!validSpan(targetSizeX) || !validSpan(targetSizeY) || !validSpan(targetSizeZ)) return Plan.denied("axis_span_out_of_range");
        DomainBounds current = state.bounds();
        if (targetSizeX < current.sizeX() || targetSizeY < current.sizeY() || targetSizeZ < current.sizeZ()) return Plan.denied("cannot_shrink");

        DomainBounds next = current
                .expandSymmetric(DomainBounds.Axis.X, targetSizeX - current.sizeX())
                .expandSymmetric(DomainBounds.Axis.Y, targetSizeY - current.sizeY())
                .expandSymmetric(DomainBounds.Axis.Z, targetSizeZ - current.sizeZ());
        long addedVolume = next.volume() - current.volume();
        long requiredMilli;
        try {
            requiredMilli = Math.multiplyExact(addedVolume, costs.milliChargePerNewBlock());
        } catch (ArithmeticException overflow) {
            return Plan.denied("cost_overflow");
        }
        if (!availableCharge.canPayMilli(requiredMilli)) return Plan.denied("insufficient_condensed_charge");
        return Plan.allowed(next, addedVolume, requiredMilli);
    }

    public static ApplyResult apply(DomainState state, Plan plan, CondensedCharge availableCharge) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(plan, "plan");
        Objects.requireNonNull(availableCharge, "availableCharge");
        if (!plan.allowed()) return new ApplyResult(false, availableCharge, plan.reason());
        if (state.lifecycle() != DomainLifecycle.PRE_CORE) return new ApplyResult(false, availableCharge, "core_already_active");
        if (!availableCharge.canPayMilli(plan.requiredChargeMilli())) return new ApplyResult(false, availableCharge, "insufficient_condensed_charge");
        state.setBounds(plan.newBounds());
        return new ApplyResult(true, availableCharge.spendMilli(plan.requiredChargeMilli()), "ok");
    }

    private static boolean validSpan(int span) { return span >= 1 && span <= MAX_AXIS_SPAN; }

    public record Plan(boolean allowed, DomainBounds newBounds, long addedVolume, long requiredChargeMilli, String reason) {
        public static Plan denied(String reason) { return new Plan(false, null, 0, 0, reason); }
        public static Plan allowed(DomainBounds bounds, long volume, long chargeMilli) { return new Plan(true, bounds, volume, chargeMilli, "ok"); }
        public long requiredChargeWholeCeil() { return (requiredChargeMilli + CondensedCharge.SCALE - 1) / CondensedCharge.SCALE; }
    }

    public record ApplyResult(boolean applied, CondensedCharge remainingCharge, String reason) {}
}
