package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.domain.DomainIdentity;
import dev.futurae.veilbound.domain.DomainRuntimeTracker;
import dev.futurae.veilbound.platform.neoforge.travel.NeoForgeDomainTravelExecutor;
import dev.futurae.veilbound.platform.neoforge.travel.NeoForgeTransitGuard;
import dev.futurae.veilbound.platform.neoforge.world.NeoForgeDomainLevelService;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import dev.futurae.veilbound.threshold.GuestThresholdSession;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

/**
 * Keeps runtime presence/session state synchronized with player lifecycle events that happen outside
 * Veilbound's V-key flow (commands, other mods, disconnects, reconnects).
 */
public final class NeoForgePlayerPresenceCoordinator {
    private final VeilboundRuntime runtime;
    private final NeoForgeDomainLevelService domainLevels;
    private final NeoForgeDomainTravelExecutor domainTravel;

    public NeoForgePlayerPresenceCoordinator(
            VeilboundRuntime runtime,
            NeoForgeDomainLevelService domainLevels,
            NeoForgeDomainTravelExecutor domainTravel) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        this.domainLevels = Objects.requireNonNull(domainLevels, "domainLevels");
        this.domainTravel = Objects.requireNonNull(domainTravel, "domainTravel");
    }

    /**
     * Invoked from NeoForge's PlayerLoggedOutEvent, which 26.2 fires at the head of
     * PlayerList.remove before vanilla persists the disconnecting player. Returning a tracked
     * visitor/owner here prevents player data from pointing at a Domain that may become dormant.
     */
    public void beforePlayerRemoval(ServerPlayer player) {
        Objects.requireNonNull(player, "player");
        if (NeoForgeTransitGuard.isInternal(player.getUUID())) return;
        MinecraftServer server = player.level().getServer();
        NeoForgeDomainTravelExecutor.TravelResult result = domainTravel.prepareForPlayerRemoval(server, player);
        if (!result.success()) {
            Veilbound.LOGGER.error(
                    "Could not safely return {} before logout: {}. The Domain will remain protected from unsafe unload while occupied.",
                    player.getUUID(), result.reason());
        }
    }

    public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        UUID playerId = player.getUUID();
        DomainRuntimeTracker tracker = runtime.domainRuntime();
        runtime.domains().getRecord(playerId).ifPresent(record -> {
            tracker.setOwnerOnline(playerId, true);
            boolean inside = player.level().dimension().identifier().toString().equals(record.identity().dimensionId());
            tracker.setOwnerInside(playerId, inside);
            if (inside) {
                tracker.setLoaded(playerId, true);
                tracker.setPlayersInside(playerId, player.level().players().size());
            }
        });

        // A guest session normally cannot survive disconnect preparation. If it does (for example a
        // teleport failed but the connection was forcibly closed), preserve it and attempt the safe
        // return as soon as that player is actually present again.
        Optional<GuestThresholdSession> guestSession = runtime.thresholdSessions().session(playerId);
        if (guestSession.isPresent()) {
            GuestThresholdSession session = guestSession.get();
            String expected = DomainIdentity.dimensionIdFor(session.ownerId());
            if (player.level().dimension().identifier().toString().equals(expected)) {
                var result = domainTravel.exitGuestDomain(player.level().getServer(), player, session);
                if (!result.success()) {
                    Veilbound.LOGGER.error("Could not recover guest {} on login: {}", playerId, result.reason());
                }
            } else {
                runtime.thresholdSessions().endGuestSession(playerId);
            }
        }
    }

    public void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        // NeoForge 26.2 posts this before PlayerList.save(player), so perform the physical return
        // first. The location produced here is what vanilla will persist moments later.
        beforePlayerRemoval(player);

        UUID playerId = player.getUUID();
        DomainRuntimeTracker tracker = runtime.domainRuntime();
        if (runtime.domains().getRecord(playerId).isPresent()) {
            tracker.setOwnerOnline(playerId, false);
            tracker.setOwnerInside(playerId, false);
            domainLevels.liveLevel(player.level().getServer(), playerId).ifPresent(level ->
                    tracker.setPlayersInside(playerId, level.players().size()));
            var unload = domainLevels.unloadIfSafe(player.level().getServer(), playerId);
            if (!unload.unloaded() && !unload.alreadyDormant() && !"players_inside".equals(unload.reason())) {
                Veilbound.LOGGER.debug("Domain {} remained loaded after owner logout: {}", playerId, unload.reason());
            }
        }
    }

    public void onPlayerChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        UUID playerId = player.getUUID();
        if (NeoForgeTransitGuard.isInternal(playerId)) return;

        String fromId = event.getFrom().identifier().toString();
        String toId = event.getTo().identifier().toString();
        Optional<UUID> fromOwner = DomainIdentity.ownerFromDimensionId(fromId);
        Optional<UUID> toOwner = DomainIdentity.ownerFromDimensionId(toId);
        MinecraftServer server = player.level().getServer();

        // A guest moved out by another system. Their saved Threshold return anchor is no longer the
        // authoritative location and must not hijack the next V press.
        runtime.thresholdSessions().session(playerId).ifPresent(session -> {
            if (fromOwner.filter(session.ownerId()::equals).isPresent()
                    && toOwner.filter(session.ownerId()::equals).isEmpty()) {
                runtime.thresholdSessions().endGuestSession(playerId);
            }
        });

        // The owner left by command/another mod rather than V. Guests still must leave immediately.
        if (fromOwner.filter(playerId::equals).isPresent()
                && toOwner.filter(playerId::equals).isEmpty()) {
            var result = domainTravel.handleExternalOwnerDeparture(server, playerId);
            if (!result.success()) {
                Veilbound.LOGGER.error("Owner {} left their Domain externally but guest evacuation failed: {}", playerId, result.reason());
            }
        }

        // External entry into one's own already-live Domain is legal for operators/mod integrations;
        // presence must still reflect reality. It does not synthesize a recall anchor.
        if (toOwner.filter(playerId::equals).isPresent()) {
            DomainRuntimeTracker tracker = runtime.domainRuntime();
            tracker.setOwnerOnline(playerId, true);
            tracker.setOwnerInside(playerId, true);
            tracker.setLoaded(playerId, true);
        }

        // Refresh both touched Domain occupancy counts from actual ServerLevels after the transition.
        fromOwner.ifPresent(owner -> refreshOccupancy(server, owner));
        toOwner.ifPresent(owner -> refreshOccupancy(server, owner));
    }

    private void refreshOccupancy(MinecraftServer server, UUID ownerId) {
        domainLevels.liveLevel(server, ownerId).ifPresent(level -> {
            runtime.domainRuntime().setLoaded(ownerId, true);
            runtime.domainRuntime().setPlayersInside(ownerId, level.players().size());
            runtime.domainRuntime().setForcedChunks(ownerId, level.getForceLoadedChunks().size());
        });
    }
}
