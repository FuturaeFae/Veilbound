package dev.futurae.veilbound.item;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Block item that preserves normal BlockItem placement when clicking a block, but also allows a
 * Void Anchor to be placed directly into empty air in the direction the player is looking.
 */
public final class VoidAnchorBlockItem extends BlockItem {
    public VoidAnchorBlockItem(Block block, Item.Properties properties) {
        super(block, properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        double distance = Math.max(1.0D, player.blockInteractionRange());
        Vec3 eye = player.getEyePosition();
        Vec3 targetPoint = eye.add(player.getLookAngle().scale(distance));
        BlockPos target = BlockPos.containing(targetPoint);

        if (!level.isEmptyBlock(target) || !level.mayInteract(player, target)) {
            return InteractionResult.PASS;
        }

        // Treat the empty target itself as the replaceable clicked block. This deliberately routes
        // through BlockItem#place so vanilla/NeoForge placement validation, sound, advancement and
        // stack-consumption behavior remain authoritative rather than using Level#setBlock directly.
        BlockHitResult syntheticHit = new BlockHitResult(targetPoint, Direction.UP, target, false);
        return place(new BlockPlaceContext(player, hand, stack, syntheticHit));
    }
}
