package dev.futurae.veilbound.client.render.entity;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.SpiderRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.monster.spider.Spider;

/** Keeps Spider locomotion while giving the Void Crawler its own Veilbound surface identity. */
public final class VoidCrawlerRenderer extends SpiderRenderer<Spider> {
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "textures/entity/breach/void_crawler.png");
    public VoidCrawlerRenderer(EntityRendererProvider.Context context) { super(context); }
    @Override public Identifier getTextureLocation(LivingEntityRenderState state) { return TEXTURE; }
}
