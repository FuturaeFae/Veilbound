package dev.futurae.veilbound.domain;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/** Runtime-only occupancy/load bookkeeping; no gameplay state is lost when this map is cleared. */
public final class DomainRuntimeTracker {
    private final Map<UUID, RuntimeState> states = new HashMap<>();

    public RuntimeState state(UUID ownerId) {
        return states.computeIfAbsent(Objects.requireNonNull(ownerId), ignored -> RuntimeState.empty());
    }

    public void setOwnerOnline(UUID ownerId, boolean value) { update(ownerId, state(ownerId).withOwnerOnline(value)); }
    public void setOwnerInside(UUID ownerId, boolean value) { update(ownerId, state(ownerId).withOwnerInside(value)); }
    public void setPlayersInside(UUID ownerId, int value) { update(ownerId, state(ownerId).withPlayersInside(value)); }
    public void setForcedChunks(UUID ownerId, int value) { update(ownerId, state(ownerId).withForcedChunks(value)); }
    public void setPendingTransits(UUID ownerId, int value) { update(ownerId, state(ownerId).withPendingTransits(value)); }
    public void setActiveRuntimeRequirements(UUID ownerId, int value) { update(ownerId, state(ownerId).withActiveRuntimeRequirements(value)); }
    public void setContinuityAnchorChunks(UUID ownerId, int value) { update(ownerId, state(ownerId).withContinuityAnchorChunks(value)); }
    public void setLoaded(UUID ownerId, boolean value) { update(ownerId, state(ownerId).withLoaded(value)); }

    public DomainUnloadGate.Decision unloadDecision(UUID ownerId) {
        RuntimeState state = state(ownerId);
        return DomainUnloadGate.evaluate(
                state.playersInside(), state.forcedChunks(), state.pendingTransits(),
                state.activeRuntimeRequirements() + state.continuityAnchorChunks());
    }

    public boolean isDormant(UUID ownerId) { return !state(ownerId).loaded(); }
    public void forget(UUID ownerId) { states.remove(ownerId); }

    private void update(UUID ownerId, RuntimeState state) {
        states.put(Objects.requireNonNull(ownerId), Objects.requireNonNull(state));
    }

    public record RuntimeState(
            boolean loaded,
            boolean ownerOnline,
            boolean ownerInside,
            int playersInside,
            int forcedChunks,
            int pendingTransits,
            int activeRuntimeRequirements,
            int continuityAnchorChunks) {
        public RuntimeState {
            if (playersInside < 0 || forcedChunks < 0 || pendingTransits < 0 || activeRuntimeRequirements < 0 || continuityAnchorChunks < 0) {
                throw new IllegalArgumentException("Runtime counters must be >= 0");
            }
        }
        public static RuntimeState empty() { return new RuntimeState(false, false, false, 0, 0, 0, 0, 0); }
        public RuntimeState withLoaded(boolean v) { return new RuntimeState(v, ownerOnline, ownerInside, playersInside, forcedChunks, pendingTransits, activeRuntimeRequirements, continuityAnchorChunks); }
        public RuntimeState withOwnerOnline(boolean v) { return new RuntimeState(loaded, v, ownerInside, playersInside, forcedChunks, pendingTransits, activeRuntimeRequirements, continuityAnchorChunks); }
        public RuntimeState withOwnerInside(boolean v) { return new RuntimeState(loaded, ownerOnline, v, playersInside, forcedChunks, pendingTransits, activeRuntimeRequirements, continuityAnchorChunks); }
        public RuntimeState withPlayersInside(int v) { return new RuntimeState(loaded, ownerOnline, ownerInside, v, forcedChunks, pendingTransits, activeRuntimeRequirements, continuityAnchorChunks); }
        public RuntimeState withForcedChunks(int v) { return new RuntimeState(loaded, ownerOnline, ownerInside, playersInside, v, pendingTransits, activeRuntimeRequirements, continuityAnchorChunks); }
        public RuntimeState withPendingTransits(int v) { return new RuntimeState(loaded, ownerOnline, ownerInside, playersInside, forcedChunks, v, activeRuntimeRequirements, continuityAnchorChunks); }
        public RuntimeState withActiveRuntimeRequirements(int v) { return new RuntimeState(loaded, ownerOnline, ownerInside, playersInside, forcedChunks, pendingTransits, v, continuityAnchorChunks); }
        public RuntimeState withContinuityAnchorChunks(int v) { return new RuntimeState(loaded, ownerOnline, ownerInside, playersInside, forcedChunks, pendingTransits, activeRuntimeRequirements, v); }
    }
}
