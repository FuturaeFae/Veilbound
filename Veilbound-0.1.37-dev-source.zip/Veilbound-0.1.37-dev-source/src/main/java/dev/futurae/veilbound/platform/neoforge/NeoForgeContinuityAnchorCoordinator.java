package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.block.entity.ContinuityAnchorBlockEntity;
import dev.futurae.veilbound.domain.ContinuityAnchorService;
import dev.futurae.veilbound.domain.DomainChunkPosition;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.platform.neoforge.world.NeoForgeDomainLevelService;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.common.world.chunk.RegisterTicketControllersEvent;
import net.neoforged.neoforge.common.world.chunk.TicketController;
import net.neoforged.neoforge.common.world.chunk.TicketHelper;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.level.block.BreakBlockEvent;

/**
 * Physical one-chunk loading lifecycle for Continuity Anchors.
 *
 * <p>Logical Anchor positions are durable Domain state. NeoForge chunk tickets are runtime
 * consequences that exist only while the owner is online. The owner block position is used as the
 * ticket owner, so multiple Anchors in one chunk can be removed independently while the chunk
 * remains loaded until its final Anchor ticket is removed.</p>
 */
public final class NeoForgeContinuityAnchorCoordinator {
    public static final Identifier TICKET_CONTROLLER_ID =
            Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "continuity_anchor");

    private final VeilboundRuntime runtime;
    private final NeoForgeDomainLevelService domainLevels;
    private final TicketController ticketController;

    public NeoForgeContinuityAnchorCoordinator(VeilboundRuntime runtime, NeoForgeDomainLevelService domainLevels) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        this.domainLevels = Objects.requireNonNull(domainLevels, "domainLevels");
        this.ticketController = new TicketController(TICKET_CONTROLLER_ID, this::validateLoadedTickets);
    }

    /** Ticket controllers are a mod-bus registration in NeoForge 26.2. */
    public void registerTicketController(RegisterTicketControllersEvent event) {
        event.register(ticketController);
    }

    /** Registers a newly placed Anchor only after higher-priority protection handlers allowed it. */
    public void onPlaceBlock(BlockEvent.EntityPlaceEvent event) {
        if (event.isCanceled() || !(event.getEntity() instanceof ServerPlayer player)) return;
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (!event.getPlacedBlock().is(VeilboundBlocks.CONTINUITY_ANCHOR.get())) return;

        DomainRecord record = ownerRecordForLevel(player.getUUID(), level);
        if (record == null) {
            message(player, "message.veilbound.anchor.not_owner_domain");
            event.setCanceled(true);
            return;
        }

        DomainPosition position = toDomainPosition(event.getPos());
        var result = ContinuityAnchorService.place(
                record.state(), position, runtime.stabilityPolicy().policy().maxContinuityAnchors());
        if (!result.placed()) {
            message(player, switch (result.reason()) {
                case "core_inactive" -> "message.veilbound.anchor.core_inactive";
                case "outside_domain" -> "message.veilbound.anchor.outside_domain";
                case "anchor_cap_reached" -> "message.veilbound.anchor.cap_reached";
                default -> "message.veilbound.anchor.place_failed";
            });
            event.setCanceled(true);
            return;
        }

        if (level.getBlockEntity(event.getPos()) instanceof ContinuityAnchorBlockEntity anchor) {
            anchor.bindOwner(player.getUUID());
        }
        if (!force(level, event.getPos(), result.chunk(), true)) {
            ContinuityAnchorService.remove(record.state(), position);
            message(player, "message.veilbound.anchor.place_failed");
            event.setCanceled(true);
            return;
        }
        syncRuntime(record);
        player.displayClientMessage(Component.translatable(
                "message.veilbound.anchor.placed",
                result.anchorCount(), runtime.stabilityPolicy().policy().maxContinuityAnchors()), true);
    }

    /** Owner-only breaking removes the durable registration and its exact source ticket. */
    public void onBreakBlock(BreakBlockEvent event) {
        if (event.isCanceled() || !(event.getPlayer() instanceof ServerPlayer player)) return;
        if (!event.getState().is(VeilboundBlocks.CONTINUITY_ANCHOR.get())) return;
        ServerLevel level = player.level();

        DomainRecord record = recordForDimension(level.dimension().identifier().toString());
        if (record == null) return;
        if (!record.ownerId().equals(player.getUUID())) {
            message(player, "message.veilbound.anchor.not_owner");
            event.setCanceled(true);
            return;
        }

        DomainPosition position = toDomainPosition(event.getPos());
        DomainChunkPosition chunk = DomainChunkPosition.containing(position);
        ContinuityAnchorService.remove(record.state(), position);
        force(level, event.getPos(), chunk, false);
        syncRuntime(record);
        player.displayClientMessage(Component.translatable(
                "message.veilbound.anchor.removed", record.state().continuityAnchors().size()), true);
    }

    /** Restores active chunk loading when an owner with persisted Anchors comes online. */
    public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        DomainRecord record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null || !record.state().coreActive() || record.state().continuityAnchors().isEmpty()) return;

        ServerLevel level;
        try {
            level = domainLevels.load(player.level().getServer(), player.getUUID());
        } catch (RuntimeException error) {
            Veilbound.LOGGER.error("Could not activate Continuity Anchors for {}", player.getUUID(), error);
            return;
        }
        for (DomainPosition position : record.state().continuityAnchors()) {
            BlockPos ownerPos = toBlockPos(position);
            DomainChunkPosition chunk = DomainChunkPosition.containing(position);
            if (!level.getBlockState(ownerPos).is(VeilboundBlocks.CONTINUITY_ANCHOR.get())) {
                record.state().removeContinuityAnchor(position);
                force(level, ownerPos, chunk, false);
                Veilbound.LOGGER.warn("Removed stale Continuity Anchor registration at {} for {}", ownerPos, record.ownerId());
                continue;
            }
            if (level.getBlockEntity(ownerPos) instanceof ContinuityAnchorBlockEntity anchor) {
                if (anchor.ownerId() == null) {
                    anchor.bindOwner(record.ownerId());
                } else if (!record.ownerId().equals(anchor.ownerId())) {
                    record.state().removeContinuityAnchor(position);
                    force(level, ownerPos, chunk, false);
                    Veilbound.LOGGER.warn("Ignored Continuity Anchor at {} with mismatched owner {} in Domain {}",
                            ownerPos, anchor.ownerId(), record.ownerId());
                    continue;
                }
            }
            force(level, ownerPos, chunk, true);
        }
        syncRuntime(record);
    }

    /** Removes active tickets before the normal logout handler decides whether the Domain can unload. */
    public void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        DomainRecord record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null) return;

        domainLevels.liveLevel(player.level().getServer(), player.getUUID()).ifPresent(level -> {
            for (DomainPosition position : record.state().continuityAnchors()) {
                force(level, toBlockPos(position), DomainChunkPosition.containing(position), false);
            }
        });
        runtime.domainRuntime().setContinuityAnchorChunks(player.getUUID(), 0);
    }

    private void syncRuntime(DomainRecord record) {
        boolean ownerOnline = runtime.domainRuntime().state(record.ownerId()).ownerOnline();
        int activeChunks = ownerOnline ? ContinuityAnchorService.anchoredChunks(record.state()).size() : 0;
        runtime.domainRuntime().setContinuityAnchorChunks(record.ownerId(), activeChunks);
    }

    /** Invalidates persisted tickets when their Domain owner is offline or the logical Anchor no longer exists. */
    private void validateLoadedTickets(ServerLevel level, TicketHelper helper) {
        DomainRecord record = recordForDimension(level.dimension().identifier().toString());
        if (record == null || !runtime.domainRuntime().state(record.ownerId()).ownerOnline()) {
            for (BlockPos ticketOwner : helper.getBlockTickets().keySet()) helper.removeAllTickets(ticketOwner);
            return;
        }
        for (BlockPos ticketOwner : helper.getBlockTickets().keySet()) {
            DomainPosition position = toDomainPosition(ticketOwner);
            if (!record.state().continuityAnchors().contains(position)) {
                helper.removeAllTickets(ticketOwner);
            } else {
                // Continuity Anchors never request natural-spawning tickets. Remove any stale/corrupt ones.
                for (long chunk : helper.getBlockTickets().get(ticketOwner).naturalSpawning()) {
                    helper.removeTicket(ticketOwner, chunk, true);
                }
            }
        }
    }

    private DomainRecord ownerRecordForLevel(UUID ownerId, ServerLevel level) {
        DomainRecord record = runtime.domains().getRecord(ownerId).orElse(null);
        if (record == null) return null;
        return record.identity().dimensionId().equals(level.dimension().identifier().toString()) ? record : null;
    }

    private DomainRecord recordForDimension(String dimensionId) {
        return runtime.domains().records().stream()
                .filter(record -> record.identity().dimensionId().equals(dimensionId))
                .findFirst()
                .orElse(null);
    }

    private boolean force(ServerLevel level, BlockPos ticketOwner, DomainChunkPosition chunk, boolean add) {
        try {
            ticketController.forceChunk(level, ticketOwner, chunk.x(), chunk.z(), add, false);
            return true;
        } catch (RuntimeException error) {
            Veilbound.LOGGER.error(
                    "Could not {} Continuity Anchor ticket at {} for chunk {},{}",
                    add ? "add" : "remove", ticketOwner, chunk.x(), chunk.z(), error);
            return false;
        }
    }

    private static DomainPosition toDomainPosition(BlockPos pos) {
        return new DomainPosition(pos.getX(), pos.getY(), pos.getZ());
    }

    private static BlockPos toBlockPos(DomainPosition pos) {
        return new BlockPos(pos.x(), pos.y(), pos.z());
    }

    private static void message(ServerPlayer player, String key) {
        player.displayClientMessage(Component.translatable(key), true);
    }
}
