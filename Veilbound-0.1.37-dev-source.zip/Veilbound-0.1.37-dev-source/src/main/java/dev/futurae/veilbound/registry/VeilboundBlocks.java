package dev.futurae.veilbound.registry;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.block.AxiomMonolithBlock;
import dev.futurae.veilbound.block.ContinuityAnchorBlock;
import dev.futurae.veilbound.block.DimensionalTransducerBlock;
import dev.futurae.veilbound.block.DimensionalFabricatorBlock;
import dev.futurae.veilbound.block.VeilFoundryBlock;
import dev.futurae.veilbound.block.OntologicalHarvesterBlock;
import dev.futurae.veilbound.block.OntologicalCompilerBlock;
import dev.futurae.veilbound.block.ThresholdFrameBlock;
import dev.futurae.veilbound.block.ThresholdPortalBlock;
import dev.futurae.veilbound.block.VoidAnchorBlock;
import dev.futurae.veilbound.block.VeilInterfaceBlock;
import dev.futurae.veilbound.block.VeilLanceBlock;
import net.minecraft.world.level.block.Block;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Settled physical Domain devices. Thresholds remain portal/structure runtime logic. */
public final class VeilboundBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(Veilbound.MOD_ID);

    /** Initial Core is created by the origin ritual and is physically indestructible. */
    public static final DeferredBlock<Block> DIMENSIONAL_CORE = BLOCKS.registerSimpleBlock(
            "dimensional_core",
            properties -> properties.destroyTime(-1.0F).explosionResistance(3_600_000.0F).noLootTable());

    public static final DeferredBlock<DimensionalTransducerBlock> DIMENSIONAL_TRANSDUCER = BLOCKS.registerBlock(
            "dimensional_transducer", DimensionalTransducerBlock::new, properties -> properties.strength(4.0F));
    public static final DeferredBlock<Block> BOUNDARY_PYLON = BLOCKS.registerSimpleBlock("boundary_pylon");
    public static final DeferredBlock<Block> DOMAIN_ORRERY = BLOCKS.registerSimpleBlock("domain_orrery");
    public static final DeferredBlock<Block> MEMORY_ARCHIVE = BLOCKS.registerSimpleBlock("memory_archive");
    public static final DeferredBlock<AxiomMonolithBlock> AXIOM_MONOLITH = BLOCKS.registerBlock(
            "axiom_monolith", AxiomMonolithBlock::new, properties -> properties.strength(4.0F));
    public static final DeferredBlock<ContinuityAnchorBlock> CONTINUITY_ANCHOR = BLOCKS.registerBlock(
            "continuity_anchor", ContinuityAnchorBlock::new, properties -> properties.strength(4.0F));
    /** Climbable buildable frame used to assemble Threshold structures before activation. */
    public static final DeferredBlock<ThresholdFrameBlock> THRESHOLD_FRAME = BLOCKS.registerBlock(
            "threshold_frame", ThresholdFrameBlock::new, properties -> properties.noOcclusion());
    /** Activated full-block portal body produced from a connected Threshold frame structure. */
    public static final DeferredBlock<ThresholdPortalBlock> THRESHOLD_PORTAL = BLOCKS.registerBlock(
            "threshold_portal", ThresholdPortalBlock::new, properties -> properties.noCollision().noOcclusion().noLootTable());
    /** Physical owner-bound automation bridge into Veil Inventory. */
    public static final DeferredBlock<VeilInterfaceBlock> VEIL_INTERFACE = BLOCKS.registerBlock(
            "veil_interface", VeilInterfaceBlock::new, properties -> properties.strength(3.5F));

    /** Reusable angel-block-style foothold; instant-break and directly returned to inventory. */
    public static final DeferredBlock<VoidAnchorBlock> VOID_ANCHOR = BLOCKS.registerBlock(
            "void_anchor", VoidAnchorBlock::new, properties -> properties.instabreak().noLootTable());


    // Dimensional-engineering / ontology branch. These start as durable physical machines and
    // materials; specialized block entities are added only where persistent machine state is required.
    public static final DeferredBlock<Block> RESONANT_ORE = BLOCKS.registerSimpleBlock("resonant_ore");
    public static final DeferredBlock<Block> PHASE_ORE = BLOCKS.registerSimpleBlock("phase_ore");
    public static final DeferredBlock<Block> MNEMONIC_CRYSTAL_ORE = BLOCKS.registerSimpleBlock("mnemonic_crystal_ore");
    public static final DeferredBlock<Block> CAUSALITE_ORE = BLOCKS.registerSimpleBlock("causalite_ore");
    public static final DeferredBlock<Block> AXIOMITE_ORE = BLOCKS.registerSimpleBlock("axiomite_ore");
    /** Breach-generated only; intentionally excluded from ordinary worldgen. */
    public static final DeferredBlock<Block> PARADOX_ORE = BLOCKS.registerSimpleBlock("paradox_ore");
    public static final DeferredBlock<DimensionalFabricatorBlock> DIMENSIONAL_FABRICATOR = BLOCKS.registerBlock(
            "dimensional_fabricator", DimensionalFabricatorBlock::new, properties -> properties.strength(5.0F));
    public static final DeferredBlock<VeilFoundryBlock> VEIL_FOUNDRY = BLOCKS.registerBlock(
            "veil_foundry", VeilFoundryBlock::new, properties -> properties.strength(8.0F).explosionResistance(24.0F));
    public static final DeferredBlock<Block> PROBABILITY_VANE = BLOCKS.registerSimpleBlock("probability_vane");
    public static final DeferredBlock<OntologicalHarvesterBlock> ONTOLOGICAL_HARVESTER = BLOCKS.registerBlock(
            "ontological_harvester", OntologicalHarvesterBlock::new, properties -> properties.strength(6.0F));
    public static final DeferredBlock<OntologicalCompilerBlock> ONTOLOGICAL_COMPILER = BLOCKS.registerBlock(
            "ontological_compiler", OntologicalCompilerBlock::new, properties -> properties.strength(7.0F));
    public static final DeferredBlock<VeilLanceBlock> VEIL_LANCE = BLOCKS.registerBlock(
            "veil_lance", VeilLanceBlock::new, properties -> properties.strength(10.0F).explosionResistance(48.0F));
    public static final DeferredBlock<Block> FOLDED_MATTER_BLOCK = BLOCKS.registerSimpleBlock("folded_matter_block");
    public static final DeferredBlock<Block> CAUSAL_STEEL_BLOCK = BLOCKS.registerSimpleBlock("causal_steel_block");
    public static final DeferredBlock<Block> AXIOMATIC_GLASS_BLOCK = BLOCKS.registerSimpleBlock("axiomatic_glass_block");
    public static final DeferredBlock<Block> CONTINUITY_CRYSTAL_BLOCK = BLOCKS.registerSimpleBlock("continuity_crystal_block");
    public static final DeferredBlock<Block> SOVEREIGN_ALLOY_BLOCK = BLOCKS.registerSimpleBlock("sovereign_alloy_block");
    /** Ascendant megastructure material: a folded lattice that carries stabilized worldlines. */
    public static final DeferredBlock<Block> WORLDLINE_LATTICE_BLOCK = BLOCKS.registerSimpleBlock("worldline_lattice_block");
    /** Paradox-safe containment shell used around late singularity assemblies. */
    public static final DeferredBlock<Block> PARADOX_CONTAINMENT_BLOCK = BLOCKS.registerSimpleBlock("paradox_containment_block");
    /** High-throughput dimensional busbar for Transcendent machinery and Regalia. */
    public static final DeferredBlock<Block> SOVEREIGN_CONDUIT_BLOCK = BLOCKS.registerSimpleBlock("sovereign_conduit_block");
    /** Endgame structural singularity package used by the Core and Regalia branches. */
    public static final DeferredBlock<Block> CROWNED_SINGULARITY_BLOCK = BLOCKS.registerSimpleBlock("crowned_singularity_block");

    private VeilboundBlocks() {}

    public static void register(IEventBus modBus) {
        BLOCKS.register(modBus);
    }
}
