package dev.futurae.veilbound.entity;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/** Small reusable persistence component for programmatically spawned Breach creatures. */
final class BreachLinkData {
    private static final String OWNER_KEY = "VeilboundDomainOwner";
    private static final String BREACH_KEY = "VeilboundSourceBreach";
    private UUID domainOwnerId;
    private UUID sourceBreachId;

    void bind(UUID ownerId, UUID breachId) {
        domainOwnerId = Objects.requireNonNull(ownerId, "ownerId");
        sourceBreachId = Objects.requireNonNull(breachId, "breachId");
    }

    Optional<UUID> ownerId() { return Optional.ofNullable(domainOwnerId); }
    Optional<UUID> breachId() { return Optional.ofNullable(sourceBreachId); }

    void save(ValueOutput output) {
        if (domainOwnerId != null) output.putString(OWNER_KEY, domainOwnerId.toString());
        if (sourceBreachId != null) output.putString(BREACH_KEY, sourceBreachId.toString());
    }

    void load(ValueInput input) {
        domainOwnerId = parse(input.getString(OWNER_KEY));
        sourceBreachId = parse(input.getString(BREACH_KEY));
    }

    private static UUID parse(Optional<String> raw) {
        return raw.flatMap(value -> {
            try { return Optional.of(UUID.fromString(value)); }
            catch (IllegalArgumentException ignored) { return Optional.empty(); }
        }).orElse(null);
    }
}
