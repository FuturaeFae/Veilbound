package dev.futurae.veilbound.environment;

import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import java.util.Objects;
import java.util.Optional;

/**
 * Temporary Lens selection state. It is deliberately ephemeral: confirmed zones persist
 * only their bounds/data, never permanent corner or anchor blocks.
 */
public final class ZoneSelection {
    private DomainPosition first;
    private DomainPosition second;

    public void selectFirst(DomainPosition position) {
        this.first = Objects.requireNonNull(position, "position");
        this.second = null;
    }

    public void selectSecond(DomainPosition position) {
        if (first == null) throw new IllegalStateException("First corner has not been selected");
        this.second = Objects.requireNonNull(position, "position");
    }

    public Optional<DomainBounds> previewBounds() {
        if (first == null || second == null) return Optional.empty();
        return Optional.of(new DomainBounds(
                Math.min(first.x(), second.x()),
                Math.min(first.y(), second.y()),
                Math.min(first.z(), second.z()),
                Math.max(first.x(), second.x()),
                Math.max(first.y(), second.y()),
                Math.max(first.z(), second.z())));
    }

    public void clear() { first = null; second = null; }
}
