package dev.futurae.veilbound.breach;

/** Deliberate Breach-forging profiles for the Veil Lance. */
public enum VeilLanceMode {
    CONTROLLED(BreachSeverity.SEVERE, 4_000_000, 250_000L, 400, 2_400, 60.0),
    OVERDRIVE(BreachSeverity.EXTREME, 12_000_000, 1_000_000L, 600, 4_800, 120.0);

    private final BreachSeverity severity;
    private final long forgeEnergyCost;
    private final long dimensionalEnergyCost;
    private final int chargeTicks;
    private final int cooldownTicks;
    private final double fractureShock;

    VeilLanceMode(BreachSeverity severity, long forgeEnergyCost, long dimensionalEnergyCost,
                  int chargeTicks, int cooldownTicks, double fractureShock) {
        this.severity = severity;
        this.forgeEnergyCost = forgeEnergyCost;
        this.dimensionalEnergyCost = dimensionalEnergyCost;
        this.chargeTicks = chargeTicks;
        this.cooldownTicks = cooldownTicks;
        this.fractureShock = fractureShock;
    }

    public BreachSeverity severity() { return severity; }
    public long forgeEnergyCost() { return forgeEnergyCost; }
    public long dimensionalEnergyCost() { return dimensionalEnergyCost; }
    public int chargeTicks() { return chargeTicks; }
    public int cooldownTicks() { return cooldownTicks; }
    public double fractureShock() { return fractureShock; }
    public long forgeEnergyPerTick() { return Math.max(1L, (forgeEnergyCost + chargeTicks - 1L) / chargeTicks); }
    public VeilLanceMode next() { return this == CONTROLLED ? OVERDRIVE : CONTROLLED; }
}
