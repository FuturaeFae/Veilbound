package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.domain.DomainIdentity;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.law.ActiveLawEffects;
import dev.futurae.veilbound.law.LawRuntimeSemantics;
import dev.futurae.veilbound.platform.neoforge.world.NeoForgeDomainLevelService;
import dev.futurae.veilbound.platform.neoforge.world.VeilboundServerLevel;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.event.entity.living.MobSpawnEvent;
import net.neoforged.neoforge.event.level.ExplosionEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * NeoForge bridge for Veilbound's built-in Law effects.
 *
 * <p>The Law registry remains data-driven. This class recognizes only the built-in effect ids and
 * translates their currently-active state into per-Domain vanilla mechanics. Unknown effect ids
 * intentionally remain inert here so addons can own them without Veilbound guessing semantics.</p>
 */
public final class NeoForgeLawEffectCoordinator {
    private final VeilboundRuntime runtime;
    private final NeoForgeDomainLevelService domainLevels;

    public NeoForgeLawEffectCoordinator(VeilboundRuntime runtime, NeoForgeDomainLevelService domainLevels) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        this.domainLevels = Objects.requireNonNull(domainLevels, "domainLevels");
    }

    /**
     * Keep live Domain rule state synchronized with datapack reloads and Axiom Monolith changes.
     * No Domain is loaded solely for this operation.
     */
    public void onServerTick(ServerTickEvent.Post event) {
        for (DomainRecord record : runtime.domains().records()) {
            domainLevels.liveLevel(event.getServer(), record.ownerId())
                    .ifPresent(level -> synchronize(level, record));
        }
    }

    /** Hostility governs natural monsters; Fauna governs every other natural mob category. */
    public void onNaturalSpawn(MobSpawnEvent.PositionCheck event) {
        if (event.getSpawnType() != EntitySpawnReason.NATURAL) return;
        ServerLevel level = event.getLevel().getLevel();
        Optional<DomainRecord> record = recordFor(level);
        if (record.isEmpty()) return;

        ActiveLawEffects effects = runtime.activeLawEffects(record.get().state());
        boolean monster = event.getEntity().getType().getCategory() == MobCategory.MONSTER;
        if (!runtime.lawRuntimeSemantics().allowNaturalSpawn(effects, monster)) {
            event.setResult(MobSpawnEvent.PositionCheck.Result.FAIL);
        }
    }

    /** Ruin controls block destruction only; explosion damage/knockback to entities remains intact. */
    public void onExplosionDetonate(ExplosionEvent.Detonate event) {
        Optional<DomainRecord> record = recordFor(event.getLevel());
        if (record.isEmpty()) return;
        LawRuntimeSemantics.Snapshot laws = semantics(record.get());
        if (!laws.ruin()) event.getAffectedBlocks().clear();
    }

    public void synchronize(ServerLevel level, DomainRecord record) {
        LawRuntimeSemantics.Snapshot laws = semantics(record);
        var memories = runtime.memoryEnvironment()
                .resolve(record.state(), record.memoryProgress(), runtime.memories())
                .semantics();
        if (level instanceof VeilboundServerLevel domainLevel) {
            domainLevel.applyEnvironmentLaws(
                    laws, memories.overworldDayCycle(), memories.rainWeather());
        }
        level.setSpawnSettings(laws.hostility());
    }

    private LawRuntimeSemantics.Snapshot semantics(DomainRecord record) {
        return runtime.lawRuntimeSemantics().snapshot(runtime.activeLawEffects(record.state()));
    }

    private Optional<DomainRecord> recordFor(Level level) {
        return DomainIdentity.ownerFromDimensionId(level.dimension().identifier().toString())
                .flatMap(runtime.domains()::getRecord);
    }

}
