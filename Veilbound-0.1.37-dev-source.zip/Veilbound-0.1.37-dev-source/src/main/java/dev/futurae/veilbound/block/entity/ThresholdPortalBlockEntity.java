package dev.futurae.veilbound.block.entity;

import dev.futurae.veilbound.registry.VeilboundBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Render-only block entity for active Threshold portal cells.
 *
 * <p>Threshold link/access state remains in Veilbound's server-global Threshold registry rather
 * than being duplicated into every portal cell. This block entity exists solely to opt each
 * active cell into the shader-backed block-entity rendering path.</p>
 */
public final class ThresholdPortalBlockEntity extends BlockEntity {
    public ThresholdPortalBlockEntity(BlockPos pos, BlockState state) {
        super(VeilboundBlockEntities.THRESHOLD_PORTAL.get(), pos, state);
    }
}
