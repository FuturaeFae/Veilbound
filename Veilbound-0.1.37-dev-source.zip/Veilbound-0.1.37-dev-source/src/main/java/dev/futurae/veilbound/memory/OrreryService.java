package dev.futurae.veilbound.memory;

import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainState;
import java.util.Objects;

/** Applies Memory unlocks only when their prerequisite chain has already been earned. */
public final class OrreryService {
    private OrreryService() {}

    public static UnlockResult unlock(DomainState state, MemoryDefinition memory) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(memory, "memory");
        if (state.unlockedMemoryIds().contains(memory.id())) return UnlockResult.denied("already_unlocked");
        if (!state.unlockedMemoryIds().containsAll(memory.prerequisiteMemoryIds())) {
            return UnlockResult.denied("memory_prerequisites_missing");
        }
        state.unlockMemory(memory.id());
        for (DomainFeature feature : memory.unlockedFeatures()) state.unlockFeature(feature);
        return UnlockResult.allowed(memory.id());
    }

    public record UnlockResult(boolean unlocked, String memoryId, String reason) {
        public static UnlockResult denied(String reason) { return new UnlockResult(false, null, reason); }
        public static UnlockResult allowed(String id) { return new UnlockResult(true, id, "ok"); }
    }
}
