package dev.futurae.veilbound.platform.neoforge;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.upgrade.CoreUpgradeDefinition;
import dev.futurae.veilbound.upgrade.CoreUpgradeRegistry;
import dev.futurae.veilbound.upgrade.UpgradeIngredient;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

/** Loads data/<namespace>/veilbound/core_upgrades/*.json without supplying unapproved built-in recipes. */
public final class NeoForgeCoreUpgradeReloadListener
        extends SimplePreparableReloadListener<DatapackDefinitionSnapshot<CoreUpgradeDefinition>> {
    public static final Identifier LISTENER_ID = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "core_upgrades");
    public static final String DIRECTORY = "veilbound/core_upgrades";

    private final Gson gson = new Gson();
    private final CoreUpgradeRegistry registry;

    public NeoForgeCoreUpgradeReloadListener(CoreUpgradeRegistry registry) {
        this.registry = Objects.requireNonNull(registry, "registry");
    }

    @Override
    protected DatapackDefinitionSnapshot<CoreUpgradeDefinition> prepare(ResourceManager resourceManager, ProfilerFiller profiler) {
        List<CoreUpgradeDefinition> definitions = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        var resources = resourceManager.listResources(DIRECTORY, id -> id.getPath().endsWith(".json"))
                .entrySet().stream()
                .sorted(Map.Entry.comparingByKey(Comparator.comparing(Identifier::toString)))
                .toList();
        for (Map.Entry<Identifier, Resource> entry : resources) {
            try (Reader reader = entry.getValue().openAsReader()) {
                JsonObject object = NeoForgeDefinitionJson.requireObject(gson.fromJson(reader, JsonElement.class));
                CoreTier from = tier(NeoForgeDefinitionJson.requiredString(object, "from"));
                CoreTier to = tier(NeoForgeDefinitionJson.requiredString(object, "to"));
                JsonElement ingredientsElement = object.get("ingredients");
                if (ingredientsElement == null || !ingredientsElement.isJsonArray()) {
                    throw new JsonParseException("'ingredients' must be a non-empty array");
                }
                JsonArray ingredientsArray = ingredientsElement.getAsJsonArray();
                if (ingredientsArray.size() == 0) throw new JsonParseException("'ingredients' must be a non-empty array");
                List<UpgradeIngredient> ingredients = new ArrayList<>();
                java.util.HashSet<String> ids = new java.util.HashSet<>();
                for (JsonElement element : ingredientsArray) {
                    JsonObject ingredient = NeoForgeDefinitionJson.requireObject(element);
                    String item = NeoForgeDefinitionJson.requiredString(ingredient, "item");
                    int count = NeoForgeDefinitionJson.optionalNonNegativeInt(ingredient, "count", 1);
                    if (count <= 0) throw new JsonParseException("Core upgrade ingredient count must be > 0");
                    if (!ids.add(item)) throw new JsonParseException("duplicate Core upgrade ingredient '" + item + "'");
                    ingredients.add(new UpgradeIngredient(item, count));
                }
                definitions.add(new CoreUpgradeDefinition(from, to, ingredients));
            } catch (IOException | JsonParseException | IllegalArgumentException ex) {
                warnings.add("Ignored Core upgrade " + entry.getKey() + ": " + ex.getMessage());
            }
        }
        return new DatapackDefinitionSnapshot<>(definitions, warnings);
    }

    @Override
    protected void apply(DatapackDefinitionSnapshot<CoreUpgradeDefinition> snapshot, ResourceManager manager, ProfilerFiller profiler) {
        try {
            registry.replaceAll(snapshot.definitions());
        } catch (IllegalArgumentException ex) {
            Veilbound.LOGGER.error("Rejected Veilbound Core-upgrade registry: {}", ex.getMessage());
            registry.replaceAll(List.of());
        }
        snapshot.warnings().forEach(warning -> Veilbound.LOGGER.warn("{}", warning));
        Veilbound.LOGGER.info("Loaded {} Veilbound Core tier upgrades", registry.all().size());
    }

    private static CoreTier tier(String name) {
        try {
            return CoreTier.valueOf(name.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            throw new JsonParseException("unknown Core tier '" + name + "'", ex);
        }
    }
}
