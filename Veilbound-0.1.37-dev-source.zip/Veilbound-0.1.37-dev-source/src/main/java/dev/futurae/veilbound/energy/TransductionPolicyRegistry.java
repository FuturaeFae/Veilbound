package dev.futurae.veilbound.energy;

import java.util.Objects;

/** Replace-all policy holder updated by datapack reload. */
public final class TransductionPolicyRegistry {
    private TransductionRuntimePolicy policy = TransductionRuntimePolicy.DEVELOPMENT_DEFAULT;
    public TransductionRuntimePolicy policy() { return policy; }
    public void replace(TransductionRuntimePolicy policy) { this.policy = Objects.requireNonNull(policy, "policy"); }
}
