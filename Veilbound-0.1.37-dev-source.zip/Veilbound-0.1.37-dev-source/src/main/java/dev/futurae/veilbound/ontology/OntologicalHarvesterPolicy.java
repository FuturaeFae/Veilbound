package dev.futurae.veilbound.ontology;

/** Validated Potential-harvesting balance loaded through the replace-all ontology datapack policy. */
public record OntologicalHarvesterPolicy(
        long potentialPerVanePerCycle,
        int maxContributingVanes,
        double baseStabilityLoadPerVane,
        double fractureYieldBonusAtFullMeter,
        double breachYieldBonusPerOpenBreach) {
    public OntologicalHarvesterPolicy {
        if (potentialPerVanePerCycle <= 0 || maxContributingVanes <= 0 || baseStabilityLoadPerVane < 0
                || fractureYieldBonusAtFullMeter < 0 || breachYieldBonusPerOpenBreach < 0) throw new IllegalArgumentException("invalid ontology policy");
    }
    public static OntologicalHarvesterPolicy defaults() {
        return new OntologicalHarvesterPolicy(2, 64, 0.35, 1.0, 0.15);
    }
}
