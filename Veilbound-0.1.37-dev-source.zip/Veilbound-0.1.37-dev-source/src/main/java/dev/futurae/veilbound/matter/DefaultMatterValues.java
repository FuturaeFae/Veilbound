package dev.futurae.veilbound.matter;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * ProjectE-compatible vanilla EMC seed values used as Veilbound Matter values.
 *
 * ProjectE does not ship one flat final-item table. It seeds raw/natural values and tag values,
 * adds a small set of special conversions, then derives the rest from the loaded recipe graph.
 * Veilbound follows the same model: this class contains concrete item seeds from ProjectE's
 * mc1.21.1 generated defaults, while ProjectETagMatterValues contains tag/metal seeds and normal
 * recipe inference derives craftables and newer/modded content.
 */
public final class DefaultMatterValues {
    public static final String PROJECTE_BASELINE = "ProjectE 1.1.0 / Minecraft 1.21.1";
    private static final String PROVENANCE = "veilbound:projecte_1_21_1_seed";
    private static final Map<String, Long> VALUES = build();

    private DefaultMatterValues() {}

    public static void installInto(MatterCatalog catalog) {
        VALUES.forEach((id, value) -> catalog.putBuiltIn(id, value, PROVENANCE));
    }

    public static Map<String, Long> snapshot() { return Map.copyOf(VALUES); }

    private static Map<String, Long> build() {
        Map<String, Long> v = new LinkedHashMap<>();

        // Internal ProjectE graph constants used by generated special conversions. These are not
        // registry items and therefore never appear as terminal patterns.
        put(v, "projecte:fake/single_emc", 1);
        put(v, "projecte:fluid/water_bucket_content", 0);
        put(v, "projecte:fluid/lava_bucket_content", 64);
        put(v, "projecte:fluid/milk_bucket_content", 16);

        add(v, 1,
                "minecraft:cobblestone", "minecraft:end_stone", "minecraft:netherrack", "minecraft:dirt",
                "minecraft:sand", "minecraft:red_sand", "minecraft:snow", "minecraft:ice",
                "minecraft:dead_bush", "minecraft:short_grass", "minecraft:seagrass", "minecraft:kelp",
                "minecraft:tall_grass", "minecraft:fern", "minecraft:large_fern", "minecraft:nether_sprouts",
                "minecraft:crimson_roots", "minecraft:warped_roots",
                "minecraft:dead_tube_coral_fan", "minecraft:dead_brain_coral_fan",
                "minecraft:dead_bubble_coral_fan", "minecraft:dead_fire_coral_fan", "minecraft:dead_horn_coral_fan",
                "minecraft:dead_tube_coral", "minecraft:dead_brain_coral", "minecraft:dead_bubble_coral",
                "minecraft:dead_fire_coral", "minecraft:dead_horn_coral", "minecraft:snowball");
        add(v, 2, "minecraft:cobbled_deepslate");
        add(v, 4,
                "minecraft:basalt", "minecraft:blackstone", "minecraft:tuff", "minecraft:gravel",
                "minecraft:pink_petals", "minecraft:dead_tube_coral_block", "minecraft:dead_brain_coral_block",
                "minecraft:dead_bubble_coral_block", "minecraft:dead_fire_coral_block",
                "minecraft:dead_horn_coral_block", "minecraft:sculk_vein", "minecraft:flint",
                "minecraft:mangrove_roots");
        add(v, 8,
                "minecraft:cactus", "minecraft:vine", "minecraft:weeping_vines", "minecraft:twisting_vines",
                "minecraft:glow_lichen");
        add(v, 12, "minecraft:moss_block", "minecraft:cobweb", "minecraft:string");
        add(v, 16,
                "minecraft:rabbit_hide",
                "minecraft:granite", "minecraft:diorite", "minecraft:andesite", "minecraft:pointed_dripstone",
                "minecraft:lily_pad", "minecraft:sea_pickle", "minecraft:tube_coral_fan",
                "minecraft:brain_coral_fan", "minecraft:bubble_coral_fan", "minecraft:fire_coral_fan",
                "minecraft:horn_coral_fan", "minecraft:tube_coral", "minecraft:brain_coral",
                "minecraft:bubble_coral", "minecraft:fire_coral", "minecraft:horn_coral",
                "minecraft:melon_slice", "minecraft:sweet_berries", "minecraft:glow_berries",
                "minecraft:ink_sac", "minecraft:clay_ball");
        add(v, 24, "minecraft:small_dripleaf");
        add(v, 32,
                "minecraft:calcite", "minecraft:big_dripleaf", "minecraft:red_mushroom", "minecraft:brown_mushroom",
                "minecraft:sugar_cane", "minecraft:bamboo", "minecraft:crimson_fungus", "minecraft:warped_fungus",
                "minecraft:rotten_flesh", "minecraft:slime_ball", "minecraft:egg");
        add(v, 48, "minecraft:honey_bottle", "minecraft:feather", "minecraft:armadillo_scute");
        put(v, "minecraft:soul_sand", 49);
        add(v, 64,
                "minecraft:obsidian", "minecraft:spore_blossom", "minecraft:tube_coral_block",
                "minecraft:brain_coral_block", "minecraft:bubble_coral_block", "minecraft:fire_coral_block",
                "minecraft:horn_coral_block", "minecraft:porkchop", "minecraft:beef", "minecraft:chicken",
                "minecraft:rabbit", "minecraft:mutton", "minecraft:cod", "minecraft:salmon",
                "minecraft:tropical_fish", "minecraft:pufferfish", "minecraft:poisonous_potato",
                "minecraft:cocoa_beans");
        add(v, 96, "minecraft:chorus_flower", "minecraft:turtle_scute", "minecraft:goat_horn");
        add(v, 128,
                "minecraft:sponge", "minecraft:magma_block", "minecraft:apple", "minecraft:rabbit_foot",
                "minecraft:spider_eye", "minecraft:coal");
        add(v, 144, "minecraft:bone");
        add(v, 192,
                "minecraft:chorus_fruit", "minecraft:turtle_egg", "minecraft:phantom_membrane",
                "minecraft:gunpowder", "minecraft:saddle", "minecraft:echo_shard", "minecraft:name_tag",
                "minecraft:disc_fragment_5");
        add(v, 256,
                "minecraft:skeleton_skull", "minecraft:zombie_head", "minecraft:creeper_head",
                "minecraft:piglin_head", "minecraft:quartz", "minecraft:prismarine_shard", "minecraft:iron_ingot");
        put(v, "minecraft:prismarine_crystals", 512);
        put(v, "minecraft:piglin_banner_pattern", 512);
        put(v, "minecraft:crying_obsidian", 768);
        put(v, "minecraft:lapis_lazuli", 864);
        add(v, 1_024, "minecraft:ender_pearl", "minecraft:nautilus_shell");
        put(v, "minecraft:blaze_rod", 1_536);
        add(v, 2_048, "minecraft:shulker_shell", "minecraft:sniffer_egg", "minecraft:gold_ingot");
        put(v, "minecraft:breeze_rod", 2_304);
        put(v, "minecraft:ghast_tear", 4_096);
        put(v, "minecraft:music_disc_otherside", 6_144);
        put(v, "minecraft:netherite_upgrade_smithing_template", 7_497);
        put(v, "minecraft:sculk_catalyst", 8_040);
        put(v, "minecraft:diamond", 8_192);
        add(v, 8_192, "minecraft:music_disc_creator_music_box", "minecraft:music_disc_pigstep");
        put(v, "minecraft:music_disc_relic", 10_176);
        put(v, "minecraft:guster_banner_pattern", 12_224);
        put(v, "minecraft:music_disc_precipice", 12_224);
        put(v, "minecraft:netherite_scrap", 12_288);
        put(v, "minecraft:emerald", 16_384);
        put(v, "minecraft:trident", 16_398);
        put(v, "minecraft:flow_banner_pattern", 20_480);
        put(v, "minecraft:heart_of_the_sea", 32_768);
        add(v, 40_960, "minecraft:heavy_core", "minecraft:music_disc_creator");
        put(v, "minecraft:nether_star", 139_264);
        put(v, "minecraft:dragon_egg", 262_144);

        // Current ProjectE direct smithing-template anchors.
        put(v, "minecraft:eye_armor_trim_smithing_template", 23_017);
        put(v, "minecraft:sentry_armor_trim_smithing_template", 57_345);
        put(v, "minecraft:dune_armor_trim_smithing_template", 53_898);
        put(v, "minecraft:vex_armor_trim_smithing_template", 51_917);
        put(v, "minecraft:wild_armor_trim_smithing_template", 42_641);
        put(v, "minecraft:silence_armor_trim_smithing_template", 39_465);
        put(v, "minecraft:tide_armor_trim_smithing_template", 22_116);
        put(v, "minecraft:ward_armor_trim_smithing_template", 19_677);
        put(v, "minecraft:spire_armor_trim_smithing_template", 18_588);
        put(v, "minecraft:coast_armor_trim_smithing_template", 12_271);
        put(v, "minecraft:rib_armor_trim_smithing_template", 10_310);
        add(v, 10_176,
                "minecraft:wayfinder_armor_trim_smithing_template", "minecraft:shaper_armor_trim_smithing_template",
                "minecraft:host_armor_trim_smithing_template", "minecraft:raiser_armor_trim_smithing_template",
                "minecraft:bolt_armor_trim_smithing_template");
        put(v, "minecraft:snout_armor_trim_smithing_template", 7_533);
        put(v, "minecraft:flow_armor_trim_smithing_template", 30_528);

        // ProjectE metal/tag equivalences that are useful even before tag expansion runs.
        put(v, "minecraft:copper_ingot", 128);
        put(v, "minecraft:amethyst_shard", 32);
        put(v, "minecraft:redstone", 64);
        put(v, "minecraft:glowstone_dust", 384);

        return v;
    }

    private static void add(Map<String, Long> values, long amount, String... ids) {
        for (String id : ids) put(values, id, amount);
    }

    private static void put(Map<String, Long> values, String id, long amount) {
        if (values.put(id, amount) != null) throw new IllegalStateException("Duplicate default Matter value: " + id);
    }
}
