package dev.futurae.veilbound.stability;

public record StabilitySnapshot(
        double load,
        double capacity,
        double loadRatio,
        StabilityBand band,
        int activeExpansionPylons,
        int permanentThresholds,
        int continuityAnchors) {
}
