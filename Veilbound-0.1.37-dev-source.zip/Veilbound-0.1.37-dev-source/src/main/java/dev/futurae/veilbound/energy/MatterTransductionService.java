package dev.futurae.veilbound.energy;

import dev.futurae.veilbound.domain.DomainState;
import java.util.Objects;

/**
 * Atomic planning/commit layer for Transducer-local Matter + Transducer-local FE -> Core DE.
 *
 * <p>Veil Inventory Matter is intentionally not accepted by this API. The physical Transducer owns
 * its own Matter reservoir and the platform machine debits that reservoir and its FE buffer only
 * after the Core accepted the produced DE.
 */
public final class MatterTransductionService {
    private MatterTransductionService() {}

    public static Result transduce(
            DomainState targetDomain,
            long availableTransducerMatter,
            long availableForgeEnergy,
            TransductionPolicy policy,
            boolean ownerOnline) {
        Objects.requireNonNull(targetDomain, "targetDomain");
        Objects.requireNonNull(policy, "policy");
        DimensionalTransducer.Result result = DimensionalTransducer.transduce(
                targetDomain, availableTransducerMatter, availableForgeEnergy, policy, ownerOnline);
        if (!result.converted()) return Result.denied(result.reason());
        return Result.allowed(result.matterConsumed(), result.forgeEnergyConsumed(), result.dimensionalEnergyProduced());
    }

    public record Result(
            boolean converted,
            long matterConsumed,
            long forgeEnergyConsumed,
            long dimensionalEnergyProduced,
            String reason) {
        public static Result denied(String reason) { return new Result(false, 0L, 0L, 0L, reason); }
        public static Result allowed(long matter, long fe, long de) { return new Result(true, matter, fe, de, "ok"); }
    }
}
