package dev.futurae.veilbound.ritual;

import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import java.util.Objects;

/** Loader-neutral validation and atomic DE/state commit for the later Core relocation ritual. */
public final class CoreRelocationService {
    public static final long DEFAULT_DIMENSIONAL_ENERGY_COST = 10_000L;

    private CoreRelocationService() {}

    public static Plan plan(DomainState state, DomainPosition target) {
        return plan(state, target, DEFAULT_DIMENSIONAL_ENERGY_COST);
    }

    public static Plan plan(DomainState state, DomainPosition target, long dimensionalEnergyCost) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(target, "target");
        if (dimensionalEnergyCost < 0) throw new IllegalArgumentException("dimensionalEnergyCost must be >= 0");
        if (!state.coreActive()) return Plan.denied("core_inactive");
        if (target.equals(state.corePosition())) return Plan.denied("same_position");
        if (!state.bounds().contains(target)) return Plan.denied("outside_domain");
        if (state.hasOpenBreach()) return Plan.denied("breach_open");
        try {
            // The standard owner arrival is on top of the Core; reserve two full blocks above it.
            if (!state.bounds().contains(new DomainPosition(target.x(), Math.addExact(target.y(), 1), target.z()))
                    || !state.bounds().contains(new DomainPosition(target.x(), Math.addExact(target.y(), 2), target.z()))) {
                return Plan.denied("insufficient_headroom");
            }
        } catch (ArithmeticException overflow) {
            return Plan.denied("coordinate_limit");
        }
        if (state.dimensionalEnergy() < dimensionalEnergyCost) return Plan.denied("insufficient_dimensional_energy");
        return Plan.allowed(target, dimensionalEnergyCost);
    }

    /** Call only after the platform has preflighted and staged the physical block move. */
    public static boolean apply(DomainState state, Plan plan) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(plan, "plan");
        if (!plan.allowed()) return false;
        if (!state.consumeDimensionalEnergy(plan.dimensionalEnergyCost())) return false;
        try {
            state.relocateCore(plan.target());
            return true;
        } catch (RuntimeException failure) {
            state.insertDimensionalEnergy(plan.dimensionalEnergyCost());
            throw failure;
        }
    }

    public record Plan(boolean allowed, DomainPosition target, long dimensionalEnergyCost, String reason) {
        public static Plan denied(String reason) { return new Plan(false, null, 0L, reason); }
        public static Plan allowed(DomainPosition target, long cost) { return new Plan(true, target, cost, "ok"); }
    }
}
