package dev.futurae.veilbound.environment;

import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Ephemeral two-corner Environmental Zone selection state. Nothing here is persisted and no
 * marker blocks are ever placed; only a confirmed EnvironmentZone enters Domain persistence.
 */
public final class EnvironmentZoneSelectionService {
    private final Map<UUID, Selection> selections = new HashMap<>();

    public BeginResult begin(UUID playerId, String memoryId, String proposedName) {
        Objects.requireNonNull(playerId, "playerId");
        if (memoryId == null || memoryId.isBlank()) return BeginResult.denied("memory_profile_missing");
        if (proposedName == null || proposedName.isBlank()) return BeginResult.denied("invalid_name");
        Selection selection = new Selection(memoryId, proposedName.trim(), null, null);
        selections.put(playerId, selection);
        return BeginResult.allowed(selection);
    }

    public Optional<Selection> selection(UUID playerId) {
        return Optional.ofNullable(selections.get(playerId));
    }

    public CornerResult markCorner(UUID playerId, DomainState state, DomainPosition position) {
        Objects.requireNonNull(playerId, "playerId");
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(position, "position");
        Selection current = selections.get(playerId);
        if (current == null) return CornerResult.denied("not_editing");
        if (!state.bounds().contains(position)) return CornerResult.denied("outside_domain_bounds");
        Selection next;
        int corner;
        if (current.cornerA() == null || current.cornerB() != null) {
            next = new Selection(current.memoryId(), current.proposedName(), position, null);
            corner = 1;
        } else {
            next = new Selection(current.memoryId(), current.proposedName(), current.cornerA(), position);
            corner = 2;
        }
        selections.put(playerId, next);
        return CornerResult.allowed(next, corner);
    }

    public ConfirmResult confirm(UUID playerId, DomainState state) {
        Objects.requireNonNull(playerId, "playerId");
        Objects.requireNonNull(state, "state");
        Selection selection = selections.get(playerId);
        if (selection == null) return ConfirmResult.denied("not_editing");
        if (!selection.complete()) return ConfirmResult.denied("selection_incomplete");
        DomainBounds bounds = selection.bounds();
        var created = EnvironmentZoneService.create(
                state, selection.proposedName(), bounds, selection.memoryId(),
                Map.of("priority", "0", "blend", "false"));
        if (!created.created()) return ConfirmResult.denied(created.reason());
        selections.remove(playerId);
        return ConfirmResult.allowed(created.zone());
    }

    public boolean cancel(UUID playerId) {
        return selections.remove(playerId) != null;
    }

    public void retainPlayers(java.util.Set<UUID> playerIds) {
        Objects.requireNonNull(playerIds, "playerIds");
        selections.keySet().removeIf(playerId -> !playerIds.contains(playerId));
    }

    public void clear() { selections.clear(); }

    public record Selection(String memoryId, String proposedName, DomainPosition cornerA, DomainPosition cornerB) {
        public boolean complete() { return cornerA != null && cornerB != null; }
        public DomainBounds bounds() {
            if (!complete()) throw new IllegalStateException("selection is incomplete");
            return new DomainBounds(
                    Math.min(cornerA.x(), cornerB.x()), Math.min(cornerA.y(), cornerB.y()), Math.min(cornerA.z(), cornerB.z()),
                    Math.max(cornerA.x(), cornerB.x()), Math.max(cornerA.y(), cornerB.y()), Math.max(cornerA.z(), cornerB.z()));
        }
    }

    public record BeginResult(boolean begun, Selection selection, String reason) {
        public static BeginResult denied(String reason) { return new BeginResult(false, null, reason); }
        public static BeginResult allowed(Selection selection) { return new BeginResult(true, selection, "ok"); }
    }

    public record CornerResult(boolean marked, Selection selection, int corner, String reason) {
        public static CornerResult denied(String reason) { return new CornerResult(false, null, 0, reason); }
        public static CornerResult allowed(Selection selection, int corner) { return new CornerResult(true, selection, corner, "ok"); }
    }

    public record ConfirmResult(boolean created, EnvironmentZone zone, String reason) {
        public static ConfirmResult denied(String reason) { return new ConfirmResult(false, null, reason); }
        public static ConfirmResult allowed(EnvironmentZone zone) { return new ConfirmResult(true, zone, "ok"); }
    }
}
