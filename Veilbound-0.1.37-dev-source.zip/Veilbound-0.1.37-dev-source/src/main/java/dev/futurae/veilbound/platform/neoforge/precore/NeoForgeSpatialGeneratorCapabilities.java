package dev.futurae.veilbound.platform.neoforge.precore;

import dev.futurae.veilbound.precore.SpatialGeneratorRuntimePolicy;
import dev.futurae.veilbound.registry.VeilboundDataComponents;
import dev.futurae.veilbound.registry.VeilboundItems;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.transfer.energy.ItemAccessEnergyHandler;

/** Allows normal NeoForge/modded FE charging of the handheld Spatial Generator. */
public final class NeoForgeSpatialGeneratorCapabilities {
    private NeoForgeSpatialGeneratorCapabilities() {}

    public static void register(RegisterCapabilitiesEvent event) {
        event.registerItem(
                Capabilities.Energy.ITEM,
                (stack, itemAccess) -> new ItemAccessEnergyHandler(
                        itemAccess, VeilboundDataComponents.SPATIAL_GENERATOR_FE.get(),
                        SpatialGeneratorRuntimePolicy.ITEM_FE_CAPACITY,
                        SpatialGeneratorRuntimePolicy.ITEM_MAX_FE_INSERT, 0),
                VeilboundItems.SPATIAL_GENERATOR.get());
    }
}
