package dev.futurae.veilbound.domain;

/** Inclusive usable-space bounds for a Domain. */
public record DomainBounds(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
    public DomainBounds {
        if (minX > maxX || minY > maxY || minZ > maxZ) {
            throw new IllegalArgumentException("Invalid Domain bounds");
        }
    }

    public static DomainBounds initial() {
        // Authoritative start: a 1 x 1 x 2 usable pocket.
        return new DomainBounds(0, 0, 0, 0, 1, 0);
    }

    public int sizeX() { return maxX - minX + 1; }
    public int sizeY() { return maxY - minY + 1; }
    public int sizeZ() { return maxZ - minZ + 1; }

    public long volume() {
        return (long) sizeX() * sizeY() * sizeZ();
    }

    public boolean contains(DomainPosition position) {
        return position.x() >= minX && position.x() <= maxX
                && position.y() >= minY && position.y() <= maxY
                && position.z() >= minZ && position.z() <= maxZ;
    }

    public boolean contains(DomainBounds other) {
        return other.minX >= minX && other.maxX <= maxX
                && other.minY >= minY && other.maxY <= maxY
                && other.minZ >= minZ && other.maxZ <= maxZ;
    }

    public DomainBounds expand(AxisDirection direction, int blocks) {
        if (blocks < 0) throw new IllegalArgumentException("blocks must be >= 0");
        return switch (direction) {
            case POSITIVE_X -> new DomainBounds(minX, minY, minZ, Math.addExact(maxX, blocks), maxY, maxZ);
            case NEGATIVE_X -> new DomainBounds(Math.subtractExact(minX, blocks), minY, minZ, maxX, maxY, maxZ);
            case POSITIVE_Y -> new DomainBounds(minX, minY, minZ, maxX, Math.addExact(maxY, blocks), maxZ);
            case NEGATIVE_Y -> new DomainBounds(minX, Math.subtractExact(minY, blocks), minZ, maxX, maxY, maxZ);
            case POSITIVE_Z -> new DomainBounds(minX, minY, minZ, maxX, maxY, Math.addExact(maxZ, blocks));
            case NEGATIVE_Z -> new DomainBounds(minX, minY, Math.subtractExact(minZ, blocks), maxX, maxY, maxZ);
        };
    }

    /** Expand both faces of one axis as evenly as integer block counts allow. */
    public DomainBounds expandSymmetric(Axis axis, int totalBlocks) {
        if (totalBlocks < 0) throw new IllegalArgumentException("totalBlocks must be >= 0");
        int negative = totalBlocks / 2;
        int positive = totalBlocks - negative;
        return switch (axis) {
            case X -> new DomainBounds(minX - negative, minY, minZ, maxX + positive, maxY, maxZ);
            case Y -> new DomainBounds(minX, minY - negative, minZ, maxX, maxY + positive, maxZ);
            case Z -> new DomainBounds(minX, minY, minZ - negative, maxX, maxY, maxZ + positive);
        };
    }

    public enum Axis { X, Y, Z }
}
