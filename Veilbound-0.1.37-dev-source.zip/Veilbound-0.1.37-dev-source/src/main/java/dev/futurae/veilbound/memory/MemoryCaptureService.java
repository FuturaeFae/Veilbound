package dev.futurae.veilbound.memory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Loader-neutral environmental Memory matcher for Mnemonic Vessel capture.
 *
 * <p>The platform layer supplies a normalized observation (dimension, biome/tag, weather, sky,
 * time band, etc.). Datapacks decide which exact observations define each Memory. More-specific
 * definitions win first, making broad fallback Memories possible without random capture results.</p>
 */
public final class MemoryCaptureService {
    public List<MemoryDefinition> eligible(
            Collection<MemoryDefinition> definitions,
            Map<String, String> observation,
            Set<String> alreadyLearned) {
        Objects.requireNonNull(definitions, "definitions");
        Objects.requireNonNull(observation, "observation");
        Objects.requireNonNull(alreadyLearned, "alreadyLearned");

        Map<String, String> normalizedObservation = observation.entrySet().stream().collect(
                java.util.stream.Collectors.toUnmodifiableMap(
                        entry -> normalize(entry.getKey()), entry -> normalize(entry.getValue()), (a, b) -> b));
        List<MemoryDefinition> eligible = new ArrayList<>();
        for (MemoryDefinition memory : definitions) {
            if (alreadyLearned.contains(memory.id())) continue;
            if (!alreadyLearned.containsAll(memory.prerequisiteMemoryIds())) continue;
            if (matches(memory.captureConditions(), normalizedObservation)) eligible.add(memory);
        }
        eligible.sort(Comparator
                .comparingInt((MemoryDefinition memory) -> memory.captureConditions().size()).reversed()
                .thenComparing(MemoryDefinition::id));
        return List.copyOf(eligible);
    }

    public CaptureResult choose(
            Collection<MemoryDefinition> definitions,
            Map<String, String> observation,
            Set<String> alreadyLearned) {
        List<MemoryDefinition> candidates = eligible(definitions, observation, alreadyLearned);
        if (candidates.isEmpty()) return CaptureResult.denied("no_memory_matches");
        return CaptureResult.allowed(candidates.getFirst(), candidates.size());
    }

    private static boolean matches(Map<String, String> conditions, Map<String, String> observation) {
        if (conditions.isEmpty()) return false; // no accidental universally-capturable definitions
        for (Map.Entry<String, String> condition : conditions.entrySet()) {
            String actual = observation.get(normalize(condition.getKey()));
            String expected = normalize(condition.getValue());
            if (actual == null) return false;
            if (!"*".equals(expected) && !expected.equals(actual)) return false;
        }
        return true;
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
    }

    public record CaptureResult(boolean capturable, MemoryDefinition memory, int candidateCount, String reason) {
        public static CaptureResult denied(String reason) { return new CaptureResult(false, null, 0, reason); }
        public static CaptureResult allowed(MemoryDefinition memory, int count) {
            return new CaptureResult(true, memory, Math.max(1, count), "ok");
        }
    }
}
