package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.block.entity.EngineeringStationBlockEntity;
import dev.futurae.veilbound.block.entity.OntologicalCompilerBlockEntity;
import dev.futurae.veilbound.block.entity.OntologicalHarvesterBlockEntity;
import dev.futurae.veilbound.block.entity.VeilLanceBlockEntity;
import dev.futurae.veilbound.engineering.EngineeringRecipe;
import dev.futurae.veilbound.network.EngineeringStationActionPayload;
import dev.futurae.veilbound.network.EngineeringStationSnapshotPayload;
import dev.futurae.veilbound.network.OpenEngineeringCodexPayload;
import dev.futurae.veilbound.network.OntologyMachineActionPayload;
import dev.futurae.veilbound.network.OntologyMachineSnapshotPayload;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import dev.futurae.veilbound.ontology.OntologicalHarvesterService;
import dev.futurae.veilbound.ontology.OntologicalMode;
import dev.futurae.veilbound.registry.VeilboundItems;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/** Physical interaction and packet authority for engineering, ontology and the Engineering Codex. */
public final class NeoForgeEngineeringStationController {
    private final VeilboundRuntime runtime;
    public NeoForgeEngineeringStationController(VeilboundRuntime runtime){ this.runtime=Objects.requireNonNull(runtime); }

    public void onRightClickItem(PlayerInteractEvent.RightClickItem event){
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getHand()!=InteractionHand.MAIN_HAND) return;
        if (!event.getItemStack().is(VeilboundItems.VEIL_ENGINEERING_CODEX.get())) return;
        PacketDistributor.sendToPlayer(player, OpenEngineeringCodexPayload.INSTANCE);
        event.setCanceled(true); event.setCancellationResult(InteractionResult.SUCCESS);
    }

    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock event){
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getHand()!=InteractionHand.MAIN_HAND) return;
        BlockPos pos=event.getPos();
        var block=event.getLevel().getBlockState(pos).getBlock();
        if (block==VeilboundBlocks.DIMENSIONAL_FABRICATOR.get() || block==VeilboundBlocks.VEIL_FOUNDRY.get()) {
            handleStationInteraction(player,pos,event); return;
        }
        if (block==VeilboundBlocks.ONTOLOGICAL_HARVESTER.get()) {
            if (!(event.getLevel().getBlockEntity(pos) instanceof OntologicalHarvesterBlockEntity harvester) || !owns(player,harvester.ownerId()) || !event.getItemStack().isEmpty()) return;
            if (player.isShiftKeyDown()) harvester.cycleMode();
            sendOntologySnapshot(player,pos,player.isShiftKeyDown()?"mode_changed":"ok");
            event.setCanceled(true); event.setCancellationResult(InteractionResult.SUCCESS); return;
        }
        if (block==VeilboundBlocks.ONTOLOGICAL_COMPILER.get()) {
            if (!(event.getLevel().getBlockEntity(pos) instanceof OntologicalCompilerBlockEntity compiler) || !owns(player,compiler.ownerId()) || !event.getItemStack().isEmpty()) return;
            sendOntologySnapshot(player,pos,"ok");
            event.setCanceled(true); event.setCancellationResult(InteractionResult.SUCCESS); return;
        }
        if (block==VeilboundBlocks.VEIL_LANCE.get()) {
            if (!(event.getLevel().getBlockEntity(pos) instanceof VeilLanceBlockEntity lance) || !owns(player,lance.ownerId())) return;
            ItemStack held=event.getItemStack();
            if (held.is(VeilboundItems.RESONANCE_MULTITOOL.get())) {
                var direction=lance.cycleBeamDirection();
                player.displayClientMessage(Component.translatable("message.veilbound.veil_lance.direction", direction.name().toLowerCase(java.util.Locale.ROOT)), true);
            } else if (held.isEmpty() && player.isShiftKeyDown()) {
                var mode=lance.cycleMode();
                player.displayClientMessage(Component.translatable("message.veilbound.veil_lance.mode", mode.name(), mode.forgeEnergyCost(), mode.dimensionalEnergyCost(), mode.fractureShock()), true);
            } else if (held.isEmpty()) {
                boolean started=lance.toggleCharging();
                player.displayClientMessage(Component.translatable(started ? "message.veilbound.veil_lance.started" : "message.veilbound.veil_lance.status", lance.mode().name(), lance.storedForgeEnergy(), lance.forgeEnergyCapacity(), lance.chargeTicks(), lance.mode().chargeTicks(), lance.cooldownTicks(), lance.lastStatus()), false);
            } else return;
            event.setCanceled(true); event.setCancellationResult(InteractionResult.SUCCESS); return;
        }
    }

    private void handleStationInteraction(ServerPlayer player, BlockPos pos, PlayerInteractEvent.RightClickBlock event){
        if (!(event.getLevel().getBlockEntity(pos) instanceof EngineeringStationBlockEntity station) || !owns(player,station.ownerId())) return;
        ItemStack held=event.getItemStack();
        if (held.isEmpty()) {
            sendSnapshot(player,station,"ok");
        } else {
            String itemId=BuiltInRegistries.ITEM.getKey(held.getItem()).toString();
            long accepted;
            if (player.isShiftKeyDown()) {
                accepted=station.feedMatter(itemId,held.getCount());
                if (accepted<=0) player.displayClientMessage(Component.translatable("message.veilbound.engineering.matter_rejected", itemId),true);
                else { held.shrink((int)accepted); player.displayClientMessage(Component.translatable("message.veilbound.engineering.matter_fed", accepted,itemId,station.storedMatter(),station.matterCapacity()),true); }
            } else {
                accepted=station.insertPhysical(itemId,held.getCount());
                if (accepted>0) { held.shrink((int)accepted); player.displayClientMessage(Component.translatable("message.veilbound.engineering.component_fed", accepted,itemId),true); }
            }
        }
        event.setCanceled(true); event.setCancellationResult(InteractionResult.SUCCESS);
    }

    public void handle(ServerPlayer player, EngineeringStationActionPayload payload){
        BlockPos pos=new BlockPos(payload.x(),payload.y(),payload.z());
        if (player.blockPosition().distSqr(pos)>100.0) { PacketDistributor.sendToPlayer(player,EngineeringStationSnapshotPayload.denied(payload.x(),payload.y(),payload.z(),"too_far")); return; }
        if (!(player.level().getBlockEntity(pos) instanceof EngineeringStationBlockEntity station) || !owns(player,station.ownerId())) { PacketDistributor.sendToPlayer(player,EngineeringStationSnapshotPayload.denied(payload.x(),payload.y(),payload.z(),"not_owner")); return; }
        String reason="ok";
        switch(payload.action()){
            case REFRESH -> {}
            case SELECT_RECIPE -> { if(!station.selectRecipe(payload.value())) reason="unknown_recipe"; }
            case CLEAR_SELECTION -> station.clearSelection();
            case CLAIM_OUTPUT -> reason=claimOutput(player,station,payload.value());
        }
        sendSnapshot(player,station,reason);
    }

    public void handle(ServerPlayer player, OntologyMachineActionPayload payload){
        BlockPos pos=new BlockPos(payload.x(),payload.y(),payload.z());
        if(player.blockPosition().distSqr(pos)>100.0){ PacketDistributor.sendToPlayer(player,OntologyMachineSnapshotPayload.denied(payload.x(),payload.y(),payload.z(),"too_far")); return; }
        var be=player.level().getBlockEntity(pos);
        java.util.UUID owner = be instanceof OntologicalHarvesterBlockEntity h ? h.ownerId() : be instanceof OntologicalCompilerBlockEntity c ? c.ownerId() : null;
        if(!owns(player,owner)){ PacketDistributor.sendToPlayer(player,OntologyMachineSnapshotPayload.denied(payload.x(),payload.y(),payload.z(),"not_owner")); return; }
        String reason="ok";
        if(payload.action()==OntologyMachineActionPayload.Action.SET_MODE){
            if(!(be instanceof OntologicalHarvesterBlockEntity harvester)){ reason="mode_not_supported"; }
            else {
                try { harvester.setMode(OntologicalMode.valueOf(payload.value())); reason="mode_changed"; }
                catch(IllegalArgumentException ex){ reason="invalid_mode"; }
            }
        }
        sendOntologySnapshot(player,pos,reason);
    }

    public void sendOntologySnapshot(ServerPlayer player, BlockPos pos, String reason){
        var be=player.level().getBlockEntity(pos);
        var record=runtime.domains().getRecord(player.getUUID()).orElse(null);
        if(record==null || !record.identity().dimensionId().equals(player.level().dimension().identifier().toString())){
            PacketDistributor.sendToPlayer(player,OntologyMachineSnapshotPayload.denied(pos.getX(),pos.getY(),pos.getZ(),"domain_unavailable")); return;
        }
        var state=record.state();
        var hp=runtime.ontologyPolicy().policy().harvester();
        var cp=runtime.ontologyPolicy().policy().compiler();
        int openBreaches=(int)state.breaches().stream().filter(dev.futurae.veilbound.breach.Breach::open).count();
        if(be instanceof OntologicalHarvesterBlockEntity harvester && owns(player,harvester.ownerId())){
            var plan=new OntologicalHarvesterService().plan(harvester.contributingVanes(),harvester.mode(),state.fractureMeter(),openBreaches,hp);
            PacketDistributor.sendToPlayer(player,new OntologyMachineSnapshotPayload(
                    pos.getX(),pos.getY(),pos.getZ(),true,reason,"HARVESTER",harvester.storedPotential(),harvester.potentialCapacity(),
                    harvester.mode().name(),harvester.contributingVanes(),harvester.lastProduced(),harvester.lastStabilityLoad(),state.fractureMeter(),openBreaches,plan.instabilityYieldMultiplier(),
                    hp.potentialPerVanePerCycle(),hp.maxContributingVanes(),"",state.dimensionalEnergy(),state.coreTier().dimensionalEnergyCapacity(),record.matterTransmutation().storedMatter(),
                    cp.matterPerPotential(),cp.dimensionalEnergyPerPotential(),cp.maxPotentialPerCycle())); return;
        }
        if(be instanceof OntologicalCompilerBlockEntity compiler && owns(player,compiler.ownerId())){
            PacketDistributor.sendToPlayer(player,new OntologyMachineSnapshotPayload(
                    pos.getX(),pos.getY(),pos.getZ(),true,reason,"COMPILER",compiler.storedPotential(),compiler.potentialCapacity(),
                    "",0,0,0.0,state.fractureMeter(),openBreaches,1.0,hp.potentialPerVanePerCycle(),hp.maxContributingVanes(),compiler.lastStatus(),
                    state.dimensionalEnergy(),state.coreTier().dimensionalEnergyCapacity(),record.matterTransmutation().storedMatter(),cp.matterPerPotential(),cp.dimensionalEnergyPerPotential(),cp.maxPotentialPerCycle())); return;
        }
        PacketDistributor.sendToPlayer(player,OntologyMachineSnapshotPayload.denied(pos.getX(),pos.getY(),pos.getZ(),"machine_missing"));
    }

    public void sendSnapshot(ServerPlayer player, EngineeringStationBlockEntity station, String reason){
        var recipes=runtime.engineeringRecipes().forStation(station.station()).stream().limit(EngineeringStationSnapshotPayload.MAX_RECIPES).map(recipe->toEntry(station,recipe)).toList();
        java.util.LinkedHashMap<String, Long> visible = new java.util.LinkedHashMap<>(station.inventorySnapshot());
        station.outputSnapshot().forEach((id, count) -> visible.merge(id, count, Long::sum));
        var inventory=visible.entrySet().stream().sorted(Map.Entry.comparingByKey()).limit(EngineeringStationSnapshotPayload.MAX_INVENTORY).map(e->new EngineeringStationSnapshotPayload.InventoryEntry(e.getKey(),e.getValue())).toList();
        EngineeringRecipe selected=runtime.engineeringRecipes().get(station.selectedRecipeId()).orElse(null);
        int process=selected==null?0:selected.processTicks();
        PacketDistributor.sendToPlayer(player,new EngineeringStationSnapshotPayload(
                station.getBlockPos().getX(),station.getBlockPos().getY(),station.getBlockPos().getZ(),true,reason,station.station().name(),
                station.storedMatter(),station.matterCapacity(),station.storedPotential(),station.potentialCapacity(),station.selectedRecipeId(),station.progressTicks(),process,station.lastStatus(),inventory,recipes));
    }

    private EngineeringStationSnapshotPayload.RecipeEntry toEntry(EngineeringStationBlockEntity station, EngineeringRecipe recipe){
        var plan=station.planFor(recipe);
        List<String> inputs=recipe.inputs().stream().map(i->i.itemId()+" × "+i.count()).toList();
        return new EngineeringStationSnapshotPayload.RecipeEntry(recipe.id(),recipe.displayName(),recipe.outputItemId(),recipe.outputCount(),recipe.matterCost(),recipe.dimensionalEnergyCost(),recipe.potentialCost(),recipe.minimumCoreTier().name(),recipe.processTicks(),inputs,new ArrayList<>(recipe.requiredMemoryIds()),new ArrayList<>(recipe.requiredLawIds()),plan.missing());
    }

    private String claimOutput(ServerPlayer player, EngineeringStationBlockEntity station, String requestedId){
        EngineeringRecipe selected=runtime.engineeringRecipes().get(station.selectedRecipeId()).orElse(null);
        String itemId=requestedId==null||requestedId.isBlank()?(selected==null?"":selected.outputItemId()):requestedId;
        if(itemId.isBlank()) return "no_output_selected";
        Identifier id=Identifier.tryParse(itemId);
        if(id==null || !BuiltInRegistries.ITEM.containsKey(id)) return "unknown_output";
        long extracted=station.extractPhysical(itemId,64);
        if(extracted<=0) return "output_empty";
        Item item=BuiltInRegistries.ITEM.getValue(id);
        long remaining=extracted;
        while(remaining>0){ int batch=(int)Math.min(remaining,item.getDefaultMaxStackSize()); ItemStack stack=new ItemStack(item,batch); player.getInventory().add(stack); if(!stack.isEmpty())player.drop(stack,false); remaining-=batch; }
        return "claimed";
    }
    private static boolean owns(ServerPlayer player, java.util.UUID owner){ return owner!=null && owner.equals(player.getUUID()); }
}
