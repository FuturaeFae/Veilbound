package dev.futurae.veilbound.matter;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/** Recipe inference manager supporting both full datapack reloads and dependency-limited live updates. */
public final class MatterReloadService {
    private final MatterCatalog catalog;
    private final RecipeMatterInferenceEngine inferenceEngine;
    private final List<MatterRecipeSource> recipeSources = new ArrayList<>();
    private List<RecipeMatterModel> cachedRecipes = List.of();
    private Map<String, Set<String>> dependents = Map.of();

    public MatterReloadService(MatterCatalog catalog) { this(catalog, new RecipeMatterInferenceEngine()); }
    public MatterReloadService(MatterCatalog catalog, RecipeMatterInferenceEngine inferenceEngine) {
        this.catalog = Objects.requireNonNull(catalog, "catalog");
        this.inferenceEngine = Objects.requireNonNull(inferenceEngine, "inferenceEngine");
    }

    public synchronized void addRecipeSource(MatterRecipeSource source) {
        recipeSources.add(Objects.requireNonNull(source, "source"));
    }
    public synchronized void clearRecipeSources() { recipeSources.clear(); cachedRecipes = List.of(); dependents = Map.of(); }

    public synchronized RecipeMatterInferenceEngine.InferenceReport reload() {
        ArrayList<RecipeMatterModel> all = new ArrayList<>();
        for (MatterRecipeSource source : recipeSources) {
            Collection<RecipeMatterModel> recipes = source.normalizedRecipes();
            if (recipes != null) all.addAll(recipes);
        }
        cachedRecipes = List.copyOf(all);
        dependents = buildDependents(cachedRecipes);
        return inferenceEngine.recompute(catalog, cachedRecipes);
    }

    /**
     * Re-evaluates only recipe identities downstream of changed item values. This does not invoke a
     * resource/datapack reload and does not reparse recipes, so operator commands remain responsive.
     */
    public synchronized IncrementalReport recomputeAffected(Collection<String> changedItemIds) {
        Objects.requireNonNull(changedItemIds, "changedItemIds");
        if (cachedRecipes.isEmpty() && !recipeSources.isEmpty()) {
            // Build the cache once if a command arrives before the first normal reload callback.
            reload();
        }
        LinkedHashSet<String> affected = dependencyClosure(changedItemIds);
        if (affected.isEmpty()) return new IncrementalReport(0, 0, 0);
        var report = inferenceEngine.recomputeSubset(catalog, cachedRecipes, affected);
        return new IncrementalReport(affected.size(), report.valueUpdates(), report.inferredItemCount());
    }

    private LinkedHashSet<String> dependencyClosure(Collection<String> roots) {
        LinkedHashSet<String> seen = new LinkedHashSet<>();
        ArrayDeque<String> queue = new ArrayDeque<>();
        for (String id : roots) if (id != null && !id.isBlank() && seen.add(id)) queue.add(id);
        while (!queue.isEmpty()) {
            for (String dependent : dependents.getOrDefault(queue.removeFirst(), Set.of())) {
                if (seen.add(dependent)) queue.addLast(dependent);
            }
        }
        return seen;
    }

    private static Map<String, Set<String>> buildDependents(List<RecipeMatterModel> recipes) {
        LinkedHashMap<String, Set<String>> graph = new LinkedHashMap<>();
        for (RecipeMatterModel recipe : recipes) {
            String output = recipe.primaryOutput().itemId();
            for (var slot : recipe.inputs()) for (var alt : slot.alternatives()) {
                graph.computeIfAbsent(alt.itemId(), ignored -> new LinkedHashSet<>()).add(output);
            }
            for (var returned : recipe.returnedOrByproductOutputs()) {
                graph.computeIfAbsent(returned.itemId(), ignored -> new LinkedHashSet<>()).add(output);
            }
            String type = recipe.recipeType().toLowerCase(java.util.Locale.ROOT);
            if ((type.contains("smelting") || type.contains("blasting"))
                    && recipe.inputs().size() == 1
                    && recipe.inputs().getFirst().alternatives().size() == 1
                    && recipe.returnedOrByproductOutputs().isEmpty()) {
                graph.computeIfAbsent(output, ignored -> new LinkedHashSet<>())
                        .add(recipe.inputs().getFirst().alternatives().getFirst().itemId());
            }
        }
        LinkedHashMap<String, Set<String>> frozen = new LinkedHashMap<>();
        graph.forEach((k, v) -> frozen.put(k, Set.copyOf(v)));
        return Map.copyOf(frozen);
    }

    public record IncrementalReport(int affectedItemCount, int valueUpdates, int inferredItemCount) {}
}
