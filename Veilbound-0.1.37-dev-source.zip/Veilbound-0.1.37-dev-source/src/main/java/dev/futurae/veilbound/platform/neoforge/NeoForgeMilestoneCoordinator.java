package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.milestone.MilestoneService;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.Objects;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** Evaluates durable progression accomplishments once per second and notifies an online owner. */
public final class NeoForgeMilestoneCoordinator {
    private static final int EVALUATION_TICKS = 20;
    private final VeilboundRuntime runtime;
    private final MilestoneService milestones = new MilestoneService();
    private long ticks;

    public NeoForgeMilestoneCoordinator(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    public void onServerTick(ServerTickEvent.Post event) {
        ticks++;
        if (ticks % EVALUATION_TICKS != 0) return;
        for (DomainRecord record : runtime.domains().records()) {
            int permanentThresholds = runtime.thresholds().permanentCountForOwner(record.ownerId());
            var result = milestones.evaluate(record.state(), runtime.milestones(), permanentThresholds);
            if (result.completedNow().isEmpty()) continue;
            ServerPlayer owner = event.getServer().getPlayerList().getPlayer(record.ownerId());
            if (owner == null) continue;
            if (result.completedNow().size() == 1) {
                owner.displayClientMessage(Component.translatable(
                        "message.veilbound.milestone.complete", result.completedNow().getFirst().displayName()), false);
            } else {
                String names = result.completedNow().stream()
                        .map(milestone -> milestone.displayName())
                        .reduce((a, b) -> a + ", " + b)
                        .orElse("");
                owner.displayClientMessage(Component.translatable(
                        "message.veilbound.milestone.multiple_complete", result.completedNow().size(), names), false);
            }
            String rewards = result.completedNow().stream()
                    .flatMap(milestone -> milestone.unlockedFeatures().stream())
                    .distinct()
                    .map(feature -> feature.name().toLowerCase(java.util.Locale.ROOT).replace('_', ' '))
                    .sorted()
                    .reduce((a, b) -> a + ", " + b)
                    .orElse("");
            if (!rewards.isBlank()) {
                owner.displayClientMessage(Component.translatable(
                        "message.veilbound.milestone.features_unlocked", rewards), false);
            }
        }
    }
}
