package dev.futurae.veilbound.breach;

import java.util.Objects;

/** Pure proximity/cadence calculation used by the platform hazard coordinator. */
public final class BreachHazardService {
    private BreachHazardService() {}

    public static Exposure evaluate(
            Breach breach,
            BreachHazardPolicy policy,
            double x,
            double y,
            double z,
            long gameTick) {
        Objects.requireNonNull(breach, "breach");
        Objects.requireNonNull(policy, "policy");
        if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)) {
            throw new IllegalArgumentException("target coordinates must be finite");
        }
        if (!breach.open()) return Exposure.NONE;
        BreachHazardPolicy.HazardBand band = policy.band(breach.severity());
        double dx = x - (breach.position().x() + 0.5);
        double dy = y - (breach.position().y() + 0.5);
        double dz = z - (breach.position().z() + 0.5);
        double distanceSquared = dx * dx + dy * dy + dz * dz;
        if (distanceSquared > band.radius() * band.radius()) return Exposure.NONE;
        boolean damageDue = band.damage() > 0.0 && Math.floorMod(gameTick, band.damageIntervalTicks()) == 0;
        boolean particlesDue = band.particleCount() > 0 && Math.floorMod(gameTick, policy.particleIntervalTicks()) == 0;
        return new Exposure(true, damageDue ? band.damage() : 0.0, particlesDue ? band.particleCount() : 0);
    }

    public record Exposure(boolean inside, double damage, int particleCount) {
        public static final Exposure NONE = new Exposure(false, 0.0, 0);
        public Exposure {
            if (!Double.isFinite(damage) || damage < 0.0) throw new IllegalArgumentException("damage must be finite and >= 0");
            if (particleCount < 0) throw new IllegalArgumentException("particleCount must be >= 0");
        }
        public boolean damageDue() { return damage > 0.0; }
        public boolean particlesDue() { return particleCount > 0; }
    }
}
