package dev.futurae.veilbound.ontology;

/** Converts exposure to the moving Veil boundary into machine-local Potential. */
public final class OntologicalHarvesterService {
    public HarvestPlan plan(int validBoundaryVanes, OntologicalMode mode, double fractureMeter, int openBreaches,
                            OntologicalHarvesterPolicy policy) {
        int vanes = Math.max(0, Math.min(validBoundaryVanes, policy.maxContributingVanes()));
        double fracture = Math.max(0.0, Math.min(1.0, fractureMeter / 100.0));
        double instabilityBonus = 1.0 + fracture * policy.fractureYieldBonusAtFullMeter()
                + Math.max(0, openBreaches) * policy.breachYieldBonusPerOpenBreach();
        long potential = (long)Math.floor(vanes * policy.potentialPerVanePerCycle()
                * mode.productionMultiplier() * instabilityBonus);
        double stabilityLoad = vanes * policy.baseStabilityLoadPerVane() * mode.stabilityMultiplier();
        return new HarvestPlan(vanes, Math.max(0,potential), stabilityLoad, instabilityBonus);
    }
    public record HarvestPlan(int contributingVanes, long potential, double stabilityLoad, double instabilityYieldMultiplier) {}
}
