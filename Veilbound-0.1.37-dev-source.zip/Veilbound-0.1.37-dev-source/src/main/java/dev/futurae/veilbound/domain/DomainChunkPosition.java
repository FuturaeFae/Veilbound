package dev.futurae.veilbound.domain;

/** Loader-neutral chunk coordinate inside a personal Domain. */
public record DomainChunkPosition(int x, int z) {
    public static DomainChunkPosition containing(DomainPosition position) {
        return new DomainChunkPosition(Math.floorDiv(position.x(), 16), Math.floorDiv(position.z(), 16));
    }
}
