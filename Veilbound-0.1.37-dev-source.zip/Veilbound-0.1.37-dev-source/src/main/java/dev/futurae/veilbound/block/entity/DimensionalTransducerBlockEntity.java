package dev.futurae.veilbound.block.entity;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.energy.MatterTransductionService;
import dev.futurae.veilbound.energy.TransducerMatterInputService;
import dev.futurae.veilbound.energy.TransductionRuntimePolicy;
import dev.futurae.veilbound.registry.VeilboundBlockEntities;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.neoforged.neoforge.transfer.ResourceHandler;
import net.neoforged.neoforge.transfer.TransferPreconditions;
import net.neoforged.neoforge.transfer.energy.EnergyHandler;
import net.neoforged.neoforge.transfer.energy.SimpleEnergyHandler;
import net.neoforged.neoforge.transfer.item.ItemResource;
import net.neoforged.neoforge.transfer.transaction.SnapshotJournal;
import net.neoforged.neoforge.transfer.transaction.TransactionContext;
import org.jspecify.annotations.Nullable;

/**
 * Persistent owner binding plus completely local Matter/FE buffers for the physical Dimensional
 * Transducer. Item automation is an insert-only Matter sink; no Veil Inventory state is consulted.
 */
public final class DimensionalTransducerBlockEntity extends BlockEntity {
    private UUID ownerId;
    private long storedMatter;
    private final ConfigurableEnergyHandler energy = new ConfigurableEnergyHandler();
    private final ResourceHandler<ItemResource> matterInput = new MatterInputHandler();

    public DimensionalTransducerBlockEntity(BlockPos pos, BlockState state) {
        super(VeilboundBlockEntities.DIMENSIONAL_TRANSDUCER.get(), pos, state);
    }

    public void bindOwner(UUID ownerId) {
        if (this.ownerId == null) {
            this.ownerId = java.util.Objects.requireNonNull(ownerId, "ownerId");
            setChanged();
        }
    }

    public @Nullable UUID ownerId() { return ownerId; }
    public EnergyHandler energyHandler(Direction side) {
        energy.applyPolicy(Veilbound.runtime().transductionPolicy().policy());
        return energy;
    }
    public ResourceHandler<ItemResource> matterInputHandler(Direction side) { return matterInput; }
    public long storedForgeEnergy() { return energy.getAmountAsLong(); }
    public long forgeEnergyCapacity() { return energy.getCapacityAsLong(); }
    public long storedMatter() { return storedMatter; }
    public long matterCapacity() { return Veilbound.runtime().transductionPolicy().policy().matterCapacity(); }

    public static void tick(Level level, BlockPos pos, BlockState state, DimensionalTransducerBlockEntity blockEntity) {
        if (!(level instanceof ServerLevel serverLevel)) return;
        TransductionRuntimePolicy runtimePolicy = Veilbound.runtime().transductionPolicy().policy();
        blockEntity.energy.applyPolicy(runtimePolicy);
        if (serverLevel.getGameTime() % runtimePolicy.cycleTicks() != 0L) return;
        blockEntity.runCycle(serverLevel, runtimePolicy);
    }

    private void runCycle(ServerLevel level, TransductionRuntimePolicy runtimePolicy) {
        if (ownerId == null || energy.getAmountAsLong() <= 0 || storedMatter <= 0) return;
        DomainRecord record = Veilbound.runtime().domains().getRecord(ownerId).orElse(null);
        if (record == null) return;
        boolean ownerOnline = level.getServer().getPlayerList().getPlayer(ownerId) != null;

        MatterTransductionService.Result result = MatterTransductionService.transduce(
                record.state(), storedMatter, energy.getAmountAsLong(), runtimePolicy.conversion(), ownerOnline);
        if (!result.converted()) return;

        long remainingMatter = storedMatter - result.matterConsumed();
        long remainingFe = energy.getAmountAsLong() - result.forgeEnergyConsumed();
        if (remainingMatter < 0 || remainingFe < 0 || remainingFe > Integer.MAX_VALUE) {
            throw new IllegalStateException("Invalid Dimensional Transducer local-buffer commit");
        }
        storedMatter = remainingMatter;
        energy.set((int) remainingFe);
        setChanged();
    }

    @Override
    protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        if (ownerId != null) output.putString("owner", ownerId.toString());
        output.putInt("forge_energy", (int) Math.min(Integer.MAX_VALUE, energy.getAmountAsLong()));
        // Store as a decimal string so the machine can retain a full long Matter reservoir without
        // depending on a loader-version-specific long helper on ValueInput/ValueOutput.
        output.putString("transducer_matter", Long.toString(storedMatter));
    }

    @Override
    protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        ownerId = input.getString("owner").flatMap(raw -> {
            try { return java.util.Optional.of(UUID.fromString(raw)); }
            catch (IllegalArgumentException ignored) { return java.util.Optional.empty(); }
        }).orElse(null);
        energy.set(Math.max(0, input.getIntOr("forge_energy", 0)));
        storedMatter = input.getString("transducer_matter").map(raw -> {
            try { return Math.max(0L, Long.parseLong(raw)); }
            catch (NumberFormatException ignored) { return 0L; }
        }).orElse(0L);
    }

    private final class ConfigurableEnergyHandler extends SimpleEnergyHandler {
        private ConfigurableEnergyHandler() {
            super(TransductionRuntimePolicy.DEVELOPMENT_DEFAULT.forgeEnergyCapacity(),
                    TransductionRuntimePolicy.DEVELOPMENT_DEFAULT.maxForgeEnergyInput(), 0);
        }

        private void applyPolicy(TransductionRuntimePolicy policy) {
            this.capacity = policy.forgeEnergyCapacity();
            this.maxInsert = policy.maxForgeEnergyInput();
            this.maxExtract = 0; // FE is consumed only by transduction; automation cannot drain it back out.
        }

        @Override
        protected void onEnergyChanged(int previousAmount) {
            DimensionalTransducerBlockEntity.this.setChanged();
        }
    }

    /** Insert-only virtual item slot that immediately converts accepted physical items into Matter. */
    private final class MatterInputHandler extends SnapshotJournal<Long> implements ResourceHandler<ItemResource> {
        @Override
        public int size() { return 1; }

        @Override
        public ItemResource getResource(int index) { return ItemResource.EMPTY; }

        @Override
        public long getAmountAsLong(int index) { return 0L; }

        @Override
        public long getCapacityAsLong(int index, ItemResource resource) {
            if (ownerId == null || Veilbound.runtime().domains().getRecord(ownerId).isEmpty()) return 0L;
            if (index != 0 || resource == null || resource.isEmpty()) return 0L;
            String itemId = BuiltInRegistries.ITEM.getKey(resource.getItem()).toString();
            var value = Veilbound.runtime().matter().amount(itemId);
            if (value.isEmpty() || value.getAsLong() <= 0) return 0L;
            long room = Math.max(0L, matterCapacity() - storedMatter);
            return room / value.getAsLong();
        }

        @Override
        public boolean isValid(int index, ItemResource resource) {
            if (ownerId == null || Veilbound.runtime().domains().getRecord(ownerId).isEmpty()) return false;
            if (index != 0 || resource == null || resource.isEmpty()) return false;
            String itemId = BuiltInRegistries.ITEM.getKey(resource.getItem()).toString();
            return Veilbound.runtime().matter().amount(itemId).isPresent();
        }

        @Override
        public int insert(int index, ItemResource resource, int amount, TransactionContext transaction) {
            TransferPreconditions.checkNonEmptyNonNegative(resource, amount);
            if (ownerId == null || Veilbound.runtime().domains().getRecord(ownerId).isEmpty()) return 0;
            if (index != 0 || amount == 0) return 0;
            String itemId = BuiltInRegistries.ITEM.getKey(resource.getItem()).toString();
            var plan = TransducerMatterInputService.plan(
                    Veilbound.runtime().matter(), itemId, amount, storedMatter, matterCapacity());
            if (!plan.accepted()) return 0;
            updateSnapshots(transaction);
            storedMatter = Math.addExact(storedMatter, plan.matterAdded());
            setChanged();
            return plan.itemsConsumed();
        }

        @Override
        public int extract(int index, ItemResource resource, int amount, TransactionContext transaction) {
            TransferPreconditions.checkNonEmptyNonNegative(resource, amount);
            return 0; // Physical input is irreversibly reduced to machine-local Matter on insertion.
        }

        @Override
        public int insert(ItemResource resource, int amount, TransactionContext transaction) {
            return insert(0, resource, amount, transaction);
        }

        @Override
        public int extract(ItemResource resource, int amount, TransactionContext transaction) {
            TransferPreconditions.checkNonEmptyNonNegative(resource, amount);
            return 0;
        }

        @Override
        protected Long createSnapshot() { return storedMatter; }

        @Override
        protected void revertToSnapshot(Long snapshot) {
            storedMatter = snapshot;
            setChanged();
        }
    }
}
