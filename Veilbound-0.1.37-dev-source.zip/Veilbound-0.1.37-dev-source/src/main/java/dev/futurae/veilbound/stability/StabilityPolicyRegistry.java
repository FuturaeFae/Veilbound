package dev.futurae.veilbound.stability;

import java.util.Objects;

/** Replace-all holder for datapack-reloadable Domain stability/breach balance. */
public final class StabilityPolicyRegistry {
    private StabilityRuntimePolicy policy = StabilityRuntimePolicy.DEVELOPMENT_DEFAULT;
    public StabilityRuntimePolicy policy() { return policy; }
    public void replace(StabilityRuntimePolicy policy) { this.policy = Objects.requireNonNull(policy, "policy"); }
}
