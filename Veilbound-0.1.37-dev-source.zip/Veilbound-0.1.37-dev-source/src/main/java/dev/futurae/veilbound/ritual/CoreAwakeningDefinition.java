package dev.futurae.veilbound.ritual;

import dev.futurae.veilbound.upgrade.UpgradeIngredient;
import java.util.List;

/**
 * Data-driven material requirements for the first Dimensional Core ritual.
 * The required Domain geometry is an invariant of DomainState; ingredients remain data-driven.
 */
public record CoreAwakeningDefinition(List<UpgradeIngredient> ingredients) {
    public CoreAwakeningDefinition {
        ingredients = List.copyOf(ingredients);
        if (ingredients.isEmpty()) throw new IllegalArgumentException("Core awakening must require ritual ingredients");
    }
}
