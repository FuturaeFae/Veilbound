package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Bounded server-authoritative snapshot for owner Domain controls. */
public record DomainControlsSnapshotPayload(
        View view,
        boolean allowed,
        String reason,
        String coreTier,
        long dimensionalEnergy,
        long dimensionalEnergyCapacity,
        int sizeX,
        int sizeY,
        int sizeZ,
        double fracture,
        boolean globalExpansion,
        List<PylonEntry> pylons,
        List<ThresholdEntry> thresholds,
        List<PlayerEntry> onlinePlayers) implements CustomPacketPayload {

    public static final int MAX_THRESHOLDS = 128;
    public static final int MAX_INVITES = 128;
    public static final int MAX_PLAYERS = 128;
    public enum View { CORE, PYLONS, THRESHOLDS }

    public static final Type<DomainControlsSnapshotPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "domain_controls_snapshot"));

    public static final StreamCodec<RegistryFriendlyByteBuf, DomainControlsSnapshotPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override public DomainControlsSnapshotPayload decode(RegistryFriendlyByteBuf buffer) {
            int ordinal = buffer.readVarInt();
            View[] views = View.values();
            View view = ordinal >= 0 && ordinal < views.length ? views[ordinal] : View.CORE;
            boolean allowed = buffer.readBoolean();
            String reason = buffer.readUtf(128);
            String tier = buffer.readUtf(64);
            long de = buffer.readVarLong();
            long cap = buffer.readVarLong();
            int sx = buffer.readVarInt(); int sy = buffer.readVarInt(); int sz = buffer.readVarInt();
            double fracture = buffer.readDouble();
            boolean expansion = buffer.readBoolean();
            int pylonCount = buffer.readVarInt();
            if (pylonCount < 0 || pylonCount > 6) throw new IllegalArgumentException("Invalid pylon count: " + pylonCount);
            List<PylonEntry> pylons = new ArrayList<>(pylonCount);
            for (int i = 0; i < pylonCount; i++) {
                pylons.add(new PylonEntry(buffer.readUtf(32), buffer.readBoolean(), buffer.readBoolean(), buffer.readBoolean(),
                        buffer.readUtf(32), buffer.readInt(), buffer.readInt(), buffer.readInt()));
            }
            int thresholdCount = buffer.readVarInt();
            if (thresholdCount < 0 || thresholdCount > MAX_THRESHOLDS) throw new IllegalArgumentException("Invalid threshold count: " + thresholdCount);
            List<ThresholdEntry> thresholds = new ArrayList<>(thresholdCount);
            for (int i = 0; i < thresholdCount; i++) {
                String id = buffer.readUtf(64);
                String dimension = buffer.readUtf(128);
                int x = buffer.readInt(); int y = buffer.readInt(); int z = buffer.readInt();
                boolean publicAccess = buffer.readBoolean();
                int invites = buffer.readVarInt();
                if (invites < 0 || invites > MAX_INVITES) throw new IllegalArgumentException("Invalid invite count: " + invites);
                List<String> invited = new ArrayList<>(invites);
                for (int j = 0; j < invites; j++) invited.add(buffer.readUtf(64));
                thresholds.add(new ThresholdEntry(id, dimension, x, y, z, publicAccess, invited));
            }
            int playerCount = buffer.readVarInt();
            if (playerCount < 0 || playerCount > MAX_PLAYERS) throw new IllegalArgumentException("Invalid player count: " + playerCount);
            List<PlayerEntry> players = new ArrayList<>(playerCount);
            for (int i = 0; i < playerCount; i++) players.add(new PlayerEntry(buffer.readUtf(64), buffer.readUtf(64)));
            return new DomainControlsSnapshotPayload(view, allowed, reason, tier, de, cap, sx, sy, sz, fracture,
                    expansion, pylons, thresholds, players);
        }

        @Override public void encode(RegistryFriendlyByteBuf buffer, DomainControlsSnapshotPayload payload) {
            buffer.writeVarInt(payload.view().ordinal());
            buffer.writeBoolean(payload.allowed());
            buffer.writeUtf(payload.reason(), 128);
            buffer.writeUtf(payload.coreTier(), 64);
            buffer.writeVarLong(payload.dimensionalEnergy());
            buffer.writeVarLong(payload.dimensionalEnergyCapacity());
            buffer.writeVarInt(payload.sizeX()); buffer.writeVarInt(payload.sizeY()); buffer.writeVarInt(payload.sizeZ());
            buffer.writeDouble(payload.fracture());
            buffer.writeBoolean(payload.globalExpansion());
            buffer.writeVarInt(Math.min(6, payload.pylons().size()));
            for (int i = 0; i < Math.min(6, payload.pylons().size()); i++) {
                PylonEntry p = payload.pylons().get(i);
                buffer.writeUtf(p.direction(), 32); buffer.writeBoolean(p.bound()); buffer.writeBoolean(p.online()); buffer.writeBoolean(p.expansionEnabled());
                buffer.writeUtf(p.speed(), 32); buffer.writeInt(p.x()); buffer.writeInt(p.y()); buffer.writeInt(p.z());
            }
            int tc = Math.min(MAX_THRESHOLDS, payload.thresholds().size());
            buffer.writeVarInt(tc);
            for (int i = 0; i < tc; i++) {
                ThresholdEntry t = payload.thresholds().get(i);
                buffer.writeUtf(t.id(), 64); buffer.writeUtf(t.sourceDimensionId(), 128);
                buffer.writeInt(t.domainX()); buffer.writeInt(t.domainY()); buffer.writeInt(t.domainZ());
                buffer.writeBoolean(t.publicAccess());
                int ic = Math.min(MAX_INVITES, t.invitedGuestIds().size());
                buffer.writeVarInt(ic);
                for (int j = 0; j < ic; j++) buffer.writeUtf(t.invitedGuestIds().get(j), 64);
            }
            int pc = Math.min(MAX_PLAYERS, payload.onlinePlayers().size());
            buffer.writeVarInt(pc);
            for (int i = 0; i < pc; i++) {
                PlayerEntry p = payload.onlinePlayers().get(i);
                buffer.writeUtf(p.uuid(), 64); buffer.writeUtf(p.name(), 64);
            }
        }
    };

    public DomainControlsSnapshotPayload {
        if (view == null) view = View.CORE;
        reason = reason == null ? "unknown" : reason;
        coreTier = coreTier == null ? "NASCENT" : coreTier;
        pylons = List.copyOf(pylons == null ? List.of() : pylons);
        thresholds = List.copyOf(thresholds == null ? List.of() : thresholds);
        onlinePlayers = List.copyOf(onlinePlayers == null ? List.of() : onlinePlayers);
    }

    public static DomainControlsSnapshotPayload denied(View view, String reason) {
        return new DomainControlsSnapshotPayload(view, false, reason, "NASCENT", 0, 0, 0, 0, 0, 0,
                false, List.of(), List.of(), List.of());
    }

    public record PylonEntry(String direction, boolean bound, boolean online, boolean expansionEnabled, String speed, int x, int y, int z) {
        public PylonEntry { speed = speed == null || speed.isBlank() ? "STABLE" : speed; }
    }
    public record ThresholdEntry(String id, String sourceDimensionId, int domainX, int domainY, int domainZ,
                                 boolean publicAccess, List<String> invitedGuestIds) {
        public ThresholdEntry { invitedGuestIds = List.copyOf(invitedGuestIds == null ? List.of() : invitedGuestIds); }
    }
    public record PlayerEntry(String uuid, String name) {}

    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
