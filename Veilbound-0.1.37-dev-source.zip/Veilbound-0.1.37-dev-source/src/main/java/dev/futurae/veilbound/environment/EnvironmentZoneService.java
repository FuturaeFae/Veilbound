package dev.futurae.veilbound.environment;

import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainState;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/** Validates creation/editing of saved, non-block Environmental Zones. */
public final class EnvironmentZoneService {
    private EnvironmentZoneService() {}

    public static CreateResult create(
            DomainState state,
            String name,
            DomainBounds bounds,
            String memoryProfileId,
            Map<String, String> parameters) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(bounds, "bounds");
        Objects.requireNonNull(memoryProfileId, "memoryProfileId");
        Objects.requireNonNull(parameters, "parameters");
        if (!state.hasFeature(DomainFeature.ENVIRONMENTAL_MASTERY)) {
            return CreateResult.denied("environmental_mastery_locked");
        }
        if (!state.unlockedMemoryIds().contains(memoryProfileId)) {
            return CreateResult.denied("memory_profile_locked");
        }
        if (!state.bounds().contains(bounds)) return CreateResult.denied("outside_domain_bounds");
        if (name == null || name.isBlank()) return CreateResult.denied("invalid_name");
        String normalizedName = name.trim();
        if (findByName(state, normalizedName).isPresent()) return CreateResult.denied("duplicate_name");

        EnvironmentZone zone = new EnvironmentZone(UUID.randomUUID(), normalizedName, bounds, memoryProfileId, parameters);
        state.addEnvironmentZone(zone);
        return CreateResult.allowed(zone);
    }

    public static Optional<EnvironmentZone> findByName(DomainState state, String name) {
        Objects.requireNonNull(state, "state");
        if (name == null || name.isBlank()) return Optional.empty();
        String target = name.trim().toLowerCase(Locale.ROOT);
        return state.environmentZones().stream()
                .filter(zone -> zone.name().toLowerCase(Locale.ROOT).equals(target))
                .findFirst();
    }

    public static UpdateResult rename(DomainState state, UUID zoneId, String name) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(zoneId, "zoneId");
        if (name == null || name.isBlank()) return UpdateResult.denied("invalid_name");
        EnvironmentZone current = byId(state, zoneId).orElse(null);
        if (current == null) return UpdateResult.denied("zone_not_found");
        String normalized = name.trim();
        Optional<EnvironmentZone> conflict = findByName(state, normalized);
        if (conflict.isPresent() && !conflict.get().id().equals(zoneId)) return UpdateResult.denied("duplicate_name");
        EnvironmentZone replacement = new EnvironmentZone(
                current.id(), normalized, current.bounds(), current.memoryProfileId(), current.parameters());
        state.replaceEnvironmentZone(replacement);
        return UpdateResult.allowed(replacement);
    }

    public static UpdateResult configure(
            DomainState state, UUID zoneId, int priority, boolean blendWithLowerPriority) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(zoneId, "zoneId");
        EnvironmentZone current = byId(state, zoneId).orElse(null);
        if (current == null) return UpdateResult.denied("zone_not_found");
        Map<String, String> parameters = new java.util.LinkedHashMap<>(current.parameters());
        parameters.put("priority", Integer.toString(priority));
        parameters.put("blend", Boolean.toString(blendWithLowerPriority));
        EnvironmentZone replacement = new EnvironmentZone(
                current.id(), current.name(), current.bounds(), current.memoryProfileId(), parameters);
        state.replaceEnvironmentZone(replacement);
        return UpdateResult.allowed(replacement);
    }

    public static UpdateResult retuneMemory(DomainState state, UUID zoneId, String memoryProfileId) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(zoneId, "zoneId");
        Objects.requireNonNull(memoryProfileId, "memoryProfileId");
        if (!state.unlockedMemoryIds().contains(memoryProfileId)) return UpdateResult.denied("memory_profile_locked");
        EnvironmentZone current = byId(state, zoneId).orElse(null);
        if (current == null) return UpdateResult.denied("zone_not_found");
        EnvironmentZone replacement = new EnvironmentZone(
                current.id(), current.name(), current.bounds(), memoryProfileId, current.parameters());
        state.replaceEnvironmentZone(replacement);
        return UpdateResult.allowed(replacement);
    }

    public static boolean delete(DomainState state, UUID zoneId) {
        int before = state.environmentZones().size();
        state.removeEnvironmentZone(zoneId);
        return state.environmentZones().size() != before;
    }

    private static Optional<EnvironmentZone> byId(DomainState state, UUID zoneId) {
        return state.environmentZones().stream().filter(zone -> zone.id().equals(zoneId)).findFirst();
    }

    public record CreateResult(boolean created, EnvironmentZone zone, String reason) {
        public static CreateResult denied(String reason) { return new CreateResult(false, null, reason); }
        public static CreateResult allowed(EnvironmentZone zone) { return new CreateResult(true, zone, "ok"); }
    }

    public record UpdateResult(boolean updated, EnvironmentZone zone, String reason) {
        public static UpdateResult denied(String reason) { return new UpdateResult(false, null, reason); }
        public static UpdateResult allowed(EnvironmentZone zone) { return new UpdateResult(true, zone, "ok"); }
    }
}
