package dev.futurae.veilbound.inventory;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Slotless owner storage for exact stack identities. Mutations are bounded by a caller-supplied
 * capacity so Core-tier changes cannot be bypassed by automation or UI code.
 */
public final class VeilInventory {
    private final LinkedHashMap<VeilStackKey, Long> counts = new LinkedHashMap<>();
    private long totalItems;
    private Runnable mutationListener = () -> {};

    public long totalItems() { return totalItems; }
    public int distinctTypes() { return counts.size(); }
    public long count(VeilStackKey key) { return counts.getOrDefault(Objects.requireNonNull(key), 0L); }
    public Map<VeilStackKey, Long> contents() { return Map.copyOf(counts); }

    /** Returns the accepted amount; excess remains with the caller. */
    public long insert(VeilStackKey key, long offered, VeilStorageCapacity capacity) {
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(capacity, "capacity");
        if (offered <= 0 || !capacity.unlocked()) return 0L;
        long existing = counts.getOrDefault(key, 0L);
        if (existing == 0L && counts.size() >= capacity.maxTypes()) return 0L;
        long room = capacity.maxItems() == Long.MAX_VALUE
                ? Long.MAX_VALUE - totalItems
                : Math.max(0L, capacity.maxItems() - totalItems);
        long accepted = Math.min(offered, room);
        if (accepted <= 0) return 0L;
        long updated;
        try {
            updated = Math.addExact(existing, accepted);
            totalItems = Math.addExact(totalItems, accepted);
        } catch (ArithmeticException overflow) {
            throw new IllegalStateException("Veil Inventory count overflow", overflow);
        }
        counts.put(key, updated);
        changed();
        return accepted;
    }

    /** Returns the extracted amount. */
    public long extract(VeilStackKey key, long requested) {
        Objects.requireNonNull(key, "key");
        if (requested <= 0) return 0L;
        long existing = counts.getOrDefault(key, 0L);
        long extracted = Math.min(existing, requested);
        if (extracted <= 0) return 0L;
        long remaining = existing - extracted;
        if (remaining == 0L) counts.remove(key); else counts.put(key, remaining);
        totalItems -= extracted;
        changed();
        return extracted;
    }

    /** Persistence-only restore; validates counts and recomputes totals rather than trusting them. */
    public void replaceFromPersistence(Map<VeilStackKey, Long> restored) {
        replaceContents(restored, false);
    }

    /** Package transaction hook: validates the complete post-operation state and emits one mutation. */
    void replaceTransactionally(Map<VeilStackKey, Long> restored) {
        replaceContents(restored, true);
    }

    private void replaceContents(Map<VeilStackKey, Long> restored, boolean notifyMutation) {
        Objects.requireNonNull(restored, "restored");
        LinkedHashMap<VeilStackKey, Long> candidate = new LinkedHashMap<>();
        long candidateTotal = 0L;
        for (var entry : restored.entrySet()) {
            VeilStackKey key = Objects.requireNonNull(entry.getKey(), "persisted key");
            long count = Objects.requireNonNull(entry.getValue(), "persisted count");
            if (count <= 0) throw new IllegalArgumentException("Persisted Veil stack count must be > 0");
            if (candidate.put(key, count) != null) throw new IllegalArgumentException("Duplicate persisted Veil stack key");
            try { candidateTotal = Math.addExact(candidateTotal, count); }
            catch (ArithmeticException overflow) { throw new IllegalArgumentException("Persisted Veil Inventory total overflow", overflow); }
        }
        counts.clear();
        counts.putAll(candidate);
        totalItems = candidateTotal;
        if (notifyMutation) changed();
    }

    public void setMutationListener(Runnable listener) {
        this.mutationListener = Objects.requireNonNull(listener, "listener");
    }

    private void changed() { mutationListener.run(); }
}
