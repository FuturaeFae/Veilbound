package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.matter.MatterRecipeSource;
import dev.futurae.veilbound.matter.RecipeMatterModel;
import dev.futurae.veilbound.matter.RecipeMatterModel.IngredientSlot;
import dev.futurae.veilbound.matter.RecipeMatterModel.ItemAmount;
import dev.futurae.veilbound.matter.RecipeMatterModel.OutputStack;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.util.context.ContextMap;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.item.crafting.display.FurnaceRecipeDisplay;
import net.minecraft.world.item.crafting.display.RecipeDisplay;
import net.minecraft.world.item.crafting.display.ShapedCraftingRecipeDisplay;
import net.minecraft.world.item.crafting.display.ShapelessCraftingRecipeDisplay;
import net.minecraft.world.item.crafting.display.SlotDisplay;
import net.minecraft.world.item.crafting.display.SlotDisplayContext;
import net.minecraft.world.item.crafting.display.SmithingRecipeDisplay;
import net.minecraft.world.item.crafting.display.StonecutterRecipeDisplay;
import net.minecraft.world.level.Level;

/**
 * NeoForge/Minecraft 26.2 recipe adapter for automatic Matter inference.
 *
 * Only recipe displays whose material flow can be understood conservatively are normalized.
 * Unknown/custom displays are skipped, not guessed. Furnace fuel is intentionally excluded:
 * the display exposes valid fuels, but a single recipe does not encode a trustworthy consumed
 * fuel amount per output. This biases inferred values downward instead of creating Matter loops.
 */
public final class NeoForgeRecipeMatterSource implements MatterRecipeSource {
    private final RecipeManager recipeManager;
    private final ContextMap displayContext;

    public NeoForgeRecipeMatterSource(RecipeManager recipeManager, Level level) {
        this.recipeManager = Objects.requireNonNull(recipeManager, "recipeManager");
        this.displayContext = SlotDisplayContext.fromLevel(Objects.requireNonNull(level, "level"));
    }

    @Override
    public Collection<RecipeMatterModel> normalizedRecipes() {
        List<RecipeMatterModel> normalized = new ArrayList<>();
        for (RecipeHolder<?> holder : recipeManager.getRecipes()) {
            Recipe<?> recipe = holder.value();
            String baseId = holder.id().identifier().toString();
            String recipeType = registryId(BuiltInRegistries.RECIPE_TYPE.getKey(recipe.getType()));
            List<RecipeDisplay> displays = recipe.display();
            for (int i = 0; i < displays.size(); i++) {
                normalizeDisplay(baseId + "#display" + i, recipeType, displays.get(i)).ifPresent(normalized::add);
            }
        }
        return List.copyOf(normalized);
    }

    private Optional<RecipeMatterModel> normalizeDisplay(String recipeId, String recipeType, RecipeDisplay display) {
        if (display instanceof ShapedCraftingRecipeDisplay shaped) {
            return normalize(recipeId, recipeType, shaped.ingredients(), shaped.result());
        }
        if (display instanceof ShapelessCraftingRecipeDisplay shapeless) {
            return normalize(recipeId, recipeType, shapeless.ingredients(), shapeless.result());
        }
        if (display instanceof StonecutterRecipeDisplay stonecutter) {
            return normalize(recipeId, recipeType, List.of(stonecutter.input()), stonecutter.result());
        }
        if (display instanceof SmithingRecipeDisplay smithing) {
            return normalize(recipeId, recipeType,
                    List.of(smithing.template(), smithing.base(), smithing.addition()), smithing.result());
        }
        if (display instanceof FurnaceRecipeDisplay furnace) {
            // Fuel is deliberately not included. See class-level safety note.
            return normalize(recipeId, recipeType, List.of(furnace.ingredient()), furnace.result());
        }
        return Optional.empty();
    }

    private Optional<RecipeMatterModel> normalize(
            String recipeId,
            String recipeType,
            List<SlotDisplay> ingredientDisplays,
            SlotDisplay resultDisplay) {
        List<IngredientSlot> inputs = new ArrayList<>();
        List<OutputStack> returned = new ArrayList<>();

        for (SlotDisplay display : ingredientDisplays) {
            if (display instanceof SlotDisplay.Empty) continue;

            SlotDisplay actualInput = display;
            if (display instanceof SlotDisplay.WithRemainder withRemainder) {
                actualInput = withRemainder.input();
                Optional<OutputStack> remainder = singleConcreteOutput(withRemainder.remainder());
                if (remainder.isEmpty()) return Optional.empty();
                returned.add(remainder.get());
            }

            Optional<IngredientSlot> slot = ingredientSlot(actualInput);
            if (slot.isEmpty()) return Optional.empty();
            inputs.add(slot.get());
        }

        if (inputs.isEmpty()) return Optional.empty();
        Optional<OutputStack> output = singleConcreteOutput(resultDisplay);
        if (output.isEmpty()) return Optional.empty();
        return Optional.of(new RecipeMatterModel(recipeId, recipeType, inputs, output.get(), returned));
    }

    private Optional<IngredientSlot> ingredientSlot(SlotDisplay display) {
        List<ItemStack> resolved = display.resolveForStacks(displayContext);
        if (resolved.isEmpty()) return Optional.empty();

        // Multiple stacks here mean alternatives (for example, a tag). Collapse duplicate item ids
        // while retaining the smallest represented count so we never inflate an alternative.
        Map<String, Integer> alternatives = new LinkedHashMap<>();
        for (ItemStack stack : resolved) {
            if (stack == null || stack.isEmpty() || stack.getCount() <= 0) continue;
            String itemId = registryId(BuiltInRegistries.ITEM.getKey(stack.getItem()));
            alternatives.merge(itemId, stack.getCount(), Math::min);
        }
        if (alternatives.isEmpty()) return Optional.empty();

        List<ItemAmount> amounts = alternatives.entrySet().stream()
                .map(entry -> new ItemAmount(entry.getKey(), entry.getValue()))
                .toList();
        return Optional.of(new IngredientSlot(amounts));
    }

    private Optional<OutputStack> singleConcreteOutput(SlotDisplay display) {
        List<ItemStack> resolved = display.resolveForStacks(displayContext);
        Map<String, Integer> distinct = new LinkedHashMap<>();
        for (ItemStack stack : resolved) {
            if (stack == null || stack.isEmpty() || stack.getCount() <= 0) continue;
            String id = registryId(BuiltInRegistries.ITEM.getKey(stack.getItem()));
            distinct.merge(id, stack.getCount(), Math::min);
        }
        if (distinct.size() != 1) return Optional.empty();
        Map.Entry<String, Integer> only = distinct.entrySet().iterator().next();
        return Optional.of(new OutputStack(only.getKey(), only.getValue()));
    }

    private static String registryId(Object identifier) {
        return Objects.requireNonNull(identifier, "registry identifier").toString();
    }
}
