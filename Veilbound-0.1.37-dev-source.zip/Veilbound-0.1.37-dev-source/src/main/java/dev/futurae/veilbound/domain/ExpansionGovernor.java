package dev.futurae.veilbound.domain;

import java.util.Objects;

/** Pure validation/planning layer for continuous six-direction Domain growth. */
public final class ExpansionGovernor {
    private ExpansionGovernor() {}

    public static ExpansionDecision planOneBlock(
            DomainState state,
            AxisDirection direction,
            ExpansionPolicy policy,
            boolean ownerOnline) {
        Objects.requireNonNull(state);
        Objects.requireNonNull(direction);
        Objects.requireNonNull(policy);
        if (!ownerOnline) return ExpansionDecision.denied("owner_offline");
        if (!state.coreActive()) return ExpansionDecision.denied("core_inactive");
        if (!state.globalExpansionEnabled()) return ExpansionDecision.denied("global_expansion_disabled");
        if (state.hasOpenBreach()) return ExpansionDecision.denied("breach_open");

        BoundaryPylonState pylon = state.pylons().get(direction);
        if (pylon == null || !pylon.online()) return ExpansionDecision.denied("pylon_offline");
        if (!pylon.expansionEnabled()) return ExpansionDecision.denied("direction_disabled");

        DomainBounds next;
        try {
            next = state.bounds().expand(direction, 1);
        } catch (ArithmeticException overflow) {
            return ExpansionDecision.denied("coordinate_limit");
        }

        int horizontalCap = state.coreTier().isHorizontallyUnlimitedByDefault()
                ? policy.transcendentHorizontalCap()
                : state.coreTier().defaultHorizontalSizeCap();
        if (horizontalCap > 0 && (next.sizeX() > horizontalCap || next.sizeZ() > horizontalCap)) {
            return ExpansionDecision.denied("tier_horizontal_cap");
        }
        if (next.sizeY() > policy.verticalSpanCap()) {
            return ExpansionDecision.denied("vertical_cap");
        }

        long addedVolume = next.volume() - state.bounds().volume();
        long cost;
        try {
            cost = Math.multiplyExact(addedVolume, pylon.speed().scaleSquared(policy.dimensionalEnergyPerNewBlock()));
        } catch (ArithmeticException overflow) {
            return ExpansionDecision.denied("cost_overflow");
        }
        if (state.dimensionalEnergy() < cost) return ExpansionDecision.denied("insufficient_dimensional_energy");
        return ExpansionDecision.allowed(next, cost);
    }

    /** Compatibility overload retained for the initial source API. */
    public static ExpansionDecision planOneBlock(
            DomainState state,
            AxisDirection direction,
            long deCostPerNewBlock,
            int configuredTranscendentHorizontalCap,
            boolean ownerOnline) {
        return planOneBlock(
                state,
                direction,
                new ExpansionPolicy(deCostPerNewBlock, ExpansionPolicy.ABSOLUTE_MAX_VERTICAL_SPAN, configuredTranscendentHorizontalCap),
                ownerOnline);
    }

    public static boolean apply(DomainState state, ExpansionDecision decision) {
        if (!decision.allowed()) return false;
        if (!state.consumeDimensionalEnergy(decision.dimensionalEnergyCost())) return false;
        state.setBounds(decision.newBounds());
        return true;
    }

    public record ExpansionDecision(boolean allowed, DomainBounds newBounds, long dimensionalEnergyCost, String reason) {
        public static ExpansionDecision denied(String reason) {
            return new ExpansionDecision(false, null, 0, reason);
        }
        public static ExpansionDecision allowed(DomainBounds bounds, long cost) {
            return new ExpansionDecision(true, bounds, cost, "ok");
        }
    }
}
