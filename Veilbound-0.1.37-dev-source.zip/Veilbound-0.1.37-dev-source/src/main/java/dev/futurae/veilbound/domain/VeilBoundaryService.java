package dev.futurae.veilbound.domain;

import java.util.Objects;

/**
 * Pure geometry for the solid Veil shell around usable Domain space. The shell is visually treated
 * as ten blocks thick by default (within the settled 8-12 block range); gameplay crossing is denied
 * at its inner face, so thickness is presentation/hazard depth rather than extra usable volume.
 */
public final class VeilBoundaryService {
    public static final int MIN_VISUAL_THICKNESS = 8;
    public static final int DEFAULT_VISUAL_THICKNESS = 10;
    public static final int MAX_VISUAL_THICKNESS = 12;

    private VeilBoundaryService() {}

    public static boolean usable(DomainState state, DomainPosition position) {
        return Objects.requireNonNull(state, "state").bounds().contains(Objects.requireNonNull(position, "position"));
    }

    public static boolean pylonException(DomainState state, DomainPosition position) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(position, "position");
        return state.pylons().values().stream()
                .anyMatch(pylon -> pylon.bound() && position.equals(pylon.blockPosition()));
    }

    public static boolean mayOccupyBlock(DomainState state, DomainPosition position) {
        return usable(state, position) || pylonException(state, position);
    }

    public static boolean inVisualVeilShell(DomainState state, DomainPosition position, int thickness) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(position, "position");
        if (thickness < MIN_VISUAL_THICKNESS || thickness > MAX_VISUAL_THICKNESS) {
            throw new IllegalArgumentException("Veil thickness must be between 8 and 12 blocks");
        }
        if (state.bounds().contains(position)) return false;
        DomainBounds b = state.bounds();
        long dx = position.x() < b.minX() ? (long) b.minX() - position.x()
                : position.x() > b.maxX() ? (long) position.x() - b.maxX() : 0;
        long dy = position.y() < b.minY() ? (long) b.minY() - position.y()
                : position.y() > b.maxY() ? (long) position.y() - b.maxY() : 0;
        long dz = position.z() < b.minZ() ? (long) b.minZ() - position.z()
                : position.z() > b.maxZ() ? (long) position.z() - b.maxZ() : 0;
        return Math.max(dx, Math.max(dy, dz)) <= thickness;
    }

    /** Clamp a block coordinate back into the nearest usable coordinate. */
    public static DomainPosition clampToUsable(DomainState state, DomainPosition position) {
        DomainBounds b = Objects.requireNonNull(state, "state").bounds();
        Objects.requireNonNull(position, "position");
        return new DomainPosition(
                Math.max(b.minX(), Math.min(b.maxX(), position.x())),
                Math.max(b.minY(), Math.min(b.maxY(), position.y())),
                Math.max(b.minZ(), Math.min(b.maxZ(), position.z())));
    }
}
