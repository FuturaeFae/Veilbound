package dev.futurae.veilbound.domain;

import java.util.Objects;

/** Durable logical state for one of the six physical Core-relative moving Boundary Pylons. */
public record BoundaryPylonState(
        AxisDirection direction,
        boolean expansionEnabled,
        boolean online,
        DomainPosition blockPosition,
        BoundaryPylonSpeed speed) {
    public BoundaryPylonState {
        Objects.requireNonNull(direction, "direction");
        speed = speed == null ? BoundaryPylonSpeed.STABLE : speed;
        if (online && blockPosition == null) {
            throw new IllegalArgumentException("An online Boundary Pylon must have a physical block position");
        }
        if (!online && expansionEnabled) {
            throw new IllegalArgumentException("An offline Boundary Pylon may not keep expansion enabled");
        }
    }

    /** Source-compatibility constructor for v11/v12-era callers; old Pylons migrate to Stable. */
    public BoundaryPylonState(
            AxisDirection direction, boolean expansionEnabled, boolean online, DomainPosition blockPosition) {
        this(direction, expansionEnabled, online, blockPosition, BoundaryPylonSpeed.STABLE);
    }

    public boolean bound() { return blockPosition != null; }

    public BoundaryPylonState withExpansionEnabled(boolean enabled) {
        if (enabled && !online) throw new IllegalStateException("Cannot enable an offline Boundary Pylon");
        return new BoundaryPylonState(direction, enabled, online, blockPosition, speed);
    }

    public BoundaryPylonState withOnline(boolean value) {
        if (!value) return new BoundaryPylonState(direction, false, false, null, speed);
        if (blockPosition == null) throw new IllegalStateException("Cannot mark an unbound Boundary Pylon online");
        return new BoundaryPylonState(direction, expansionEnabled, true, blockPosition, speed);
    }

    public BoundaryPylonState withSpeed(BoundaryPylonSpeed value) {
        return new BoundaryPylonState(direction, expansionEnabled, online, blockPosition, Objects.requireNonNull(value, "value"));
    }

    public BoundaryPylonState cycleSpeed() { return withSpeed(speed.next()); }

    public BoundaryPylonState bind(DomainPosition position) {
        return new BoundaryPylonState(direction, expansionEnabled, true, Objects.requireNonNull(position, "position"), speed);
    }

    public BoundaryPylonState moveTo(DomainPosition position) {
        if (!bound()) throw new IllegalStateException("Cannot move an unbound Boundary Pylon");
        return new BoundaryPylonState(direction, expansionEnabled, online, Objects.requireNonNull(position, "position"), speed);
    }

    public BoundaryPylonState unbind() {
        return new BoundaryPylonState(direction, false, false, null, speed);
    }
}
