package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Opens the local, translation-backed Engineering Codex screen. */
public record OpenEngineeringCodexPayload() implements CustomPacketPayload {
    public static final OpenEngineeringCodexPayload INSTANCE = new OpenEngineeringCodexPayload();
    public static final Type<OpenEngineeringCodexPayload> TYPE = new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "open_engineering_codex"));
    public static final StreamCodec<RegistryFriendlyByteBuf, OpenEngineeringCodexPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override public OpenEngineeringCodexPayload decode(RegistryFriendlyByteBuf b){ return INSTANCE; }
        @Override public void encode(RegistryFriendlyByteBuf b, OpenEngineeringCodexPayload p){}
    };
    @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
}
