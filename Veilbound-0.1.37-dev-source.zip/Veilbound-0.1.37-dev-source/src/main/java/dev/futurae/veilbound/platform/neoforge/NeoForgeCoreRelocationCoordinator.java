package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.domain.DomainIdentity;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import dev.futurae.veilbound.registry.VeilboundItems;
import dev.futurae.veilbound.ritual.CoreRelocationService;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * Physical later-game Core relocation ritual.
 *
 * <p>Sneak-use a Nucleus Catalyst against a block face inside the owner's active Domain. The
 * adjacent cell becomes the proposed Core position. The ritual is deliberately physical: it
 * consumes one Catalyst and 10,000 DE, refuses an open Breach or obstructed arrival space, moves
 * the indestructible Core block atomically, and never changes the Domain's permanent origin.</p>
 */
public final class NeoForgeCoreRelocationCoordinator {
    private final VeilboundRuntime runtime;

    public NeoForgeCoreRelocationCoordinator(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.isCanceled()
                || !(event.getEntity() instanceof ServerPlayer player)
                || event.getLevel().isClientSide()
                || !player.isShiftKeyDown()
                || !event.getItemStack().is(VeilboundItems.NUCLEUS_CATALYST.get())) {
            return;
        }

        String currentDimension = event.getLevel().dimension().identifier().toString();
        if (DomainIdentity.ownerFromDimensionId(currentDimension).isEmpty()) {
            return; // A Catalyst remains an ordinary item outside Veilbound personal Domains.
        }

        DomainRecord record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null || !record.identity().dimensionId().equals(currentDimension)) {
            player.displayClientMessage(Component.translatable("message.veilbound.core_relocation.not_owner_domain"), true);
            reject(event);
            return;
        }
        if (!(event.getLevel() instanceof ServerLevel level)) return;

        BlockPos targetPos = event.getPos().relative(event.getFace());
        DomainPosition target = position(targetPos);
        CoreRelocationService.Plan plan = CoreRelocationService.plan(record.state(), target);
        if (!plan.allowed()) {
            player.displayClientMessage(Component.translatable(
                    "message.veilbound.core_relocation." + plan.reason(), plan.dimensionalEnergyCost()), true);
            reject(event);
            return;
        }

        BlockPos oldCorePos = blockPos(record.state().corePosition());
        if (!level.getBlockState(oldCorePos).is(VeilboundBlocks.DIMENSIONAL_CORE.get())) {
            player.displayClientMessage(Component.translatable("message.veilbound.core_relocation.core_missing"), true);
            reject(event);
            return;
        }

        BlockState targetPrevious = level.getBlockState(targetPos);
        if (!targetPrevious.canBeReplaced()) {
            player.displayClientMessage(Component.translatable("message.veilbound.core_relocation.target_obstructed"), true);
            reject(event);
            return;
        }
        if (!level.getBlockState(targetPos.above()).isAir() || !level.getBlockState(targetPos.above(2)).isAir()) {
            player.displayClientMessage(Component.translatable("message.veilbound.core_relocation.arrival_obstructed"), true);
            reject(event);
            return;
        }

        // Stage the physical move before committing state/DE. Restore both sides on any failure.
        if (!level.setBlockAndUpdate(targetPos, VeilboundBlocks.DIMENSIONAL_CORE.get().defaultBlockState())) {
            player.displayClientMessage(Component.translatable("message.veilbound.core_relocation.target_obstructed"), true);
            reject(event);
            return;
        }
        if (!level.setBlockAndUpdate(oldCorePos, Blocks.AIR.defaultBlockState())) {
            level.setBlockAndUpdate(targetPos, targetPrevious);
            player.displayClientMessage(Component.translatable("message.veilbound.core_relocation.move_failed"), true);
            reject(event);
            return;
        }

        boolean applied;
        try {
            applied = CoreRelocationService.apply(record.state(), plan);
        } catch (RuntimeException failure) {
            level.setBlockAndUpdate(targetPos, targetPrevious);
            level.setBlockAndUpdate(oldCorePos, VeilboundBlocks.DIMENSIONAL_CORE.get().defaultBlockState());
            throw failure;
        }
        if (!applied) {
            level.setBlockAndUpdate(targetPos, targetPrevious);
            level.setBlockAndUpdate(oldCorePos, VeilboundBlocks.DIMENSIONAL_CORE.get().defaultBlockState());
            player.displayClientMessage(Component.translatable("message.veilbound.core_relocation.move_failed"), true);
            reject(event);
            return;
        }

        if (!player.getAbilities().instabuild) event.getItemStack().shrink(1);
        player.displayClientMessage(Component.translatable(
                "message.veilbound.core_relocation.success", CoreRelocationService.DEFAULT_DIMENSIONAL_ENERGY_COST), false);
        accept(event);
    }

    private static DomainPosition position(BlockPos pos) {
        return new DomainPosition(pos.getX(), pos.getY(), pos.getZ());
    }

    private static BlockPos blockPos(DomainPosition pos) {
        return new BlockPos(pos.x(), pos.y(), pos.z());
    }

    private static void accept(PlayerInteractEvent.RightClickBlock event) {
        event.setCancellationResult(InteractionResult.SUCCESS);
        event.setCanceled(true);
    }

    private static void reject(PlayerInteractEvent.RightClickBlock event) {
        event.setCancellationResult(InteractionResult.FAIL);
        event.setCanceled(true);
    }
}
