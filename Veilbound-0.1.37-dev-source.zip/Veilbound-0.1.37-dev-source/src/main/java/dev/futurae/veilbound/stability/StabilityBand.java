package dev.futurae.veilbound.stability;

/** Descriptive bands; thresholds themselves are configurable. */
public enum StabilityBand {
    STABLE,
    STRAINED,
    CRITICAL,
    RUPTURING
}
