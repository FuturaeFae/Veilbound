package dev.futurae.veilbound.domain;

/** Canonical geometry for a newly-created personal Domain. */
public final class StarterPocketLayout {
    private StarterPocketLayout() {}

    /** The first two usable blocks of stable Domain space. */
    public static final DomainBounds USABLE_BOUNDS = DomainBounds.initial();

    /** Reusable Void Anchor foothold directly beneath the usable 1x1x2 pocket. */
    public static final DomainPosition VOID_ANCHOR_FLOOR = new DomainPosition(0, -1, 0);

    /** Centered feet position used on first arrival. */
    public static final double ARRIVAL_X = 0.5D;
    public static final double ARRIVAL_Y = 0.0D;
    public static final double ARRIVAL_Z = 0.5D;

    public static boolean isCanonical() {
        return USABLE_BOUNDS.minX() == 0 && USABLE_BOUNDS.maxX() == 0
                && USABLE_BOUNDS.minY() == 0 && USABLE_BOUNDS.maxY() == 1
                && USABLE_BOUNDS.minZ() == 0 && USABLE_BOUNDS.maxZ() == 0
                && VOID_ANCHOR_FLOOR.x() == 0
                && VOID_ANCHOR_FLOOR.y() == USABLE_BOUNDS.minY() - 1
                && VOID_ANCHOR_FLOOR.z() == 0;
    }
}
