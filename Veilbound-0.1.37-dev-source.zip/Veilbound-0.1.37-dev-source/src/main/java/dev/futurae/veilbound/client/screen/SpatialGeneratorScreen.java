package dev.futurae.veilbound.client.screen;

import dev.futurae.veilbound.network.SpatialGeneratorActionPayload;
import dev.futurae.veilbound.network.SpatialGeneratorSnapshotPayload;
import dev.futurae.veilbound.precore.CondensedCharge;
import dev.futurae.veilbound.precore.SpatialGeneratorPlanner;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;

/** Compact pre-Core control panel for the handheld Spatial Generator. */
public final class SpatialGeneratorScreen extends Screen {
    private static final int WIDTH = 360;
    private static final int HEIGHT = 214;
    private SpatialGeneratorSnapshotPayload snapshot;

    public SpatialGeneratorScreen(SpatialGeneratorSnapshotPayload snapshot) {
        super(Component.translatable("screen.veilbound.spatial_generator"));
        this.snapshot = snapshot;
    }

    public void acceptSnapshot(SpatialGeneratorSnapshotPayload next) {
        this.snapshot = next;
        if (minecraft != null) {
            clearWidgets();
            init();
        }
    }

    @Override
    protected void init() {
        super.init();
        if (!snapshot.allowed()) return;
        int left = width / 2 - WIDTH / 2;
        int top = height / 2 - HEIGHT / 2;

        addRenderableWidget(Button.builder(Component.translatable("screen.veilbound.spatial_generator.condense"),
                b -> send(SpatialGeneratorActionPayload.Action.CONDENSE_FEED_HAND))
                .bounds(left + 16, top + 64, 156, 20).build());

        Button x = Button.builder(Component.translatable("screen.veilbound.spatial_generator.expand_x"),
                b -> send(SpatialGeneratorActionPayload.Action.EXPAND_X)).bounds(left + 16, top + 102, 100, 20).build();
        x.active = canExpandX();
        addRenderableWidget(x);
        Button y = Button.builder(Component.translatable("screen.veilbound.spatial_generator.expand_y"),
                b -> send(SpatialGeneratorActionPayload.Action.EXPAND_Y)).bounds(left + 130, top + 102, 100, 20).build();
        y.active = canExpandY();
        addRenderableWidget(y);
        Button z = Button.builder(Component.translatable("screen.veilbound.spatial_generator.expand_z"),
                b -> send(SpatialGeneratorActionPayload.Action.EXPAND_Z)).bounds(left + 244, top + 102, 100, 20).build();
        z.active = canExpandZ();
        addRenderableWidget(z);

        Button awaken = Button.builder(Component.translatable("screen.veilbound.spatial_generator.awaken"),
                b -> send(SpatialGeneratorActionPayload.Action.AWAKEN_CORE)).bounds(left + 188, top + 64, 156, 20).build();
        awaken.active = canAwaken();
        addRenderableWidget(awaken);
    }

    private void send(SpatialGeneratorActionPayload.Action action) {
        ClientPacketDistributor.sendToServer(new SpatialGeneratorActionPayload(action));
    }

    private long chargeMilli() { return snapshot.chargeMilli(); }
    private long costMilli(long addedBlocks) {
        try { return Math.multiplyExact(Math.multiplyExact(addedBlocks, snapshot.chargePerNewBlock()), CondensedCharge.SCALE); }
        catch (ArithmeticException ignored) { return Long.MAX_VALUE; }
    }
    private boolean canExpandX() {
        return snapshot.sizeX() < SpatialGeneratorPlanner.MAX_AXIS_SPAN
                && chargeMilli() >= costMilli((long) snapshot.sizeY() * snapshot.sizeZ());
    }
    private boolean canExpandY() {
        return snapshot.sizeY() < SpatialGeneratorPlanner.MAX_AXIS_SPAN
                && chargeMilli() >= costMilli((long) snapshot.sizeX() * snapshot.sizeZ());
    }
    private boolean canExpandZ() {
        return snapshot.sizeZ() < SpatialGeneratorPlanner.MAX_AXIS_SPAN
                && chargeMilli() >= costMilli((long) snapshot.sizeX() * snapshot.sizeY());
    }
    private boolean canAwaken() {
        return snapshot.sizeX() >= 3 && snapshot.sizeY() >= 2 && snapshot.sizeZ() >= 3
                && snapshot.chargeMilli() >= snapshot.awakeningCharge() * CondensedCharge.SCALE
                && snapshot.hasCatalyst() && snapshot.atOriginRange() && snapshot.originClear();
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        extractTransparentBackground(graphics);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
        int left = width / 2 - WIDTH / 2;
        int top = height / 2 - HEIGHT / 2;
        graphics.fill(left, top, left + WIDTH, top + HEIGHT, 0xED12101A);
        graphics.fill(left, top, left + WIDTH, top + 34, 0xF0271737);
        graphics.fill(left, top + 33, left + WIDTH, top + 34, 0xFF9F7AC8);
        graphics.centeredText(font, title, width / 2, top + 12, 0xFFF3ECFF);

        if (!snapshot.allowed()) {
            graphics.centeredText(font, reason(snapshot.reason()), width / 2, top + 92, 0xFFFF8585);
            return;
        }

        graphics.text(font, Component.translatable("screen.veilbound.spatial_generator.fe",
                        snapshot.storedForgeEnergy(), snapshot.forgeEnergyCapacity()), left + 16, top + 43, 0xFF9EDCFF, false);
        graphics.text(font, Component.translatable("screen.veilbound.spatial_generator.charge",
                        formatCharge(snapshot.chargeMilli())), left + 188, top + 43, 0xFFE4BCFF, false);
        graphics.centeredText(font, Component.translatable("screen.veilbound.spatial_generator.domain_size",
                        snapshot.sizeX(), snapshot.sizeY(), snapshot.sizeZ()), width / 2, top + 91, 0xFFFFFFFF);
        graphics.text(font, Component.translatable("screen.veilbound.spatial_generator.expansion_cost",
                        snapshot.chargePerNewBlock()), left + 16, top + 132, 0xFFC5BDD0, false);
        graphics.text(font, Component.translatable("screen.veilbound.spatial_generator.efficiency"), left + 16, top + 146, 0xFFC5BDD0, false);

        boolean geometry = snapshot.sizeX() >= 3 && snapshot.sizeY() >= 2 && snapshot.sizeZ() >= 3;
        graphics.text(font, requirement("screen.veilbound.spatial_generator.req.size", geometry), left + 16, top + 168,
                geometry ? 0xFF86E5A7 : 0xFFFF9A9A, false);
        boolean charge = snapshot.chargeMilli() >= snapshot.awakeningCharge() * CondensedCharge.SCALE;
        graphics.text(font, requirement("screen.veilbound.spatial_generator.req.charge", charge, snapshot.awakeningCharge()), left + 16, top + 181,
                charge ? 0xFF86E5A7 : 0xFFFF9A9A, false);
        boolean ritual = snapshot.hasCatalyst() && snapshot.atOriginRange() && snapshot.originClear();
        graphics.text(font, requirement("screen.veilbound.spatial_generator.req.ritual", ritual), left + 188, top + 168,
                ritual ? 0xFF86E5A7 : 0xFFFF9A9A, false);
        if (!snapshot.atOriginRange()) graphics.text(font, Component.translatable("screen.veilbound.spatial_generator.origin_hint"), left + 188, top + 181, 0xFFFFC080, false);
    }

    private static Component requirement(String key, boolean met, Object... args) {
        Component body = Component.translatable(key, args);
        return Component.literal(met ? "✓ " : "✗ ").append(body);
    }

    private static Component reason(String reason) {
        return Component.translatable("screen.veilbound.spatial_generator.denied", reason);
    }

    private static String formatCharge(long milli) {
        long whole = milli / CondensedCharge.SCALE;
        long fraction = milli % CondensedCharge.SCALE;
        return fraction == 0 ? Long.toString(whole) : whole + "." + String.format("%03d", fraction);
    }
}
