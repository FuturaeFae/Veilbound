package dev.futurae.veilbound.upgrade;

import dev.futurae.veilbound.domain.CoreTier;
import java.util.Collection;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/** Runtime datapack registry for sequential Core-tier upgrade definitions. */
public final class CoreUpgradeRegistry {
    private final EnumMap<CoreTier, CoreUpgradeDefinition> byFrom = new EnumMap<>(CoreTier.class);

    public synchronized void replaceAll(Collection<CoreUpgradeDefinition> definitions) {
        Objects.requireNonNull(definitions, "definitions");
        EnumMap<CoreTier, CoreUpgradeDefinition> replacement = new EnumMap<>(CoreTier.class);
        for (CoreUpgradeDefinition definition : definitions) {
            Objects.requireNonNull(definition, "definition");
            if (replacement.putIfAbsent(definition.from(), definition) != null) {
                throw new IllegalArgumentException("Duplicate Core upgrade definition from " + definition.from());
            }
        }
        byFrom.clear();
        byFrom.putAll(replacement);
    }

    public synchronized Optional<CoreUpgradeDefinition> from(CoreTier tier) {
        return Optional.ofNullable(byFrom.get(Objects.requireNonNull(tier, "tier")));
    }

    public synchronized List<CoreUpgradeDefinition> all() {
        return List.copyOf(byFrom.values());
    }

    public synchronized Map<CoreTier, CoreUpgradeDefinition> snapshot() {
        return Map.copyOf(byFrom);
    }
}
