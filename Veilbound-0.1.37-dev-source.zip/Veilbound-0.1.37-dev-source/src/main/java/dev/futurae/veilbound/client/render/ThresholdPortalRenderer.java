package dev.futurae.veilbound.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.futurae.veilbound.block.entity.ThresholdPortalBlockEntity;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.AbstractEndPortalRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.CameraRenderState;

/**
 * Full-cell shader renderer for active Thresholds.
 *
 * <p>Uses Minecraft's real End-Portal render pipeline, submitted as a complete cube, so every
 * activated frame cell becomes a full block of spatial/depth distortion instead of a flat
 * animated texture. Veilbound transit logic remains server-authoritative and unrelated to the
 * vanilla End Portal block.</p>
 */
public final class ThresholdPortalRenderer
        implements BlockEntityRenderer<ThresholdPortalBlockEntity, BlockEntityRenderState> {

    @Override
    public BlockEntityRenderState createRenderState() {
        return new BlockEntityRenderState();
    }

    @Override
    public void submit(
            BlockEntityRenderState state,
            PoseStack poseStack,
            SubmitNodeCollector collector,
            CameraRenderState camera) {
        AbstractEndPortalRenderer.submitSpecial(RenderTypes.endPortal(), poseStack, collector);
    }
}
