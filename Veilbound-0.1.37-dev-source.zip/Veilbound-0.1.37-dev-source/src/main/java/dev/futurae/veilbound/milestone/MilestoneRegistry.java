package dev.futurae.veilbound.milestone;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/** Replace-all runtime registry for datapack-defined milestones. Missing prerequisites simply leave a milestone inert. */
public final class MilestoneRegistry {
    private final LinkedHashMap<String, MilestoneDefinition> byId = new LinkedHashMap<>();

    public synchronized void replaceAll(Collection<MilestoneDefinition> definitions) {
        Objects.requireNonNull(definitions, "definitions");
        LinkedHashMap<String, MilestoneDefinition> replacement = new LinkedHashMap<>();
        for (MilestoneDefinition definition : definitions) {
            Objects.requireNonNull(definition, "definition");
            if (replacement.putIfAbsent(definition.id(), definition) != null) {
                throw new IllegalArgumentException("Duplicate milestone definition: " + definition.id());
            }
        }
        byId.clear();
        byId.putAll(replacement);
    }

    public synchronized Optional<MilestoneDefinition> get(String id) {
        return Optional.ofNullable(byId.get(Objects.requireNonNull(id, "id")));
    }

    public synchronized List<MilestoneDefinition> all() { return List.copyOf(byId.values()); }
    public synchronized Map<String, MilestoneDefinition> snapshot() { return Map.copyOf(byId); }
}
