package dev.futurae.veilbound.registry;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorMaterials;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

/**
 * Veilbound armor materials keep the familiar vanilla armor-stat baselines while owning
 * their own equipment assets. This is what allows the worn armor model to render Veilbound
 * textures instead of silently borrowing Diamond/Netherite visuals.
 */
public final class VeilboundArmorMaterials {
    public static final ResourceKey<EquipmentAsset> PHASEWEAVE_ASSET = asset("phaseweave");
    public static final ResourceKey<EquipmentAsset> CAUSAL_ASSET = asset("causal");
    public static final ResourceKey<EquipmentAsset> SOVEREIGN_ASSET = asset("sovereign");

    public static final ArmorMaterial PHASEWEAVE = withAsset(ArmorMaterials.DIAMOND, PHASEWEAVE_ASSET);
    public static final ArmorMaterial CAUSAL = withAsset(ArmorMaterials.NETHERITE, CAUSAL_ASSET);
    public static final ArmorMaterial SOVEREIGN = withAsset(ArmorMaterials.NETHERITE, SOVEREIGN_ASSET);

    private static ResourceKey<EquipmentAsset> asset(String path) {
        return ResourceKey.create(EquipmentAssets.ROOT_ID, Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, path));
    }

    private static ArmorMaterial withAsset(ArmorMaterial base, ResourceKey<EquipmentAsset> asset) {
        return new ArmorMaterial(
                base.durability(),
                base.defense(),
                base.enchantmentValue(),
                base.equipSound(),
                base.toughness(),
                base.knockbackResistance(),
                base.repairIngredient(),
                asset);
    }

    private VeilboundArmorMaterials() {}
}
