package dev.futurae.veilbound.platform.neoforge;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.milestone.MilestoneCriteria;
import dev.futurae.veilbound.milestone.MilestoneDefinition;
import dev.futurae.veilbound.milestone.MilestoneRegistry;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

/** Loads data/<namespace>/veilbound/milestones/<path>.json into the runtime progression registry. */
public final class NeoForgeMilestoneReloadListener
        extends SimplePreparableReloadListener<DatapackDefinitionSnapshot<MilestoneDefinition>> {
    public static final Identifier LISTENER_ID = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "milestones");
    public static final String DIRECTORY = "veilbound/milestones";

    private final Gson gson = new Gson();
    private final MilestoneRegistry registry;

    public NeoForgeMilestoneReloadListener(MilestoneRegistry registry) {
        this.registry = Objects.requireNonNull(registry, "registry");
    }

    @Override
    protected DatapackDefinitionSnapshot<MilestoneDefinition> prepare(ResourceManager resourceManager, ProfilerFiller profiler) {
        List<MilestoneDefinition> definitions = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        List<Map.Entry<Identifier, Resource>> resources = resourceManager
                .listResources(DIRECTORY, id -> id.getPath().endsWith(".json"))
                .entrySet().stream()
                .sorted(Map.Entry.comparingByKey(Comparator.comparing(Identifier::toString)))
                .toList();

        for (Map.Entry<Identifier, Resource> entry : resources) {
            Identifier resourceId = entry.getKey();
            String id = NeoForgeDefinitionJson.idFromResource(resourceId, DIRECTORY);
            if (id == null) {
                warnings.add("Ignored malformed Milestone path: " + resourceId);
                continue;
            }
            try (Reader reader = entry.getValue().openAsReader()) {
                JsonObject object = NeoForgeDefinitionJson.requireObject(gson.fromJson(reader, JsonElement.class));
                JsonObject criteriaObject = NeoForgeDefinitionJson.optionalObject(object, "criteria");
                MilestoneCriteria criteria = new MilestoneCriteria(
                        NeoForgeDefinitionJson.optionalBoolean(criteriaObject, "core_active", false),
                        optionalCoreTier(criteriaObject, "minimum_core_tier"),
                        NeoForgeDefinitionJson.optionalNonNegativeInt(criteriaObject, "minimum_archived_memories", 0),
                        NeoForgeDefinitionJson.optionalNonNegativeInt(criteriaObject, "minimum_bound_pylons", 0),
                        NeoForgeDefinitionJson.optionalNonNegativeInt(criteriaObject, "minimum_environment_zones", 0),
                        NeoForgeDefinitionJson.optionalNonNegativeInt(criteriaObject, "minimum_permanent_thresholds", 0),
                        NeoForgeDefinitionJson.optionalNonNegativeInt(criteriaObject, "minimum_imposed_laws", 0),
                        NeoForgeDefinitionJson.optionalNonNegativeInt(criteriaObject, "minimum_size_x", 0),
                        NeoForgeDefinitionJson.optionalNonNegativeInt(criteriaObject, "minimum_size_y", 0),
                        NeoForgeDefinitionJson.optionalNonNegativeInt(criteriaObject, "minimum_size_z", 0),
                        NeoForgeDefinitionJson.optionalBoolean(criteriaObject, "sovereignty_unlocked", false),
                        parseFeatures(criteriaObject, "required_features"));
                definitions.add(new MilestoneDefinition(
                        id,
                        NeoForgeDefinitionJson.requiredString(object, "display_name"),
                        NeoForgeDefinitionJson.optionalStringSet(object, "prerequisites"),
                        criteria,
                        parseFeatures(object, "unlocked_features")));
            } catch (IOException | JsonParseException | IllegalArgumentException ex) {
                warnings.add("Ignored Milestone " + resourceId + ": " + ex.getMessage());
            }
        }
        return new DatapackDefinitionSnapshot<>(definitions, warnings);
    }

    @Override
    protected void apply(DatapackDefinitionSnapshot<MilestoneDefinition> snapshot, ResourceManager manager, ProfilerFiller profiler) {
        registry.replaceAll(snapshot.definitions());
        snapshot.warnings().forEach(warning -> Veilbound.LOGGER.warn("{}", warning));
        Veilbound.LOGGER.info("Loaded {} Veilbound Milestones", snapshot.definitions().size());
    }

    private static CoreTier optionalCoreTier(JsonObject object, String key) {
        String name = NeoForgeDefinitionJson.optionalString(object, key, null);
        if (name == null) return null;
        try {
            return CoreTier.valueOf(name.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            throw new JsonParseException("unknown Core tier '" + name + "'");
        }
    }

    private static Set<DomainFeature> parseFeatures(JsonObject object, String key) {
        Set<String> names = NeoForgeDefinitionJson.optionalStringSet(object, key);
        EnumSet<DomainFeature> features = EnumSet.noneOf(DomainFeature.class);
        for (String name : names) {
            try {
                features.add(DomainFeature.valueOf(name.toUpperCase(Locale.ROOT)));
            } catch (IllegalArgumentException ex) {
                throw new JsonParseException("unknown Domain feature '" + name + "'");
            }
        }
        return Set.copyOf(features);
    }
}
