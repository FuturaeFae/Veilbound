package dev.futurae.veilbound.domain;

/**
 * Reality capabilities intentionally absent from a fresh Domain.
 * Unlock sources are data-driven (upgrades, Memories, milestones, Laws) rather than
 * being silently granted by Domain size.
 */
public enum DomainFeature {
    ILLUMINATION,
    FERTILITY,
    ARBOREAL_GROWTH,
    FIRMAMENT,
    CELESTIAL_CYCLE,
    WEATHER,
    AMBIENCE,
    LIFE,
    PREDATION,
    SURFACE_DEFINITION,
    ENVIRONMENTAL_MASTERY,
    ANOMALIES,
    MILESTONES,
    RELICS,
    SURVEYING,
    VEIL_INVENTORY,
    VEIL_CRAFTING,
    VEIL_TRANSMUTATION
}
