package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.BoundaryPylonBindingService;
import dev.futurae.veilbound.domain.CoreControlService;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.network.DomainControlsActionPayload;
import dev.futurae.veilbound.network.DomainControlsSnapshotPayload;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import dev.futurae.veilbound.threshold.ThresholdDefinition;
import java.util.Comparator;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

/** Server authority for the combined Core, Pylon, and Threshold owner controls. */
public final class NeoForgeDomainControlsController {
    private final VeilboundRuntime runtime;

    public NeoForgeDomainControlsController(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    public void open(ServerPlayer player, DomainControlsSnapshotPayload.View view) { send(player, view, "ok"); }

    public void handle(ServerPlayer player, DomainControlsActionPayload payload) {
        DomainControlsSnapshotPayload.View view = viewFor(payload.action());
        DomainRecord record = ownerRecordInCurrentDomain(player);
        if (record == null) {
            PacketDistributor.sendToPlayer(player, DomainControlsSnapshotPayload.denied(view, "not_owner_domain"));
            return;
        }
        String reason = switch (payload.action()) {
            case OPEN_CORE, OPEN_PYLONS, OPEN_THRESHOLDS -> "ok";
            case TOGGLE_GLOBAL_EXPANSION -> toggleExpansion(record);
            case TOGGLE_PYLON -> togglePylon(record, payload.targetId());
            case CYCLE_PYLON_SPEED -> cyclePylonSpeed(record, payload.targetId());
            case TOGGLE_THRESHOLD_PUBLIC -> togglePublic(record, payload.targetId());
            case TOGGLE_THRESHOLD_INVITE -> toggleInvite(record, payload.targetId(), payload.value());
        };
        send(player, view, reason);
    }

    private static String toggleExpansion(DomainRecord record) {
        var result = CoreControlService.toggleExpansion(record.state());
        return result.toggled() ? "ok" : result.reason();
    }


    private static String togglePylon(DomainRecord record, String rawDirection) {
        AxisDirection direction;
        try { direction = AxisDirection.valueOf(rawDirection); }
        catch (IllegalArgumentException | NullPointerException ignored) { return "invalid_pylon"; }
        var state = record.state().pylons().get(direction);
        if (state == null || !state.bound() || !state.online() || state.blockPosition() == null) return "pylon_offline";
        var result = BoundaryPylonBindingService.toggleExpansion(record.state(), direction, state.blockPosition());
        return result.toggled() ? "ok" : result.reason();
    }


    private static String cyclePylonSpeed(DomainRecord record, String rawDirection) {
        AxisDirection direction;
        try { direction = AxisDirection.valueOf(rawDirection); }
        catch (IllegalArgumentException | NullPointerException ignored) { return "invalid_pylon"; }
        var result = BoundaryPylonBindingService.cycleSpeed(record.state(), direction);
        return result.changed() ? "ok" : result.reason();
    }

    private String togglePublic(DomainRecord record, String thresholdId) {
        ThresholdDefinition threshold = ownedThreshold(record, thresholdId);
        if (threshold == null) return "threshold_not_found";
        threshold.access().setPublicAccess(!threshold.access().publicAccess());
        return "ok";
    }

    private String toggleInvite(DomainRecord record, String thresholdId, String playerId) {
        ThresholdDefinition threshold = ownedThreshold(record, thresholdId);
        if (threshold == null) return "threshold_not_found";
        UUID guest;
        try { guest = UUID.fromString(playerId); }
        catch (IllegalArgumentException | NullPointerException ignored) { return "invalid_guest"; }
        if (guest.equals(record.state().ownerId())) return "owner_not_guest";
        if (threshold.access().invitedGuests().contains(guest)) threshold.access().revoke(guest);
        else threshold.access().invite(guest);
        return "ok";
    }

    private ThresholdDefinition ownedThreshold(DomainRecord record, String thresholdId) {
        UUID id;
        try { id = UUID.fromString(thresholdId); }
        catch (IllegalArgumentException | NullPointerException ignored) { return null; }
        ThresholdDefinition threshold = runtime.thresholds().get(id).orElse(null);
        return threshold != null && threshold.ownerId().equals(record.state().ownerId()) ? threshold : null;
    }

    private void send(ServerPlayer player, DomainControlsSnapshotPayload.View view, String reason) {
        DomainRecord record = ownerRecordInCurrentDomain(player);
        if (record == null) {
            PacketDistributor.sendToPlayer(player, DomainControlsSnapshotPayload.denied(view, "not_owner_domain"));
            return;
        }
        var state = record.state();
        List<DomainControlsSnapshotPayload.PylonEntry> pylons = state.pylons().values().stream()
                .sorted(Comparator.comparing(p -> p.direction().ordinal()))
                .map(p -> new DomainControlsSnapshotPayload.PylonEntry(
                        p.direction().name(), p.bound(), p.online(), p.expansionEnabled(), p.speed().name(),
                        p.blockPosition() == null ? 0 : p.blockPosition().x(),
                        p.blockPosition() == null ? 0 : p.blockPosition().y(),
                        p.blockPosition() == null ? 0 : p.blockPosition().z()))
                .toList();
        List<DomainControlsSnapshotPayload.ThresholdEntry> thresholds = runtime.thresholds().forOwner(player.getUUID()).stream()
                .sorted(Comparator.comparing(ThresholdDefinition::sourceDimensionId).thenComparing(t -> t.id().toString()))
                .limit(DomainControlsSnapshotPayload.MAX_THRESHOLDS)
                .map(t -> new DomainControlsSnapshotPayload.ThresholdEntry(
                        t.id().toString(), t.sourceDimensionId(), t.domainPosition().x(), t.domainPosition().y(), t.domainPosition().z(),
                        t.access().publicAccess(), t.access().invitedGuests().stream().map(UUID::toString).sorted().limit(DomainControlsSnapshotPayload.MAX_INVITES).toList()))
                .toList();
        Map<UUID, String> candidateNames = new LinkedHashMap<>();
        player.level().getServer().getPlayerList().getPlayers().stream()
                .filter(other -> !other.getUUID().equals(player.getUUID()))
                .sorted(Comparator.comparing(p -> p.getName().getString(), String.CASE_INSENSITIVE_ORDER))
                .forEach(other -> candidateNames.put(other.getUUID(), other.getName().getString()));
        // Keep already-invited offline UUIDs visible so access can always be revoked without waiting
        // for that guest to reconnect. Online identity still comes from the authoritative player UUID.
        for (var threshold : runtime.thresholds().forOwner(player.getUUID())) {
            for (UUID invited : threshold.access().invitedGuests()) {
                candidateNames.putIfAbsent(invited, "Offline " + invited.toString().substring(0, 8));
            }
        }
        List<DomainControlsSnapshotPayload.PlayerEntry> players = candidateNames.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(String.CASE_INSENSITIVE_ORDER))
                .limit(DomainControlsSnapshotPayload.MAX_PLAYERS)
                .map(entry -> new DomainControlsSnapshotPayload.PlayerEntry(entry.getKey().toString(), entry.getValue()))
                .toList();
        PacketDistributor.sendToPlayer(player, new DomainControlsSnapshotPayload(
                view, true, reason, state.coreTier().name(), state.dimensionalEnergy(), state.coreTier().dimensionalEnergyCapacity(),
                state.bounds().sizeX(), state.bounds().sizeY(), state.bounds().sizeZ(), state.fractureMeter(),
                state.globalExpansionEnabled(), pylons, thresholds, players));
    }

    private DomainRecord ownerRecordInCurrentDomain(ServerPlayer player) {
        DomainRecord record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null || !record.state().coreActive()) return null;
        return record.identity().dimensionId().equals(player.level().dimension().identifier().toString()) ? record : null;
    }

    private static DomainControlsSnapshotPayload.View viewFor(DomainControlsActionPayload.Action action) {
        return switch (action) {
            case OPEN_CORE, TOGGLE_GLOBAL_EXPANSION -> DomainControlsSnapshotPayload.View.CORE;
            case OPEN_PYLONS, TOGGLE_PYLON, CYCLE_PYLON_SPEED -> DomainControlsSnapshotPayload.View.PYLONS;
            default -> DomainControlsSnapshotPayload.View.THRESHOLDS;
        };
    }
}
