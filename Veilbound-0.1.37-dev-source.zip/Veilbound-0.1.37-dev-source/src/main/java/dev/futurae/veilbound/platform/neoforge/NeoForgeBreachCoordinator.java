package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.breach.Breach;
import dev.futurae.veilbound.breach.BreachEmergenceService;
import dev.futurae.veilbound.breach.BreachHazardService;
import dev.futurae.veilbound.breach.BreachRuntimeService;
import dev.futurae.veilbound.breach.BreachSpawnPolicy;
import dev.futurae.veilbound.breach.VoidCreatureType;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.entity.BreachLinkedCreature;
import dev.futurae.veilbound.platform.neoforge.world.NeoForgeDomainLevelService;
import dev.futurae.veilbound.registry.VeilboundEntities;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import dev.futurae.veilbound.stability.StabilityCalculator;
import dev.futurae.veilbound.stability.StabilityRuntimePolicy;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.neoforged.neoforge.event.entity.EntityMobGriefingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Drives fracture accumulation, Breach formation, linked intruder emergence, and proximity hazards.
 * All gameplay mutations remain server-authoritative; the personal Domain level is never loaded only
 * for this coordinator, so dormant Domains stay dormant.
 */
public final class NeoForgeBreachCoordinator {
    private final VeilboundRuntime runtime;
    private final NeoForgeDomainLevelService domainLevels;
    private final Map<UUID, Long> nextEmergenceTick = new HashMap<>();
    private long ticks;

    public NeoForgeBreachCoordinator(VeilboundRuntime runtime, NeoForgeDomainLevelService domainLevels) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        this.domainLevels = Objects.requireNonNull(domainLevels, "domainLevels");
    }

    /** Breach fauna may threaten players, but must never rearrange the owner's Domain blocks. */
    public void onMobGrief(EntityMobGriefingEvent event) {
        if (event.getEntity() instanceof BreachLinkedCreature) event.setCanGrief(false);
    }

    public void onServerTick(ServerTickEvent.Post event) {
        ticks++;
        StabilityRuntimePolicy policy = runtime.stabilityPolicy().policy();

        for (DomainRecord record : runtime.domains().records()) {
            // Existing open Breaches remain hazardous while the Domain is live, including to guests.
            // This lookup never wakes a dormant Domain.
            domainLevels.liveLevel(event.getServer(), record.ownerId())
                    .ifPresent(level -> tickOpenBreaches(record, level, policy));

            if (ticks % policy.evaluationTicks() != 0) continue;
            if (!runtime.domainRuntime().state(record.ownerId()).ownerOnline()) continue;
            if (!record.state().coreActive()) continue;

            int permanentThresholds = runtime.thresholds().permanentCountForOwner(record.ownerId());
            int continuityAnchors = record.state().continuityAnchors().size();
            double ontologicalLoad = domainLevels.liveLevel(event.getServer(), record.ownerId())
                    .map(level -> runtime.ontologicalLoads().totalFresh(record.ownerId(), level.getGameTime(), 40L))
                    .orElse(0.0);
            var stability = StabilityCalculator.calculate(
                    record.state(), permanentThresholds, continuityAnchors, ontologicalLoad,
                    policy.forTier(record.state().coreTier()));
            var evaluation = BreachRuntimeService.evaluate(
                    record.state(), stability, policy.breachPolicy(), ticks, ThreadLocalRandom.current());
            Breach formed = evaluation.formedBreach();
            if (formed == null) continue;

            // Start the first emergence interval from formation instead of allowing an immediate burst.
            nextEmergenceTick.put(
                    formed.id(),
                    BreachEmergenceService.initialDueTick(
                            formed, policy.breachPolicy().spawnPolicy(), ticks, ThreadLocalRandom.current()));

            domainLevels.liveLevel(event.getServer(), record.ownerId()).ifPresent(level -> seedParadoxAccretions(record, level, formed));

            ServerPlayer owner = event.getServer().getPlayerList().getPlayer(record.ownerId());
            if (owner != null) {
                owner.displayClientMessage(Component.translatable(
                        "message.veilbound.breach.formed",
                        formed.severity().name(),
                        formed.position().x(), formed.position().y(), formed.position().z()), false);
            }
        }

        pruneSchedules();
    }

    private void tickOpenBreaches(DomainRecord record, ServerLevel level, StabilityRuntimePolicy stabilityPolicy) {
        var breachPolicy = stabilityPolicy.breachPolicy();
        BreachSpawnPolicy spawnPolicy = breachPolicy.spawnPolicy();
        Map<UUID, Breach> openBreaches = new HashMap<>();
        for (Breach breach : record.state().breaches()) {
            if (breach.open()) openBreaches.put(breach.id(), breach);
        }

        reconcileLinkedCreatures(record.ownerId(), level, openBreaches, spawnPolicy.localCreatureRadius());
        if (openBreaches.isEmpty()) return;

        for (Breach breach : openBreaches.values()) {
            tickHazard(level, breach, breachPolicy.hazardPolicy());

            Long existingDue = nextEmergenceTick.get(breach.id());
            long due;
            if (existingDue == null) {
                due = BreachEmergenceService.initialDueTick(
                        breach, spawnPolicy, ticks, ThreadLocalRandom.current());
                nextEmergenceTick.put(breach.id(), due);
                // Forced Veil-Lance Breaches enter through the same persistent Breach list as
                // natural ruptures. First observation performs the same material-seeding hook.
                seedParadoxAccretions(record, level, breach);
            } else {
                due = existingDue;
            }
            int linkedCount = countLinkedCreatures(level, record.ownerId(), breach.id());
            var decision = BreachEmergenceService.evaluate(
                    breach, spawnPolicy, ticks, due, linkedCount, ThreadLocalRandom.current());
            if (decision.status() == BreachEmergenceService.Decision.Status.WAITING) continue;
            if (decision.status() == BreachEmergenceService.Decision.Status.INACTIVE) {
                nextEmergenceTick.remove(breach.id());
                continue;
            }
            nextEmergenceTick.put(breach.id(), decision.nextDueTick());
            if (decision.shouldSpawn()) {
                spawnLinkedCreature(record, level, breach, decision.creatureType(), spawnPolicy);
            }
        }
    }

    private void reconcileLinkedCreatures(
            UUID ownerId,
            ServerLevel level,
            Map<UUID, Breach> openBreaches,
            double tetherRadius) {
        double tetherSq = tetherRadius * tetherRadius;
        for (Entity entity : level.getAllEntities()) {
            if (!(entity instanceof BreachLinkedCreature linked)) continue;
            UUID linkedOwner = linked.veilboundDomainOwnerId().orElse(null);
            UUID breachId = linked.veilboundSourceBreachId().orElse(null);
            Breach source = breachId == null ? null : openBreaches.get(breachId);
            if (!ownerId.equals(linkedOwner) || source == null) {
                entity.discard();
                continue;
            }
            double bx = source.position().x() + 0.5;
            double by = source.position().y() + 0.5;
            double bz = source.position().z() + 0.5;
            if (entity.distanceToSqr(bx, by, bz) > tetherSq) entity.discard();
        }
    }

    private int countLinkedCreatures(ServerLevel level, UUID ownerId, UUID breachId) {
        int count = 0;
        for (Entity entity : level.getAllEntities()) {
            if (!(entity instanceof BreachLinkedCreature linked)) continue;
            if (linked.veilboundDomainOwnerId().filter(ownerId::equals).isEmpty()) continue;
            if (linked.veilboundSourceBreachId().filter(breachId::equals).isEmpty()) continue;
            if (entity.isRemoved()) continue;
            count++;
        }
        return count;
    }

    private void tickHazard(ServerLevel level, Breach breach, dev.futurae.veilbound.breach.BreachHazardPolicy policy) {
        var band = policy.band(breach.severity());
        double x = breach.position().x() + 0.5;
        double y = breach.position().y() + 0.5;
        double z = breach.position().z() + 0.5;

        if (band.particleCount() > 0 && Math.floorMod(ticks, policy.particleIntervalTicks()) == 0) {
            var particle = switch (breach.severity()) {
                case MINOR -> ParticleTypes.PORTAL;
                case SEVERE -> ParticleTypes.REVERSE_PORTAL;
                case EXTREME -> ParticleTypes.SCULK_SOUL;
            };
            level.sendParticles(particle, x, y, z, band.particleCount(),
                    Math.max(0.15, band.radius() * 0.25),
                    Math.max(0.15, band.radius() * 0.25),
                    Math.max(0.15, band.radius() * 0.25), 0.03);
        }

        if (band.damage() <= 0.0) return;
        for (ServerPlayer player : level.players()) {
            if (player.isSpectator()) continue;
            BreachHazardService.Exposure exposure = BreachHazardService.evaluate(
                    breach, policy, player.getX(), player.getY(), player.getZ(), ticks);
            if (exposure.damageDue()) {
                player.hurtServer(level, level.damageSources().magic(), (float) exposure.damage());
            }
        }
    }

    private void spawnLinkedCreature(
            DomainRecord record,
            ServerLevel level,
            Breach breach,
            VoidCreatureType creatureType,
            BreachSpawnPolicy spawnPolicy) {
        var emergence = BreachEmergenceService.emergencePosition(
                record.state().bounds(), breach, spawnPolicy.emergenceRadius(), ThreadLocalRandom.current());
        BlockPos spawnPos = new BlockPos(emergence.x(), emergence.y(), emergence.z());
        Entity spawned = switch (creatureType) {
            case VOID_CRAWLER -> VeilboundEntities.VOID_CRAWLER.get().spawn(
                    level,
                    entity -> bind(entity, record.ownerId(), breach.id()),
                    spawnPos,
                    EntitySpawnReason.EVENT,
                    false,
                    false);
            case RIFT_STALKER -> VeilboundEntities.RIFT_STALKER.get().spawn(
                    level,
                    entity -> bind(entity, record.ownerId(), breach.id()),
                    spawnPos,
                    EntitySpawnReason.EVENT,
                    false,
                    false);
            case NULL_WRAITH -> VeilboundEntities.NULL_WRAITH.get().spawn(
                    level,
                    entity -> bind(entity, record.ownerId(), breach.id()),
                    spawnPos,
                    EntitySpawnReason.EVENT,
                    false,
                    false);
        };
        if (spawned != null) {
            level.sendParticles(ParticleTypes.REVERSE_PORTAL,
                    spawnPos.getX() + 0.5, spawnPos.getY() + 0.5, spawnPos.getZ() + 0.5,
                    18, 0.45, 0.65, 0.45, 0.08);
        }
    }

    private static void bind(Entity entity, UUID ownerId, UUID breachId) {
        if (!(entity instanceof BreachLinkedCreature linked)) {
            throw new IllegalStateException("Veilbound Breach entity factory produced an unlinked entity: " + entity.getType());
        }
        linked.veilboundBind(ownerId, breachId);
    }


    private void seedParadoxAccretions(DomainRecord record, ServerLevel level, Breach breach) {
        int nodes = switch (breach.severity()) { case MINOR -> 1; case SEVERE -> 2; case EXTREME -> 4; };
        var r = java.util.concurrent.ThreadLocalRandom.current();
        for (int i = 0; i < nodes; i++) {
            for (int attempt = 0; attempt < 8; attempt++) {
                int dx = r.nextInt(-3, 4), dy = r.nextInt(-2, 3), dz = r.nextInt(-3, 4);
                var p = new dev.futurae.veilbound.domain.DomainPosition(breach.position().x()+dx, breach.position().y()+dy, breach.position().z()+dz);
                if (!record.state().bounds().contains(p)) continue;
                BlockPos bp = new BlockPos(p.x(), p.y(), p.z());
                if (!level.getBlockState(bp).isAir()) continue;
                level.setBlockAndUpdate(bp, dev.futurae.veilbound.registry.VeilboundBlocks.PARADOX_ORE.get().defaultBlockState());
                break;
            }
        }
    }

    private void pruneSchedules() {
        Set<UUID> open = new HashSet<>();
        for (DomainRecord record : runtime.domains().records()) {
            for (Breach breach : record.state().breaches()) if (breach.open()) open.add(breach.id());
        }
        nextEmergenceTick.keySet().removeIf(id -> !open.contains(id));
    }
}
