package dev.futurae.veilbound.registry;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.block.entity.AxiomMonolithBlockEntity;
import dev.futurae.veilbound.block.entity.ContinuityAnchorBlockEntity;
import dev.futurae.veilbound.block.entity.DimensionalTransducerBlockEntity;
import dev.futurae.veilbound.block.entity.EngineeringStationBlockEntity;
import dev.futurae.veilbound.block.entity.OntologicalHarvesterBlockEntity;
import dev.futurae.veilbound.block.entity.OntologicalCompilerBlockEntity;
import dev.futurae.veilbound.block.entity.ThresholdPortalBlockEntity;
import dev.futurae.veilbound.block.entity.VeilInterfaceBlockEntity;
import dev.futurae.veilbound.block.entity.VeilLanceBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Persistent block-entity registrations for stateful Veilbound devices and portal runtime data. */
public final class VeilboundBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, Veilbound.MOD_ID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AxiomMonolithBlockEntity>> AXIOM_MONOLITH =
            BLOCK_ENTITIES.register("axiom_monolith", () -> new BlockEntityType<>(
                    AxiomMonolithBlockEntity::new,
                    false,
                    VeilboundBlocks.AXIOM_MONOLITH.get()));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ContinuityAnchorBlockEntity>> CONTINUITY_ANCHOR =
            BLOCK_ENTITIES.register("continuity_anchor", () -> new BlockEntityType<>(
                    ContinuityAnchorBlockEntity::new,
                    false,
                    VeilboundBlocks.CONTINUITY_ANCHOR.get()));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<DimensionalTransducerBlockEntity>> DIMENSIONAL_TRANSDUCER =
            BLOCK_ENTITIES.register("dimensional_transducer", () -> new BlockEntityType<>(
                    DimensionalTransducerBlockEntity::new,
                    false,
                    VeilboundBlocks.DIMENSIONAL_TRANSDUCER.get()));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<EngineeringStationBlockEntity>> ENGINEERING_STATION =
            BLOCK_ENTITIES.register("engineering_station", () -> new BlockEntityType<>(
                    EngineeringStationBlockEntity::new,
                    false,
                    VeilboundBlocks.DIMENSIONAL_FABRICATOR.get(), VeilboundBlocks.VEIL_FOUNDRY.get()));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<OntologicalHarvesterBlockEntity>> ONTOLOGICAL_HARVESTER =
            BLOCK_ENTITIES.register("ontological_harvester", () -> new BlockEntityType<>(
                    OntologicalHarvesterBlockEntity::new,
                    false,
                    VeilboundBlocks.ONTOLOGICAL_HARVESTER.get()));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<OntologicalCompilerBlockEntity>> ONTOLOGICAL_COMPILER =
            BLOCK_ENTITIES.register("ontological_compiler", () -> new BlockEntityType<>(
                    OntologicalCompilerBlockEntity::new,
                    false,
                    VeilboundBlocks.ONTOLOGICAL_COMPILER.get()));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<VeilLanceBlockEntity>> VEIL_LANCE =
            BLOCK_ENTITIES.register("veil_lance", () -> new BlockEntityType<>(
                    VeilLanceBlockEntity::new,
                    false,
                    VeilboundBlocks.VEIL_LANCE.get()));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ThresholdPortalBlockEntity>> THRESHOLD_PORTAL =
            BLOCK_ENTITIES.register("threshold_portal", () -> new BlockEntityType<>(
                    ThresholdPortalBlockEntity::new,
                    false,
                    VeilboundBlocks.THRESHOLD_PORTAL.get()));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<VeilInterfaceBlockEntity>> VEIL_INTERFACE =
            BLOCK_ENTITIES.register("veil_interface", () -> new BlockEntityType<>(
                    VeilInterfaceBlockEntity::new,
                    false,
                    VeilboundBlocks.VEIL_INTERFACE.get()));

    private VeilboundBlockEntities() {}

    public static void register(IEventBus modBus) {
        BLOCK_ENTITIES.register(modBus);
    }
}
