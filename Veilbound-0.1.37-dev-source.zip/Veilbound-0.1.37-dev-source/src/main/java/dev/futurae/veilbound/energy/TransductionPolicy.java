package dev.futurae.veilbound.energy;

/**
 * Config/datapack supplied conversion parameters for Transducer-local Matter + FE -> DE.
 *
 * <p>Matter values now use the ProjectE EMC numerical scale. The Matter-to-DE divisor is kept
 * separate from item valuation so changing the accounting scale cannot accidentally multiply the
 * Core's energy economy.</p>
 */
public record TransductionPolicy(long forgeEnergyPerMatter, long matterPerDimensionalEnergy) {
    public TransductionPolicy {
        if (forgeEnergyPerMatter < 0 || matterPerDimensionalEnergy <= 0) {
            throw new IllegalArgumentException("FE per Matter must be >= 0 and Matter per DE must be > 0");
        }
    }
}
