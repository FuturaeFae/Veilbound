package dev.futurae.veilbound.persistence;

import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.threshold.ThresholdAccess;
import dev.futurae.veilbound.threshold.ThresholdDefinition;
import java.util.Set;
import java.util.UUID;

/** Persisted permanent Threshold definition; active guest sessions are runtime-only. */
public record ThresholdSnapshot(
        UUID id,
        UUID ownerId,
        String sourceDimensionId,
        Set<DomainPosition> sourcePositions,
        DomainPosition domainPosition,
        boolean publicAccess,
        Set<UUID> invitedGuests) {
    public ThresholdSnapshot {
        sourceDimensionId = sourceDimensionId == null ? "" : sourceDimensionId;
        sourcePositions = sourcePositions == null ? Set.of() : Set.copyOf(sourcePositions);
        invitedGuests = Set.copyOf(invitedGuests);
    }

    /** Backward-compatible shape for pre-0.1.9 snapshots/tests. */
    public ThresholdSnapshot(UUID id, UUID ownerId, DomainPosition domainPosition, boolean publicAccess, Set<UUID> invitedGuests) {
        this(id, ownerId, "", Set.of(), domainPosition, publicAccess, invitedGuests);
    }

    public static ThresholdSnapshot capture(ThresholdDefinition threshold) {
        return new ThresholdSnapshot(
                threshold.id(), threshold.ownerId(), threshold.sourceDimensionId(), threshold.sourcePositions(),
                threshold.domainPosition(), threshold.access().publicAccess(), threshold.access().invitedGuests());
    }

    public ThresholdDefinition restore() {
        ThresholdAccess access = new ThresholdAccess();
        access.setPublicAccess(publicAccess);
        for (UUID guest : invitedGuests) access.invite(guest);
        return new ThresholdDefinition(id, ownerId, sourceDimensionId, sourcePositions, domainPosition, access);
    }
}
