package dev.futurae.veilbound.inventory;

import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainState;
import dev.futurae.veilbound.matter.MatterTransmutationState;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Atomic storage-side crafting transaction. Recipe matching itself remains a platform concern;
 * this service only consumes an already-authoritative ingredient plan and commits results plus
 * container/remainder items together or not at all.
 */
public final class VeilCraftingService {
    public CraftResult preview(
            DomainState state,
            VeilInventory inventory,
            VeilStorageCapacity capacity,
            List<IngredientRequest> ingredients,
            List<ProducedStack> returnedStacks) {
        return evaluate(state, inventory, capacity, ingredients, returnedStacks, null, false);
    }

    public CraftResult craft(
            DomainState state,
            VeilInventory inventory,
            VeilStorageCapacity capacity,
            List<IngredientRequest> ingredients,
            List<ProducedStack> returnedStacks) {
        return evaluate(state, inventory, capacity, ingredients, returnedStacks, null, true);
    }

    /**
     * Hybrid post-Transmutation preview. Physical unvalued stacks are consumed from Veil Inventory
     * first; any remaining valued canonical ingredients may be synthesized from learned patterns.
     */
    public CraftResult previewWithMatter(
            DomainState state,
            VeilInventory inventory,
            VeilStorageCapacity capacity,
            List<IngredientRequest> ingredients,
            List<ProducedStack> returnedStacks,
            MatterTransmutationState transmutation) {
        return evaluate(state, Objects.requireNonNull(inventory, "inventory"),
                Objects.requireNonNull(capacity, "capacity"), ingredients,
                Objects.requireNonNull(returnedStacks, "returnedStacks"),
                Objects.requireNonNull(transmutation, "transmutation"), false);
    }

    public CraftResult craftWithMatter(
            DomainState state,
            VeilInventory inventory,
            VeilStorageCapacity capacity,
            List<IngredientRequest> ingredients,
            List<ProducedStack> returnedStacks,
            MatterTransmutationState transmutation) {
        return evaluate(state, Objects.requireNonNull(inventory, "inventory"),
                Objects.requireNonNull(capacity, "capacity"), ingredients,
                Objects.requireNonNull(returnedStacks, "returnedStacks"),
                Objects.requireNonNull(transmutation, "transmutation"), true);
    }

    public CraftResult previewFromMatter(
            DomainState state,
            List<IngredientRequest> ingredients,
            MatterTransmutationState transmutation) {
        return evaluateMatterOnly(state, ingredients, Objects.requireNonNull(transmutation, "transmutation"), false);
    }

    public CraftResult craftFromMatter(
            DomainState state,
            List<IngredientRequest> ingredients,
            MatterTransmutationState transmutation) {
        return evaluateMatterOnly(state, ingredients, Objects.requireNonNull(transmutation, "transmutation"), true);
    }

    private CraftResult evaluateMatterOnly(
            DomainState state,
            List<IngredientRequest> ingredients,
            MatterTransmutationState transmutation,
            boolean commit) {
        Objects.requireNonNull(state, "state");
        ingredients = List.copyOf(Objects.requireNonNull(ingredients, "ingredients"));
        if (!state.hasFeature(DomainFeature.VEIL_CRAFTING)) return CraftResult.denied("veil_crafting_locked");
        if (!state.hasFeature(DomainFeature.VEIL_TRANSMUTATION)) return CraftResult.denied("veil_transmutation_locked");

        long availableMatter = transmutation.storedMatter();
        long matterSpent = 0L;
        List<SynthesizedStack> synthesized = new ArrayList<>();
        for (IngredientRequest request : ingredients) {
            SynthesisCandidate candidate = request.synthesisCandidates().stream()
                    .filter(c -> transmutation.knows(c.stack().itemId()))
                    .filter(c -> c.matterPerItem() > 0)
                    .min(Comparator.comparingLong(SynthesisCandidate::matterPerItem)
                            .thenComparing(c -> c.stack().itemId()))
                    .orElse(null);
            if (candidate == null) return CraftResult.denied("pattern_missing");
            long cost;
            try {
                cost = Math.multiplyExact(request.count(), candidate.matterPerItem());
                matterSpent = Math.addExact(matterSpent, cost);
            } catch (ArithmeticException overflow) {
                return CraftResult.denied("matter_cost_overflow");
            }
            if (matterSpent > availableMatter) return CraftResult.denied("matter_missing");
            synthesized.add(new SynthesizedStack(candidate.stack(), request.count(), cost));
        }

        if (commit && matterSpent > 0 && !transmutation.consumeMatter(matterSpent)) {
            throw new IllegalStateException("Matter craft preflight disagreed with debit");
        }
        return CraftResult.allowed(List.of(), synthesized, List.of(), matterSpent);
    }

    private CraftResult evaluate(
            DomainState state,
            VeilInventory inventory,
            VeilStorageCapacity capacity,
            List<IngredientRequest> ingredients,
            List<ProducedStack> returnedStacks,
            MatterTransmutationState transmutation,
            boolean commit) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(inventory, "inventory");
        Objects.requireNonNull(capacity, "capacity");
        ingredients = List.copyOf(Objects.requireNonNull(ingredients, "ingredients"));
        returnedStacks = List.copyOf(Objects.requireNonNull(returnedStacks, "returnedStacks"));
        if (!state.hasFeature(DomainFeature.VEIL_CRAFTING)) return CraftResult.denied("veil_crafting_locked");
        if (!capacity.unlocked()) return CraftResult.denied("veil_inventory_locked");

        boolean matterEnabled = transmutation != null && state.hasFeature(DomainFeature.VEIL_TRANSMUTATION);
        long simulatedMatter = transmutation == null ? 0L : transmutation.storedMatter();
        long matterSpent = 0L;
        LinkedHashMap<VeilStackKey, Long> simulated = new LinkedHashMap<>(inventory.contents());
        List<ConsumedStack> consumed = new ArrayList<>();
        List<SynthesizedStack> synthesized = new ArrayList<>();

        for (IngredientRequest request : ingredients) {
            long remaining = request.count();
            for (VeilStackKey candidate : request.acceptableStacks()) {
                long available = simulated.getOrDefault(candidate, 0L);
                long take = Math.min(available, remaining);
                if (take <= 0) continue;
                long left = available - take;
                if (left == 0) simulated.remove(candidate); else simulated.put(candidate, left);
                consumed.add(new ConsumedStack(candidate, take));
                remaining -= take;
                if (remaining == 0) break;
            }

            if (remaining != 0 && matterEnabled && !request.synthesisCandidates().isEmpty()) {
                SynthesisCandidate candidate = request.synthesisCandidates().stream()
                        .filter(c -> transmutation.knows(c.stack().itemId()))
                        .filter(c -> c.matterPerItem() > 0)
                        .min(Comparator.comparingLong(SynthesisCandidate::matterPerItem)
                                .thenComparing(c -> c.stack().itemId()))
                        .orElse(null);
                if (candidate == null) return CraftResult.denied("pattern_missing");
                long cost;
                try {
                    cost = Math.multiplyExact(remaining, candidate.matterPerItem());
                } catch (ArithmeticException overflow) {
                    return CraftResult.denied("matter_cost_overflow");
                }
                if (cost > simulatedMatter) return CraftResult.denied("matter_missing");
                simulatedMatter -= cost;
                try {
                    matterSpent = Math.addExact(matterSpent, cost);
                } catch (ArithmeticException overflow) {
                    return CraftResult.denied("matter_cost_overflow");
                }
                synthesized.add(new SynthesizedStack(candidate.stack(), remaining, cost));
                remaining = 0L;
            }
            if (remaining != 0) return CraftResult.denied("ingredients_missing");
        }

        try {
            for (ProducedStack produced : returnedStacks) {
                long existing = simulated.getOrDefault(produced.stack(), 0L);
                simulated.put(produced.stack(), Math.addExact(existing, produced.count()));
            }
        } catch (ArithmeticException overflow) {
            return CraftResult.denied("count_overflow");
        }

        long total = 0L;
        try {
            for (long count : simulated.values()) total = Math.addExact(total, count);
        } catch (ArithmeticException overflow) {
            return CraftResult.denied("count_overflow");
        }
        if (total > capacity.maxItems()) return CraftResult.denied("item_capacity_exceeded");
        if (simulated.size() > capacity.maxTypes()) return CraftResult.denied("type_capacity_exceeded");

        if (commit) {
            inventory.replaceTransactionally(simulated);
            if (matterSpent > 0) {
                // The full transaction was preflighted; replace cannot fail for a non-negative balance.
                transmutation.replace(simulatedMatter, transmutation.learnedItemIds());
            }
        }
        return CraftResult.allowed(consumed, synthesized, returnedStacks, matterSpent);
    }

    public record IngredientRequest(
            List<VeilStackKey> acceptableStacks,
            long count,
            List<SynthesisCandidate> synthesisCandidates) {
        public IngredientRequest {
            acceptableStacks = List.copyOf(acceptableStacks);
            synthesisCandidates = List.copyOf(synthesisCandidates == null ? List.of() : synthesisCandidates);
            if (acceptableStacks.isEmpty()) throw new IllegalArgumentException("acceptableStacks may not be empty");
            if (acceptableStacks.stream().anyMatch(Objects::isNull)) throw new NullPointerException("acceptable stack");
            if (synthesisCandidates.stream().anyMatch(Objects::isNull)) throw new NullPointerException("synthesis candidate");
            if (count <= 0) throw new IllegalArgumentException("count must be > 0");
        }

        public IngredientRequest(List<VeilStackKey> acceptableStacks, long count) {
            this(acceptableStacks, count, List.of());
        }
    }

    /** A canonical/default stack that the recipe accepts, plus its authoritative Matter cost. */
    public record SynthesisCandidate(VeilStackKey stack, long matterPerItem) {
        public SynthesisCandidate {
            Objects.requireNonNull(stack, "stack");
            if (!stack.componentData().isEmpty()) {
                throw new IllegalArgumentException("Synthesized stacks must use the canonical/default component state");
            }
            if (matterPerItem <= 0) throw new IllegalArgumentException("matterPerItem must be > 0");
        }
    }

    public record ProducedStack(VeilStackKey stack, long count) {
        public ProducedStack {
            Objects.requireNonNull(stack, "stack");
            if (count <= 0) throw new IllegalArgumentException("count must be > 0");
        }
    }

    public record ConsumedStack(VeilStackKey stack, long count) {}
    public record SynthesizedStack(VeilStackKey stack, long count, long matterCost) {}

    public record CraftResult(
            boolean crafted,
            List<ConsumedStack> consumed,
            List<SynthesizedStack> synthesized,
            List<ProducedStack> returnedStacks,
            long matterSpent,
            String reason) {
        public CraftResult {
            consumed = List.copyOf(consumed);
            synthesized = List.copyOf(synthesized);
            returnedStacks = List.copyOf(returnedStacks);
            if (matterSpent < 0) throw new IllegalArgumentException("matterSpent must be >= 0");
        }
        public static CraftResult denied(String reason) {
            return new CraftResult(false, List.of(), List.of(), List.of(), 0L, reason);
        }
        public static CraftResult allowed(
                List<ConsumedStack> consumed,
                List<SynthesizedStack> synthesized,
                List<ProducedStack> returnedStacks,
                long matterSpent) {
            return new CraftResult(true, consumed, synthesized, returnedStacks, matterSpent, "ok");
        }
    }
}
