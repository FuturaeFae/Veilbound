package dev.futurae.veilbound.platform.neoforge;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.ontology.OntologicalCompilerPolicy;
import dev.futurae.veilbound.ontology.OntologicalHarvesterPolicy;
import dev.futurae.veilbound.ontology.OntologyPolicyRegistry;
import dev.futurae.veilbound.ontology.OntologyRuntimePolicy;
import java.io.Reader;
import java.util.Objects;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

/** Loads the tunable observation-yield and Potential->Matter conversion policy. */
public final class NeoForgeOntologyPolicyReloadListener extends SimplePreparableReloadListener<OntologyRuntimePolicy> {
    public static final Identifier LISTENER_ID = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "ontology_policy");
    private static final Identifier RESOURCE_ID = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "veilbound/balance/ontology_industry.json");
    private final Gson gson = new Gson();
    private final OntologyPolicyRegistry registry;

    public NeoForgeOntologyPolicyReloadListener(OntologyPolicyRegistry registry) {
        this.registry = Objects.requireNonNull(registry, "registry");
    }

    @Override
    protected OntologyRuntimePolicy prepare(ResourceManager manager, ProfilerFiller profiler) {
        OntologyRuntimePolicy fallback = OntologyRuntimePolicy.DEVELOPMENT_DEFAULT;
        return manager.getResource(RESOURCE_ID).map(resource -> {
            try (Reader reader = resource.openAsReader()) {
                JsonElement parsed = gson.fromJson(reader, JsonElement.class);
                if (parsed == null || !parsed.isJsonObject()) throw new IllegalArgumentException("root must be an object");
                JsonObject root = parsed.getAsJsonObject();
                JsonObject h = object(root, "harvester");
                JsonObject c = object(root, "compiler");
                var hd = fallback.harvester();
                var cd = fallback.compiler();
                OntologicalHarvesterPolicy harvester = new OntologicalHarvesterPolicy(
                        longValue(h, "potential_per_vane_per_cycle", hd.potentialPerVanePerCycle()),
                        intValue(h, "max_contributing_vanes", hd.maxContributingVanes()),
                        doubleValue(h, "base_stability_load_per_vane", hd.baseStabilityLoadPerVane()),
                        doubleValue(h, "fracture_yield_bonus_at_full_meter", hd.fractureYieldBonusAtFullMeter()),
                        doubleValue(h, "breach_yield_bonus_per_open_breach", hd.breachYieldBonusPerOpenBreach()));
                OntologicalCompilerPolicy compiler = new OntologicalCompilerPolicy(
                        longValue(c, "matter_per_potential", cd.matterPerPotential()),
                        longValue(c, "dimensional_energy_per_potential", cd.dimensionalEnergyPerPotential()),
                        longValue(c, "max_potential_per_cycle", cd.maxPotentialPerCycle()));
                return new OntologyRuntimePolicy(harvester, compiler);
            } catch (Exception ex) {
                Veilbound.LOGGER.warn("Invalid {}: {}; using development default", RESOURCE_ID, ex.getMessage());
                return fallback;
            }
        }).orElse(fallback);
    }

    @Override
    protected void apply(OntologyRuntimePolicy policy, ResourceManager manager, ProfilerFiller profiler) {
        registry.replace(policy);
        Veilbound.LOGGER.info(
                "Loaded ontology policy: {} Potential/vane, max {} vanes, {} Matter/Potential, {} DE/Potential",
                policy.harvester().potentialPerVanePerCycle(), policy.harvester().maxContributingVanes(),
                policy.compiler().matterPerPotential(), policy.compiler().dimensionalEnergyPerPotential());
    }

    private static JsonObject object(JsonObject parent, String key) {
        if (!parent.has(key) || !parent.get(key).isJsonObject()) return new JsonObject();
        return parent.getAsJsonObject(key);
    }
    private static long longValue(JsonObject o, String key, long fallback) { return o.has(key) ? o.get(key).getAsLong() : fallback; }
    private static int intValue(JsonObject o, String key, int fallback) { return o.has(key) ? o.get(key).getAsInt() : fallback; }
    private static double doubleValue(JsonObject o, String key, double fallback) { return o.has(key) ? o.get(key).getAsDouble() : fallback; }
}
