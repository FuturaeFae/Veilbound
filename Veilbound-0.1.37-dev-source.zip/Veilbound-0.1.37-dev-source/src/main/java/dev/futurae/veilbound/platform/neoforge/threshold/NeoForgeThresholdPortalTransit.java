package dev.futurae.veilbound.platform.neoforge.threshold;

import dev.futurae.veilbound.domain.DomainIdentity;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainRuntimeTracker;
import dev.futurae.veilbound.domain.StarterPocketLayout;
import dev.futurae.veilbound.platform.neoforge.travel.NeoForgeDomainTravelExecutor;
import dev.futurae.veilbound.platform.neoforge.travel.NeoForgeReturnAnchorResolver;
import dev.futurae.veilbound.platform.neoforge.travel.NeoForgeTransitGuard;
import dev.futurae.veilbound.platform.neoforge.world.NeoForgeDomainLevelService;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import dev.futurae.veilbound.threshold.GuestThresholdSession;
import dev.futurae.veilbound.threshold.ThresholdDefinition;
import dev.futurae.veilbound.threshold.ThresholdSessionManager;
import dev.futurae.veilbound.threshold.PortalTouchLatch;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import dev.futurae.veilbound.travel.ReturnAnchor;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Relative;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

/** Executes touch-based travel through an activated persistent Threshold structure. */
public final class NeoForgeThresholdPortalTransit {
    private final VeilboundRuntime runtime;
    private final NeoForgeDomainLevelService domainLevels;
    private final NeoForgeDomainTravelExecutor domainTravel;
    private final NeoForgeReturnAnchorResolver returnResolver;
    private final PortalTouchLatch touchLatch = new PortalTouchLatch();

    public NeoForgeThresholdPortalTransit(
            VeilboundRuntime runtime,
            NeoForgeDomainLevelService domainLevels,
            NeoForgeDomainTravelExecutor domainTravel,
            NeoForgeReturnAnchorResolver returnResolver) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        this.domainLevels = Objects.requireNonNull(domainLevels, "domainLevels");
        this.domainTravel = Objects.requireNonNull(domainTravel, "domainTravel");
        this.returnResolver = Objects.requireNonNull(returnResolver, "returnResolver");
    }

    public TransitResult onPortalTouch(ServerPlayer player, BlockPos blockPos) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(blockPos, "blockPos");
        if (touchLatch.isArmed(player.getUUID())) return TransitResult.denied("portal_exit_required");
        MinecraftServer server = player.getServer();
        if (server == null) return TransitResult.denied("server_unavailable");

        String currentDimension = player.level().dimension().identifier().toString();
        DomainPosition touched = new DomainPosition(blockPos.getX(), blockPos.getY(), blockPos.getZ());
        ThresholdDefinition threshold = runtime.thresholds().findAt(currentDimension, touched).orElse(null);
        if (threshold == null) return TransitResult.denied("unbound_portal_block");

        UUID playerId = player.getUUID();
        UUID ownerId = threshold.ownerId();
        String ownerDomainId = DomainIdentity.dimensionIdFor(ownerId);

        // A Threshold built inside its owner's Domain acts as a controlled exit point. Owners and
        // tracked guests return through the exact anchors already maintained by the travel system.
        if (currentDimension.equals(ownerDomainId)) {
            if (playerId.equals(ownerId)) {
                var result = domainTravel.exitOwnDomain(server, player);
                if (result.success()) { touchLatch.arm(playerId); return TransitResult.exited("owner"); }
                return TransitResult.denied(result.reason());
            }
            GuestThresholdSession session = runtime.thresholdSessions().session(playerId).orElse(null);
            if (session != null && session.ownerId().equals(ownerId)) {
                var result = domainTravel.exitGuestDomain(server, player, session);
                if (result.success()) { touchLatch.arm(playerId); return TransitResult.exited("guest"); }
                return TransitResult.denied(result.reason());
            }
            return TransitResult.denied("untracked_foreign_domain");
        }

        // Owners may always use their own outside Threshold as another entrance to their Domain.
        if (playerId.equals(ownerId)) {
            var result = domainTravel.enterFromOutside(server, player);
            if (result.success()) { touchLatch.arm(playerId); return TransitResult.entered(ownerId, "owner"); }
            return TransitResult.denied(result.reason());
        }

        DomainRuntimeTracker.RuntimeState ownerRuntime = runtime.domainRuntime().state(ownerId);
        ReturnAnchor guestReturn = NeoForgeDomainTravelExecutor.capture(player);
        ThresholdSessionManager.EntryDecision decision = runtime.thresholdSessions().beginGuestEntry(
                threshold,
                playerId,
                guestReturn,
                player.level().getGameTime(),
                ownerRuntime.ownerOnline(),
                ownerRuntime.ownerInside());
        if (!decision.allowed()) return TransitResult.denied(decision.reason());

        ServerLevel domain = domainLevels.load(server, ownerId);
        ReturnAnchor preferredArrival = new ReturnAnchor(
                ownerDomainId,
                threshold.domainPosition().x() + 0.5D,
                threshold.domainPosition().y(),
                threshold.domainPosition().z() + 0.5D,
                player.getYRot(),
                player.getXRot());
        NeoForgeReturnAnchorResolver.ResolvedReturn arrival = returnResolver.resolve(server, player, preferredArrival);
        if (!arrival.level().dimension().identifier().toString().equals(ownerDomainId)) {
            runtime.thresholdSessions().endGuestSession(playerId);
            return TransitResult.denied("domain_arrival_unavailable");
        }

        int previousPending = ownerRuntime.pendingTransits();
        runtime.domainRuntime().setPendingTransits(ownerId, previousPending + 1);
        try {
            boolean moved = NeoForgeTransitGuard.run(playerId, () -> player.teleportTo(
                    arrival.level(), arrival.x(), arrival.y(), arrival.z(), Set.<Relative>of(),
                    arrival.yaw(), arrival.pitch(), true));
            if (!moved) {
                runtime.thresholdSessions().endGuestSession(playerId);
                return TransitResult.denied("guest_enter_teleport_failed");
            }
            runtime.domainRuntime().setLoaded(ownerId, true);
            runtime.domainRuntime().setPlayersInside(ownerId, domain.players().size());
            touchLatch.arm(playerId);
            return TransitResult.entered(ownerId, "guest");
        } finally {
            runtime.domainRuntime().setPendingTransits(ownerId, previousPending);
        }
    }

    /** Clear the one-shot latch only after the player has physically left every portal cell. */
    public void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (player.level().isClientSide() || !touchLatch.isArmed(player.getUUID())) return;
        if (!isInsidePortalCell(player)) touchLatch.clear(player.getUUID());
    }

    public void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        touchLatch.clear(event.getEntity().getUUID());
    }

    private static boolean isInsidePortalCell(ServerPlayer player) {
        int x = (int)Math.floor(player.getX());
        int y = (int)Math.floor(player.getY());
        int z = (int)Math.floor(player.getZ());
        BlockPos feet = new BlockPos(x, y, z);
        BlockPos body = new BlockPos(x, y + 1, z);
        return player.level().getBlockState(feet).is(VeilboundBlocks.THRESHOLD_PORTAL.get())
                || player.level().getBlockState(body).is(VeilboundBlocks.THRESHOLD_PORTAL.get());
    }

    public record TransitResult(boolean success, boolean entered, UUID ownerId, String role, String reason) {
        static TransitResult denied(String reason) { return new TransitResult(false, false, null, null, reason); }
        static TransitResult entered(UUID ownerId, String role) { return new TransitResult(true, true, ownerId, role, "ok"); }
        static TransitResult exited(String role) { return new TransitResult(true, false, null, role, "ok"); }
    }
}
