package dev.futurae.veilbound.breach;

import dev.futurae.veilbound.domain.DomainState;
import java.util.Objects;
import java.util.UUID;

/** Mutation service kept separate so sealing costs can remain data/config-driven. */
public final class BreachService {
    private BreachService() {}

    public static SealResult sealWithStitcher(DomainState state, UUID breachId, long dimensionalEnergyCost) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(breachId, "breachId");
        if (dimensionalEnergyCost < 0) return SealResult.denied("invalid_cost");
        Breach breach = state.breaches().stream()
                .filter(candidate -> candidate.id().equals(breachId))
                .findFirst()
                .orElse(null);
        if (breach == null) return SealResult.denied("breach_not_found");
        if (!breach.open()) return SealResult.denied("already_sealed");
        if (!state.consumeDimensionalEnergy(dimensionalEnergyCost)) {
            return SealResult.denied("insufficient_dimensional_energy");
        }
        state.replaceBreach(breach.sealed());
        return SealResult.allowed(dimensionalEnergyCost);
    }

    public record SealResult(boolean sealed, long dimensionalEnergySpent, String reason) {
        public static SealResult denied(String reason) { return new SealResult(false, 0, reason); }
        public static SealResult allowed(long cost) { return new SealResult(true, cost, "ok"); }
    }
}
