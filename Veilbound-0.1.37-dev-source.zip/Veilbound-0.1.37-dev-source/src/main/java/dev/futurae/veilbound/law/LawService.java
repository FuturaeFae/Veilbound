package dev.futurae.veilbound.law;

import dev.futurae.veilbound.domain.DomainState;
import java.util.Objects;

/** Pure imposition/repeal validation for data-driven Laws. */
public final class LawService {
    private LawService() {}

    public static ChangeResult impose(DomainState state, LawDefinition law) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(law, "law");
        if (state.imposedLawIds().contains(law.id())) return ChangeResult.denied("already_imposed");
        if (!state.imposedLawIds().containsAll(law.prerequisites())) return ChangeResult.denied("law_prerequisites_missing");
        for (String incompatible : law.incompatibleLawIds()) {
            if (state.imposedLawIds().contains(incompatible)) return ChangeResult.denied("incompatible_law:" + incompatible);
        }
        state.imposeLaw(law.id());
        return ChangeResult.allowed(law.id());
    }

    public static ChangeResult repeal(DomainState state, LawDefinition law, LawRegistry registry) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(law, "law");
        Objects.requireNonNull(registry, "registry");
        if (!state.imposedLawIds().contains(law.id())) return ChangeResult.denied("not_imposed");
        for (String imposedId : state.imposedLawIds()) {
            if (imposedId.equals(law.id())) continue;
            LawDefinition imposed = registry.get(imposedId).orElse(null);
            if (imposed != null && imposed.prerequisites().contains(law.id())) {
                return ChangeResult.denied("required_by:" + imposedId);
            }
        }
        state.repealLaw(law.id());
        return ChangeResult.allowed(law.id());
    }

    public record ChangeResult(boolean changed, String lawId, String reason) {
        public static ChangeResult denied(String reason) { return new ChangeResult(false, null, reason); }
        public static ChangeResult allowed(String id) { return new ChangeResult(true, id, "ok"); }
    }
}
