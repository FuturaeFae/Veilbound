package dev.futurae.veilbound.platform.neoforge.world;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.domain.DomainIdentity;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.domain.DomainRuntimeTracker;
import dev.futurae.veilbound.domain.DomainUnloadGate;
import dev.futurae.veilbound.platform.neoforge.mixin.MinecraftServerAccessor;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalLong;
import java.util.UUID;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.dimension.LevelStem;
import net.minecraft.world.level.levelgen.FlatLevelSource;
import net.minecraft.world.level.levelgen.flat.FlatLevelGeneratorSettings;
import net.minecraft.world.level.levelgen.structure.StructureSet;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.level.LevelEvent;

/**
 * Owns the live {@link ServerLevel} lifecycle for Veilbound personal Domains.
 *
 * <p>Domains are deliberately absent from the server's live world map while dormant. Loading
 * reconstructs a normal ServerLevel from the owner's persisted identity/seed and the normal
 * per-dimension storage path. Unloading saves, removes and closes only after the loader-neutral
 * safety gate reports that no player/chunk/transit/runtime requirement still depends on it.</p>
 *
 * <p>Every method in this class must be called on the logical server thread. The service never
 * creates a starter floor or other canonical pocket blocks; initial-pocket material/geometry is
 * a separate gameplay concern.</p>
 */
public final class NeoForgeDomainLevelService {
    private final VeilboundRuntime runtime;

    public NeoForgeDomainLevelService(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    /** Returns the already-live level or reconstructs it from durable Domain state. */
    public ServerLevel load(MinecraftServer server, UUID ownerId) {
        Objects.requireNonNull(server, "server");
        Objects.requireNonNull(ownerId, "ownerId");
        DomainRecord record = runtime.domains().getRecord(ownerId)
                .orElseThrow(() -> new IllegalArgumentException("Domain not found for owner " + ownerId));
        ResourceKey<Level> key = levelKey(record.identity());

        ServerLevel existing = server.forgeGetWorldMap().get(key);
        if (existing != null) {
            refreshRuntimeState(ownerId, existing, true);
            return existing;
        }

        ServerLevel created = createLevel(server, record, key);
        Map<ResourceKey<Level>, ServerLevel> levels = server.forgeGetWorldMap();
        ServerLevel conflict = levels.putIfAbsent(key, created);
        if (conflict != null) {
            closeQuietly(created, "discarding duplicate Domain level " + key.identifier());
            refreshRuntimeState(ownerId, conflict, true);
            return conflict;
        }

        server.markWorldsDirty();
        NeoForge.EVENT_BUS.post(new LevelEvent.Load(created));
        refreshRuntimeState(ownerId, created, true);
        Veilbound.LOGGER.info("Loaded Domain {} for {}", key.identifier(), ownerId);
        return created;
    }

    /**
     * Attempts to unload a dormant Domain. The returned decision explains why the level remained
     * loaded when unloading would be unsafe.
     */
    public UnloadResult unloadIfSafe(MinecraftServer server, UUID ownerId) {
        Objects.requireNonNull(server, "server");
        Objects.requireNonNull(ownerId, "ownerId");
        DomainRecord record = runtime.domains().getRecord(ownerId)
                .orElseThrow(() -> new IllegalArgumentException("Domain not found for owner " + ownerId));
        ResourceKey<Level> key = levelKey(record.identity());
        Map<ResourceKey<Level>, ServerLevel> levels = server.forgeGetWorldMap();
        ServerLevel level = levels.get(key);
        if (level == null) {
            runtime.domainRuntime().setLoaded(ownerId, false);
            runtime.domainRuntime().setPlayersInside(ownerId, 0);
            runtime.domainRuntime().setForcedChunks(ownerId, 0);
            return UnloadResult.alreadyDormantResult();
        }

        refreshRuntimeState(ownerId, level, true);
        DomainUnloadGate.Decision decision = runtime.domainRuntime().unloadDecision(ownerId);
        if (!decision.allowed()) return UnloadResult.denied(decision.reason());

        // Save before removing the level from the server. A save failure must leave the live level
        // intact rather than silently discarding the only in-memory copy of dirty chunks.
        if (level instanceof VeilboundServerLevel domainLevel) domainLevel.persistEnvironmentState();
        level.save(null, true, false);
        if (!levels.remove(key, level)) return UnloadResult.denied("level_map_changed");
        server.markWorldsDirty();
        NeoForge.EVENT_BUS.post(new LevelEvent.Unload(level));

        try {
            level.close();
        } catch (IOException error) {
            // The level has already been removed after a successful save. Surface the close failure
            // loudly; restoring a half-closed ServerLevel to the live map would be less safe.
            throw new IllegalStateException("Failed to close saved Domain " + key.identifier(), error);
        }

        DomainRuntimeTracker tracker = runtime.domainRuntime();
        tracker.setLoaded(ownerId, false);
        tracker.setPlayersInside(ownerId, 0);
        tracker.setForcedChunks(ownerId, 0);
        Veilbound.LOGGER.info("Unloaded dormant Domain {} for {}", key.identifier(), ownerId);
        return UnloadResult.unloadedResult();
    }

    public Optional<ServerLevel> liveLevel(MinecraftServer server, UUID ownerId) {
        Objects.requireNonNull(server, "server");
        Objects.requireNonNull(ownerId, "ownerId");
        return runtime.domains().getRecord(ownerId)
                .map(record -> server.forgeGetWorldMap().get(levelKey(record.identity())));
    }

    public static ResourceKey<Level> levelKey(DomainIdentity identity) {
        Objects.requireNonNull(identity, "identity");
        Identifier id = Identifier.parse(identity.dimensionId());
        return ResourceKey.create(Registries.DIMENSION, id);
    }

    private ServerLevel createLevel(
            MinecraftServer server,
            DomainRecord record,
            ResourceKey<Level> key) {
        ResourceKey<Biome> domainBiomeKey = ResourceKey.create(
                Registries.BIOME, Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "domain_void"));
        Holder<Biome> domainBiome = server.registryAccess()
                .lookupOrThrow(Registries.BIOME)
                .getOrThrow(domainBiomeKey);
        ResourceKey<DimensionType> domainTypeKey = ResourceKey.create(
                Registries.DIMENSION_TYPE, Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "domain"));
        Holder<DimensionType> domainType = server.registryAccess()
                .lookupOrThrow(Registries.DIMENSION_TYPE)
                .getOrThrow(domainTypeKey);
        Optional<HolderSet<StructureSet>> noStructures = Optional.of(HolderSet.empty());
        FlatLevelGeneratorSettings settings = new FlatLevelGeneratorSettings(noStructures, domainBiome, List.of())
                .withBiomeAndLayers(List.of(), noStructures, domainBiome);
        FlatLevelSource generator = new FlatLevelSource(settings);

        LevelStem stem = new LevelStem(
                domainType,
                generator,
                OptionalLong.of(record.identity().seed()));
        VeilboundDomainLevelData levelData = new VeilboundDomainLevelData(server, record.state());
        var lawSnapshot = runtime.lawRuntimeSemantics().snapshot(runtime.activeLawEffects(record.state()));
        var memorySnapshot = runtime.memoryEnvironment()
                .resolve(record.state(), record.memoryProgress(), runtime.memories())
                .semantics();
        MinecraftServerAccessor accessor = (MinecraftServerAccessor) (Object) server;
        VeilboundServerLevel level = new VeilboundServerLevel(
                server,
                accessor.veilbound$getExecutor(),
                accessor.veilbound$getStorageSource(),
                levelData,
                key,
                stem,
                false,
                BiomeManager.obfuscateSeed(record.identity().seed()),
                List.of(),
                false,
                record.state());

        level.applyEnvironmentLaws(
                lawSnapshot, memorySnapshot.overworldDayCycle(), memorySnapshot.rainWeather());
        level.applyMemoryIllumination(memorySnapshot);
        level.setRememberedRain(
                lawSnapshot.weather() && memorySnapshot.rainWeather(),
                runtime.memoryEffectPolicy().policy().forcedRainRefreshTicks());

        // Minecraft 26.2 exposes this chunk-source switch specifically for monster spawning;
        // passive natural categories are controlled by SPAWN_MOBS plus the Law spawn gate.
        level.setSpawnSettings(lawSnapshot.hostility());
        return level;
    }

    private void refreshRuntimeState(UUID ownerId, ServerLevel level, boolean loaded) {
        DomainRuntimeTracker tracker = runtime.domainRuntime();
        tracker.setLoaded(ownerId, loaded);
        tracker.setPlayersInside(ownerId, level.players().size());
        tracker.setForcedChunks(ownerId, level.getForceLoadedChunks().size());
    }

    private static void closeQuietly(ServerLevel level, String context) {
        try {
            level.close();
        } catch (IOException error) {
            Veilbound.LOGGER.warn("Failed while {}", context, error);
        }
    }

    public record UnloadResult(boolean unloaded, boolean alreadyDormant, String reason) {
        public static UnloadResult unloadedResult() { return new UnloadResult(true, false, "ok"); }
        public static UnloadResult alreadyDormantResult() { return new UnloadResult(false, true, "already_dormant"); }
        public static UnloadResult denied(String reason) { return new UnloadResult(false, false, reason); }
    }
}
