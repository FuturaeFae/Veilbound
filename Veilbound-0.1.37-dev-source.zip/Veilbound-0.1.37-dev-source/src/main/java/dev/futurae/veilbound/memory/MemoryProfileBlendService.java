package dev.futurae.veilbound.memory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Deterministically combines compatible Orrery Memory profiles without silently overwriting one
 * remembered reality with another. Visual and mechanic keys remain independent namespaces in the
 * profile, allowing a sky/ambience Memory to mix with a fertility/weather Memory when they do not
 * claim contradictory values for the same key.
 */
public final class MemoryProfileBlendService {
    public BlendResult blend(Collection<MemoryDefinition> selected, Set<String> learnedIds) {
        Objects.requireNonNull(selected, "selected");
        Objects.requireNonNull(learnedIds, "learnedIds");
        if (selected.isEmpty()) return BlendResult.denied("no_memories_selected", Set.of());

        LinkedHashMap<String, String> profile = new LinkedHashMap<>();
        LinkedHashSet<String> ids = new LinkedHashSet<>();
        LinkedHashSet<String> conflicts = new LinkedHashSet<>();
        for (MemoryDefinition memory : selected) {
            if (!learnedIds.contains(memory.id())) return BlendResult.denied("memory_not_learned", Set.of(memory.id()));
            if (!ids.add(memory.id())) continue;
            for (Map.Entry<String, String> entry : memory.environmentalProfile().entrySet()) {
                String prior = profile.putIfAbsent(entry.getKey(), entry.getValue());
                if (prior != null && !prior.equals(entry.getValue())) conflicts.add(entry.getKey());
            }
        }
        if (!conflicts.isEmpty()) return BlendResult.denied("profile_conflict", conflicts);
        return BlendResult.allowed(List.copyOf(ids), Map.copyOf(profile));
    }

    public record BlendResult(
            boolean compatible,
            String reason,
            List<String> memoryIds,
            Map<String, String> environmentalProfile,
            Set<String> conflicts) {
        private static BlendResult denied(String reason, Set<String> conflicts) {
            return new BlendResult(false, reason, List.of(), Map.of(), Set.copyOf(conflicts));
        }
        private static BlendResult allowed(List<String> ids, Map<String, String> profile) {
            return new BlendResult(true, "ok", List.copyOf(ids), Map.copyOf(profile), Set.of());
        }
    }
}
