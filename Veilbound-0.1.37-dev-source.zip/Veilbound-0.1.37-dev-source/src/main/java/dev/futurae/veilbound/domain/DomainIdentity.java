package dev.futurae.veilbound.domain;

import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/** Stable persisted identity for one owner's true personal runtime dimension. */
public record DomainIdentity(UUID ownerId, String dimensionId, long seed) {
    public static final String DIMENSION_NAMESPACE = "veilbound";
    public static final String DIMENSION_PATH_PREFIX = "domain/";

    public DomainIdentity {
        Objects.requireNonNull(ownerId, "ownerId");
        Objects.requireNonNull(dimensionId, "dimensionId");
        if (!dimensionId.equals(dimensionIdFor(ownerId))) {
            throw new IllegalArgumentException("Domain dimension id must be derived from the owner UUID");
        }
    }

    public static DomainIdentity create(UUID ownerId, long seed) {
        return new DomainIdentity(ownerId, dimensionIdFor(ownerId), seed);
    }

    /** Parse only canonical Veilbound personal-Domain dimension ids. */
    public static Optional<UUID> ownerFromDimensionId(String dimensionId) {
        Objects.requireNonNull(dimensionId, "dimensionId");
        String prefix = DIMENSION_NAMESPACE + ":" + DIMENSION_PATH_PREFIX;
        if (!dimensionId.startsWith(prefix)) return Optional.empty();
        String raw = dimensionId.substring(prefix.length());
        try {
            UUID ownerId = UUID.fromString(raw);
            return dimensionIdFor(ownerId).equals(dimensionId) ? Optional.of(ownerId) : Optional.empty();
        } catch (IllegalArgumentException ignored) {
            return Optional.empty();
        }
    }

    public static String dimensionIdFor(UUID ownerId) {
        Objects.requireNonNull(ownerId, "ownerId");
        return DIMENSION_NAMESPACE + ":" + DIMENSION_PATH_PREFIX + ownerId.toString().toLowerCase(Locale.ROOT);
    }
}
