package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Server-authoritative actions for one physical Fabricator/Foundry. */
public record EngineeringStationActionPayload(Action action, int x, int y, int z, String value) implements CustomPacketPayload {
    public enum Action { REFRESH, SELECT_RECIPE, CLEAR_SELECTION, CLAIM_OUTPUT }
    public static final Type<EngineeringStationActionPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "engineering_station_action"));
    public static final StreamCodec<RegistryFriendlyByteBuf, EngineeringStationActionPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override public EngineeringStationActionPayload decode(RegistryFriendlyByteBuf buffer) {
            int ordinal = buffer.readVarInt();
            Action[] values = Action.values();
            Action action = ordinal >= 0 && ordinal < values.length ? values[ordinal] : Action.REFRESH;
            return new EngineeringStationActionPayload(action, buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readUtf(192));
        }
        @Override public void encode(RegistryFriendlyByteBuf buffer, EngineeringStationActionPayload payload) {
            buffer.writeVarInt(payload.action().ordinal());
            buffer.writeInt(payload.x()); buffer.writeInt(payload.y()); buffer.writeInt(payload.z());
            buffer.writeUtf(payload.value() == null ? "" : payload.value(), 192);
        }
    };
    public EngineeringStationActionPayload { if (action == null) action = Action.REFRESH; if (value == null) value = ""; }
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
