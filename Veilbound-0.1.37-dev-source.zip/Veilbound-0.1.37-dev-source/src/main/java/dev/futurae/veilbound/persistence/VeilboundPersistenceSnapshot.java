package dev.futurae.veilbound.persistence;

import dev.futurae.veilbound.domain.DomainRepository;
import dev.futurae.veilbound.threshold.ThresholdRegistry;
import java.util.List;

/** Complete server-global persistent Veilbound state. Active transit sessions remain runtime-only. */
public record VeilboundPersistenceSnapshot(
        List<DomainRecordSnapshot> domains,
        List<ThresholdSnapshot> thresholds) {
    public VeilboundPersistenceSnapshot {
        domains = List.copyOf(domains);
        thresholds = List.copyOf(thresholds);
    }

    public static VeilboundPersistenceSnapshot capture(DomainRepository domains, ThresholdRegistry thresholds) {
        return new VeilboundPersistenceSnapshot(
                domains.records().stream().map(DomainRecordSnapshot::capture).toList(),
                thresholds.all().stream().map(ThresholdSnapshot::capture).toList());
    }

    public void restoreInto(DomainRepository domains, ThresholdRegistry thresholds) {
        domains.replaceRecordsFromPersistence(this.domains.stream().map(DomainRecordSnapshot::restore).toList());
        thresholds.replaceFromPersistence(this.thresholds.stream().map(ThresholdSnapshot::restore).toList());
    }
}
