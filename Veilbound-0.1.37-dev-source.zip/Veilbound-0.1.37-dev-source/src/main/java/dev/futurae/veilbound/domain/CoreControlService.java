package dev.futurae.veilbound.domain;

import java.util.Objects;

/** Server-authoritative owner controls exposed by empty-hand Dimensional Core interactions. */
public final class CoreControlService {
    private CoreControlService() {}

    public static ToggleResult toggleExpansion(DomainState state) {
        Objects.requireNonNull(state, "state");
        if (!state.coreActive()) return ToggleResult.denied("core_inactive");
        return ToggleResult.allowed(state.toggleGlobalExpansion());
    }

    public record ToggleResult(boolean toggled, boolean enabled, String reason) {
        public static ToggleResult denied(String reason) { return new ToggleResult(false, false, reason); }
        public static ToggleResult allowed(boolean enabled) { return new ToggleResult(true, enabled, "ok"); }
    }
}
