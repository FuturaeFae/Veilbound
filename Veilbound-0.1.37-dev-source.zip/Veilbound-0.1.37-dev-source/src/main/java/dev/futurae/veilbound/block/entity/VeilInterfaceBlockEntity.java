package dev.futurae.veilbound.block.entity;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.inventory.VeilInventory;
import dev.futurae.veilbound.inventory.VeilStackKey;
import dev.futurae.veilbound.inventory.VeilStorageCapacity;
import dev.futurae.veilbound.matter.MatterTransmutationService;
import dev.futurae.veilbound.platform.neoforge.inventory.NeoForgeVeilStackBridge;
import dev.futurae.veilbound.registry.VeilboundBlockEntities;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.neoforged.neoforge.transfer.ResourceHandler;
import net.neoforged.neoforge.transfer.TransferPreconditions;
import net.neoforged.neoforge.transfer.item.ItemResource;
import net.neoforged.neoforge.transfer.transaction.SnapshotJournal;
import net.neoforged.neoforge.transfer.transaction.TransactionContext;
import org.jspecify.annotations.Nullable;

/**
 * Owner-bound physical bridge. Before Transmutation it exposes digital storage. After the upgrade
 * valued items are learned/absorbed/synthesized through Matter, while genuinely unvalued items
 * remain exact physical stacks in the same Veil Inventory and stay extractable through automation.
 */
public final class VeilInterfaceBlockEntity extends BlockEntity {
    private UUID ownerId;
    private final ResourceHandler<ItemResource> itemHandler = new InterfaceItemHandler();
    private final MatterTransmutationService transmutation = new MatterTransmutationService();

    public VeilInterfaceBlockEntity(BlockPos pos, BlockState state) {
        super(VeilboundBlockEntities.VEIL_INTERFACE.get(), pos, state);
    }

    public void bindOwner(UUID ownerId) {
        if (this.ownerId == null) {
            this.ownerId = java.util.Objects.requireNonNull(ownerId, "ownerId");
            setChanged();
        }
    }

    public @Nullable UUID ownerId() { return ownerId; }
    public ResourceHandler<ItemResource> itemHandler(Direction side) { return itemHandler; }

    @Override
    protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        if (ownerId != null) output.putString("owner", ownerId.toString());
    }

    @Override
    protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        ownerId = input.getString("owner").flatMap(raw -> {
            try { return java.util.Optional.of(UUID.fromString(raw)); }
            catch (IllegalArgumentException ignored) { return java.util.Optional.empty(); }
        }).orElse(null);
    }

    private Access access() {
        if (!(level instanceof ServerLevel serverLevel) || ownerId == null) return Access.denied();
        boolean ownerOnline = serverLevel.getServer().getPlayerList().getPlayer(ownerId) != null;
        var inventoryAccess = Veilbound.runtime().veilInventoryAccess().interfaceAccess(ownerId, ownerOnline);
        if (!inventoryAccess.allowed()) return Access.denied();
        DomainRecord record = Veilbound.runtime().domains().getRecord(ownerId).orElse(null);
        if (record == null) return Access.denied();
        ensureTerminalMigration(record);
        return new Access(record, inventoryAccess.inventory(), inventoryAccess.capacity());
    }

    private void ensureTerminalMigration(DomainRecord record) {
        if (!record.state().hasFeature(DomainFeature.VEIL_TRANSMUTATION) || record.veilInventory().totalItems() == 0) return;
        var result = transmutation.migrateLegacyInventory(
                record.state(), record.veilInventory(), record.matterTransmutation(), Veilbound.runtime().matter());
        if (!result.migrated()) throw new IllegalStateException("Could not migrate Interface-backed Veil Inventory: " + result.reason());
    }

    private List<VeilStackKey> sortedStoredKeys(VeilInventory inventory) {
        return inventory.contents().keySet().stream()
                .filter(key -> Veilbound.runtime().matter().amount(key.itemId()).isEmpty())
                .sorted(Comparator.comparing(VeilStackKey::itemId).thenComparing(VeilStackKey::componentData))
                .toList();
    }

    private List<String> sortedPatterns(DomainRecord record) {
        return record.matterTransmutation().learnedItemIds().stream()
                .filter(id -> Veilbound.runtime().matter().amount(id).isPresent())
                .sorted()
                .toList();
    }

    private int insertionIndex(Access access) {
        return access.terminal()
                ? sortedPatterns(access.record()).size() + sortedStoredKeys(access.inventory()).size()
                : sortedStoredKeys(access.inventory()).size();
    }

    private record Access(@Nullable DomainRecord record, @Nullable VeilInventory inventory, VeilStorageCapacity capacity) {
        static Access denied() { return new Access(null, null, VeilStorageCapacity.LOCKED); }
        boolean allowed() { return record != null && inventory != null && capacity.unlocked(); }
        boolean terminal() { return allowed() && record.state().hasFeature(DomainFeature.VEIL_TRANSMUTATION); }
    }

    private record InterfaceSnapshot(
            @Nullable VeilInventory inventory,
            Map<VeilStackKey, Long> contents,
            @Nullable dev.futurae.veilbound.matter.MatterTransmutationState matterState,
            long storedMatter,
            Set<String> learnedPatterns) {}

    private final class InterfaceItemHandler extends SnapshotJournal<InterfaceSnapshot> implements ResourceHandler<ItemResource> {
        @Override
        public int size() {
            Access access = access();
            if (!access.allowed()) return 0;
            return insertionIndex(access) + 1;
        }

        @Override
        public ItemResource getResource(int index) {
            Access access = access();
            if (!access.allowed() || index < 0) return ItemResource.EMPTY;
            if (access.terminal()) {
                List<String> patterns = sortedPatterns(access.record());
                if (index < patterns.size()) {
                    return NeoForgeVeilStackBridge.toResource(VeilStackKey.plain(patterns.get(index)), level.registryAccess());
                }
                List<VeilStackKey> stored = sortedStoredKeys(access.inventory());
                int storedIndex = index - patterns.size();
                if (storedIndex >= 0 && storedIndex < stored.size()) {
                    return NeoForgeVeilStackBridge.toResource(stored.get(storedIndex), level.registryAccess());
                }
                return ItemResource.EMPTY;
            }
            List<VeilStackKey> stored = sortedStoredKeys(access.inventory());
            if (index >= stored.size()) return ItemResource.EMPTY;
            return NeoForgeVeilStackBridge.toResource(stored.get(index), level.registryAccess());
        }

        @Override
        public long getAmountAsLong(int index) {
            Access access = access();
            if (!access.allowed() || index < 0) return 0;
            if (access.terminal()) {
                List<String> patterns = sortedPatterns(access.record());
                if (index < patterns.size()) {
                    var resolved = Veilbound.runtime().matter().amount(patterns.get(index));
                    if (resolved.isEmpty() || resolved.getAsLong() <= 0) return 0;
                    return access.record().matterTransmutation().storedMatter() / resolved.getAsLong();
                }
                List<VeilStackKey> stored = sortedStoredKeys(access.inventory());
                int storedIndex = index - patterns.size();
                return storedIndex >= 0 && storedIndex < stored.size()
                        ? access.inventory().count(stored.get(storedIndex)) : 0;
            }
            List<VeilStackKey> stored = sortedStoredKeys(access.inventory());
            return index < stored.size() ? access.inventory().count(stored.get(index)) : 0;
        }

        @Override
        public long getCapacityAsLong(int index, ItemResource resource) {
            Access access = access();
            if (!access.allowed() || resource == null || resource.isEmpty() || index < 0) return 0;
            VeilStackKey offered;
            try { offered = NeoForgeVeilStackBridge.toKey(resource, level.registryAccess()); }
            catch (RuntimeException malformed) { return 0; }

            if (access.terminal()) {
                List<String> patterns = sortedPatterns(access.record());
                if (index < patterns.size()) {
                    if (!patterns.get(index).equals(offered.itemId())) return 0;
                    return matterInsertionCapacity(access, offered.itemId());
                }
                List<VeilStackKey> stored = sortedStoredKeys(access.inventory());
                int storedIndex = index - patterns.size();
                if (storedIndex >= 0 && storedIndex < stored.size()) {
                    if (!stored.get(storedIndex).equals(offered)) return 0;
                    return physicalInsertionCapacity(access, offered);
                }
                if (index != patterns.size() + stored.size()) return 0;
                return Veilbound.runtime().matter().amount(offered.itemId()).isPresent()
                        ? matterInsertionCapacity(access, offered.itemId())
                        : physicalInsertionCapacity(access, offered);
            }

            List<VeilStackKey> stored = sortedStoredKeys(access.inventory());
            if (index < stored.size() && !stored.get(index).equals(offered)) return 0;
            if (index > stored.size()) return 0;
            return physicalInsertionCapacity(access, offered);
        }

        @Override
        public boolean isValid(int index, ItemResource resource) {
            if (resource == null || resource.isEmpty()) return false;
            Access access = access();
            if (!access.allowed() || index < 0) return false;
            VeilStackKey offered;
            try { offered = NeoForgeVeilStackBridge.toKey(resource, level.registryAccess()); }
            catch (RuntimeException malformed) { return false; }

            if (access.terminal()) {
                List<String> patterns = sortedPatterns(access.record());
                if (index < patterns.size()) return patterns.get(index).equals(offered.itemId());
                List<VeilStackKey> stored = sortedStoredKeys(access.inventory());
                int storedIndex = index - patterns.size();
                if (storedIndex >= 0 && storedIndex < stored.size()) return stored.get(storedIndex).equals(offered);
                return index == patterns.size() + stored.size();
            }
            List<VeilStackKey> stored = sortedStoredKeys(access.inventory());
            if (index < stored.size()) return stored.get(index).equals(offered);
            return index == stored.size();
        }

        @Override
        public int insert(int index, ItemResource resource, int amount, TransactionContext transaction) {
            TransferPreconditions.checkNonEmptyNonNegative(resource, amount);
            if (amount == 0) return 0;
            Access access = access();
            if (!access.allowed() || index < 0) return 0;
            VeilStackKey key;
            try { key = NeoForgeVeilStackBridge.toKey(resource, level.registryAccess()); }
            catch (RuntimeException malformed) { return 0; }

            if (access.terminal()) {
                List<String> patterns = sortedPatterns(access.record());
                List<VeilStackKey> stored = sortedStoredKeys(access.inventory());
                if (index < patterns.size()) {
                    if (!patterns.get(index).equals(key.itemId())) return 0;
                    updateSnapshots(transaction);
                    var absorbed = transmutation.absorb(
                            access.record().state(), access.record().matterTransmutation(),
                            Veilbound.runtime().matter(), key, amount);
                    return absorbed.absorbed() ? (int) absorbed.itemCount() : 0;
                }
                int storedIndex = index - patterns.size();
                if (storedIndex >= 0 && storedIndex < stored.size()) {
                    if (!stored.get(storedIndex).equals(key)
                            || Veilbound.runtime().matter().amount(key.itemId()).isPresent()) return 0;
                    updateSnapshots(transaction);
                    return (int) access.inventory().insert(key, amount, access.capacity());
                }
                if (index != patterns.size() + stored.size()) return 0;
                updateSnapshots(transaction);
                if (Veilbound.runtime().matter().amount(key.itemId()).isPresent()) {
                    var absorbed = transmutation.absorb(
                            access.record().state(), access.record().matterTransmutation(),
                            Veilbound.runtime().matter(), key, amount);
                    return absorbed.absorbed() ? (int) absorbed.itemCount() : 0;
                }
                return (int) access.inventory().insert(key, amount, access.capacity());
            }

            List<VeilStackKey> stored = sortedStoredKeys(access.inventory());
            if (index < stored.size() && !stored.get(index).equals(key)) return 0;
            if (index > stored.size()) return 0;
            updateSnapshots(transaction);
            return (int) access.inventory().insert(key, amount, access.capacity());
        }

        @Override
        public int extract(int index, ItemResource resource, int amount, TransactionContext transaction) {
            TransferPreconditions.checkNonEmptyNonNegative(resource, amount);
            if (amount == 0) return 0;
            Access access = access();
            if (!access.allowed() || index < 0) return 0;

            if (access.terminal()) {
                List<String> patterns = sortedPatterns(access.record());
                if (index < patterns.size()) {
                    String itemId = patterns.get(index);
                    ItemResource expected = NeoForgeVeilStackBridge.toResource(
                            VeilStackKey.plain(itemId), level.registryAccess());
                    if (!expected.equals(resource)) return 0;
                    updateSnapshots(transaction);
                    var synthesized = transmutation.synthesize(
                            access.record().state(), access.record().matterTransmutation(),
                            Veilbound.runtime().matter(), itemId, amount);
                    return synthesized.synthesized() ? (int) synthesized.itemCount() : 0;
                }
                List<VeilStackKey> stored = sortedStoredKeys(access.inventory());
                int storedIndex = index - patterns.size();
                if (storedIndex < 0 || storedIndex >= stored.size()) return 0;
                VeilStackKey key = stored.get(storedIndex);
                ItemResource expected = NeoForgeVeilStackBridge.toResource(key, level.registryAccess());
                if (!expected.equals(resource)) return 0;
                updateSnapshots(transaction);
                return (int) access.inventory().extract(key, amount);
            }

            List<VeilStackKey> stored = sortedStoredKeys(access.inventory());
            if (index >= stored.size()) return 0;
            VeilStackKey key = stored.get(index);
            ItemResource expected = NeoForgeVeilStackBridge.toResource(key, level.registryAccess());
            if (!expected.equals(resource)) return 0;
            updateSnapshots(transaction);
            return (int) access.inventory().extract(key, amount);
        }

        @Override
        public int insert(ItemResource resource, int amount, TransactionContext transaction) {
            TransferPreconditions.checkNonEmptyNonNegative(resource, amount);
            if (amount == 0) return 0;
            Access access = access();
            return access.allowed() ? insert(insertionIndex(access), resource, amount, transaction) : 0;
        }

        @Override
        public int extract(ItemResource resource, int amount, TransactionContext transaction) {
            TransferPreconditions.checkNonEmptyNonNegative(resource, amount);
            if (amount == 0) return 0;
            Access access = access();
            if (!access.allowed()) return 0;
            VeilStackKey key;
            try { key = NeoForgeVeilStackBridge.toKey(resource, level.registryAccess()); }
            catch (RuntimeException malformed) { return 0; }

            if (access.terminal()) {
                List<String> patterns = sortedPatterns(access.record());
                List<VeilStackKey> stored = sortedStoredKeys(access.inventory());
                int storedIndex = stored.indexOf(key);
                if (storedIndex >= 0) return extract(patterns.size() + storedIndex, resource, amount, transaction);
                if (!key.componentData().isEmpty()) return 0;
                int patternIndex = patterns.indexOf(key.itemId());
                return patternIndex < 0 ? 0 : extract(patternIndex, resource, amount, transaction);
            }
            List<VeilStackKey> stored = sortedStoredKeys(access.inventory());
            int storedIndex = stored.indexOf(key);
            return storedIndex < 0 ? 0 : extract(storedIndex, resource, amount, transaction);
        }

        private long matterInsertionCapacity(Access access, String itemId) {
            var resolved = Veilbound.runtime().matter().amount(itemId);
            if (resolved.isEmpty() || resolved.getAsLong() <= 0) return 0;
            long room = Long.MAX_VALUE - access.record().matterTransmutation().storedMatter();
            return room / resolved.getAsLong();
        }

        private long physicalInsertionCapacity(Access access, VeilStackKey key) {
            if (Veilbound.runtime().matter().amount(key.itemId()).isPresent() && access.terminal()) return 0;
            long remaining = access.capacity().maxItems() == Long.MAX_VALUE
                    ? Long.MAX_VALUE
                    : Math.max(0L, access.capacity().maxItems() - access.inventory().totalItems());
            long existing = access.inventory().count(key);
            if (existing == 0 && access.inventory().distinctTypes() >= access.capacity().maxTypes()) return 0;
            return saturatingAdd(existing, remaining);
        }

        @Override
        protected InterfaceSnapshot createSnapshot() {
            Access access = access();
            return access.allowed()
                    ? new InterfaceSnapshot(
                            access.inventory(), access.inventory().contents(), access.record().matterTransmutation(),
                            access.record().matterTransmutation().storedMatter(), access.record().matterTransmutation().learnedItemIds())
                    : new InterfaceSnapshot(null, Map.of(), null, 0L, Set.of());
        }

        @Override
        protected void revertToSnapshot(InterfaceSnapshot snapshot) {
            if (snapshot.inventory() != null) snapshot.inventory().replaceFromPersistence(snapshot.contents());
            if (snapshot.matterState() != null) snapshot.matterState().replace(snapshot.storedMatter(), snapshot.learnedPatterns());
        }

        private long saturatingAdd(long a, long b) {
            if (a == Long.MAX_VALUE || b == Long.MAX_VALUE || Long.MAX_VALUE - a < b) return Long.MAX_VALUE;
            return a + b;
        }
    }
}
