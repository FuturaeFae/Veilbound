package dev.futurae.veilbound.engineering;

import java.util.Objects;

public record EngineeringIngredient(String itemId, int count) {
    public EngineeringIngredient {
        itemId = Objects.requireNonNull(itemId, "itemId").trim();
        if (itemId.isEmpty()) throw new IllegalArgumentException("itemId may not be blank");
        if (count <= 0) throw new IllegalArgumentException("count must be positive");
    }
}
