package dev.futurae.veilbound.milestone;

import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainState;
import java.util.Objects;
import java.util.Set;

/** Compatibility facade over the now-persistent Domain milestone state. */
public final class MilestoneProgress {
    public Set<String> completed(DomainState state) { return Objects.requireNonNull(state, "state").completedMilestoneIds(); }

    public CompleteResult complete(DomainState state, MilestoneDefinition milestone) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(milestone, "milestone");
        if (state.completedMilestoneIds().contains(milestone.id())) return CompleteResult.denied("already_complete");
        if (!state.completedMilestoneIds().containsAll(milestone.prerequisiteMilestoneIds())) return CompleteResult.denied("prerequisites_missing");
        if (!state.completeMilestone(milestone.id())) return CompleteResult.denied("already_complete");
        for (DomainFeature feature : milestone.unlockedFeatures()) state.unlockFeature(feature);
        return CompleteResult.allowed(milestone.id());
    }

    public record CompleteResult(boolean completed, String milestoneId, String reason) {
        public static CompleteResult denied(String reason) { return new CompleteResult(false, null, reason); }
        public static CompleteResult allowed(String id) { return new CompleteResult(true, id, "ok"); }
    }
}
