package dev.futurae.veilbound.client.screen;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** In-game progression manual; written docs mirror and expand these player-facing instructions. */
public final class EngineeringCodexScreen extends Screen {
    private static final String[] PAGES={"progression","fabrication","matter","memories","laws","stability","breaches","equipment"};
    private int page;
    public EngineeringCodexScreen(){super(Component.translatable("screen.veilbound.codex"));}
    @Override protected void init(){super.init();int l=Math.max(12,width/2-270),t=Math.max(16,height/2-150);Button prev=Button.builder(Component.literal("<"),b->{page=Math.max(0,page-1);rebuild();}).bounds(l+12,t+264,32,20).build();prev.active=page>0;addRenderableWidget(prev);Button next=Button.builder(Component.literal(">"),b->{page=Math.min(PAGES.length-1,page+1);rebuild();}).bounds(l+496,t+264,32,20).build();next.active=page+1<PAGES.length;addRenderableWidget(next);}
    private void rebuild(){clearWidgets();init();}
    @Override public void extractBackground(GuiGraphicsExtractor g,int mouseX,int mouseY,float partial){extractTransparentBackground(g);}
    @Override public void extractRenderState(GuiGraphicsExtractor g,int mouseX,int mouseY,float partial){super.extractRenderState(g,mouseX,mouseY,partial);int l=Math.max(12,width/2-270),t=Math.max(16,height/2-150);g.fill(l,t,l+540,t+300,0xF00E0C15);g.fill(l,t,l+540,t+34,0xF02A163C);g.fill(l,t+33,l+540,t+34,0xFFB783E3);String id=PAGES[page];g.text(font,Component.translatable("codex.veilbound."+id+".title"),l+18,t+13,0xFFF2E9FF,false);g.text(font,Component.translatable("screen.veilbound.codex.page",page+1,PAGES.length),l+440,t+13,0xFFC5BDD0,false);int y=t+54;for(int i=1;i<=12;i++){Component line=Component.translatable("codex.veilbound."+id+"."+i);String resolved=line.getString();if(resolved.equals("codex.veilbound."+id+"."+i))break;g.text(font,line,l+22,y,0xFFCFC4D8,false);y+=16;}}
}
