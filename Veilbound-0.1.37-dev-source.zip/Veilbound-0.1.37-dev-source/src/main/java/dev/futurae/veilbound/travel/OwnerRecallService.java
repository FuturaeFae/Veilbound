package dev.futurae.veilbound.travel;

import dev.futurae.veilbound.domain.DomainRecord;
import java.util.Objects;

/** Pure state transition for the owner's no-cost personal Domain teleport keybind. */
public final class OwnerRecallService {
    private OwnerRecallService() {}

    public static RecallDecision requestFromOutside(DomainRecord record, ReturnAnchor currentLocation) {
        Objects.requireNonNull(record, "record");
        Objects.requireNonNull(currentLocation, "currentLocation");
        if (currentLocation.dimensionId().equals(record.identity().dimensionId())) {
            return RecallDecision.denied("already_inside_domain");
        }
        record.setOwnerReturnAnchor(currentLocation);
        return RecallDecision.enter(record.identity().dimensionId());
    }

    public static RecallDecision requestFromInside(DomainRecord record) {
        Objects.requireNonNull(record, "record");
        ReturnAnchor anchor = record.ownerReturnAnchor().orElse(null);
        if (anchor == null) return RecallDecision.denied("missing_return_anchor");
        return RecallDecision.exit(anchor);
    }

    /** Clear only after the platform confirms the owner was safely returned. */
    public static void completeExit(DomainRecord record) {
        Objects.requireNonNull(record, "record");
        record.clearOwnerReturnAnchor();
    }

    public record RecallDecision(boolean allowed, boolean enteringDomain, String targetDomainId, ReturnAnchor returnAnchor, String reason) {
        static RecallDecision denied(String reason) { return new RecallDecision(false, false, null, null, reason); }
        static RecallDecision enter(String domainId) { return new RecallDecision(true, true, domainId, null, "ok"); }
        static RecallDecision exit(ReturnAnchor anchor) { return new RecallDecision(true, false, null, anchor, "ok"); }
    }
}
