package dev.futurae.veilbound.persistence;

import dev.futurae.veilbound.matter.MatterTransmutationState;
import java.util.List;
import java.util.Set;

/** Persistent Matter reserve, learned patterns, favorites, and recent terminal history. */
public record MatterTransmutationSnapshot(
        long storedMatter,
        Set<String> learnedItemIds,
        Set<String> favoriteItemIds,
        List<String> recentItemIds) {
    public static final MatterTransmutationSnapshot EMPTY = new MatterTransmutationSnapshot(0L, Set.of(), Set.of(), List.of());

    public MatterTransmutationSnapshot {
        if (storedMatter < 0) throw new IllegalArgumentException("storedMatter must be >= 0");
        learnedItemIds = Set.copyOf(learnedItemIds);
        favoriteItemIds = Set.copyOf(favoriteItemIds);
        recentItemIds = List.copyOf(recentItemIds);
        if (!learnedItemIds.containsAll(favoriteItemIds)) {
            throw new IllegalArgumentException("Favorite Matter patterns must also be learned");
        }
        if (!learnedItemIds.containsAll(recentItemIds)) {
            throw new IllegalArgumentException("Recent Matter patterns must also be learned");
        }
    }

    /** Compatibility constructor for persistence v5 data/tests. */
    public MatterTransmutationSnapshot(long storedMatter, Set<String> learnedItemIds) {
        this(storedMatter, learnedItemIds, Set.of(), List.of());
    }

    public static MatterTransmutationSnapshot capture(MatterTransmutationState state) {
        return new MatterTransmutationSnapshot(
                state.storedMatter(), state.learnedItemIds(), state.favoriteItemIds(), state.recentItemIds());
    }

    public void restoreInto(MatterTransmutationState state) {
        state.replace(storedMatter, learnedItemIds, favoriteItemIds, recentItemIds);
    }
}
