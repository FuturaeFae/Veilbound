package dev.futurae.veilbound.precore;

/** Pure preflight/commit arithmetic for Matter + FE -> single Condensed Charge. */
public final class SpatialGeneratorCondensationService {
    private SpatialGeneratorCondensationService() {}

    public static Plan plan(long matterPerItem, int offeredItems, long availableForgeEnergy, SpatialGeneratorRuntimePolicy policy) {
        if (matterPerItem <= 0 || offeredItems <= 0) return Plan.denied("no_convertible_matter");
        if (availableForgeEnergy <= 0) return Plan.denied("insufficient_forge_energy");
        try {
            long fePerItem = Math.multiplyExact(matterPerItem, policy.forgeEnergyPerRawMatter());
            if (fePerItem <= 0) return Plan.denied("cost_overflow");
            long byEnergy = availableForgeEnergy / fePerItem;
            int acceptedItems = (int) Math.min((long) offeredItems, byEnergy);
            if (acceptedItems <= 0) return Plan.denied("insufficient_forge_energy");
            long rawMatter = Math.multiplyExact(matterPerItem, acceptedItems);
            long chargeMilli = Math.multiplyExact(rawMatter, (long) policy.efficiencyBasisPoints() * CondensedCharge.SCALE) / 10_000L;
            long consumedFe = Math.multiplyExact(fePerItem, acceptedItems);
            if (chargeMilli <= 0) return Plan.denied("conversion_rounds_to_zero");
            return new Plan(true, acceptedItems, rawMatter, consumedFe, chargeMilli, "ok");
        } catch (ArithmeticException overflow) {
            return Plan.denied("cost_overflow");
        }
    }

    public record Plan(boolean allowed, int acceptedItems, long rawMatter, long consumedForgeEnergy, long producedChargeMilli, String reason) {
        public static Plan denied(String reason) { return new Plan(false, 0, 0, 0, 0, reason); }
        public CondensedCharge producedCharge() { return new CondensedCharge(producedChargeMilli); }
    }
}
