package dev.futurae.veilbound.domain;

import java.util.Objects;

/** Replace-all holder so datapack reloads can tune continuous Domain growth without restart. */
public final class ExpansionPolicyRegistry {
    private ExpansionRuntimePolicy policy = ExpansionRuntimePolicy.DEVELOPMENT_DEFAULT;
    public ExpansionRuntimePolicy policy() { return policy; }
    public void replace(ExpansionRuntimePolicy policy) { this.policy = Objects.requireNonNull(policy, "policy"); }
}
