package dev.futurae.veilbound.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** Deterministic one-block growth operations for Boundary Pylons. */
public final class ExpansionCycleService {
    private ExpansionCycleService() {}

    public static DirectionResult runDirection(
            DomainState state, AxisDirection direction, ExpansionPolicy policy, boolean ownerOnline) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(direction, "direction");
        Objects.requireNonNull(policy, "policy");
        BoundaryPylonState pylon = state.pylons().get(direction);
        if (pylon == null || !pylon.online() || !pylon.expansionEnabled()) {
            return new DirectionResult(direction, false, 0L, "direction_disabled");
        }
        ExpansionGovernor.ExpansionDecision decision =
                ExpansionGovernor.planOneBlock(state, direction, policy, ownerOnline);
        DomainPosition oldPylonPosition = pylon.blockPosition();
        boolean applied = decision.allowed() && ExpansionGovernor.apply(state, decision);
        if (applied) {
            if (oldPylonPosition != null) {
                DomainPosition newPylonPosition = BoundaryPylonBindingService.advance(oldPylonPosition, direction);
                BoundaryPylonBindingService.moveBoundPylon(state, direction, oldPylonPosition, newPylonPosition);
            }
            return new DirectionResult(direction, true, decision.dimensionalEnergyCost(), "ok");
        }
        return new DirectionResult(direction, false, 0L, decision.allowed() ? "apply_failed" : decision.reason());
    }

    /** Compatibility helper: all enabled directions receive one opportunity in enum order. */
    public static CycleResult runCycle(DomainState state, ExpansionPolicy policy, boolean ownerOnline) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(policy, "policy");
        List<DirectionResult> results = new ArrayList<>();
        long energySpent = 0L;
        int expandedDirections = 0;
        for (AxisDirection direction : AxisDirection.values()) {
            BoundaryPylonState pylon = state.pylons().get(direction);
            if (pylon == null || !pylon.online() || !pylon.expansionEnabled()) continue;
            DirectionResult result = runDirection(state, direction, policy, ownerOnline);
            results.add(result);
            if (result.expanded()) {
                energySpent = saturatedAdd(energySpent, result.dimensionalEnergySpent());
                expandedDirections++;
            }
        }
        return new CycleResult(List.copyOf(results), expandedDirections, energySpent, state.bounds());
    }

    private static long saturatedAdd(long a, long b) {
        if (a > Long.MAX_VALUE - b) return Long.MAX_VALUE;
        return a + b;
    }

    public record DirectionResult(AxisDirection direction, boolean expanded, long dimensionalEnergySpent, String reason) {}
    public record CycleResult(List<DirectionResult> directions, int expandedDirectionCount, long dimensionalEnergySpent, DomainBounds resultingBounds) {}
}
