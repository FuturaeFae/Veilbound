package dev.futurae.veilbound.domain;

/** Reloadable cadence + deterministic per-cycle expansion policy. */
public record ExpansionRuntimePolicy(int cycleTicks, ExpansionPolicy expansionPolicy) {
    public static final ExpansionRuntimePolicy DEVELOPMENT_DEFAULT =
            new ExpansionRuntimePolicy(200, new ExpansionPolicy(4L, ExpansionPolicy.ABSOLUTE_MAX_VERTICAL_SPAN, 0));

    public ExpansionRuntimePolicy {
        if (cycleTicks < 1) throw new IllegalArgumentException("cycleTicks must be >= 1");
        if (expansionPolicy == null) throw new IllegalArgumentException("expansionPolicy may not be null");
    }
}
