package dev.futurae.veilbound.domain;

/** Distinguishes the Spatial-Generator pocket from the post-ritual Core era. */
public enum DomainLifecycle {
    PRE_CORE,
    CORE_ACTIVE
}
