package dev.futurae.veilbound.block.entity;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.ontology.OntologicalCompilerPolicy;
import dev.futurae.veilbound.ontology.OntologicalCompilerService;
import dev.futurae.veilbound.ontology.PotentialReservoir;
import dev.futurae.veilbound.registry.VeilboundBlockEntities;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jspecify.annotations.Nullable;

/** Potential + Core DE -> Veil Inventory Matter. Core storage remains DE-only. */
public final class OntologicalCompilerBlockEntity extends BlockEntity {
    public static final long POTENTIAL_CAPACITY = 2_097_152L;
    private final PotentialReservoir potential = new PotentialReservoir(POTENTIAL_CAPACITY);
    private final OntologicalCompilerService compiler = new OntologicalCompilerService();
    private UUID ownerId;
    private String lastStatus = "idle";

    public OntologicalCompilerBlockEntity(BlockPos pos, BlockState state) { super(VeilboundBlockEntities.ONTOLOGICAL_COMPILER.get(), pos, state); }
    public void bindOwner(UUID ownerId) { if (this.ownerId == null) { this.ownerId = Objects.requireNonNull(ownerId); setChanged(); } }
    public @Nullable UUID ownerId() { return ownerId; }
    public long storedPotential() { return potential.stored(); }
    public long potentialCapacity() { return potential.capacity(); }
    public String lastStatus() { return lastStatus; }
    public long receivePotential(long amount) { long accepted = potential.insert(amount); if (accepted > 0) setChanged(); return accepted; }

    public static void tick(Level level, BlockPos pos, BlockState state, OntologicalCompilerBlockEntity be) {
        if (!(level instanceof ServerLevel) || level.getGameTime() % 20L != 0L || be.ownerId == null) return;
        DomainRecord record = Veilbound.runtime().domains().getRecord(be.ownerId).orElse(null);
        if (record == null || !record.identity().dimensionId().equals(level.dimension().identifier().toString())) return;
        if (!record.state().hasFeature(DomainFeature.VEIL_TRANSMUTATION)) {
            be.updateStatus("transmutation_not_unlocked");
            return;
        }
        OntologicalCompilerPolicy policy = Veilbound.runtime().ontologyPolicy().policy().compiler();
        var result = be.compiler.compile(record.state(), record.matterTransmutation(), be.potential, policy.maxPotentialPerCycle(), policy);
        be.updateStatus(result.reason());
        if (result.compiled()) be.setChanged();
    }

    private void updateStatus(String status) { if (!Objects.equals(lastStatus, status)) { lastStatus = status; setChanged(); } }

    @Override protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        if (ownerId != null) output.putString("owner", ownerId.toString());
        output.putString("potential", Long.toString(potential.stored()));
        output.putString("status", lastStatus);
    }
    @Override protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        ownerId = input.getString("owner").flatMap(raw -> { try { return java.util.Optional.of(UUID.fromString(raw)); } catch (IllegalArgumentException ignored) { return java.util.Optional.empty(); } }).orElse(null);
        long restored; try { restored = Long.parseLong(input.getString("potential").orElse("0")); } catch (NumberFormatException ignored) { restored = 0; }
        potential.setStored(Math.max(0L, Math.min(POTENTIAL_CAPACITY, restored)));
        lastStatus = input.getString("status").filter(raw -> !raw.isBlank()).orElse("idle");
    }
}
