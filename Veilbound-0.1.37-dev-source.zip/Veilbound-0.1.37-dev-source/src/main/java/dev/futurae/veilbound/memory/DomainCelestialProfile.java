package dev.futurae.veilbound.memory;

/** Pure clock-to-sky projection used by the client Orrery renderer. */
public final class DomainCelestialProfile {
    public static final long DAY_TICKS = 24_000L;
    public static final long NOON_TICK = 6_000L;

    private DomainCelestialProfile() {}

    /**
     * Minecraft 26.2 sky angles are degrees with zero directly overhead. The remembered Overworld
     * cycle therefore places the sun overhead at tick 6000 and opposite it at tick 18000.
     */
    public static Sample sample(long dayTime, boolean cycleActive) {
        long tick = cycleActive ? Math.floorMod(dayTime, DAY_TICKS) : NOON_TICK;
        float sun = Math.floorMod(tick - NOON_TICK, DAY_TICKS) * 360.0F / DAY_TICKS;
        float moon = wrapDegrees(sun + 180.0F);
        float stars = cycleActive ? starBrightness(tick) : 0.0F;
        return new Sample(sun, moon, sun, stars);
    }

    private static float starBrightness(long tick) {
        // Smooth, deterministic night envelope: no stars at noon, full stars at midnight.
        double phase = (tick - NOON_TICK) * (Math.PI * 2.0D / DAY_TICKS);
        double darkness = (1.0D - Math.cos(phase)) * 0.5D;
        return (float) Math.max(0.0D, Math.min(1.0D, (darkness - 0.25D) / 0.75D));
    }

    private static float wrapDegrees(float degrees) {
        float wrapped = degrees % 360.0F;
        return wrapped < 0.0F ? wrapped + 360.0F : wrapped;
    }

    public record Sample(float sunAngle, float moonAngle, float starAngle, float starBrightness) {}
}
