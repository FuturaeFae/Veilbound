package dev.futurae.veilbound.engineering;

import dev.futurae.veilbound.domain.CoreTier;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/** Data-driven advanced fabrication recipe. Knowledge/Law requirements are checks, not consumed. */
public record EngineeringRecipe(
        String id,
        String displayName,
        EngineeringStation station,
        List<EngineeringIngredient> inputs,
        String outputItemId,
        int outputCount,
        long matterCost,
        long dimensionalEnergyCost,
        long potentialCost,
        CoreTier minimumCoreTier,
        Set<String> requiredMemoryIds,
        Set<String> requiredLawIds,
        int processTicks) {
    public EngineeringRecipe {
        id = require(id, "id");
        displayName = require(displayName, "displayName");
        station = Objects.requireNonNull(station, "station");
        inputs = List.copyOf(inputs == null ? List.of() : inputs);
        outputItemId = require(outputItemId, "outputItemId");
        if (outputCount <= 0) throw new IllegalArgumentException("outputCount must be positive");
        if (matterCost < 0 || dimensionalEnergyCost < 0 || potentialCost < 0) throw new IllegalArgumentException("resource costs must be >= 0");
        minimumCoreTier = Objects.requireNonNull(minimumCoreTier, "minimumCoreTier");
        requiredMemoryIds = Set.copyOf(requiredMemoryIds == null ? Set.of() : requiredMemoryIds);
        requiredLawIds = Set.copyOf(requiredLawIds == null ? Set.of() : requiredLawIds);
        if (processTicks <= 0) throw new IllegalArgumentException("processTicks must be positive");
    }
    private static String require(String value, String field) {
        String v = Objects.requireNonNull(value, field).trim();
        if (v.isEmpty()) throw new IllegalArgumentException(field + " may not be blank");
        return v;
    }
}
