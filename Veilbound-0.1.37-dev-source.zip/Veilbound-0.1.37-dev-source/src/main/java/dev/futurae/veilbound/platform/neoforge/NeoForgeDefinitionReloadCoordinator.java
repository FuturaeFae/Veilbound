package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.Objects;
import net.neoforged.neoforge.event.AddServerReloadListenersEvent;

/** Registers data-driven Veilbound definition loaders on the server datapack reload graph. */
public final class NeoForgeDefinitionReloadCoordinator {
    private final VeilboundRuntime runtime;

    public NeoForgeDefinitionReloadCoordinator(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    public void onAddReloadListeners(AddServerReloadListenersEvent event) {
        Objects.requireNonNull(event, "event");
        event.addListener(NeoForgeLawReloadListener.LISTENER_ID, new NeoForgeLawReloadListener(runtime.laws()));
        event.addListener(NeoForgeMemoryReloadListener.LISTENER_ID, new NeoForgeMemoryReloadListener(runtime.memories()));
        event.addListener(NeoForgeMilestoneReloadListener.LISTENER_ID, new NeoForgeMilestoneReloadListener(runtime.milestones()));
        event.addListener(NeoForgeMemoryEffectPolicyReloadListener.LISTENER_ID, new NeoForgeMemoryEffectPolicyReloadListener(runtime.memoryEffectPolicy()));
        event.addListener(NeoForgeExpansionPolicyReloadListener.LISTENER_ID, new NeoForgeExpansionPolicyReloadListener(runtime.expansionPolicy()));
        event.addListener(NeoForgeStabilityPolicyReloadListener.LISTENER_ID, new NeoForgeStabilityPolicyReloadListener(runtime.stabilityPolicy()));
        event.addListener(NeoForgeTransductionPolicyReloadListener.LISTENER_ID, new NeoForgeTransductionPolicyReloadListener(runtime.transductionPolicy()));
        event.addListener(NeoForgeSpatialGeneratorPolicyReloadListener.LISTENER_ID, new NeoForgeSpatialGeneratorPolicyReloadListener(runtime.spatialGeneratorPolicy()));
        event.addListener(NeoForgeOntologyPolicyReloadListener.LISTENER_ID, new NeoForgeOntologyPolicyReloadListener(runtime.ontologyPolicy()));
        event.addListener(NeoForgeCoreUpgradeReloadListener.LISTENER_ID, new NeoForgeCoreUpgradeReloadListener(runtime.coreUpgrades()));
        event.addListener(NeoForgeEngineeringRecipeReloadListener.LISTENER_ID, new NeoForgeEngineeringRecipeReloadListener(runtime.engineeringRecipes()));
    }
}
