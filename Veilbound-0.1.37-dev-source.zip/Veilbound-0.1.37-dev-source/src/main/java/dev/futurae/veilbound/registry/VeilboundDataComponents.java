package dev.futurae.veilbound.registry;

import com.mojang.serialization.Codec;
import dev.futurae.veilbound.Veilbound;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Persistent per-stack state for stateful Veilbound tools. */
public final class VeilboundDataComponents {
    public static final DeferredRegister.DataComponents COMPONENTS = DeferredRegister.createDataComponents(Registries.DATA_COMPONENT_TYPE, Veilbound.MOD_ID);

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> SPATIAL_GENERATOR_FE =
            COMPONENTS.registerComponentType("spatial_generator_fe", builder -> builder.persistent(Codec.INT));
    /** Milli-Condensed-Charge; 1000 = one displayed Condensed Charge. */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Long>> SPATIAL_GENERATOR_CHARGE =
            COMPONENTS.registerComponentType("spatial_generator_charge", builder -> builder.persistent(Codec.LONG));
    /** Captured Memory id carried by one physical Mnemonic Vessel stack. */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<String>> MNEMONIC_VESSEL_MEMORY =
            COMPONENTS.registerComponentType("mnemonic_vessel_memory", builder -> builder.persistent(Codec.STRING));
    /** 0=normal, 1=vein, 2=plane, 3=phase for the Phasebreaker. */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> VEIL_TOOL_MODE =
            COMPONENTS.registerComponentType("veil_tool_mode", builder -> builder.persistent(Codec.INT));

    private VeilboundDataComponents() {}
    public static void register(IEventBus modBus) { COMPONENTS.register(modBus); }
}
