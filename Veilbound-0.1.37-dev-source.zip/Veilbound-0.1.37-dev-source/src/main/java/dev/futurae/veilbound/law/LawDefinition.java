package dev.futurae.veilbound.law;

import java.util.Set;

/** Datapack-defined Law. Effects are implemented by registered effect handlers keyed by effect ids. */
public record LawDefinition(
        String id,
        String displayName,
        int progressionWeight,
        Set<String> prerequisites,
        Set<String> incompatibleLawIds,
        Set<String> effectIds,
        String axiomItemId) {

    public LawDefinition {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("id may not be blank");
        if (displayName == null || displayName.isBlank()) throw new IllegalArgumentException("displayName may not be blank");
        if (progressionWeight < 0) throw new IllegalArgumentException("progressionWeight must be >= 0");
        prerequisites = Set.copyOf(prerequisites);
        incompatibleLawIds = Set.copyOf(incompatibleLawIds);
        effectIds = Set.copyOf(effectIds);
        axiomItemId = axiomItemId == null ? "" : axiomItemId.trim();
    }

    /** Compatibility constructor for loader-neutral callers that do not care about physical attunement. */
    public LawDefinition(
            String id,
            String displayName,
            int progressionWeight,
            Set<String> prerequisites,
            Set<String> incompatibleLawIds,
            Set<String> effectIds) {
        this(id, displayName, progressionWeight, prerequisites, incompatibleLawIds, effectIds, "");
    }

    /** Compatibility constructor retained from the first implementation slice. */
    public LawDefinition(String id, String displayName, int progressionWeight, Set<String> prerequisites) {
        this(id, displayName, progressionWeight, prerequisites, Set.of(), Set.of(), "");
    }

    public boolean hasAxiomItem() { return !axiomItemId.isBlank(); }
}
