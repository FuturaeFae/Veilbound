package dev.futurae.veilbound.memory;

import dev.futurae.veilbound.domain.DomainState;
import java.util.Objects;

/** Commits a captured Mnemonic Vessel Memory into the owner's permanent earned Archive. */
public final class MemoryArchiveService {
    /** Item-local path used by the physical Mnemonic Vessel. */
    public ArchiveResult archive(DomainState state, String capturedId, MemoryRegistry registry) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(registry, "registry");
        if (capturedId == null || capturedId.isBlank()) return ArchiveResult.denied("vessel_empty");
        MemoryDefinition definition = registry.get(capturedId).orElse(null);
        if (definition == null) return ArchiveResult.denied("memory_definition_missing");
        OrreryService.UnlockResult result = OrreryService.unlock(state, definition);
        if (!result.unlocked()) return ArchiveResult.denied(result.reason());
        return ArchiveResult.allowed(capturedId);
    }

    /** Legacy v7-v10 migration path for pending captures that predate item-local Vessel state. */
    public ArchiveResult archiveCaptured(DomainState state, MemoryProgressState progress, MemoryRegistry registry) {
        Objects.requireNonNull(progress, "progress");
        String capturedId = progress.capturedMemoryId().orElse(null);
        ArchiveResult result = archive(state, capturedId, registry);
        if (result.archived()) progress.clearCapturedMemory();
        return result;
    }

    public record ArchiveResult(boolean archived, String memoryId, String reason) {
        public static ArchiveResult denied(String reason) { return new ArchiveResult(false, null, reason); }
        public static ArchiveResult allowed(String memoryId) { return new ArchiveResult(true, memoryId, "ok"); }
    }
}
