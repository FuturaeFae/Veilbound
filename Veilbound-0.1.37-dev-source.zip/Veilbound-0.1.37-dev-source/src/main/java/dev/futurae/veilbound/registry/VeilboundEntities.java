package dev.futurae.veilbound.registry;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.entity.NullWraithEntity;
import dev.futurae.veilbound.entity.RiftStalkerEntity;
import dev.futurae.veilbound.entity.VoidCrawlerEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.monster.spider.Spider;
import net.minecraft.world.entity.monster.Vex;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Dedicated programmatic-only fauna emitted by open Domain Breaches. */
public final class VeilboundEntities {
    public static final DeferredRegister.Entities ENTITY_TYPES = DeferredRegister.createEntities(Veilbound.MOD_ID);

    /* Parent generic types deliberately match the inherited vanilla renderer/attribute contracts while
       each factory still constructs a distinct Veilbound subclass carrying its Breach linkage. */
    public static final DeferredHolder<EntityType<?>, EntityType<Spider>> VOID_CRAWLER =
            ENTITY_TYPES.<Spider>registerEntityType(
                    "void_crawler",
                    VoidCrawlerEntity::new,
                    MobCategory.MONSTER,
                    builder -> builder.sized(0.9F, 0.55F).clientTrackingRange(8).updateInterval(3).noSummon().notInPeaceful());

    public static final DeferredHolder<EntityType<?>, EntityType<EnderMan>> RIFT_STALKER =
            ENTITY_TYPES.<EnderMan>registerEntityType(
                    "rift_stalker",
                    RiftStalkerEntity::new,
                    MobCategory.MONSTER,
                    builder -> builder.sized(0.7F, 2.9F).clientTrackingRange(8).updateInterval(3).noSummon().notInPeaceful());

    public static final DeferredHolder<EntityType<?>, EntityType<Vex>> NULL_WRAITH =
            ENTITY_TYPES.<Vex>registerEntityType(
                    "null_wraith",
                    NullWraithEntity::new,
                    MobCategory.MONSTER,
                    builder -> builder.sized(0.55F, 0.9F).clientTrackingRange(10).updateInterval(2).noSummon().notInPeaceful());

    private VeilboundEntities() {}

    public static void register(IEventBus modBus) { ENTITY_TYPES.register(modBus); }

    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(VOID_CRAWLER.get(), Spider.createAttributes().build());
        event.put(RIFT_STALKER.get(), EnderMan.createAttributes().build());
        event.put(NULL_WRAITH.get(), Vex.createAttributes().build());
    }
}
