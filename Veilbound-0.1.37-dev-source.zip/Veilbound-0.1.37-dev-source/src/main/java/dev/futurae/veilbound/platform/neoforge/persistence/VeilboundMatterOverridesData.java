package dev.futurae.veilbound.platform.neoforge.persistence;

import com.mojang.serialization.Codec;
import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.matter.MatterCatalog;
import dev.futurae.veilbound.matter.MatterReloadService;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

/** Persistent server-owner Matter overrides used by the live held-item Matter commands. */
public final class VeilboundMatterOverridesData extends SavedData {
    private static final Codec<VeilboundMatterOverridesData> CODEC = Codec.STRING.xmap(
            VeilboundMatterOverridesData::fromPayload,
            VeilboundMatterOverridesData::toPayload);

    @SuppressWarnings("DataFlowIssue")
    public static final SavedDataType<VeilboundMatterOverridesData> TYPE = new SavedDataType<>(
            Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "matter_overrides"),
            VeilboundMatterOverridesData::new,
            CODEC,
            null);

    private final LinkedHashMap<String, Long> values = new LinkedHashMap<>();
    private MatterCatalog attachedCatalog;

    public VeilboundMatterOverridesData() {}

    public static VeilboundMatterOverridesData attach(
            MinecraftServer server, MatterCatalog catalog, MatterReloadService reloadService) {
        VeilboundMatterOverridesData data = server.getDataStorage().computeIfAbsent(TYPE);
        data.attachedCatalog = Objects.requireNonNull(catalog, "catalog");
        catalog.setAdminMutationListener(data::onCatalogChanged);
        catalog.replaceAdminSilently(data.values, "admin_saved:");
        if (!data.values.isEmpty()) reloadService.recomputeAffected(data.values.keySet());
        return data;
    }

    private void onCatalogChanged() {
        if (attachedCatalog == null) return;
        values.clear();
        values.putAll(attachedCatalog.adminAmountSnapshot());
        setDirty();
    }

    private String toPayload() {
        if (attachedCatalog != null) {
            values.clear();
            values.putAll(attachedCatalog.adminAmountSnapshot());
        }
        StringBuilder out = new StringBuilder();
        values.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(entry ->
                out.append(entry.getKey()).append('=').append(entry.getValue()).append('\n'));
        return out.toString();
    }

    private static VeilboundMatterOverridesData fromPayload(String payload) {
        VeilboundMatterOverridesData data = new VeilboundMatterOverridesData();
        if (payload == null || payload.isBlank()) return data;
        for (String raw : payload.split("\\R")) {
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            int split = line.lastIndexOf('=');
            if (split <= 0 || split == line.length() - 1) continue;
            try {
                long amount = Long.parseLong(line.substring(split + 1).trim());
                if (amount < 0) continue;
                String id = line.substring(0, split).trim();
                if (!id.isBlank()) data.values.put(id, amount);
            } catch (NumberFormatException ignored) {
                // Ignore one malformed historical/admin row rather than making the world unloadable.
            }
        }
        return data;
    }
}
