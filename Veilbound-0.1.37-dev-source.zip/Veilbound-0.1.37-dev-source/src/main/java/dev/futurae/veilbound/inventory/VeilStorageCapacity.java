package dev.futurae.veilbound.inventory;

/** Hard item-count and distinct-stack-type limits for one owner's Veil Inventory. */
public record VeilStorageCapacity(long maxItems, int maxTypes) {
    public static final VeilStorageCapacity LOCKED = new VeilStorageCapacity(0L, 0);
    public static final VeilStorageCapacity EFFECTIVELY_UNLIMITED =
            new VeilStorageCapacity(Long.MAX_VALUE, Integer.MAX_VALUE);

    public VeilStorageCapacity {
        if (maxItems < 0) throw new IllegalArgumentException("maxItems must be >= 0");
        if (maxTypes < 0) throw new IllegalArgumentException("maxTypes must be >= 0");
    }

    public boolean unlocked() { return maxItems > 0 && maxTypes > 0; }
}
