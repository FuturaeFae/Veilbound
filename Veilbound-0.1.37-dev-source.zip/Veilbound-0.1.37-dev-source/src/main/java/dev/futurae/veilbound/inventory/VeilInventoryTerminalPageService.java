package dev.futurae.veilbound.inventory;

import dev.futurae.veilbound.matter.MatterCatalog;
import dev.futurae.veilbound.matter.MatterPatternPageService;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.OptionalLong;
import java.util.Set;

/**
 * Combined post-Transmutation Inventory view.
 *
 * <p>Valued item identities appear as learned Matter patterns. Items with no Matter value remain
 * exact physical stacks in {@link VeilInventory}. This service deliberately never invents a value
 * for an unvalued item.</p>
 */
public final class VeilInventoryTerminalPageService {
    public static final int MAX_PAGE_SIZE = 90;

    public Page page(
            VeilInventory inventory,
            Set<String> learnedItemIds,
            MatterCatalog catalog,
            long storedMatter,
            Set<String> favorites,
            List<String> recents,
            Map<VeilStackKey, String> storedDisplayNames,
            Map<String, String> patternDisplayNames,
            String query,
            MatterPatternPageService.SortMode sortMode,
            MatterPatternPageService.FilterMode filterMode,
            int requestedPage,
            int requestedPageSize) {
        Objects.requireNonNull(inventory, "inventory");
        Objects.requireNonNull(learnedItemIds, "learnedItemIds");
        Objects.requireNonNull(catalog, "catalog");
        Objects.requireNonNull(favorites, "favorites");
        Objects.requireNonNull(recents, "recents");
        Objects.requireNonNull(storedDisplayNames, "storedDisplayNames");
        Objects.requireNonNull(patternDisplayNames, "patternDisplayNames");
        if (storedMatter < 0) throw new IllegalArgumentException("storedMatter must be >= 0");

        String normalizedQuery = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        MatterPatternPageService.SortMode mode = sortMode == null
                ? MatterPatternPageService.SortMode.NAME_ASC : sortMode;
        MatterPatternPageService.FilterMode filter = filterMode == null
                ? MatterPatternPageService.FilterMode.ALL : filterMode;
        int pageSize = Math.max(1, Math.min(MAX_PAGE_SIZE, requestedPageSize));

        Map<String, Integer> recentRank = new HashMap<>();
        for (int i = 0; i < recents.size(); i++) recentRank.putIfAbsent(recents.get(i), i);

        List<Entry> all = new ArrayList<>();
        if (filter == MatterPatternPageService.FilterMode.ALL) {
            for (var stored : inventory.contents().entrySet()) {
                VeilStackKey key = stored.getKey();
                // A valued item should have been migrated to Matter already. Fail closed in the
                // presentation layer if a reload made it valued before migration runs again.
                if (catalog.amount(key.itemId()).isPresent()) continue;
                String displayName = storedDisplayNames.getOrDefault(key, key.itemId());
                if (!matches(key.itemId(), displayName, normalizedQuery)) continue;
                all.add(Entry.stored(key, displayName, stored.getValue()));
            }
        }

        for (String id : learnedItemIds) {
            OptionalLong value = catalog.amount(id);
            if (value.isEmpty() || value.getAsLong() <= 0) continue; // dormant if a datapack removes valuation
            if (!matchesFilter(id, favorites, recentRank, filter)) continue;
            String displayName = patternDisplayNames.getOrDefault(id, id);
            if (!matches(id, displayName, normalizedQuery)) continue;
            long cost = value.getAsLong();
            all.add(Entry.matterPattern(
                    VeilStackKey.plain(id), displayName, cost, storedMatter / cost,
                    favorites.contains(id), recentRank.getOrDefault(id, Integer.MAX_VALUE)));
        }

        all.sort(comparator(mode, filter));
        int pageCount = Math.max(1, (all.size() + pageSize - 1) / pageSize);
        int page = Math.max(0, Math.min(requestedPage, pageCount - 1));
        int from = Math.min(all.size(), page * pageSize);
        int to = Math.min(all.size(), from + pageSize);
        return new Page(page, pageCount, pageSize, all.size(),
                List.copyOf(all.subList(from, to)));
    }

    private static boolean matchesFilter(
            String id,
            Set<String> favorites,
            Map<String, Integer> recentRank,
            MatterPatternPageService.FilterMode filter) {
        return switch (filter) {
            case ALL -> true;
            case FAVORITES -> favorites.contains(id);
            case RECENT -> recentRank.containsKey(id);
        };
    }

    private static boolean matches(String itemId, String displayName, String query) {
        if (query.isEmpty()) return true;
        String id = itemId.toLowerCase(Locale.ROOT);
        if (query.startsWith("@")) {
            int colon = id.indexOf(':');
            String namespace = colon < 0 ? "minecraft" : id.substring(0, colon);
            return namespace.contains(query.substring(1));
        }
        return id.contains(query) || displayName.toLowerCase(Locale.ROOT).contains(query);
    }

    private static Comparator<Entry> comparator(
            MatterPatternPageService.SortMode mode,
            MatterPatternPageService.FilterMode filter) {
        if (filter == MatterPatternPageService.FilterMode.RECENT) {
            return Comparator.comparingInt(Entry::recentRank)
                    .thenComparing(Entry::displayName, String.CASE_INSENSITIVE_ORDER)
                    .thenComparing(e -> e.key().itemId())
                    .thenComparing(e -> e.key().componentData());
        }
        Comparator<Entry> name = Comparator.comparing(Entry::displayName, String.CASE_INSENSITIVE_ORDER)
                .thenComparing(e -> e.key().itemId())
                .thenComparing(e -> e.key().componentData());
        Comparator<Entry> costAscending = Comparator.comparing((Entry e) -> e.pattern()).reversed()
                .thenComparingLong(e -> e.pattern() ? e.matterCost() : Long.MAX_VALUE)
                .thenComparing(name);
        Comparator<Entry> costDescending = Comparator.comparing((Entry e) -> e.pattern()).reversed()
                .thenComparing(Comparator.comparingLong(Entry::matterCost).reversed())
                .thenComparing(name);
        return switch (mode) {
            case NAME_ASC -> name;
            case NAME_DESC -> name.reversed();
            case COST_ASC -> costAscending;
            case COST_DESC -> costDescending;
        };
    }

    public record Entry(
            VeilStackKey key,
            String displayName,
            long storedCount,
            long matterCost,
            long affordableCount,
            boolean pattern,
            boolean favorite,
            int recentRank) {
        public Entry {
            Objects.requireNonNull(key, "key");
            displayName = displayName == null || displayName.isBlank() ? key.itemId() : displayName;
            if (storedCount < 0 || matterCost < 0 || affordableCount < 0) {
                throw new IllegalArgumentException("terminal entry counts/costs must be non-negative");
            }
            if (pattern && matterCost <= 0) throw new IllegalArgumentException("pattern must have a Matter value");
            if (!pattern && storedCount <= 0) throw new IllegalArgumentException("stored entry must have physical items");
            if (!pattern && (favorite || recentRank != Integer.MAX_VALUE)) {
                throw new IllegalArgumentException("physical unvalued stacks are not Matter pattern preferences");
            }
        }

        static Entry stored(VeilStackKey key, String displayName, long count) {
            return new Entry(key, displayName, count, 0L, 0L, false, false, Integer.MAX_VALUE);
        }

        static Entry matterPattern(
                VeilStackKey key,
                String displayName,
                long matterCost,
                long affordableCount,
                boolean favorite,
                int recentRank) {
            return new Entry(key, displayName, 0L, matterCost, affordableCount, true, favorite, recentRank);
        }
    }

    public record Page(
            int page,
            int pageCount,
            int pageSize,
            int matchingEntries,
            List<Entry> entries) {
        public Page { entries = List.copyOf(entries); }
    }
}
