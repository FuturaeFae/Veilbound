package dev.futurae.veilbound.platform.neoforge;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.breach.BreachRuntimePolicy;
import dev.futurae.veilbound.breach.BreachHazardPolicy;
import dev.futurae.veilbound.breach.VoidCreatureType;
import dev.futurae.veilbound.breach.BreachSeverity;
import dev.futurae.veilbound.breach.BreachSpawnPolicy;
import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.stability.StabilityBand;
import dev.futurae.veilbound.stability.StabilityPolicyRegistry;
import dev.futurae.veilbound.stability.StabilityRuntimePolicy;
import java.io.Reader;
import java.util.EnumMap;
import java.util.Locale;
import java.util.Objects;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

/** Loads data/veilbound/veilbound/balance/domain_stability.json. */
public final class NeoForgeStabilityPolicyReloadListener extends SimplePreparableReloadListener<StabilityRuntimePolicy> {
    public static final Identifier LISTENER_ID = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "domain_stability_policy");
    private static final Identifier RESOURCE_ID = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "veilbound/balance/domain_stability.json");
    private final Gson gson = new Gson();
    private final StabilityPolicyRegistry registry;

    public NeoForgeStabilityPolicyReloadListener(StabilityPolicyRegistry registry) {
        this.registry = Objects.requireNonNull(registry, "registry");
    }

    @Override
    protected StabilityRuntimePolicy prepare(ResourceManager manager, ProfilerFiller profiler) {
        StabilityRuntimePolicy fallback = StabilityRuntimePolicy.DEVELOPMENT_DEFAULT;
        return manager.getResource(RESOURCE_ID).map(resource -> {
            try (Reader reader = resource.openAsReader()) {
                JsonElement parsed = gson.fromJson(reader, JsonElement.class);
                if (parsed == null || !parsed.isJsonObject()) throw new IllegalArgumentException("root must be an object");
                JsonObject root = parsed.getAsJsonObject();

                EnumMap<CoreTier, Double> capacities = new EnumMap<>(CoreTier.class);
                JsonObject capacityObject = object(root, "capacity_by_core_tier");
                for (CoreTier tier : CoreTier.values()) {
                    String key = tier.name().toLowerCase(Locale.ROOT);
                    capacities.put(tier, decimal(capacityObject, key, fallback.capacity(tier)));
                }

                JsonObject loads = object(root, "loads");
                double pylonLoad = decimal(loads, "active_pylon", fallback.activePylonLoad());
                double thresholdLoad = decimal(loads, "permanent_threshold", fallback.thresholdLoad());
                double anchorLoad = decimal(loads, "continuity_anchor", fallback.continuityAnchorLoad());

                JsonObject bands = object(root, "load_ratio_bands");
                double strained = decimal(bands, "strained", fallback.strainedLoadRatio());
                double critical = decimal(bands, "critical", fallback.criticalLoadRatio());
                double rupturing = decimal(bands, "rupturing", fallback.rupturingLoadRatio());

                int evaluationTicks = integer(root, "evaluation_ticks", fallback.evaluationTicks());
                int maxAnchors = integer(root, "max_continuity_anchors", fallback.maxContinuityAnchors());

                BreachRuntimePolicy fallbackBreach = fallback.breachPolicy();
                JsonObject breach = object(root, "breach");
                EnumMap<StabilityBand, Double> deltas = new EnumMap<>(StabilityBand.class);
                JsonObject deltaObject = object(breach, "fracture_delta_per_evaluation");
                for (StabilityBand band : StabilityBand.values()) {
                    String key = band.name().toLowerCase(Locale.ROOT);
                    deltas.put(band, decimal(deltaObject, key, fallbackBreach.fractureDelta(band)));
                }
                double fractureThreshold = decimal(breach, "fracture_threshold", fallbackBreach.fractureThreshold());
                double maximumFractureMeter = decimal(breach, "maximum_fracture_meter", fallbackBreach.maximumFractureMeter());
                int maxOpenBreaches = integer(breach, "max_open_breaches", fallbackBreach.maxOpenBreaches());
                double stitcherRange = decimal(breach, "stitcher_range", fallbackBreach.stitcherRange());

                EnumMap<BreachSeverity, Long> stitcherCosts = new EnumMap<>(BreachSeverity.class);
                JsonObject costs = object(breach, "stitcher_de_cost");
                for (BreachSeverity severity : BreachSeverity.values()) {
                    String key = severity.name().toLowerCase(Locale.ROOT);
                    stitcherCosts.put(severity, longValue(costs, key, fallbackBreach.stitcherDimensionalEnergyCost(severity)));
                }

                JsonObject spawn = object(breach, "intruder_spawns");
                BreachSpawnPolicy fallbackSpawn = fallbackBreach.spawnPolicy();
                int localCap = integer(spawn, "local_creature_cap", fallbackSpawn.localCreatureCap());
                double localRadius = decimal(spawn, "local_creature_radius", fallbackSpawn.localCreatureRadius());
                double emergenceRadius = decimal(spawn, "emergence_radius", fallbackSpawn.emergenceRadius());
                EnumMap<BreachSeverity, BreachSpawnPolicy.SpawnBand> spawnBands = new EnumMap<>(BreachSeverity.class);
                EnumMap<BreachSeverity, BreachSpawnPolicy.WeightedCreaturePool> creaturePools = new EnumMap<>(BreachSeverity.class);
                for (BreachSeverity severity : BreachSeverity.values()) {
                    String key = severity.name().toLowerCase(Locale.ROOT);
                    JsonObject configured = spawn.has(key) && spawn.get(key).isJsonObject() ? spawn.getAsJsonObject(key) : new JsonObject();
                    BreachSpawnPolicy.SpawnBand fb = fallbackSpawn.band(severity);
                    spawnBands.put(severity, new BreachSpawnPolicy.SpawnBand(
                            integer(configured, "min_ticks", fb.minTicks()),
                            integer(configured, "max_ticks", fb.maxTicks())));

                    JsonObject weights = object(configured, "weights");
                    EnumMap<VoidCreatureType, Integer> configuredWeights = new EnumMap<>(VoidCreatureType.class);
                    for (VoidCreatureType type : VoidCreatureType.values()) {
                        String creatureKey = type.name().toLowerCase(Locale.ROOT);
                        configuredWeights.put(type, integer(weights, creatureKey, fallbackSpawn.creaturePool(severity).weight(type)));
                    }
                    creaturePools.put(severity, new BreachSpawnPolicy.WeightedCreaturePool(configuredWeights));
                }
                BreachSpawnPolicy spawnPolicy = new BreachSpawnPolicy(
                        spawnBands, localCap, localRadius, emergenceRadius, creaturePools);

                BreachHazardPolicy fallbackHazards = fallbackBreach.hazardPolicy();
                JsonObject hazards = object(breach, "proximity_hazard");
                int particleInterval = integer(hazards, "particle_interval_ticks", fallbackHazards.particleIntervalTicks());
                EnumMap<BreachSeverity, BreachHazardPolicy.HazardBand> hazardBands = new EnumMap<>(BreachSeverity.class);
                for (BreachSeverity severity : BreachSeverity.values()) {
                    String key = severity.name().toLowerCase(Locale.ROOT);
                    JsonObject configured = hazards.has(key) && hazards.get(key).isJsonObject() ? hazards.getAsJsonObject(key) : new JsonObject();
                    BreachHazardPolicy.HazardBand fb = fallbackHazards.band(severity);
                    hazardBands.put(severity, new BreachHazardPolicy.HazardBand(
                            decimal(configured, "radius", fb.radius()),
                            decimal(configured, "damage", fb.damage()),
                            integer(configured, "damage_interval_ticks", fb.damageIntervalTicks()),
                            integer(configured, "particle_count", fb.particleCount())));
                }
                BreachHazardPolicy hazardPolicy = new BreachHazardPolicy(hazardBands, particleInterval);

                BreachRuntimePolicy breachPolicy = new BreachRuntimePolicy(
                        deltas,
                        fractureThreshold,
                        maximumFractureMeter,
                        maxOpenBreaches,
                        stitcherRange,
                        stitcherCosts,
                        spawnPolicy,
                        hazardPolicy);
                return new StabilityRuntimePolicy(
                        capacities,
                        pylonLoad,
                        thresholdLoad,
                        anchorLoad,
                        strained,
                        critical,
                        rupturing,
                        evaluationTicks,
                        maxAnchors,
                        breachPolicy);
            } catch (Exception ex) {
                Veilbound.LOGGER.warn("Invalid {}: {}; using development default", RESOURCE_ID, ex.getMessage());
                return fallback;
            }
        }).orElse(fallback);
    }

    @Override
    protected void apply(StabilityRuntimePolicy policy, ResourceManager manager, ProfilerFiller profiler) {
        registry.replace(policy);
        Veilbound.LOGGER.info(
                "Loaded Domain stability policy: Pylon +{}, Threshold +{}, Continuity Anchor +{}, {} anchor cap, fracture threshold {}",
                policy.activePylonLoad(), policy.thresholdLoad(), policy.continuityAnchorLoad(),
                policy.maxContinuityAnchors(), policy.breachPolicy().fractureThreshold());
    }

    private static JsonObject object(JsonObject root, String key) {
        return root.has(key) && root.get(key).isJsonObject() ? root.getAsJsonObject(key) : new JsonObject();
    }

    private static int integer(JsonObject o, String key, int fallback) {
        return o.has(key) ? o.get(key).getAsInt() : fallback;
    }

    private static long longValue(JsonObject o, String key, long fallback) {
        return o.has(key) ? o.get(key).getAsLong() : fallback;
    }

    private static double decimal(JsonObject o, String key, double fallback) {
        return o.has(key) ? o.get(key).getAsDouble() : fallback;
    }
}
