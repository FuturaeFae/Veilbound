package dev.futurae.veilbound.platform.neoforge.inventory;

import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.inventory.VeilInventory;
import dev.futurae.veilbound.inventory.VeilStackKey;
import dev.futurae.veilbound.matter.MatterPatternPageService;
import dev.futurae.veilbound.network.VeilCraftablesRequestPayload;
import dev.futurae.veilbound.network.VeilCraftablesSnapshotPayload;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.context.ContextMap;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.display.RecipeDisplay;
import net.minecraft.world.item.crafting.display.ShapedCraftingRecipeDisplay;
import net.minecraft.world.item.crafting.display.ShapelessCraftingRecipeDisplay;
import net.minecraft.world.item.crafting.display.SlotDisplay;
import net.minecraft.world.item.crafting.display.SlotDisplayContext;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.transfer.item.ItemResource;

/** Builds the Magic-Storage-style Craftables catalog entirely on the server. */
public final class NeoForgeVeilCraftablesController {
    private final VeilboundRuntime runtime;

    public NeoForgeVeilCraftablesController(VeilboundRuntime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
    }

    public void handle(ServerPlayer player, VeilCraftablesRequestPayload request) {
        var access = runtime.veilInventoryAccess().ownerAccess(player.getUUID(), player.getUUID());
        if (!access.allowed()) {
            PacketDistributor.sendToPlayer(player,
                    VeilCraftablesSnapshotPayload.denied(access.reason(), request.allCrafts()));
            return;
        }
        var record = runtime.domains().getRecord(player.getUUID()).orElse(null);
        if (record == null) {
            PacketDistributor.sendToPlayer(player,
                    VeilCraftablesSnapshotPayload.denied("domain_not_found", request.allCrafts()));
            return;
        }
        if (!record.state().hasFeature(DomainFeature.VEIL_CRAFTING)) {
            PacketDistributor.sendToPlayer(player,
                    VeilCraftablesSnapshotPayload.denied("veil_crafting_locked", request.allCrafts()));
            return;
        }
        if (!record.state().hasFeature(DomainFeature.VEIL_TRANSMUTATION)) {
            PacketDistributor.sendToPlayer(player,
                    VeilCraftablesSnapshotPayload.denied("veil_transmutation_locked", request.allCrafts()));
            return;
        }

        long matter = record.matterTransmutation().storedMatter();
        Set<String> learned = record.matterTransmutation().learnedItemIds();
        ContextMap displayContext = SlotDisplayContext.fromLevel(player.level());
        List<CatalogEntry> all = new ArrayList<>();
        Set<String> dedupe = new HashSet<>();

        for (RecipeHolder<?> holder : player.level().recipeAccess().getRecipes()) {
            for (RecipeDisplay display : holder.value().display()) {
                CatalogEntry entry = switch (display) {
                    case ShapedCraftingRecipeDisplay shaped -> fromShaped(shaped, displayContext, learned, matter, access.inventory(), player);
                    case ShapelessCraftingRecipeDisplay shapeless -> fromShapeless(shapeless, displayContext, learned, matter, access.inventory(), player);
                    default -> null;
                };
                if (entry == null || (!request.allCrafts() && !entry.craftable())) continue;
                if (!matches(entry, request.query())) continue;
                String signature = signature(entry);
                if (dedupe.add(signature)) all.add(entry);
            }
        }

        all.sort(comparator(request.sortMode()));
        int matching = all.size();
        int pageCount = Math.max(1, (all.size() + VeilCraftablesSnapshotPayload.PAGE_SIZE - 1)
                / VeilCraftablesSnapshotPayload.PAGE_SIZE);
        int page = Math.max(0, Math.min(request.page(), pageCount - 1));
        int from = Math.min(all.size(), page * VeilCraftablesSnapshotPayload.PAGE_SIZE);
        int to = Math.min(all.size(), from + VeilCraftablesSnapshotPayload.PAGE_SIZE);

        List<VeilCraftablesSnapshotPayload.Entry> entries = all.subList(from, to).stream()
                .map(entry -> new VeilCraftablesSnapshotPayload.Entry(
                        entry.result(), entry.resultCount(), entry.matterCost(), entry.craftable(),
                        entry.patternsKnown(), entry.affordableCrafts(), entry.grid(), entry.learnedGrid()))
                .toList();
        PacketDistributor.sendToPlayer(player, new VeilCraftablesSnapshotPayload(
                true, "ok", request.allCrafts(), page, pageCount, matter, matching, entries));
    }

    private CatalogEntry fromShaped(
            ShapedCraftingRecipeDisplay display,
            ContextMap context,
            Set<String> learned,
            long storedMatter,
            VeilInventory inventory,
            ServerPlayer player) {
        if (display.width() < 1 || display.height() < 1 || display.width() > 3 || display.height() > 3) return null;
        if (display.ingredients().size() != display.width() * display.height()) return null;
        List<ItemResource> grid = emptyGrid();
        List<Boolean> availableGrid = emptyLearnedGrid();
        Map<VeilStackKey, Integer> storedNeeds = new LinkedHashMap<>();
        long cost = 0L;
        boolean allAvailable = true;
        for (int y = 0; y < display.height(); y++) {
            for (int x = 0; x < display.width(); x++) {
                SlotDisplay slot = display.ingredients().get(y * display.width() + x);
                if (slot instanceof SlotDisplay.Empty) continue;
                Candidate candidate = choose(slot, context, learned, storedMatter, inventory, player);
                if (candidate == null) return null;
                int target = y * 3 + x;
                grid.set(target, candidate.resource());
                boolean available = candidate.available();
                if (candidate.matterBased()) {
                    cost = saturatedAdd(cost, candidate.matterCost());
                } else {
                    int needed = storedNeeds.merge(candidate.key(), 1, Integer::sum);
                    available = inventory.count(candidate.key()) >= needed;
                }
                availableGrid.set(target, available);
                allAvailable &= available;
            }
        }
        return finish(display.result(), context, grid, availableGrid, cost, allAvailable, storedMatter, inventory, storedNeeds);
    }

    private CatalogEntry fromShapeless(
            ShapelessCraftingRecipeDisplay display,
            ContextMap context,
            Set<String> learned,
            long storedMatter,
            VeilInventory inventory,
            ServerPlayer player) {
        if (display.ingredients().isEmpty() || display.ingredients().size() > 9) return null;
        List<ItemResource> grid = emptyGrid();
        List<Boolean> availableGrid = emptyLearnedGrid();
        Map<VeilStackKey, Integer> storedNeeds = new LinkedHashMap<>();
        long cost = 0L;
        boolean allAvailable = true;
        int slotIndex = 0;
        for (SlotDisplay slot : display.ingredients()) {
            if (slot instanceof SlotDisplay.Empty) continue;
            if (slotIndex >= 9) return null;
            Candidate candidate = choose(slot, context, learned, storedMatter, inventory, player);
            if (candidate == null) return null;
            grid.set(slotIndex, candidate.resource());
            boolean available = candidate.available();
            if (candidate.matterBased()) {
                cost = saturatedAdd(cost, candidate.matterCost());
            } else {
                int needed = storedNeeds.merge(candidate.key(), 1, Integer::sum);
                available = inventory.count(candidate.key()) >= needed;
            }
            availableGrid.set(slotIndex, available);
            allAvailable &= available;
            slotIndex++;
        }
        return finish(display.result(), context, grid, availableGrid, cost, allAvailable, storedMatter, inventory, storedNeeds);
    }

    private CatalogEntry finish(
            SlotDisplay resultDisplay,
            ContextMap context,
            List<ItemResource> grid,
            List<Boolean> availableGrid,
            long matterCost,
            boolean allAvailable,
            long storedMatter,
            VeilInventory inventory,
            Map<VeilStackKey, Integer> storedNeeds) {
        List<ItemStack> results = resultDisplay.resolveForStacks(context).stream()
                .filter(stack -> stack != null && !stack.isEmpty() && stack.getCount() > 0)
                .toList();
        if (results.size() != 1) return null;
        ItemStack resultStack = results.getFirst();
        ItemResource result = ItemResource.of(resultStack);
        if (result.isEmpty()) return null;
        String resultId = BuiltInRegistries.ITEM.getKey(resultStack.getItem()).toString();
        String displayName = resultStack.getHoverName().getString();

        long affordableCrafts = matterCost > 0 ? storedMatter / matterCost : Long.MAX_VALUE;
        for (var need : storedNeeds.entrySet()) {
            affordableCrafts = Math.min(affordableCrafts, inventory.count(need.getKey()) / need.getValue());
        }
        if (affordableCrafts == Long.MAX_VALUE) affordableCrafts = 0L;
        boolean craftable = allAvailable && affordableCrafts > 0;
        return new CatalogEntry(result, resultStack.getCount(), resultId, displayName, matterCost,
                craftable, allAvailable, affordableCrafts, List.copyOf(grid), List.copyOf(availableGrid));
    }

    private Candidate choose(
            SlotDisplay rawDisplay,
            ContextMap context,
            Set<String> learned,
            long storedMatter,
            VeilInventory inventory,
            ServerPlayer player) {
        SlotDisplay input = rawDisplay instanceof SlotDisplay.WithRemainder remainder ? remainder.input() : rawDisplay;
        Map<String, Candidate> unique = new LinkedHashMap<>();
        for (ItemStack stack : input.resolveForStacks(context)) {
            if (stack == null || stack.isEmpty()) continue;
            ItemResource resource = ItemResource.of(stack.copyWithCount(1));
            VeilStackKey key;
            try {
                key = NeoForgeVeilStackBridge.toKey(resource, player.registryAccess());
            } catch (RuntimeException malformed) {
                continue;
            }
            String itemId = BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
            var value = runtime.matter().amount(itemId);
            Candidate candidate;
            if (value.isPresent() && value.getAsLong() > 0 && key.componentData().isEmpty()) {
                long cost = value.getAsLong();
                boolean available = learned.contains(itemId);
                long hint = available ? storedMatter / cost : 0L;
                candidate = new Candidate(resource, key, itemId, cost, true, available, hint);
            } else if (value.isEmpty()) {
                long count = inventory.count(key);
                candidate = new Candidate(resource, key, itemId, 0L, false, count > 0, count);
            } else {
                // Valued component-bearing states cannot be synthesized from a canonical pattern
                // and should not survive terminal reconciliation as physical stacks.
                candidate = new Candidate(resource, key, itemId, value.getAsLong(), true, false, 0L);
            }
            String dedupeKey = itemId + "\u0000" + key.componentData();
            unique.merge(dedupeKey, candidate, (a, b) -> better(a, b) ? a : b);
        }
        return unique.values().stream()
                .min(Comparator.comparing(Candidate::available).reversed()
                        .thenComparing(Comparator.comparingLong(Candidate::availabilityHint).reversed())
                        .thenComparingLong(Candidate::matterCost)
                        .thenComparing(Candidate::itemId))
                .orElse(null);
    }

    private static boolean matches(CatalogEntry entry, String query) {
        if (query == null || query.isBlank()) return true;
        String q = query.trim().toLowerCase(Locale.ROOT);
        if (q.startsWith("@")) {
            int colon = entry.resultId().indexOf(':');
            String namespace = colon < 0 ? "minecraft" : entry.resultId().substring(0, colon);
            return namespace.contains(q.substring(1));
        }
        return entry.resultId().toLowerCase(Locale.ROOT).contains(q)
                || entry.displayName().toLowerCase(Locale.ROOT).contains(q);
    }

    private static Comparator<CatalogEntry> comparator(MatterPatternPageService.SortMode mode) {
        Comparator<CatalogEntry> name = Comparator.comparing(CatalogEntry::displayName, String.CASE_INSENSITIVE_ORDER)
                .thenComparing(CatalogEntry::resultId);
        Comparator<CatalogEntry> cost = Comparator.comparingLong(CatalogEntry::matterCost)
                .thenComparing(CatalogEntry::displayName, String.CASE_INSENSITIVE_ORDER)
                .thenComparing(CatalogEntry::resultId);
        return switch (mode == null ? MatterPatternPageService.SortMode.NAME_ASC : mode) {
            case NAME_ASC -> name;
            case NAME_DESC -> name.reversed();
            case COST_ASC -> cost;
            case COST_DESC -> cost.reversed();
        };
    }

    private static boolean better(Candidate a, Candidate b) {
        if (a.available() != b.available()) return a.available();
        if (a.availabilityHint() != b.availabilityHint()) return a.availabilityHint() > b.availabilityHint();
        if (a.matterCost() != b.matterCost()) return a.matterCost() < b.matterCost();
        return a.itemId().compareTo(b.itemId()) <= 0;
    }

    private static List<ItemResource> emptyGrid() {
        ArrayList<ItemResource> grid = new ArrayList<>(9);
        for (int i = 0; i < 9; i++) grid.add(ItemResource.EMPTY);
        return grid;
    }

    private static List<Boolean> emptyLearnedGrid() {
        ArrayList<Boolean> grid = new ArrayList<>(9);
        for (int i = 0; i < 9; i++) grid.add(true);
        return grid;
    }

    private static long saturatedAdd(long a, long b) {
        if (a >= Long.MAX_VALUE - b) return Long.MAX_VALUE;
        return a + b;
    }

    private static String signature(CatalogEntry entry) {
        StringBuilder out = new StringBuilder(entry.resultId()).append('|').append(entry.resultCount());
        for (ItemResource resource : entry.grid()) out.append('|').append(resource);
        return out.toString();
    }

    private record Candidate(
            ItemResource resource, VeilStackKey key, String itemId, long matterCost,
            boolean matterBased, boolean available, long availabilityHint) {}
    private record CatalogEntry(
            ItemResource result,
            int resultCount,
            String resultId,
            String displayName,
            long matterCost,
            boolean craftable,
            boolean patternsKnown,
            long affordableCrafts,
            List<ItemResource> grid,
            List<Boolean> learnedGrid) {}
}
