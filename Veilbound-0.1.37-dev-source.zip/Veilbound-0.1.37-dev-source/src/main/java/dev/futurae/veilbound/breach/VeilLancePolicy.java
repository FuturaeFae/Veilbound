package dev.futurae.veilbound.breach;

import dev.futurae.veilbound.domain.CoreTier;

/** Balance/eligibility policy for deliberate Breach generation. */
public record VeilLancePolicy(
        CoreTier minimumTier,
        int maxBeamRange,
        int forgeEnergyCapacity,
        int maxForgeEnergyInput,
        int maxOpenBreaches) {
    public static final VeilLancePolicy DEVELOPMENT_DEFAULT = new VeilLancePolicy(
            CoreTier.RESONANT, 512, 16_000_000, 250_000, 3);

    public VeilLancePolicy {
        if (minimumTier == null) throw new NullPointerException("minimumTier");
        if (maxBeamRange < 1) throw new IllegalArgumentException("maxBeamRange must be >= 1");
        if (forgeEnergyCapacity < 1 || maxForgeEnergyInput < 1) throw new IllegalArgumentException("FE limits must be positive");
        if (maxForgeEnergyInput > forgeEnergyCapacity) throw new IllegalArgumentException("max input exceeds capacity");
        if (maxOpenBreaches < 1) throw new IllegalArgumentException("maxOpenBreaches must be >= 1");
    }
}
