package dev.futurae.veilbound.platform.neoforge;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.equipment.BoundarySpadeMode;
import dev.futurae.veilbound.equipment.PhasebreakerMode;
import dev.futurae.veilbound.registry.VeilboundDataComponents;
import dev.futurae.veilbound.registry.VeilboundItems;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import dev.futurae.veilbound.network.DomainControlsSnapshotPayload;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.block.BreakBlockEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.common.NeoForgeMod;

/** Initial active abilities for Veilforged tools/armor. Every advanced effect is paid from Core DE. */
public final class NeoForgeVeilforgedEquipmentCoordinator {
    private static final Identifier SOVEREIGN_FLIGHT_MODIFIER = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "sovereign_flight");
    private static final long SOVEREIGN_FLIGHT_DE_PER_SECOND = 2_000L;
    private final VeilboundRuntime runtime;
    private final NeoForgeDomainControlsController domainControls;
    private final Set<UUID> toolOperationGuard = new HashSet<>();
    public NeoForgeVeilforgedEquipmentCoordinator(VeilboundRuntime runtime){
        this.runtime=Objects.requireNonNull(runtime);
        this.domainControls=new NeoForgeDomainControlsController(runtime);
    }

    public void onRightClickItem(PlayerInteractEvent.RightClickItem event){
        if(!(event.getEntity() instanceof ServerPlayer player)||event.getHand()!=InteractionHand.MAIN_HAND)return;
        ItemStack stack=event.getItemStack();

        // Sovereign Regalia + Resonance Multitool provides remote Core administration from anywhere
        // inside the owner's own Domain. This is intentionally management-only and costs no DE.
        if(stack.is(VeilboundItems.RESONANCE_MULTITOOL.get()) && !player.isShiftKeyDown()){
            DomainRecord record=runtime.domains().getRecord(player.getUUID()).orElse(null);
            if(record!=null && record.state().coreActive() && fullSovereign(player)
                    && record.identity().dimensionId().equals(player.level().dimension().identifier().toString())){
                domainControls.open(player, DomainControlsSnapshotPayload.View.CORE);
                player.displayClientMessage(Component.translatable("message.veilbound.sovereign.remote_core"),true);
                event.setCanceled(true);event.setCancellationResult(InteractionResult.SUCCESS);
            }
            return;
        }

        if(!player.isShiftKeyDown())return;
        if(stack.is(VeilboundItems.PHASEBREAKER.get())){
            PhasebreakerMode current=PhasebreakerMode.fromId(stack.getOrDefault(VeilboundDataComponents.VEIL_TOOL_MODE.get(),0));
            PhasebreakerMode next=current.next(); stack.set(VeilboundDataComponents.VEIL_TOOL_MODE.get(),next.id());
            player.displayClientMessage(Component.translatable("message.veilbound.phasebreaker.mode",next.name(),next.dePerExtraBlock()),true);
            event.setCanceled(true);event.setCancellationResult(InteractionResult.SUCCESS);
            return;
        }
        if(stack.is(VeilboundItems.BOUNDARY_SPADE.get())){
            BoundarySpadeMode current=BoundarySpadeMode.fromId(stack.getOrDefault(VeilboundDataComponents.VEIL_TOOL_MODE.get(),0));
            BoundarySpadeMode next=current.next(); stack.set(VeilboundDataComponents.VEIL_TOOL_MODE.get(),next.id());
            player.displayClientMessage(Component.translatable("message.veilbound.boundary_spade.mode",next.name(),next.dePerExtraBlock()),true);
            event.setCanceled(true);event.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock event){
        if(!(event.getEntity() instanceof ServerPlayer player)||event.getHand()!=InteractionHand.MAIN_HAND)return;
        if(!event.getItemStack().is(VeilboundItems.RESONANCE_MULTITOOL.get()))return;
        BlockPos pos=event.getPos();String blockId=BuiltInRegistries.BLOCK.getKey(event.getLevel().getBlockState(pos).getBlock()).toString();
        DomainRecord record=runtime.domains().getRecord(player.getUUID()).orElse(null);
        if(record!=null&&record.identity().dimensionId().equals(player.level().dimension().identifier().toString())){
            var b=record.state().bounds();int edge=Math.min(Math.min(Math.min(pos.getX()-b.minX(),b.maxX()-pos.getX()),Math.min(pos.getY()-b.minY(),b.maxY()-pos.getY())),Math.min(pos.getZ()-b.minZ(),b.maxZ()-pos.getZ()));
            player.displayClientMessage(Component.translatable("message.veilbound.multitool.inspect_domain",blockId,pos.getX(),pos.getY(),pos.getZ(),Math.max(0,edge),record.state().dimensionalEnergy()),false);
        }else player.displayClientMessage(Component.translatable("message.veilbound.multitool.inspect",blockId,pos.getX(),pos.getY(),pos.getZ()),false);
        event.setCanceled(true);event.setCancellationResult(InteractionResult.SUCCESS);
    }

    /** LOWEST priority is intentional: the primary break must first survive protection/claim handlers. */
    public void onBreakBlock(BreakBlockEvent event){
        if(event.getLevel().isClientSide()||!(event.getPlayer() instanceof ServerPlayer player))return;
        if(toolOperationGuard.contains(player.getUUID()))return;
        ItemStack tool=player.getMainHandItem();
        DomainRecord record=runtime.domains().getRecord(player.getUUID()).orElse(null);if(record==null||!record.state().coreActive())return;
        BlockState target=event.getState();
        if(tool.is(VeilboundItems.PHASEBREAKER.get())){
            PhasebreakerMode mode=PhasebreakerMode.fromId(tool.getOrDefault(VeilboundDataComponents.VEIL_TOOL_MODE.get(),0));if(mode==PhasebreakerMode.NORMAL)return;
            java.util.List<BlockPos> extras=switch(mode){case VEIN->veinTargets(event.getLevel(),event.getPos(),target,mode.maxExtraBlocks());case PLANE->planeTargets(event.getLevel(),event.getPos(),target,player,mode.maxExtraBlocks());case PHASE->phaseTargets(event.getLevel(),event.getPos(),target,player,mode.maxExtraBlocks());default->java.util.List.of();};
            if(extras.isEmpty())return;
            toolOperationGuard.add(player.getUUID());
            try{
                int broken=breakExtraBlocks(player,event,target,extras,record,mode.dePerExtraBlock());
                if(broken>0)player.displayClientMessage(Component.translatable("message.veilbound.phasebreaker.used",mode.name(),broken,broken*mode.dePerExtraBlock()),true);
            }finally{toolOperationGuard.remove(player.getUUID());}
            return;
        }
        if(tool.is(VeilboundItems.BOUNDARY_SPADE.get())){
            BoundarySpadeMode mode=BoundarySpadeMode.fromId(tool.getOrDefault(VeilboundDataComponents.VEIL_TOOL_MODE.get(),0));if(mode==BoundarySpadeMode.PRECISION)return;
            java.util.List<BlockPos> extras=planeTargets(event.getLevel(),event.getPos(),target,player,mode.maxExtraBlocks());
            if(extras.isEmpty())return;
            toolOperationGuard.add(player.getUUID());
            try{
                int broken=breakExtraBlocks(player,event,target,extras,record,mode.dePerExtraBlock());
                if(broken>0)player.displayClientMessage(Component.translatable("message.veilbound.boundary_spade.used",broken,broken*mode.dePerExtraBlock()),true);
            }finally{toolOperationGuard.remove(player.getUUID());}
        }
    }

    /**
     * Sovereign Regalia grants creative-style flight only inside the owner's own Domain.
     * The permission itself is free while the full set is worn; actively flying drains Core DE once per second.
     * Outside the Domain the set remains powerful armor but does not grant flight.
     */
    public void onPlayerTick(PlayerTickEvent.Post event){
        if(!(event.getEntity() instanceof ServerPlayer player) || player.level().isClientSide())return;
        var flight=player.getAttribute(NeoForgeMod.CREATIVE_FLIGHT);
        if(flight==null)return;

        DomainRecord record=runtime.domains().getRecord(player.getUUID()).orElse(null);
        boolean eligible=record!=null && record.state().coreActive() && fullSovereign(player)
                && record.identity().dimensionId().equals(player.level().dimension().identifier().toString());

        if(eligible){
            flight.addOrUpdateTransientModifier(new AttributeModifier(
                    SOVEREIGN_FLIGHT_MODIFIER, 1.0D, AttributeModifier.Operation.ADD_VALUE));
            if(player.getAbilities().flying && player.level().getGameTime()%20L==0L && !player.getAbilities().instabuild){
                if(!record.state().consumeDimensionalEnergy(SOVEREIGN_FLIGHT_DE_PER_SECOND)){
                    flight.removeModifier(SOVEREIGN_FLIGHT_MODIFIER);
                    player.getAbilities().flying=false;
                    player.onUpdateAbilities();
                    player.displayClientMessage(Component.translatable("message.veilbound.sovereign.flight_depleted"),true);
                }
            }
            return;
        }

        if(flight.removeModifier(SOVEREIGN_FLIGHT_MODIFIER) && !player.isCreative() && !player.isSpectator()){
            if(player.getAbilities().flying){
                player.getAbilities().flying=false;
                player.onUpdateAbilities();
            }
        }
    }

    /** Rift Cutter adds post-armor spatial shear; full armor sets can absorb part of post-armor damage using DE. */
    public void onLivingDamagePre(LivingDamageEvent.Pre event){
        if(event.getSource().getEntity() instanceof ServerPlayer attacker&&attacker.getMainHandItem().is(VeilboundItems.RIFT_CUTTER.get())){
            DomainRecord record=runtime.domains().getRecord(attacker.getUUID()).orElse(null);if(record!=null&&record.state().coreActive()&&record.state().consumeDimensionalEnergy(250))event.setNewDamage(event.getNewDamage()*1.35F);
        }
        if(!(event.getEntity() instanceof ServerPlayer defender))return;
        ArmorBand band=armorBand(defender);if(band==ArmorBand.NONE)return;
        DomainRecord record=runtime.domains().getRecord(defender.getUUID()).orElse(null);if(record==null||!record.state().coreActive())return;
        boolean insideOwn=record.identity().dimensionId().equals(defender.level().dimension().identifier().toString());
        long cost=switch(band){case PHASEWEAVE->75;case CAUSAL->250;case SOVEREIGN->insideOwn?400:600;default->0;};
        float reduction=switch(band){case PHASEWEAVE->insideOwn?0.20F:0.10F;case CAUSAL->0.35F;case SOVEREIGN->insideOwn?0.55F:0.35F;default->0F;};
        if(cost>0&&record.state().consumeDimensionalEnergy(cost))event.setNewDamage(Math.max(0F,event.getNewDamage()*(1F-reduction)));
    }


    private static int breakExtraBlocks(ServerPlayer player, BreakBlockEvent event, BlockState target, java.util.List<BlockPos> extras, DomainRecord record, long dePerBlock){
        int broken=0;
        for(BlockPos extra:extras){
            if(record.state().dimensionalEnergy()<dePerBlock)break;
            if(!event.getLevel().getBlockState(extra).is(target.getBlock()))continue;
            if(player.gameMode.destroyBlock(extra)&&record.state().consumeDimensionalEnergy(dePerBlock))broken++;
        }
        return broken;
    }

    private static java.util.List<BlockPos> veinTargets(net.minecraft.world.level.Level level,BlockPos origin,BlockState state,int cap){ArrayDeque<BlockPos> q=new ArrayDeque<>();Set<BlockPos> seen=new HashSet<>();java.util.ArrayList<BlockPos> out=new java.util.ArrayList<>();q.add(origin);seen.add(origin);while(!q.isEmpty()&&out.size()<cap){BlockPos p=q.removeFirst();for(Direction d:Direction.values()){BlockPos n=p.relative(d);if(!seen.add(n)||n.equals(origin)||origin.distManhattan(n)>8)continue;if(level.getBlockState(n).is(state.getBlock())){out.add(n.immutable());q.addLast(n);if(out.size()>=cap)break;}}}return out;}
    private static java.util.List<BlockPos> planeTargets(net.minecraft.world.level.Level level,BlockPos origin,BlockState state,ServerPlayer player,int cap){Direction.Axis axis=dominantAxis(player);java.util.ArrayList<BlockPos> out=new java.util.ArrayList<>();for(int a=-1;a<=1&&out.size()<cap;a++)for(int b=-1;b<=1&&out.size()<cap;b++){if(a==0&&b==0)continue;BlockPos p=switch(axis){case X->origin.offset(0,a,b);case Y->origin.offset(a,0,b);case Z->origin.offset(a,b,0);};if(level.getBlockState(p).is(state.getBlock()))out.add(p.immutable());}return out;}
    private static java.util.List<BlockPos> phaseTargets(net.minecraft.world.level.Level level,BlockPos origin,BlockState state,ServerPlayer player,int cap){Direction.Axis axis=dominantAxis(player);double component=switch(axis){case X->player.getLookAngle().x;case Y->player.getLookAngle().y;case Z->player.getLookAngle().z;};int sign=component>=0?1:-1;java.util.ArrayList<BlockPos> out=new java.util.ArrayList<>();for(int i=1;i<=6&&out.size()<cap;i++){BlockPos p=switch(axis){case X->origin.offset(sign*i,0,0);case Y->origin.offset(0,sign*i,0);case Z->origin.offset(0,0,sign*i);};if(level.getBlockState(p).is(state.getBlock()))out.add(p.immutable());}return out;}
    private static Direction.Axis dominantAxis(ServerPlayer p){var v=p.getLookAngle();double x=Math.abs(v.x),y=Math.abs(v.y),z=Math.abs(v.z);return y>=x&&y>=z?Direction.Axis.Y:x>=z?Direction.Axis.X:Direction.Axis.Z;}
    private static ArmorBand armorBand(ServerPlayer p){if(full(p,VeilboundItems.SOVEREIGN_HELMET.get(),VeilboundItems.SOVEREIGN_CHESTPLATE.get(),VeilboundItems.SOVEREIGN_LEGGINGS.get(),VeilboundItems.SOVEREIGN_BOOTS.get()))return ArmorBand.SOVEREIGN;if(full(p,VeilboundItems.CAUSAL_HELMET.get(),VeilboundItems.CAUSAL_CHESTPLATE.get(),VeilboundItems.CAUSAL_LEGGINGS.get(),VeilboundItems.CAUSAL_BOOTS.get()))return ArmorBand.CAUSAL;if(full(p,VeilboundItems.PHASEWEAVE_HELMET.get(),VeilboundItems.PHASEWEAVE_CHESTPLATE.get(),VeilboundItems.PHASEWEAVE_LEGGINGS.get(),VeilboundItems.PHASEWEAVE_BOOTS.get()))return ArmorBand.PHASEWEAVE;return ArmorBand.NONE;}
    private static boolean full(ServerPlayer p,net.minecraft.world.item.Item h,net.minecraft.world.item.Item c,net.minecraft.world.item.Item l,net.minecraft.world.item.Item b){return p.getItemBySlot(EquipmentSlot.HEAD).is(h)&&p.getItemBySlot(EquipmentSlot.CHEST).is(c)&&p.getItemBySlot(EquipmentSlot.LEGS).is(l)&&p.getItemBySlot(EquipmentSlot.FEET).is(b);}
    private static boolean fullSovereign(ServerPlayer p){return full(p,VeilboundItems.SOVEREIGN_HELMET.get(),VeilboundItems.SOVEREIGN_CHESTPLATE.get(),VeilboundItems.SOVEREIGN_LEGGINGS.get(),VeilboundItems.SOVEREIGN_BOOTS.get());}
    private enum ArmorBand{NONE,PHASEWEAVE,CAUSAL,SOVEREIGN}
}
