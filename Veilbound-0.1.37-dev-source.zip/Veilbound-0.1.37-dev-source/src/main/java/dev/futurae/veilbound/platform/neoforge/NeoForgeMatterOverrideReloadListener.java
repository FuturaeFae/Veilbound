package dev.futurae.veilbound.platform.neoforge;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import dev.futurae.veilbound.matter.MatterDatapackSnapshot;
import dev.futurae.veilbound.matter.MatterDatapackSnapshot.OverrideValue;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

/**
 * Loads exact per-item Matter overrides from datapacks.
 *
 * Resource layout deliberately mirrors the target item id so ordinary datapack resource
 * priority resolves conflicts without Veilbound inventing a second precedence system:
 *
 *   data/<item-namespace>/veilbound/matter_values/<item-path>.json
 *
 * Example for minecraft:diamond:
 *   data/minecraft/veilbound/matter_values/diamond.json
 *   { "value": 300 }
 *
 * Because the item namespace is the resource namespace and the item path is encoded in the
 * resource path, a higher-priority datapack overrides the same item by replacing the same
 * resource location. Unknown/optional item ids are allowed; they are simply dormant unless
 * that item exists in the running modpack.
 */
public final class NeoForgeMatterOverrideReloadListener
        extends SimplePreparableReloadListener<MatterDatapackSnapshot> {
    public static final String DIRECTORY = "veilbound/matter_values";

    private final Gson gson = new Gson();
    private final Consumer<MatterDatapackSnapshot> publisher;

    public NeoForgeMatterOverrideReloadListener(Consumer<MatterDatapackSnapshot> publisher) {
        this.publisher = Objects.requireNonNull(publisher, "publisher");
    }

    @Override
    protected MatterDatapackSnapshot prepare(ResourceManager resourceManager, ProfilerFiller profiler) {
        Map<String, OverrideValue> values = new LinkedHashMap<>();
        List<String> warnings = new ArrayList<>();

        List<Map.Entry<Identifier, Resource>> resources = resourceManager
                .listResources(DIRECTORY, id -> id.getPath().endsWith(".json"))
                .entrySet()
                .stream()
                .sorted(Map.Entry.comparingByKey(Comparator.comparing(Identifier::toString)))
                .toList();

        for (Map.Entry<Identifier, Resource> entry : resources) {
            Identifier resourceId = entry.getKey();
            Resource resource = entry.getValue();
            String itemId = itemIdFromResource(resourceId);
            if (itemId == null) {
                warnings.add("Ignored malformed Matter value path: " + resourceId);
                continue;
            }

            try (Reader reader = resource.openAsReader()) {
                JsonElement root = gson.fromJson(reader, JsonElement.class);
                long amount = readAmount(root, resourceId);
                values.put(itemId, new OverrideValue(
                        amount,
                        "datapack:" + resource.sourcePackId() + ":" + resourceId));
            } catch (IOException | JsonParseException | IllegalArgumentException ex) {
                warnings.add("Ignored Matter value " + resourceId + ": " + ex.getMessage());
            }
        }

        return new MatterDatapackSnapshot(values, warnings);
    }

    @Override
    protected void apply(MatterDatapackSnapshot snapshot, ResourceManager resourceManager, ProfilerFiller profiler) {
        publisher.accept(snapshot);
    }

    static String itemIdFromResource(Identifier resourceId) {
        String path = resourceId.getPath();
        String prefix = DIRECTORY + "/";
        if (!path.startsWith(prefix) || !path.endsWith(".json")) return null;
        String itemPath = path.substring(prefix.length(), path.length() - ".json".length());
        if (itemPath.isBlank() || itemPath.startsWith("/") || itemPath.endsWith("/")) return null;
        return resourceId.getNamespace() + ":" + itemPath;
    }

    private static long readAmount(JsonElement root, Identifier resourceId) {
        if (root == null || !root.isJsonObject()) {
            throw new JsonParseException("expected a JSON object");
        }
        JsonObject object = root.getAsJsonObject();
        if (!object.has("value")) {
            throw new JsonParseException("missing required 'value' field");
        }
        JsonElement value = object.get("value");
        if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isNumber()) {
            throw new JsonParseException("'value' must be a non-negative integer");
        }

        long amount;
        try {
            amount = value.getAsLong();
        } catch (NumberFormatException ex) {
            throw new JsonParseException("'value' is outside the signed 64-bit integer range", ex);
        }
        if (amount < 0) {
            throw new JsonParseException("'value' must be non-negative");
        }
        return amount;
    }
}
