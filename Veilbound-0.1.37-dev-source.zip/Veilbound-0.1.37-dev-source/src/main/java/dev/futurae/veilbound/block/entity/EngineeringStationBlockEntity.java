package dev.futurae.veilbound.block.entity;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.engineering.EngineeringFabricationService;
import dev.futurae.veilbound.engineering.EngineeringInventory;
import dev.futurae.veilbound.engineering.EngineeringMatterReservoir;
import dev.futurae.veilbound.engineering.EngineeringRecipe;
import dev.futurae.veilbound.engineering.EngineeringStation;
import dev.futurae.veilbound.ontology.PotentialReservoir;
import dev.futurae.veilbound.registry.VeilboundBlockEntities;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.neoforged.neoforge.transfer.ResourceHandler;
import net.neoforged.neoforge.transfer.TransferPreconditions;
import net.neoforged.neoforge.transfer.item.ItemResource;
import net.neoforged.neoforge.transfer.transaction.SnapshotJournal;
import net.neoforged.neoforge.transfer.transaction.TransactionContext;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jspecify.annotations.Nullable;

/**
 * Persistent server-authoritative state for the Dimensional Fabricator and Veil Foundry.
 *
 * <p>Physical components, fabrication Matter and Potential are three independent local resources.
 * Valued components do not automatically dissolve: normal insertion keeps them physical, while an
 * explicit Matter-feed action converts them. Core DE is drawn only at successful job completion.</p>
 */
public final class EngineeringStationBlockEntity extends BlockEntity {
    public static final long FABRICATOR_MATTER_CAPACITY = 268_435_456L;
    public static final long FOUNDRY_MATTER_CAPACITY = 4_294_967_296L;
    public static final long FABRICATOR_POTENTIAL_CAPACITY = 262_144L;
    public static final long FOUNDRY_POTENTIAL_CAPACITY = 2_097_152L;
    public static final long MAX_PHYSICAL_ITEMS_PER_ID = 1_000_000L;

    private final EngineeringInventory inventory = new EngineeringInventory();
    private final EngineeringInventory outputs = new EngineeringInventory();
    private final EngineeringFabricationService fabrication = new EngineeringFabricationService();
    private final ResourceHandler<ItemResource> componentInput = new ComponentInputHandler();
    private final ResourceHandler<ItemResource> matterInput = new MatterFeedHandler();
    private final ResourceHandler<ItemResource> outputHandler = new OutputHandler();
    private EngineeringMatterReservoir matter;
    private PotentialReservoir potential;
    private UUID ownerId;
    private String selectedRecipeId = "";
    private String lastStatus = "idle";
    private int progressTicks;

    public EngineeringStationBlockEntity(BlockPos pos, BlockState state) {
        super(VeilboundBlockEntities.ENGINEERING_STATION.get(), pos, state);
        EngineeringStation station = station(state);
        matter = new EngineeringMatterReservoir(station == EngineeringStation.VEIL_FOUNDRY
                ? FOUNDRY_MATTER_CAPACITY : FABRICATOR_MATTER_CAPACITY);
        potential = new PotentialReservoir(station == EngineeringStation.VEIL_FOUNDRY
                ? FOUNDRY_POTENTIAL_CAPACITY : FABRICATOR_POTENTIAL_CAPACITY);
    }

    public void bindOwner(UUID ownerId) {
        UUID candidate = Objects.requireNonNull(ownerId, "ownerId");
        if (this.ownerId == null) { this.ownerId = candidate; setChanged(); }
    }

    public @Nullable UUID ownerId() { return ownerId; }
    public EngineeringStation station() { return station(getBlockState()); }
    public long storedMatter() { return matter.stored(); }
    public long matterCapacity() { return matter.capacity(); }
    public long storedPotential() { return potential.stored(); }
    public long potentialCapacity() { return potential.capacity(); }
    public Map<String, Long> inventorySnapshot() { return inventory.snapshot(); }
    public Map<String, Long> outputSnapshot() { return outputs.snapshot(); }
    public String selectedRecipeId() { return selectedRecipeId; }
    public int progressTicks() { return progressTicks; }
    public String lastStatus() { return lastStatus; }

    public long insertPhysical(String itemId, long offered) {
        if (itemId == null || itemId.isBlank() || offered <= 0) return 0;
        long room = Math.max(0L, MAX_PHYSICAL_ITEMS_PER_ID - inventory.count(itemId));
        long accepted = Math.min(offered, room);
        if (accepted > 0) { inventory.insert(itemId, accepted); setChanged(); }
        return accepted;
    }

    /** Explicit Matter port/action. Never called for ordinary component insertion. */
    public long feedMatter(String itemId, long offeredItems) {
        if (itemId == null || itemId.isBlank() || offeredItems <= 0) return 0;
        var value = Veilbound.runtime().matter().amount(itemId);
        if (value.isEmpty() || value.getAsLong() <= 0) return 0;
        long perItem = value.getAsLong();
        long itemRoom = (matter.capacity() - matter.stored()) / perItem;
        long acceptedItems = Math.min(offeredItems, itemRoom);
        if (acceptedItems <= 0) return 0;
        long acceptedMatter;
        try { acceptedMatter = Math.multiplyExact(acceptedItems, perItem); }
        catch (ArithmeticException overflow) { return 0; }
        if (matter.insert(acceptedMatter) != acceptedMatter) return 0;
        setChanged();
        return acceptedItems;
    }

    public long receivePotential(long offered) {
        long accepted = potential.insert(offered);
        if (accepted > 0) setChanged();
        return accepted;
    }

    public boolean selectRecipe(String recipeId) {
        EngineeringRecipe recipe = Veilbound.runtime().engineeringRecipes().get(recipeId).orElse(null);
        if (recipe == null || recipe.station() != station()) return false;
        if (!selectedRecipeId.equals(recipeId)) {
            selectedRecipeId = recipeId;
            progressTicks = 0;
            lastStatus = "selected";
            setChanged();
        }
        return true;
    }

    public void clearSelection() {
        if (!selectedRecipeId.isEmpty() || progressTicks != 0) {
            selectedRecipeId = ""; progressTicks = 0; lastStatus = "idle"; setChanged();
        }
    }

    public long extractPhysical(String itemId, long requested) {
        if (itemId == null || itemId.isBlank() || requested <= 0) return 0;
        long accepted = Math.min(requested, outputs.count(itemId));
        if (accepted > 0 && outputs.extract(itemId, accepted)) { setChanged(); return accepted; }
        return 0;
    }

    public long outputCount(String itemId) { return outputs.count(itemId); }

    /** Automation convention: top inserts components, horizontal sides feed valued items as Matter, bottom extracts finished outputs. */
    public ResourceHandler<ItemResource> automationHandler(Direction side) {
        if (side == Direction.DOWN) return outputHandler;
        if (side == Direction.UP) return componentInput;
        return matterInput;
    }

    public EngineeringFabricationService.FabricationPlan currentPlan() {
        DomainRecord record = ownerRecordInCurrentDomain();
        EngineeringRecipe recipe = currentRecipe();
        if (record == null || recipe == null) return new EngineeringFabricationService.FabricationPlan(false, java.util.List.of(record == null ? "owner_domain_unavailable" : "no_recipe"), recipe == null ? 0 : recipe.processTicks());
        return fabrication.plan(recipe, station(), record.state(), matter, potential, inventory);
    }

    public EngineeringFabricationService.FabricationPlan planFor(EngineeringRecipe recipe) {
        DomainRecord record = ownerRecordInCurrentDomain();
        if (record == null) return new EngineeringFabricationService.FabricationPlan(false, java.util.List.of("owner_domain_unavailable"), recipe == null ? 0 : recipe.processTicks());
        if (recipe == null) return new EngineeringFabricationService.FabricationPlan(false, java.util.List.of("no_recipe"), 0);
        return fabrication.plan(recipe, station(), record.state(), matter, potential, inventory);
    }

    public static void tick(Level level, BlockPos pos, BlockState state, EngineeringStationBlockEntity station) {
        if (!(level instanceof ServerLevel)) return;
        EngineeringRecipe recipe = station.currentRecipe();
        DomainRecord record = station.ownerRecordInCurrentDomain();
        if (recipe == null || record == null) {
            if (station.progressTicks != 0) { station.progressTicks = 0; station.setChanged(); }
            return;
        }
        var plan = station.fabrication.plan(recipe, station.station(), record.state(), station.matter, station.potential, station.inventory);
        if (!plan.ready()) {
            String status = plan.missing().isEmpty() ? "blocked" : plan.missing().get(0);
            if (station.progressTicks != 0 || !status.equals(station.lastStatus)) {
                station.progressTicks = 0; station.lastStatus = status; station.setChanged();
            }
            return;
        }
        station.progressTicks++;
        station.lastStatus = "fabricating";
        if (station.progressTicks < recipe.processTicks()) {
            if (station.progressTicks % 20 == 0) station.setChanged();
            return;
        }
        var result = station.fabrication.execute(recipe, station.station(), record.state(), station.matter, station.potential, station.inventory, station.outputs);
        station.progressTicks = 0;
        station.lastStatus = result.crafted() ? "complete" : (result.missing().isEmpty() ? "blocked" : result.missing().get(0));
        station.setChanged();
    }

    private @Nullable EngineeringRecipe currentRecipe() {
        if (selectedRecipeId == null || selectedRecipeId.isBlank()) return null;
        return Veilbound.runtime().engineeringRecipes().get(selectedRecipeId).orElse(null);
    }

    private @Nullable DomainRecord ownerRecordInCurrentDomain() {
        if (!(level instanceof ServerLevel) || ownerId == null) return null;
        DomainRecord record = Veilbound.runtime().domains().getRecord(ownerId).orElse(null);
        if (record == null) return null;
        return record.identity().dimensionId().equals(level.dimension().identifier().toString()) ? record : null;
    }

    @Override protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        if (ownerId != null) output.putString("owner", ownerId.toString());
        output.putString("engineering_matter", Long.toString(matter.stored()));
        output.putString("potential", Long.toString(potential.stored()));
        output.putString("engineering_inventory", encodeCounts(inventory.snapshot()));
        output.putString("engineering_outputs", encodeCounts(outputs.snapshot()));
        if (selectedRecipeId != null && !selectedRecipeId.isBlank()) output.putString("selected_recipe", selectedRecipeId);
        output.putInt("progress", progressTicks);
        if (lastStatus != null && !lastStatus.isBlank()) output.putString("status", lastStatus);
    }

    @Override protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        ownerId = input.getString("owner").flatMap(raw -> {
            try { return java.util.Optional.of(UUID.fromString(raw)); }
            catch (IllegalArgumentException ignored) { return java.util.Optional.empty(); }
        }).orElse(null);
        matter.setStored(clamp(parseLong(input.getString("engineering_matter").orElse("0")), 0, matter.capacity()));
        potential.setStored(clamp(parseLong(input.getString("potential").orElse("0")), 0, potential.capacity()));
        inventory.replace(decodeCounts(input.getString("engineering_inventory").orElse("")));
        outputs.replace(decodeCounts(input.getString("engineering_outputs").orElse("")));
        selectedRecipeId = input.getString("selected_recipe").filter(raw -> !raw.isBlank()).orElse("");
        progressTicks = Math.max(0, input.getIntOr("progress", 0));
        lastStatus = input.getString("status").filter(raw -> !raw.isBlank()).orElse("idle");
    }


    private final class ComponentInputHandler extends SnapshotJournal<Map<String, Long>> implements ResourceHandler<ItemResource> {
        @Override public int size() { return 1; }
        @Override public ItemResource getResource(int index) { return ItemResource.EMPTY; }
        @Override public long getAmountAsLong(int index) { return 0L; }
        @Override public long getCapacityAsLong(int index, ItemResource resource) { return index == 0 && resource != null && !resource.isEmpty() ? MAX_PHYSICAL_ITEMS_PER_ID : 0L; }
        @Override public boolean isValid(int index, ItemResource resource) { return index == 0 && resource != null && !resource.isEmpty(); }
        @Override public int insert(int index, ItemResource resource, int amount, TransactionContext transaction) {
            TransferPreconditions.checkNonEmptyNonNegative(resource, amount);
            if (index != 0 || amount == 0) return 0;
            String itemId = BuiltInRegistries.ITEM.getKey(resource.getItem()).toString();
            long accepted = Math.min(Integer.MAX_VALUE, Math.min(amount, Math.max(0L, MAX_PHYSICAL_ITEMS_PER_ID - inventory.count(itemId))));
            if (accepted <= 0) return 0;
            updateSnapshots(transaction); inventory.insert(itemId, accepted); setChanged(); return (int) accepted;
        }
        @Override public int extract(int index, ItemResource resource, int amount, TransactionContext transaction) { TransferPreconditions.checkNonEmptyNonNegative(resource, amount); return 0; }
        @Override public int insert(ItemResource resource, int amount, TransactionContext transaction) { return insert(0, resource, amount, transaction); }
        @Override public int extract(ItemResource resource, int amount, TransactionContext transaction) { TransferPreconditions.checkNonEmptyNonNegative(resource, amount); return 0; }
        @Override protected Map<String, Long> createSnapshot() { return inventory.snapshot(); }
        @Override protected void revertToSnapshot(Map<String, Long> snapshot) { inventory.replace(snapshot); setChanged(); }
    }

    private final class MatterFeedHandler extends SnapshotJournal<Long> implements ResourceHandler<ItemResource> {
        @Override public int size() { return 1; }
        @Override public ItemResource getResource(int index) { return ItemResource.EMPTY; }
        @Override public long getAmountAsLong(int index) { return 0L; }
        @Override public long getCapacityAsLong(int index, ItemResource resource) {
            if (index != 0 || resource == null || resource.isEmpty()) return 0L;
            String itemId = BuiltInRegistries.ITEM.getKey(resource.getItem()).toString();
            var value = Veilbound.runtime().matter().amount(itemId); if (value.isEmpty() || value.getAsLong() <= 0) return 0L;
            return Math.max(0L, matter.capacity() - matter.stored()) / value.getAsLong();
        }
        @Override public boolean isValid(int index, ItemResource resource) { return getCapacityAsLong(index, resource) > 0; }
        @Override public int insert(int index, ItemResource resource, int amount, TransactionContext transaction) {
            TransferPreconditions.checkNonEmptyNonNegative(resource, amount); if (index != 0 || amount == 0) return 0;
            String itemId = BuiltInRegistries.ITEM.getKey(resource.getItem()).toString();
            var value = Veilbound.runtime().matter().amount(itemId); if (value.isEmpty() || value.getAsLong() <= 0) return 0;
            long per = value.getAsLong(), roomItems = Math.max(0L, matter.capacity() - matter.stored()) / per;
            int accepted = (int)Math.min(amount, Math.min(Integer.MAX_VALUE, roomItems)); if (accepted <= 0) return 0;
            updateSnapshots(transaction); matter.insert(Math.multiplyExact((long)accepted, per)); setChanged(); return accepted;
        }
        @Override public int extract(int index, ItemResource resource, int amount, TransactionContext transaction) { TransferPreconditions.checkNonEmptyNonNegative(resource, amount); return 0; }
        @Override public int insert(ItemResource resource, int amount, TransactionContext transaction) { return insert(0, resource, amount, transaction); }
        @Override public int extract(ItemResource resource, int amount, TransactionContext transaction) { TransferPreconditions.checkNonEmptyNonNegative(resource, amount); return 0; }
        @Override protected Long createSnapshot() { return matter.stored(); }
        @Override protected void revertToSnapshot(Long snapshot) { matter.setStored(snapshot); setChanged(); }
    }

    private final class OutputHandler extends SnapshotJournal<Map<String, Long>> implements ResourceHandler<ItemResource> {
        private java.util.List<Map.Entry<String, Long>> entries() { return outputs.snapshot().entrySet().stream().filter(e -> e.getValue() > 0).sorted(Map.Entry.comparingByKey()).toList(); }
        @Override public int size() { return Math.max(1, entries().size()); }
        @Override public ItemResource getResource(int index) {
            var entries = entries(); if (index < 0 || index >= entries.size()) return ItemResource.EMPTY;
            Identifier id = Identifier.tryParse(entries.get(index).getKey());
            if (id == null || !BuiltInRegistries.ITEM.containsKey(id)) return ItemResource.EMPTY;
            return ItemResource.of(BuiltInRegistries.ITEM.getValue(id));
        }
        @Override public long getAmountAsLong(int index) { var e=entries(); return index>=0&&index<e.size()?e.get(index).getValue():0L; }
        @Override public long getCapacityAsLong(int index, ItemResource resource) { return getAmountAsLong(index); }
        @Override public boolean isValid(int index, ItemResource resource) { return false; }
        @Override public int insert(int index, ItemResource resource, int amount, TransactionContext transaction) { TransferPreconditions.checkNonEmptyNonNegative(resource, amount); return 0; }
        @Override public int extract(int index, ItemResource resource, int amount, TransactionContext transaction) {
            TransferPreconditions.checkNonEmptyNonNegative(resource, amount); if (amount == 0) return 0;
            var entries=entries(); if(index<0||index>=entries.size())return 0; var entry=entries.get(index);
            Identifier id=Identifier.tryParse(entry.getKey()); if(id==null||!BuiltInRegistries.ITEM.containsKey(id))return 0;
            ItemResource actual=ItemResource.of(BuiltInRegistries.ITEM.getValue(id)); if(!actual.equals(resource))return 0;
            int extracted=(int)Math.min(amount,Math.min(Integer.MAX_VALUE,entry.getValue())); if(extracted<=0)return 0;
            updateSnapshots(transaction); if(!outputs.extract(entry.getKey(),extracted))throw new IllegalStateException("output changed during extraction"); setChanged(); return extracted;
        }
        @Override public int insert(ItemResource resource, int amount, TransactionContext transaction) { TransferPreconditions.checkNonEmptyNonNegative(resource, amount); return 0; }
        @Override public int extract(ItemResource resource, int amount, TransactionContext transaction) {
            TransferPreconditions.checkNonEmptyNonNegative(resource, amount); if(resource.isEmpty()||amount==0)return 0;
            var entries=entries(); for(int i=0;i<entries.size();i++){ if(getResource(i).equals(resource)) return extract(i,resource,amount,transaction); } return 0;
        }
        @Override protected Map<String, Long> createSnapshot() { return outputs.snapshot(); }
        @Override protected void revertToSnapshot(Map<String, Long> snapshot) { outputs.replace(snapshot); setChanged(); }
    }

    private static EngineeringStation station(BlockState state) {
        return state.is(VeilboundBlocks.VEIL_FOUNDRY.get()) ? EngineeringStation.VEIL_FOUNDRY : EngineeringStation.DIMENSIONAL_FABRICATOR;
    }
    private static long parseLong(String raw) { try { return Long.parseLong(raw); } catch (NumberFormatException ignored) { return 0L; } }
    private static long clamp(long value, long min, long max) { return Math.max(min, Math.min(max, value)); }
    private static String encodeCounts(Map<String, Long> counts) {
        StringBuilder out = new StringBuilder();
        counts.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(entry -> {
            if (entry.getValue() <= 0 || entry.getKey().contains(";") || entry.getKey().contains("=")) return;
            if (!out.isEmpty()) out.append(';');
            out.append(entry.getKey()).append('=').append(entry.getValue());
        });
        return out.toString();
    }
    private static Map<String, Long> decodeCounts(String encoded) {
        LinkedHashMap<String, Long> result = new LinkedHashMap<>();
        if (encoded == null || encoded.isBlank()) return result;
        for (String token : encoded.split(";")) {
            int split = token.lastIndexOf('=');
            if (split <= 0 || split + 1 >= token.length()) continue;
            long count = parseLong(token.substring(split + 1));
            if (count > 0) result.put(token.substring(0, split), count);
        }
        return result;
    }
}
