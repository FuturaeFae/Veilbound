package dev.futurae.veilbound;

import com.mojang.logging.LogUtils;
import dev.futurae.veilbound.platform.neoforge.NeoForgeAxiomMonolithCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeBoundaryPylonCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeBreachCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeContinuityAnchorCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeCoreControlCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeCoreRelocationCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeGenesisSeedCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeDefinitionReloadCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeExpansionCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeEnvironmentalZoneCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeEngineeringStationController;
import dev.futurae.veilbound.platform.neoforge.NeoForgeMatterCommandCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeMatterRecipeCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeMemoryGameplayCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeMilestoneCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeMemoryEffectCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeLawEffectCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgePlayerPresenceCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeResonanceLensCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeTransducerCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeVeilStitcherCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeVeilforgedEquipmentCoordinator;
import dev.futurae.veilbound.platform.neoforge.NeoForgeVeilBoundaryCoordinator;
import dev.futurae.veilbound.client.VeilboundClient;
import dev.futurae.veilbound.platform.neoforge.network.NeoForgeNetworking;
import dev.futurae.veilbound.platform.neoforge.inventory.NeoForgeCoreUpgradeCoordinator;
import dev.futurae.veilbound.platform.neoforge.inventory.NeoForgeVeilInterfaceCapabilities;
import dev.futurae.veilbound.platform.neoforge.persistence.NeoForgePersistenceCoordinator;
import dev.futurae.veilbound.platform.neoforge.precore.NeoForgeSpatialGeneratorController;
import dev.futurae.veilbound.platform.neoforge.precore.NeoForgeSpatialGeneratorCapabilities;
import dev.futurae.veilbound.platform.neoforge.travel.NeoForgeDomainTravelExecutor;
import dev.futurae.veilbound.platform.neoforge.travel.NeoForgeReturnAnchorResolver;
import dev.futurae.veilbound.platform.neoforge.world.NeoForgeDomainLevelService;
import dev.futurae.veilbound.platform.neoforge.world.NeoForgeStarterPocketService;
import dev.futurae.veilbound.platform.neoforge.threshold.NeoForgeThresholdFrameCoordinator;
import dev.futurae.veilbound.platform.neoforge.threshold.NeoForgeThresholdDeactivationCoordinator;
import dev.futurae.veilbound.platform.neoforge.threshold.NeoForgeThresholdPortalTransit;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import dev.futurae.veilbound.registry.VeilboundBlockEntities;
import dev.futurae.veilbound.registry.VeilboundCreativeTabs;
import dev.futurae.veilbound.registry.VeilboundEntities;
import dev.futurae.veilbound.registry.VeilboundDataComponents;
import dev.futurae.veilbound.registry.VeilboundItems;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;

@Mod(Veilbound.MOD_ID)
public final class Veilbound {
    public static final String MOD_ID = "veilbound";
    public static final Logger LOGGER = LogUtils.getLogger();

    private static final VeilboundRuntime RUNTIME = new VeilboundRuntime();
    private static final NeoForgeMatterRecipeCoordinator MATTER_RECIPES =
            new NeoForgeMatterRecipeCoordinator(RUNTIME);
    private static final NeoForgeMatterCommandCoordinator MATTER_COMMANDS =
            new NeoForgeMatterCommandCoordinator(RUNTIME);
    private static final NeoForgeDefinitionReloadCoordinator DEFINITIONS =
            new NeoForgeDefinitionReloadCoordinator(RUNTIME);
    private static final NeoForgePersistenceCoordinator PERSISTENCE =
            new NeoForgePersistenceCoordinator(RUNTIME);
    private static final NeoForgeMilestoneCoordinator MILESTONES =
            new NeoForgeMilestoneCoordinator(RUNTIME);
    private static final NeoForgeMemoryGameplayCoordinator MEMORY_GAMEPLAY =
            new NeoForgeMemoryGameplayCoordinator(RUNTIME);
    private static final NeoForgeAxiomMonolithCoordinator AXIOM_MONOLITH =
            new NeoForgeAxiomMonolithCoordinator(RUNTIME);
    private static final NeoForgeBoundaryPylonCoordinator BOUNDARY_PYLONS =
            new NeoForgeBoundaryPylonCoordinator(RUNTIME);
    private static final NeoForgeTransducerCoordinator TRANSDUCER =
            new NeoForgeTransducerCoordinator(RUNTIME);
    private static final NeoForgeResonanceLensCoordinator RESONANCE_LENS =
            new NeoForgeResonanceLensCoordinator(RUNTIME);
    private static final NeoForgeSpatialGeneratorController SPATIAL_GENERATOR =
            new NeoForgeSpatialGeneratorController(RUNTIME);
    private static final NeoForgeEnvironmentalZoneCoordinator ENVIRONMENTAL_ZONES =
            new NeoForgeEnvironmentalZoneCoordinator(RUNTIME);
    private static final NeoForgeEngineeringStationController ENGINEERING =
            new NeoForgeEngineeringStationController(RUNTIME);
    private static final NeoForgeDomainLevelService DOMAIN_LEVELS =
            new NeoForgeDomainLevelService(RUNTIME);
    private static final NeoForgeExpansionCoordinator DOMAIN_EXPANSION =
            new NeoForgeExpansionCoordinator(RUNTIME, DOMAIN_LEVELS);
    private static final NeoForgeVeilBoundaryCoordinator VEIL_BOUNDARY =
            new NeoForgeVeilBoundaryCoordinator(RUNTIME, DOMAIN_LEVELS);
    private static final NeoForgeLawEffectCoordinator LAW_EFFECTS =
            new NeoForgeLawEffectCoordinator(RUNTIME, DOMAIN_LEVELS);
    private static final NeoForgeMemoryEffectCoordinator MEMORY_EFFECTS =
            new NeoForgeMemoryEffectCoordinator(RUNTIME, DOMAIN_LEVELS);
    private static final NeoForgeContinuityAnchorCoordinator CONTINUITY_ANCHORS =
            new NeoForgeContinuityAnchorCoordinator(RUNTIME, DOMAIN_LEVELS);
    private static final NeoForgeBreachCoordinator BREACHES =
            new NeoForgeBreachCoordinator(RUNTIME, DOMAIN_LEVELS);
    private static final NeoForgeVeilStitcherCoordinator VEIL_STITCHER =
            new NeoForgeVeilStitcherCoordinator(RUNTIME);
    private static final NeoForgeVeilforgedEquipmentCoordinator VEILFORGED_EQUIPMENT =
            new NeoForgeVeilforgedEquipmentCoordinator(RUNTIME);
    private static final NeoForgeStarterPocketService STARTER_POCKET =
            new NeoForgeStarterPocketService();
    private static final NeoForgeReturnAnchorResolver RETURN_RESOLVER =
            new NeoForgeReturnAnchorResolver();
    private static final NeoForgeDomainTravelExecutor DOMAIN_TRAVEL =
            new NeoForgeDomainTravelExecutor(RUNTIME, DOMAIN_LEVELS, STARTER_POCKET, RETURN_RESOLVER);
    private static final NeoForgePlayerPresenceCoordinator PLAYER_PRESENCE =
            new NeoForgePlayerPresenceCoordinator(RUNTIME, DOMAIN_LEVELS, DOMAIN_TRAVEL);
    private static final NeoForgeThresholdFrameCoordinator THRESHOLD_FRAMES =
            new NeoForgeThresholdFrameCoordinator(RUNTIME);
    private static final NeoForgeCoreUpgradeCoordinator CORE_UPGRADES =
            new NeoForgeCoreUpgradeCoordinator(RUNTIME);
    private static final NeoForgeCoreControlCoordinator CORE_CONTROLS =
            new NeoForgeCoreControlCoordinator(RUNTIME);
    private static final NeoForgeCoreRelocationCoordinator CORE_RELOCATION =
            new NeoForgeCoreRelocationCoordinator(RUNTIME);
    private static final NeoForgeGenesisSeedCoordinator GENESIS_SEED =
            new NeoForgeGenesisSeedCoordinator(RUNTIME);
    private static final NeoForgeThresholdDeactivationCoordinator THRESHOLD_DEACTIVATION =
            new NeoForgeThresholdDeactivationCoordinator(RUNTIME, DOMAIN_TRAVEL);
    private static final NeoForgeThresholdPortalTransit THRESHOLD_PORTAL_TRANSIT =
            new NeoForgeThresholdPortalTransit(RUNTIME, DOMAIN_LEVELS, DOMAIN_TRAVEL, RETURN_RESOLVER);

    public static VeilboundRuntime runtime() { return RUNTIME; }
    public static NeoForgeDomainLevelService domainLevels() { return DOMAIN_LEVELS; }
    public static NeoForgeDomainTravelExecutor domainTravel() { return DOMAIN_TRAVEL; }
    public static NeoForgePlayerPresenceCoordinator playerPresence() { return PLAYER_PRESENCE; }
    public static NeoForgeSpatialGeneratorController spatialGenerator() { return SPATIAL_GENERATOR; }
    public static NeoForgeThresholdPortalTransit thresholdPortalTransit() { return THRESHOLD_PORTAL_TRANSIT; }

    public Veilbound(IEventBus modBus, ModContainer modContainer) {
        VeilboundDataComponents.register(modBus);
        VeilboundBlocks.register(modBus);
        VeilboundBlockEntities.register(modBus);
        VeilboundEntities.register(modBus);
        VeilboundItems.register(modBus);
        VeilboundCreativeTabs.register(modBus);
        modBus.addListener(NeoForgeNetworking::register);
        modBus.addListener(VeilboundEntities::registerAttributes);
        modBus.addListener(NeoForgeVeilInterfaceCapabilities::register);
        modBus.addListener(NeoForgeSpatialGeneratorCapabilities::register);
        modBus.addListener(CONTINUITY_ANCHORS::registerTicketController);
        if (FMLEnvironment.getDist().isClient()) {
            VeilboundClient.init(modBus);
        }
        NeoForge.EVENT_BUS.addListener(MATTER_RECIPES::onAddReloadListeners);
        NeoForge.EVENT_BUS.addListener(MATTER_COMMANDS::onRegisterCommands);
        NeoForge.EVENT_BUS.addListener(DEFINITIONS::onAddReloadListeners);
        NeoForge.EVENT_BUS.addListener(MATTER_RECIPES::onDatapackSync);
        NeoForge.EVENT_BUS.addListener(PERSISTENCE::onServerStarted);
        NeoForge.EVENT_BUS.addListener(PLAYER_PRESENCE::onPlayerLoggedIn);
        NeoForge.EVENT_BUS.addListener(EventPriority.LOWEST, CONTINUITY_ANCHORS::onPlayerLoggedIn);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, CONTINUITY_ANCHORS::onPlayerLoggedOut);
        NeoForge.EVENT_BUS.addListener(PLAYER_PRESENCE::onPlayerLoggedOut);
        NeoForge.EVENT_BUS.addListener(PLAYER_PRESENCE::onPlayerChangedDimension);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, GENESIS_SEED::onRightClickBlock);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, CORE_RELOCATION::onRightClickBlock);
        NeoForge.EVENT_BUS.addListener(CORE_UPGRADES::onRightClickBlock);
        NeoForge.EVENT_BUS.addListener(CORE_CONTROLS::onRightClickBlock);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, GENESIS_SEED::onRightClickItem);
        NeoForge.EVENT_BUS.addListener(MEMORY_GAMEPLAY::onRightClickItem);
        NeoForge.EVENT_BUS.addListener(ENVIRONMENTAL_ZONES::onRightClickItem);
        NeoForge.EVENT_BUS.addListener(RESONANCE_LENS::onRightClickItem);
        NeoForge.EVENT_BUS.addListener(SPATIAL_GENERATOR::onRightClickItem);
        NeoForge.EVENT_BUS.addListener(VEIL_STITCHER::onRightClickItem);
        NeoForge.EVENT_BUS.addListener(ENGINEERING::onRightClickItem);
        NeoForge.EVENT_BUS.addListener(VEILFORGED_EQUIPMENT::onRightClickItem);
        NeoForge.EVENT_BUS.addListener(MEMORY_GAMEPLAY::onRightClickBlock);
        NeoForge.EVENT_BUS.addListener(ENVIRONMENTAL_ZONES::onRightClickBlock);
        NeoForge.EVENT_BUS.addListener(AXIOM_MONOLITH::onRightClickBlock);
        NeoForge.EVENT_BUS.addListener(BOUNDARY_PYLONS::onRightClickBlock);
        NeoForge.EVENT_BUS.addListener(ENGINEERING::onRightClickBlock);
        NeoForge.EVENT_BUS.addListener(VEILFORGED_EQUIPMENT::onRightClickBlock);
        NeoForge.EVENT_BUS.addListener(EventPriority.LOWEST, BOUNDARY_PYLONS::onPlaceBlock);
        NeoForge.EVENT_BUS.addListener(EventPriority.LOWEST, BOUNDARY_PYLONS::onBreakBlock);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, VEIL_BOUNDARY::onPlaceBlock);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, VEIL_BOUNDARY::onBreakBlock);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, VEIL_BOUNDARY::onFluidPlaceBlock);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, VEIL_BOUNDARY::onPistonPre);
        NeoForge.EVENT_BUS.addListener(EventPriority.LOWEST, CONTINUITY_ANCHORS::onPlaceBlock);
        NeoForge.EVENT_BUS.addListener(EventPriority.LOWEST, CONTINUITY_ANCHORS::onBreakBlock);
        NeoForge.EVENT_BUS.addListener(DOMAIN_EXPANSION::onServerTick);
        NeoForge.EVENT_BUS.addListener(VEIL_BOUNDARY::onServerTick);
        NeoForge.EVENT_BUS.addListener(MILESTONES::onServerTick);
        NeoForge.EVENT_BUS.addListener(LAW_EFFECTS::onServerTick);
        NeoForge.EVENT_BUS.addListener(MEMORY_EFFECTS::onServerTick);
        NeoForge.EVENT_BUS.addListener(ENVIRONMENTAL_ZONES::onServerTick);
        NeoForge.EVENT_BUS.addListener(LAW_EFFECTS::onNaturalSpawn);
        NeoForge.EVENT_BUS.addListener(LAW_EFFECTS::onExplosionDetonate);
        NeoForge.EVENT_BUS.addListener(BREACHES::onServerTick);
        NeoForge.EVENT_BUS.addListener(BREACHES::onMobGrief);
        NeoForge.EVENT_BUS.addListener(TRANSDUCER::onRightClickBlock);
        NeoForge.EVENT_BUS.addListener(THRESHOLD_FRAMES::onRightClickBlock);
        // LOWEST respects protection/claim mods that cancel block breaking earlier in the event.
        NeoForge.EVENT_BUS.addListener(EventPriority.LOWEST, VEILFORGED_EQUIPMENT::onBreakBlock);
        NeoForge.EVENT_BUS.addListener(EventPriority.LOWEST, THRESHOLD_DEACTIVATION::onBreakBlock);
        NeoForge.EVENT_BUS.addListener(THRESHOLD_PORTAL_TRANSIT::onPlayerTick);
        NeoForge.EVENT_BUS.addListener(VEILFORGED_EQUIPMENT::onLivingDamagePre);
        NeoForge.EVENT_BUS.addListener(VEILFORGED_EQUIPMENT::onPlayerTick);
        NeoForge.EVENT_BUS.addListener(THRESHOLD_PORTAL_TRANSIT::onPlayerLoggedOut);
    }
}
