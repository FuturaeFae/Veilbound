package dev.futurae.veilbound.platform.neoforge;

import java.util.List;

/** Immutable result of parsing one class of Veilbound datapack definitions. */
public record DatapackDefinitionSnapshot<T>(List<T> definitions, List<String> warnings) {
    public DatapackDefinitionSnapshot {
        definitions = List.copyOf(definitions);
        warnings = List.copyOf(warnings);
    }
}
