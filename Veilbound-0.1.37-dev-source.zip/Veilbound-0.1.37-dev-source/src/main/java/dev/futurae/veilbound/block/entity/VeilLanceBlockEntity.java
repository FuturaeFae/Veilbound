package dev.futurae.veilbound.block.entity;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.breach.ForcedBreachService;
import dev.futurae.veilbound.breach.VeilLanceMode;
import dev.futurae.veilbound.breach.VeilLancePolicy;
import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.registry.VeilboundBlockEntities;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.neoforged.neoforge.transfer.energy.EnergyHandler;
import net.neoforged.neoforge.transfer.energy.SimpleEnergyHandler;
import org.jspecify.annotations.Nullable;

/**
 * FE charges the physical lance; Core DE is paid only when the beam successfully tears the Veil.
 * FE already spent during an aborted charge is intentionally not refunded.
 */
public final class VeilLanceBlockEntity extends BlockEntity {
    private static final int FAILED_SHOT_COOLDOWN = 200;
    private final ConfigurableEnergyHandler energy = new ConfigurableEnergyHandler();
    private UUID ownerId;
    private Direction beamDirection = Direction.NORTH;
    private VeilLanceMode mode = VeilLanceMode.CONTROLLED;
    private boolean charging;
    private int chargeTicks;
    private long forgeEnergySpentThisCharge;
    private int cooldownTicks;
    private String lastStatus = "idle";
    private @Nullable BlockPos lastTarget;

    public VeilLanceBlockEntity(BlockPos pos, BlockState state) {
        super(VeilboundBlockEntities.VEIL_LANCE.get(), pos, state);
    }

    public void bindOwner(UUID ownerId) { if (this.ownerId == null) { this.ownerId = Objects.requireNonNull(ownerId); setChanged(); } }
    public @Nullable UUID ownerId() { return ownerId; }
    public Direction beamDirection() { return beamDirection; }
    public VeilLanceMode mode() { return mode; }
    public boolean charging() { return charging; }
    public int chargeTicks() { return chargeTicks; }
    public int cooldownTicks() { return cooldownTicks; }
    public String lastStatus() { return lastStatus; }
    public long storedForgeEnergy() { return energy.getAmountAsLong(); }
    public long forgeEnergyCapacity() { return energy.getCapacityAsLong(); }
    public @Nullable BlockPos lastTarget() { return lastTarget; }
    public EnergyHandler energyHandler(Direction side) { energy.applyPolicy(VeilLancePolicy.DEVELOPMENT_DEFAULT); return energy; }

    public VeilLanceMode cycleMode() {
        if (charging) return mode;
        mode = mode.next();
        lastStatus = "mode_changed";
        setChanged();
        return mode;
    }

    public Direction cycleBeamDirection() {
        if (charging) return beamDirection;
        Direction[] directions = Direction.values();
        beamDirection = directions[(beamDirection.ordinal() + 1) % directions.length];
        lastStatus = "direction_changed";
        lastTarget = null;
        setChanged();
        return beamDirection;
    }

    public boolean toggleCharging() {
        if (charging) {
            charging = false;
            chargeTicks = 0;
            forgeEnergySpentThisCharge = 0L;
            lastStatus = "charge_aborted";
            setChanged();
            return false;
        }
        if (cooldownTicks > 0) { lastStatus = "cooldown"; setChanged(); return false; }
        charging = true;
        chargeTicks = 0;
        forgeEnergySpentThisCharge = 0L;
        lastStatus = "charging";
        setChanged();
        return true;
    }

    public static void tick(Level level, BlockPos pos, BlockState state, VeilLanceBlockEntity be) {
        if (!(level instanceof ServerLevel serverLevel)) return;
        be.energy.applyPolicy(VeilLancePolicy.DEVELOPMENT_DEFAULT);
        if (be.cooldownTicks > 0) {
            be.cooldownTicks--;
            if (be.cooldownTicks == 0 && !be.charging) be.lastStatus = "idle";
            if (be.cooldownTicks % 20 == 0) be.setChanged();
        }
        if (!be.charging || be.ownerId == null) return;

        DomainRecord record = Veilbound.runtime().domains().getRecord(be.ownerId).orElse(null);
        if (record == null || !record.state().coreActive()
                || !record.identity().dimensionId().equals(level.dimension().identifier().toString())) {
            be.abort("domain_unavailable", 0);
            return;
        }
        VeilLancePolicy policy = VeilLancePolicy.DEVELOPMENT_DEFAULT;
        if (record.state().coreTier().ordinal() < policy.minimumTier().ordinal()) {
            be.abort("core_tier_too_low", 0);
            return;
        }
        BlockPos target = be.findBoundaryTarget(record.state().bounds(), policy.maxBeamRange());
        if (target == null) {
            be.abort("beam_obstructed_or_out_of_range", FAILED_SHOT_COOLDOWN);
            return;
        }
        be.lastTarget = target;
        be.renderBeam(serverLevel, target);

        long remainingFe = Math.max(0L, be.mode.forgeEnergyCost() - be.forgeEnergySpentThisCharge);
        if (remainingFe > 0) {
            long perTick = Math.min(remainingFe, be.mode.forgeEnergyPerTick());
            if (be.energy.getAmountAsLong() < perTick) {
                be.lastStatus = "waiting_for_fe";
                return;
            }
            be.energy.set((int) (be.energy.getAmountAsLong() - perTick));
            be.forgeEnergySpentThisCharge += perTick;
        }
        be.chargeTicks++;
        be.lastStatus = "charging";
        if (be.chargeTicks < be.mode.chargeTicks() || be.forgeEnergySpentThisCharge < be.mode.forgeEnergyCost()) {
            if (be.chargeTicks % 20 == 0) be.setChanged();
            return;
        }

        AxisDirection face = axisDirection(be.beamDirection);
        DomainPosition impact = new DomainPosition(target.getX(), target.getY(), target.getZ());
        var result = ForcedBreachService.open(
                record.state(), impact, face, be.mode, policy, level.getGameTime(), UUID.randomUUID(),
                Veilbound.runtime().stabilityPolicy().policy().breachPolicy().maximumFractureMeter());
        if (!result.opened()) {
            be.abort(result.reason(), FAILED_SHOT_COOLDOWN);
            return;
        }
        be.charging = false;
        be.chargeTicks = 0;
        be.forgeEnergySpentThisCharge = 0L;
        be.cooldownTicks = be.mode.cooldownTicks();
        be.lastStatus = "breach_formed";
        be.setChanged();
        serverLevel.sendParticles(ParticleTypes.REVERSE_PORTAL,
                target.getX() + 0.5, target.getY() + 0.5, target.getZ() + 0.5,
                be.mode == VeilLanceMode.OVERDRIVE ? 96 : 48, 0.8, 0.8, 0.8, 0.15);
    }

    private void abort(String status, int cooldown) {
        charging = false;
        chargeTicks = 0;
        forgeEnergySpentThisCharge = 0L;
        cooldownTicks = Math.max(cooldownTicks, cooldown);
        lastStatus = status;
        setChanged();
    }

    private @Nullable BlockPos findBoundaryTarget(DomainBounds bounds, int maxRange) {
        DomainPosition machine = new DomainPosition(worldPosition.getX(), worldPosition.getY(), worldPosition.getZ());
        if (!bounds.contains(machine) || level == null) return null;
        int distance = switch (beamDirection) {
            case EAST -> bounds.maxX() - worldPosition.getX();
            case WEST -> worldPosition.getX() - bounds.minX();
            case UP -> bounds.maxY() - worldPosition.getY();
            case DOWN -> worldPosition.getY() - bounds.minY();
            case SOUTH -> bounds.maxZ() - worldPosition.getZ();
            case NORTH -> worldPosition.getZ() - bounds.minZ();
        };
        if (distance < 1 || distance > maxRange) return null;
        BlockPos cursor = worldPosition;
        for (int step = 1; step <= distance; step++) {
            cursor = cursor.relative(beamDirection);
            if (!level.getBlockState(cursor).isAir()) return null;
        }
        return cursor.immutable();
    }

    private void renderBeam(ServerLevel level, BlockPos target) {
        if (level.getGameTime() % 3L != 0L) return;
        int dx = target.getX() - worldPosition.getX();
        int dy = target.getY() - worldPosition.getY();
        int dz = target.getZ() - worldPosition.getZ();
        int distance = Math.max(Math.abs(dx), Math.max(Math.abs(dy), Math.abs(dz)));
        int stride = mode == VeilLanceMode.OVERDRIVE ? 1 : 2;
        for (int step = 1; step <= distance; step += stride) {
            double x = worldPosition.getX() + 0.5 + beamDirection.getStepX() * step;
            double y = worldPosition.getY() + 0.5 + beamDirection.getStepY() * step;
            double z = worldPosition.getZ() + 0.5 + beamDirection.getStepZ() * step;
            level.sendParticles(ParticleTypes.REVERSE_PORTAL, x, y, z, 1, 0.03, 0.03, 0.03, 0.01);
        }
    }

    private static AxisDirection axisDirection(Direction direction) {
        return switch (direction) {
            case EAST -> AxisDirection.POSITIVE_X;
            case WEST -> AxisDirection.NEGATIVE_X;
            case UP -> AxisDirection.POSITIVE_Y;
            case DOWN -> AxisDirection.NEGATIVE_Y;
            case SOUTH -> AxisDirection.POSITIVE_Z;
            case NORTH -> AxisDirection.NEGATIVE_Z;
        };
    }

    @Override protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        if (ownerId != null) output.putString("owner", ownerId.toString());
        output.putInt("forge_energy", (int)Math.min(Integer.MAX_VALUE, energy.getAmountAsLong()));
        output.putString("direction", beamDirection.name());
        output.putString("mode", mode.name());
        output.putBoolean("charging", charging);
        output.putInt("charge_ticks", chargeTicks);
        output.putString("charge_fe", Long.toString(forgeEnergySpentThisCharge));
        output.putInt("cooldown_ticks", cooldownTicks);
        output.putString("status", lastStatus);
    }

    @Override protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        ownerId = input.getString("owner").flatMap(raw -> { try { return java.util.Optional.of(UUID.fromString(raw)); } catch (IllegalArgumentException ignored) { return java.util.Optional.empty(); } }).orElse(null);
        energy.set(Math.max(0, input.getIntOr("forge_energy", 0)));
        beamDirection = input.getString("direction").flatMap(raw -> { try { return java.util.Optional.of(Direction.valueOf(raw)); } catch (IllegalArgumentException ignored) { return java.util.Optional.empty(); } }).orElse(Direction.NORTH);
        mode = input.getString("mode").flatMap(raw -> { try { return java.util.Optional.of(VeilLanceMode.valueOf(raw)); } catch (IllegalArgumentException ignored) { return java.util.Optional.empty(); } }).orElse(VeilLanceMode.CONTROLLED);
        charging = input.getBooleanOr("charging", false);
        chargeTicks = Math.max(0, input.getIntOr("charge_ticks", 0));
        try { forgeEnergySpentThisCharge = Math.max(0L, Long.parseLong(input.getString("charge_fe").orElse("0"))); } catch (NumberFormatException ignored) { forgeEnergySpentThisCharge = 0L; }
        cooldownTicks = Math.max(0, input.getIntOr("cooldown_ticks", 0));
        lastStatus = input.getString("status").filter(raw -> !raw.isBlank()).orElse("idle");
    }

    private final class ConfigurableEnergyHandler extends SimpleEnergyHandler {
        private ConfigurableEnergyHandler() { super(VeilLancePolicy.DEVELOPMENT_DEFAULT.forgeEnergyCapacity(), VeilLancePolicy.DEVELOPMENT_DEFAULT.maxForgeEnergyInput(), 0); }
        private void applyPolicy(VeilLancePolicy policy) { capacity = policy.forgeEnergyCapacity(); maxInsert = policy.maxForgeEnergyInput(); maxExtract = 0; }
        @Override protected void onEnergyChanged(int previousAmount) { VeilLanceBlockEntity.this.setChanged(); }
    }
}
