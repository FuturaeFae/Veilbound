package dev.futurae.veilbound.platform.neoforge;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.memory.MemoryEffectPolicy;
import dev.futurae.veilbound.memory.MemoryEffectPolicyRegistry;
import java.io.Reader;
import java.util.Objects;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

/** Loads data/veilbound/veilbound/balance/memory_effects.json. */
public final class NeoForgeMemoryEffectPolicyReloadListener extends SimplePreparableReloadListener<MemoryEffectPolicy> {
    public static final Identifier LISTENER_ID = Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "memory_effect_policy");
    private static final Identifier RESOURCE_ID = Identifier.fromNamespaceAndPath(
            Veilbound.MOD_ID, "veilbound/balance/memory_effects.json");
    private final Gson gson = new Gson();
    private final MemoryEffectPolicyRegistry registry;

    public NeoForgeMemoryEffectPolicyReloadListener(MemoryEffectPolicyRegistry registry) {
        this.registry = Objects.requireNonNull(registry, "registry");
    }

    @Override
    protected MemoryEffectPolicy prepare(ResourceManager manager, ProfilerFiller profiler) {
        MemoryEffectPolicy fallback = MemoryEffectPolicy.DEVELOPMENT_DEFAULT;
        return manager.getResource(RESOURCE_ID).map(resource -> {
            try (Reader reader = resource.openAsReader()) {
                JsonElement parsed = gson.fromJson(reader, JsonElement.class);
                if (parsed == null || !parsed.isJsonObject()) throw new IllegalArgumentException("root must be an object");
                JsonObject root = parsed.getAsJsonObject();
                JsonObject fertility = object(root, "fertility");
                return new MemoryEffectPolicy(
                        integer(root, "evaluation_ticks", fallback.evaluationTicks()),
                        integer(root, "forced_rain_refresh_ticks", fallback.forcedRainRefreshTicks()),
                        integer(fertility, "pulse_ticks", fallback.fertilityPulseTicks()),
                        integer(fertility, "attempts_per_player", fallback.fertilityAttemptsPerPlayer()),
                        integer(fertility, "horizontal_radius", fallback.fertilityHorizontalRadius()),
                        integer(fertility, "vertical_radius", fallback.fertilityVerticalRadius()));
            } catch (Exception ex) {
                Veilbound.LOGGER.warn("Invalid {}: {}; using development default", RESOURCE_ID, ex.getMessage());
                return fallback;
            }
        }).orElse(fallback);
    }

    @Override
    protected void apply(MemoryEffectPolicy policy, ResourceManager manager, ProfilerFiller profiler) {
        registry.replace(policy);
        Veilbound.LOGGER.info(
                "Loaded Memory effect policy: evaluation {} ticks, rain refresh {} ticks, fertility {} attempts/player every {} ticks",
                policy.evaluationTicks(), policy.forcedRainRefreshTicks(),
                policy.fertilityAttemptsPerPlayer(), policy.fertilityPulseTicks());
    }

    private static JsonObject object(JsonObject root, String key) {
        return root.has(key) && root.get(key).isJsonObject() ? root.getAsJsonObject(key) : new JsonObject();
    }

    private static int integer(JsonObject object, String key, int fallback) {
        return object.has(key) ? object.get(key).getAsInt() : fallback;
    }
}
