package dev.futurae.veilbound.memory;

import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import dev.futurae.veilbound.environment.EnvironmentZoneResolver;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** Resolves the currently active, earned Orrery blend into a safe runtime profile. */
public final class MemoryEnvironmentRuntime {
    private final DomainOrreryService orrery = new DomainOrreryService();
    private final MemoryRuntimeSemantics semantics = new MemoryRuntimeSemantics();
    private final EnvironmentZoneResolver zones = new EnvironmentZoneResolver();

    public Resolution resolve(DomainState state, MemoryProgressState progress, MemoryRegistry registry) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(progress, "progress");
        Objects.requireNonNull(registry, "registry");
        if (progress.activeOrreryMemoryIds().isEmpty()) return Resolution.inactive("no_memories_selected");

        DomainOrreryService.SelectionResult current = orrery.current(state, progress, registry);
        if (!current.selected()) return Resolution.inactive(current.reason());
        return Resolution.active(current.memoryIds(), current.environmentalProfile(), semantics.snapshot(current.environmentalProfile()));
    }

    /**
     * Resolves the environment at one Domain position. A named Environmental Zone overrides the
     * global Orrery there; when that zone enables blending, lower-priority zones and finally the
     * global Orrery may fill otherwise-unclaimed profile keys.
     */
    public Resolution resolveAt(
            DomainState state, MemoryProgressState progress, MemoryRegistry registry, DomainPosition position) {
        Objects.requireNonNull(position, "position");
        Resolution base = resolve(state, progress, registry);
        Map<String, String> baseProfile = base.active() ? base.environmentalProfile() : Map.of();
        List<String> baseIds = base.active() ? base.memoryIds() : List.of();
        EnvironmentZoneResolver.Resolution zoned = zones.resolve(state, position, registry, baseProfile, baseIds);
        if (!zoned.zoned()) return base;
        return Resolution.active(
                zoned.memoryIds(), zoned.environmentalProfile(), semantics.snapshot(zoned.environmentalProfile()),
                zoned.primaryZoneName());
    }

    public record Resolution(
            boolean active,
            String reason,
            List<String> memoryIds,
            Map<String, String> environmentalProfile,
            MemoryRuntimeSemantics.Snapshot semantics,
            String zoneName) {
        public Resolution {
            memoryIds = List.copyOf(memoryIds);
            environmentalProfile = Collections.unmodifiableMap(new LinkedHashMap<>(environmentalProfile));
            Objects.requireNonNull(semantics, "semantics");
            zoneName = zoneName == null ? "" : zoneName;
        }

        public static Resolution inactive(String reason) {
            return new Resolution(false, reason, List.of(), Map.of(), MemoryRuntimeSemantics.Snapshot.empty(), "");
        }

        public static Resolution active(List<String> ids, Map<String, String> profile, MemoryRuntimeSemantics.Snapshot semantics) {
            return new Resolution(true, "ok", ids, profile, semantics, "");
        }
        public static Resolution active(List<String> ids, Map<String, String> profile, MemoryRuntimeSemantics.Snapshot semantics, String zoneName) {
            return new Resolution(true, "ok", ids, profile, semantics, zoneName);
        }
    }
}
