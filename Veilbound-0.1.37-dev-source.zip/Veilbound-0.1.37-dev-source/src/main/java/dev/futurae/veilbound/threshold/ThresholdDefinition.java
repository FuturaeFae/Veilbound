package dev.futurae.veilbound.threshold;

import dev.futurae.veilbound.domain.DomainPosition;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/**
 * Permanent controlled entrance/exit point bound to one owner's Domain.
 *
 * <p>The source structure may exist in any dimension. {@code domainPosition} is the preferred
 * arrival anchor inside the owner's personal Domain; source block membership is persisted so
 * active portal blocks can resolve their binding after a restart without trusting client state.</p>
 */
public record ThresholdDefinition(
        UUID id,
        UUID ownerId,
        String sourceDimensionId,
        Set<DomainPosition> sourcePositions,
        DomainPosition domainPosition,
        ThresholdAccess access) {
    public ThresholdDefinition {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(ownerId, "ownerId");
        Objects.requireNonNull(sourceDimensionId, "sourceDimensionId");
        sourcePositions = Set.copyOf(Objects.requireNonNull(sourcePositions, "sourcePositions"));
        Objects.requireNonNull(domainPosition, "domainPosition");
        Objects.requireNonNull(access, "access");
    }

    /** Compatibility constructor for persistence/tests created before source-structure binding. */
    public ThresholdDefinition(UUID id, UUID ownerId, DomainPosition domainPosition, ThresholdAccess access) {
        this(id, ownerId, "", Set.of(), domainPosition, access);
    }

    public boolean containsSource(String dimensionId, DomainPosition position) {
        return sourceDimensionId.equals(dimensionId) && sourcePositions.contains(position);
    }
}
