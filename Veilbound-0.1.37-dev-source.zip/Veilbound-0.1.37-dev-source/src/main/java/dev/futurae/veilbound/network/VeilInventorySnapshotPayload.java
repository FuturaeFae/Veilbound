package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.neoforged.neoforge.transfer.item.ItemResource;

/** Bounded server snapshot rendered by the client-only Veil Inventory/Matter terminal screen. */
public record VeilInventorySnapshotPayload(
        boolean allowed,
        String reason,
        int page,
        int pageCount,
        long totalItems,
        long maxItems,
        int distinctTypes,
        int maxTypes,
        boolean craftingUnlocked,
        boolean transmutationUnlocked,
        long storedMatter,
        int learnedPatterns,
        int matchingPatterns,
        List<Entry> entries) implements CustomPacketPayload {

    public static final int MAX_NETWORK_ENTRIES = 45;
    public static final Type<VeilInventorySnapshotPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "veil_inventory_snapshot"));

    public static final StreamCodec<RegistryFriendlyByteBuf, VeilInventorySnapshotPayload> STREAM_CODEC =
            new StreamCodec<>() {
                @Override
                public VeilInventorySnapshotPayload decode(RegistryFriendlyByteBuf buffer) {
                    boolean allowed = buffer.readBoolean();
                    String reason = buffer.readUtf(128);
                    int page = Math.max(0, buffer.readVarInt());
                    int pageCount = Math.max(1, buffer.readVarInt());
                    long totalItems = Math.max(0L, buffer.readVarLong());
                    long maxItems = Math.max(0L, buffer.readVarLong());
                    int distinctTypes = Math.max(0, buffer.readVarInt());
                    int maxTypes = Math.max(0, buffer.readVarInt());
                    boolean craftingUnlocked = buffer.readBoolean();
                    boolean transmutationUnlocked = buffer.readBoolean();
                    long storedMatter = Math.max(0L, buffer.readVarLong());
                    int learnedPatterns = Math.max(0, buffer.readVarInt());
                    int matchingPatterns = Math.max(0, buffer.readVarInt());
                    int count = buffer.readVarInt();
                    if (count < 0 || count > MAX_NETWORK_ENTRIES) {
                        throw new IllegalArgumentException("Invalid Veil Inventory snapshot entry count: " + count);
                    }
                    List<Entry> entries = new ArrayList<>(count);
                    for (int i = 0; i < count; i++) {
                        entries.add(new Entry(
                                ItemResource.STREAM_CODEC.decode(buffer),
                                buffer.readVarLong(),
                                buffer.readVarLong(),
                                buffer.readVarLong(),
                                buffer.readBoolean(),
                                buffer.readBoolean()));
                    }
                    return new VeilInventorySnapshotPayload(allowed, reason, page, pageCount, totalItems, maxItems,
                            distinctTypes, maxTypes, craftingUnlocked, transmutationUnlocked, storedMatter,
                            learnedPatterns, matchingPatterns, entries);
                }

                @Override
                public void encode(RegistryFriendlyByteBuf buffer, VeilInventorySnapshotPayload payload) {
                    buffer.writeBoolean(payload.allowed());
                    buffer.writeUtf(payload.reason(), 128);
                    buffer.writeVarInt(payload.page());
                    buffer.writeVarInt(payload.pageCount());
                    buffer.writeVarLong(payload.totalItems());
                    buffer.writeVarLong(payload.maxItems());
                    buffer.writeVarInt(payload.distinctTypes());
                    buffer.writeVarInt(payload.maxTypes());
                    buffer.writeBoolean(payload.craftingUnlocked());
                    buffer.writeBoolean(payload.transmutationUnlocked());
                    buffer.writeVarLong(payload.storedMatter());
                    buffer.writeVarInt(payload.learnedPatterns());
                    buffer.writeVarInt(payload.matchingPatterns());
                    int count = Math.min(MAX_NETWORK_ENTRIES, payload.entries().size());
                    buffer.writeVarInt(count);
                    for (int i = 0; i < count; i++) {
                        Entry entry = payload.entries().get(i);
                        ItemResource.STREAM_CODEC.encode(buffer, entry.resource());
                        buffer.writeVarLong(entry.storedCount());
                        buffer.writeVarLong(entry.matterCost());
                        buffer.writeVarLong(entry.affordableCount());
                        buffer.writeBoolean(entry.favorite());
                        buffer.writeBoolean(entry.recent());
                    }
                }
            };

    public VeilInventorySnapshotPayload {
        reason = reason == null ? "unknown" : reason;
        page = Math.max(0, page);
        pageCount = Math.max(1, pageCount);
        storedMatter = Math.max(0L, storedMatter);
        learnedPatterns = Math.max(0, learnedPatterns);
        matchingPatterns = Math.max(0, matchingPatterns);
        entries = List.copyOf(entries == null ? List.of() : entries);
    }

    /** Compatibility constructor from the 0.1.17 terminal payload. */
    public VeilInventorySnapshotPayload(
            boolean allowed, String reason, int page, int pageCount, long totalItems, long maxItems,
            int distinctTypes, int maxTypes, boolean craftingUnlocked, boolean transmutationUnlocked,
            long storedMatter, int learnedPatterns, List<Entry> entries) {
        this(allowed, reason, page, pageCount, totalItems, maxItems, distinctTypes, maxTypes,
                craftingUnlocked, transmutationUnlocked, storedMatter, learnedPatterns, learnedPatterns, entries);
    }

    public static VeilInventorySnapshotPayload denied(String reason) {
        return new VeilInventorySnapshotPayload(false, reason, 0, 1, 0, 0, 0, 0,
                false, false, 0, 0, 0, List.of());
    }

    public record Entry(
            ItemResource resource,
            long storedCount,
            long matterCost,
            long affordableCount,
            boolean favorite,
            boolean recent) {
        public Entry {
            if (resource == null) resource = ItemResource.EMPTY;
            if (storedCount < 0) throw new IllegalArgumentException("storedCount must be >= 0");
            if (matterCost < 0) throw new IllegalArgumentException("matterCost must be >= 0");
            if (affordableCount < 0) throw new IllegalArgumentException("affordableCount must be >= 0");
        }

        public Entry(ItemResource resource, long storedCount, long matterCost, long affordableCount) {
            this(resource, storedCount, matterCost, affordableCount, false, false);
        }
    }

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
