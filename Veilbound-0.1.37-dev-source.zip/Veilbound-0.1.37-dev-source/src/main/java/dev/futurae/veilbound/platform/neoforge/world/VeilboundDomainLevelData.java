package dev.futurae.veilbound.platform.neoforge.world;

import dev.futurae.veilbound.domain.DomainState;
import java.util.Objects;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.DerivedLevelData;

/**
 * Minimal persisted metadata adapter for a Veilbound Domain.
 *
 * <p>Minecraft 26.1+ moved mutable clock/weather state out of {@code LevelData}. Domain-local
 * gamerules, remembered clock time and remembered weather therefore live on
 * {@link VeilboundServerLevel}; this class intentionally delegates only ordinary level metadata.
 * Keeping this adapter small avoids relying on removed pre-26.1 LevelData methods.</p>
 */
public final class VeilboundDomainLevelData extends DerivedLevelData {
    private final DomainState state;

    public VeilboundDomainLevelData(MinecraftServer server, DomainState state) {
        super(
                Objects.requireNonNull(server, "server").getWorldData(),
                server.overworld().getLevelData());
        this.state = Objects.requireNonNull(state, "state");
    }

    public DomainState domainState() { return state; }
}
