package dev.futurae.veilbound.equipment;

/** Boundary Spade modes. TERRAFORM removes a protection-safe 3x3 matching plane around the primary break. */
public enum BoundarySpadeMode {
    PRECISION(0, 0, 0),
    TERRAFORM(1, 8, 40);

    private final int id;
    private final int maxExtraBlocks;
    private final long dePerExtraBlock;
    BoundarySpadeMode(int id, int maxExtraBlocks, long dePerExtraBlock) {
        this.id=id; this.maxExtraBlocks=maxExtraBlocks; this.dePerExtraBlock=dePerExtraBlock;
    }
    public int id(){ return id; }
    public int maxExtraBlocks(){ return maxExtraBlocks; }
    public long dePerExtraBlock(){ return dePerExtraBlock; }
    public BoundarySpadeMode next(){ return this==PRECISION ? TERRAFORM : PRECISION; }
    public static BoundarySpadeMode fromId(int id){ return id==TERRAFORM.id ? TERRAFORM : PRECISION; }
}
