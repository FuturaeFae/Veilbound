package dev.futurae.veilbound.platform.neoforge.threshold;

import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.platform.neoforge.travel.NeoForgeDomainTravelExecutor;
import dev.futurae.veilbound.registry.VeilboundBlocks;
import dev.futurae.veilbound.runtime.VeilboundRuntime;
import dev.futurae.veilbound.threshold.GuestThresholdSession;
import dev.futurae.veilbound.threshold.ThresholdDeactivationService;
import dev.futurae.veilbound.threshold.ThresholdDefinition;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.event.level.block.BreakBlockEvent;

/**
 * Turns a player break on any active portal cell into an atomic whole-Threshold teardown.
 *
 * <p>Guests tied to this exact Threshold are evacuated first. Only after all of them are safely
 * out does the structure revert to Threshold Frame blocks and the persistent binding disappear.
 * If any guest cannot be returned, the portal remains active and may be retried later.</p>
 */
public final class NeoForgeThresholdDeactivationCoordinator {
    private final VeilboundRuntime runtime;
    private final NeoForgeDomainTravelExecutor domainTravel;
    private final ThresholdDeactivationService deactivation;

    public NeoForgeThresholdDeactivationCoordinator(
            VeilboundRuntime runtime,
            NeoForgeDomainTravelExecutor domainTravel) {
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        this.domainTravel = Objects.requireNonNull(domainTravel, "domainTravel");
        this.deactivation = new ThresholdDeactivationService(runtime.thresholds(), runtime.thresholdSessions());
    }

    public void onBreakBlock(BreakBlockEvent event) {
        if (!event.getState().is(VeilboundBlocks.THRESHOLD_PORTAL.get())) return;

        if (!(event.getPlayer() instanceof ServerPlayer breaker)) return;

        // Suppress vanilla's one-cell break on the authoritative side. The server either commits
        // the entire Threshold teardown or leaves every portal cell intact. NeoForge's notify path
        // repairs the client prediction when we cancel here.
        event.setCanceled(true);
        event.setNotifyClient(true);

        Level level = breaker.level();
        String dimensionId = level.dimension().identifier().toString();
        BlockPos broken = event.getPos();
        ThresholdDeactivationService.PlanResult planResult = deactivation.plan(
                dimensionId,
                new DomainPosition(broken.getX(), broken.getY(), broken.getZ()));
        if (!planResult.allowed()) return;

        ThresholdDeactivationService.DeactivationPlan plan = planResult.plan();
        MinecraftServer server = breaker.getServer();
        if (server == null) return;

        // Evacuate only sessions that entered through this exact Threshold. A different Threshold
        // owned by the same player remains usable and its guests remain untouched.
        for (GuestThresholdSession session : plan.guests()) {
            ServerPlayer guest = server.getPlayerList().getPlayer(session.guestId());
            if (guest == null) {
                // Disconnect safety normally clears sessions before this can happen. If it does,
                // preserve the active portal rather than deleting somebody's only known return path.
                return;
            }
            NeoForgeDomainTravelExecutor.TravelResult result = domainTravel.exitGuestDomain(server, guest, session);
            if (!result.success()) return;
        }

        ThresholdDefinition threshold = plan.threshold();
        List<RestoredCell> restored = new ArrayList<>(threshold.sourcePositions().size());
        BlockState frameState = VeilboundBlocks.THRESHOLD_FRAME.get().defaultBlockState();

        // Restore the complete persisted structure first. Keep enough old state to reverse the
        // visual mutation if any set fails or if the binding cannot be committed afterward.
        for (DomainPosition source : threshold.sourcePositions()) {
            BlockPos pos = new BlockPos(source.x(), source.y(), source.z());
            BlockState oldState = level.getBlockState(pos);
            if (!oldState.is(VeilboundBlocks.THRESHOLD_PORTAL.get())) {
                rollback(level, restored);
                return;
            }
            if (!level.setBlockAndUpdate(pos, frameState)) {
                rollback(level, restored);
                return;
            }
            restored.add(new RestoredCell(pos, oldState));
        }

        ThresholdDeactivationService.CommitResult committed = deactivation.commit(plan);
        if (!committed.success()) {
            rollback(level, restored);
        }
    }

    private static void rollback(Level level, List<RestoredCell> restored) {
        for (int i = restored.size() - 1; i >= 0; i--) {
            RestoredCell cell = restored.get(i);
            level.setBlockAndUpdate(cell.pos(), cell.oldState());
        }
    }

    private record RestoredCell(BlockPos pos, BlockState oldState) {}
}
