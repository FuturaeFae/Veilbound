package dev.futurae.veilbound.platform.neoforge.inventory;

import dev.futurae.veilbound.registry.VeilboundBlockEntities;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;

/** Exposes Veil Interface storage to hoppers and generic NeoForge item-transfer automation. */
public final class NeoForgeVeilInterfaceCapabilities {
    private NeoForgeVeilInterfaceCapabilities() {}

    public static void register(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(
                Capabilities.Item.BLOCK,
                VeilboundBlockEntities.VEIL_INTERFACE.get(),
                (blockEntity, side) -> blockEntity.itemHandler(side));
        event.registerBlockEntity(
                Capabilities.Energy.BLOCK,
                VeilboundBlockEntities.DIMENSIONAL_TRANSDUCER.get(),
                (blockEntity, side) -> blockEntity.energyHandler(side));
        event.registerBlockEntity(
                Capabilities.Energy.BLOCK,
                VeilboundBlockEntities.VEIL_LANCE.get(),
                (blockEntity, side) -> blockEntity.energyHandler(side));
        event.registerBlockEntity(
                Capabilities.Item.BLOCK,
                VeilboundBlockEntities.DIMENSIONAL_TRANSDUCER.get(),
                (blockEntity, side) -> blockEntity.matterInputHandler(side));
        event.registerBlockEntity(
                Capabilities.Item.BLOCK,
                VeilboundBlockEntities.ENGINEERING_STATION.get(),
                (blockEntity, side) -> blockEntity.automationHandler(side));
    }
}
