package dev.futurae.veilbound.platform.neoforge.mixin;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.attribute.EnvironmentAttributeSystem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Client-only narrow accessor used to install Veilbound's per-Domain 26.2 attribute projection. */
@Mixin(ClientLevel.class)
public interface ClientLevelEnvironmentAccessor {
    @Accessor("environmentAttributes")
    @Mutable
    void veilbound$setEnvironmentAttributes(EnvironmentAttributeSystem environmentAttributes);
}
