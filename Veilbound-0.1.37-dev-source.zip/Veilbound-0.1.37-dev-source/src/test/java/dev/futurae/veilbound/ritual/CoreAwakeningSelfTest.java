package dev.futurae.veilbound.ritual;

import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import dev.futurae.veilbound.upgrade.UpgradeIngredient;
import java.util.List;
import java.util.UUID;

public final class CoreAwakeningSelfTest {
    public static void main(String[] args) {
        CoreAwakeningDefinition definition = new CoreAwakeningDefinition(List.of(
                new UpgradeIngredient("minecraft:amethyst_shard", 4),
                new UpgradeIngredient("minecraft:ender_pearl", 1)));
        CoreAwakeningProgress progress = new CoreAwakeningProgress(definition);
        DomainState state = new DomainState(UUID.randomUUID());

        eq(4, progress.feed("minecraft:amethyst_shard", 99), "excess ritual items must not be consumed");
        eq(0, progress.feed("minecraft:dirt", 99), "unneeded item rejected");
        eq("domain_too_small", progress.finalizeAt(state, DomainPosition.ORIGIN).reason(), "must expand first");

        state.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        eq("not_domain_origin", progress.finalizeAt(state, new DomainPosition(1, 0, 0)).reason(), "origin required");
        eq("requirements_incomplete", progress.finalizeAt(state, DomainPosition.ORIGIN).reason(), "all ingredients required");
        eq(1, progress.feed("minecraft:ender_pearl", 1), "remaining ingredient accepted");
        truth(progress.finalizeAt(state, DomainPosition.ORIGIN).awakened(), "completed ritual awakens Core");
        truth(state.coreActive(), "Core state transitioned");
        System.out.println("CoreAwakeningSelfTest: PASS");
    }

    private static void eq(long expected, long actual, String msg) {
        if (expected != actual) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual);
    }
    private static void eq(String expected, String actual, String msg) {
        if (!expected.equals(actual)) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String msg) { if (!value) throw new AssertionError(msg); }
}
