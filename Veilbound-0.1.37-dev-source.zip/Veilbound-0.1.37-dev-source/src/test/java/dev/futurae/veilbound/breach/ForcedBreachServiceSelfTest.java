package dev.futurae.veilbound.breach;

import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import java.util.UUID;

public final class ForcedBreachServiceSelfTest {
    public static void main(String[] args) {
        UUID owner = UUID.randomUUID();
        DomainState state = new DomainState(owner);
        state.setBounds(new dev.futurae.veilbound.domain.DomainBounds(-2, 0, -2, 2, 2, 2));
        state.awakenCore(DomainPosition.ORIGIN);
        state.setCoreTier(CoreTier.RESONANT);
        state.setDimensionalEnergy(1_000_000L);
        var policy = VeilLancePolicy.DEVELOPMENT_DEFAULT;
        var bad = ForcedBreachService.open(state, DomainPosition.ORIGIN, AxisDirection.POSITIVE_X,
                VeilLanceMode.CONTROLLED, policy, 10L, UUID.randomUUID(), 300.0);
        require(!bad.opened() && bad.reason().equals("invalid_boundary_target"), "interior impact rejected");
        long before = state.dimensionalEnergy();
        var ok = ForcedBreachService.open(state, new DomainPosition(2, 1, 0), AxisDirection.POSITIVE_X,
                VeilLanceMode.CONTROLLED, policy, 20L, UUID.randomUUID(), 300.0);
        require(ok.opened(), "valid face shot opens breach");
        require(ok.breach().severity() == BreachSeverity.SEVERE, "controlled severity");
        require(state.dimensionalEnergy() == before - VeilLanceMode.CONTROLLED.dimensionalEnergyCost(), "DE committed once");
        require(state.fractureMeter() == VeilLanceMode.CONTROLLED.fractureShock(), "stability shock applied");
        System.out.println("PASS ForcedBreachServiceSelfTest");
    }
    private static void require(boolean condition, String label) { if (!condition) throw new AssertionError(label); }
}
