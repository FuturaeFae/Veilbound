package dev.futurae.veilbound.law;

import java.util.Set;

public final class LawAxiomAttunementSelfTest {
    public static void main(String[] args) {
        LawRegistry registry = new LawRegistry();
        LawDefinition hostility = new LawDefinition(
                "veilbound:hostility", "Hostility", 0, Set.of(), Set.of(), Set.of("veilbound:hostility"),
                "veilbound:axiom_of_hostility");
        LawDefinition fauna = new LawDefinition(
                "veilbound:fauna", "Fauna", 0, Set.of(), Set.of(), Set.of("veilbound:fauna"),
                "veilbound:axiom_of_fauna");
        registry.replaceAll(java.util.List.of(hostility, fauna));

        var attune = LawAxiomAttunementService.plan(null, "veilbound:axiom_of_hostility", registry);
        truth(attune.allowed(), "matching physical Axiom attunes");
        eq("veilbound:hostility", attune.law().id(), "correct Law selected by item");
        eq(1, attune.itemsConsumed(), "exactly one Axiom is consumed");

        var permanent = LawAxiomAttunementService.plan("veilbound:hostility", "veilbound:axiom_of_fauna", registry);
        truth(!permanent.allowed(), "attuned Monolith cannot be overwritten");
        eq("permanently_attuned", permanent.reason(), "permanent dedication reason");

        var unrelated = LawAxiomAttunementService.plan(null, "minecraft:stick", registry);
        truth(!unrelated.allowed(), "unrelated item rejected");
        eq("invalid_axiom", unrelated.reason(), "invalid item reason");

        LawDefinition duplicate = new LawDefinition(
                "example:duplicate", "Duplicate", 0, Set.of(), Set.of(), Set.of(),
                "veilbound:axiom_of_hostility");
        registry.replaceAll(java.util.List.of(hostility, duplicate));
        var ambiguous = LawAxiomAttunementService.plan(null, "veilbound:axiom_of_hostility", registry);
        truth(!ambiguous.allowed(), "one physical item may not silently represent two Laws");
        eq("ambiguous_axiom_item", ambiguous.reason(), "ambiguous mapping fails closed");

        System.out.println("LawAxiomAttunementSelfTest: PASS");
    }

    private static void eq(String expected, String actual, String label) {
        if (!expected.equals(actual)) throw new AssertionError(label + ": expected=" + expected + " actual=" + actual);
    }
    private static void eq(int expected, int actual, String label) {
        if (expected != actual) throw new AssertionError(label + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean condition, String label) { if (!condition) throw new AssertionError(label); }
}
