package dev.futurae.veilbound.domain;

import dev.futurae.veilbound.breach.Breach;
import dev.futurae.veilbound.breach.BreachSeverity;
import dev.futurae.veilbound.domain.BoundaryPylonSpeed;
import dev.futurae.veilbound.inventory.VeilStackKey;
import dev.futurae.veilbound.persistence.VeilboundPersistenceSnapshot;
import dev.futurae.veilbound.persistence.VeilboundSnapshotBinaryCodec;
import dev.futurae.veilbound.threshold.ThresholdAccess;
import dev.futurae.veilbound.threshold.ThresholdDefinition;
import dev.futurae.veilbound.threshold.ThresholdRegistry;
import dev.futurae.veilbound.travel.ReturnAnchor;
import java.util.UUID;

public final class FullPersistenceSelfTest {
    public static void main(String[] args) {
        UUID owner = UUID.randomUUID();
        UUID guest = UUID.randomUUID();
        DomainRepository domains = new DomainRepository();
        DomainRecord record = domains.createRecord(owner, 42424242L);
        DomainState state = record.state();
        state.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        state.awakenCore(DomainPosition.ORIGIN);
        state.setCoreTier(CoreTier.ANCHORED);
        state.setDimensionalEnergy(123_456);
        state.imposeLaw("veilbound:law/test");
        state.unlockMemory("veilbound:memory/test");
        state.completeMilestone("veilbound:core_awakened");
        state.completeMilestone("veilbound:first_memory_archived");
        state.unlockFeature(DomainFeature.VEIL_INVENTORY);
        state.unlockFeature(DomainFeature.VEIL_CRAFTING);
        state.unlockFeature(DomainFeature.VEIL_TRANSMUTATION);
        state.addBreach(new Breach(UUID.randomUUID(), DomainPosition.ORIGIN, AxisDirection.NEGATIVE_X, BreachSeverity.MINOR, true, 99));
        state.addContinuityAnchor(new DomainPosition(1, 0, 1));
        state.setFractureMeter(73.25);
        state.setDayTime(6_543L);
        state.setWeatherState(40, true, 500, false, 700);
        state.setGlobalExpansionEnabled(false);
        state.setPylon(new BoundaryPylonState(
                AxisDirection.NEGATIVE_Z, true, true, new DomainPosition(0, 0, -2), BoundaryPylonSpeed.FORCED));
        state.feedCoreUpgradeItem("minecraft:diamond", 7, 16);
        record.veilInventory().replaceFromPersistence(java.util.Map.of(
                new VeilStackKey("minecraft:diamond_sword", "{minecraft:damage:7}"), 3L));
        record.matterTransmutation().replace(987_654L,
                java.util.Set.of("minecraft:cobblestone", "minecraft:oak_log"),
                java.util.Set.of("minecraft:cobblestone"),
                java.util.List.of("minecraft:oak_log", "minecraft:cobblestone"));
        record.memoryProgress().capture("veilbound:test_memory");
        record.memoryProgress().setActiveOrreryMemoryIds(java.util.List.of("veilbound:memory/test"));
        record.markStarterPocketInitialized();
        record.setOwnerReturnAnchor(new ReturnAnchor("minecraft:the_nether", 1.5, 80, 2.5, 90, -5));

        ThresholdRegistry thresholds = new ThresholdRegistry();
        ThresholdAccess access = new ThresholdAccess();
        access.invite(guest);
        access.setPublicAccess(true);
        UUID thresholdId = UUID.randomUUID();
        thresholds.add(new ThresholdDefinition(
                thresholdId, owner, "minecraft:overworld",
                java.util.Set.of(new DomainPosition(10, 64, 10), new DomainPosition(10, 65, 10)),
                new DomainPosition(1, 0, 1), access));

        String payload = VeilboundSnapshotBinaryCodec.encode(VeilboundPersistenceSnapshot.capture(domains, thresholds));
        VeilboundPersistenceSnapshot decoded = VeilboundSnapshotBinaryCodec.decode(payload);
        DomainRepository restoredDomains = new DomainRepository();
        ThresholdRegistry restoredThresholds = new ThresholdRegistry();
        decoded.restoreInto(restoredDomains, restoredThresholds);

        DomainRecord restored = restoredDomains.getRecord(owner).orElseThrow();
        truth(restored.identity().seed() == 42424242L, "seed");
        truth(restored.identity().dimensionId().equals(DomainIdentity.dimensionIdFor(owner)), "dimension id");
        truth(restored.state().coreTier() == CoreTier.ANCHORED, "core tier");
        truth(restored.state().dimensionalEnergy() == 123_456, "DE");
        truth(restored.state().hasOpenBreach(), "breach");
        truth(restored.state().continuityAnchors().contains(new DomainPosition(1, 0, 1)), "continuity anchor");
        truth(Double.compare(restored.state().fractureMeter(), 73.25) == 0, "fracture meter");
        truth(restored.state().dayTime() == 6_543L, "Domain day time persistence");
        truth(restored.state().clearWeatherTime() == 40, "clear-weather timer persistence");
        truth(restored.state().raining(), "rain persistence");
        truth(restored.state().rainTime() == 500, "rain timer persistence");
        truth(!restored.state().thundering(), "thunder boolean persistence");
        truth(restored.state().thunderTime() == 700, "thunder timer persistence");
        truth(!restored.state().globalExpansionEnabled(), "global expansion toggle persistence");
        truth(restored.state().pylons().get(AxisDirection.NEGATIVE_Z).blockPosition().equals(new DomainPosition(0, 0, -2)),
                "Boundary Pylon physical binding persistence");
        truth(restored.state().pylons().get(AxisDirection.NEGATIVE_Z).speed() == BoundaryPylonSpeed.FORCED,
                "Boundary Pylon speed persistence");
        truth(restored.state().coreUpgradeFedItems().getOrDefault("minecraft:diamond", 0L) == 7L,
                "Core tier fed-item progress persistence");
        truth(restored.starterPocketInitialized(), "starter pocket initialized");
        truth(restored.state().completedMilestoneIds().contains("veilbound:core_awakened"), "milestone persistence");
        truth(restored.state().completedMilestoneIds().contains("veilbound:first_memory_archived"), "second milestone persistence");
        truth(restored.state().hasFeature(DomainFeature.VEIL_INVENTORY), "Veil Inventory unlock");
        truth(restored.veilInventory().count(new VeilStackKey("minecraft:diamond_sword", "{minecraft:damage:7}")) == 3L,
                "Veil Inventory exact stack persistence");
        truth(restored.state().hasFeature(DomainFeature.VEIL_TRANSMUTATION), "Veil Transmutation unlock");
        truth(restored.matterTransmutation().storedMatter() == 987_654L, "stored Matter persistence");
        truth(restored.matterTransmutation().knows("minecraft:cobblestone"), "Matter pattern persistence");
        truth(restored.matterTransmutation().favorite("minecraft:cobblestone"), "Matter favorite persistence");
        truth(restored.matterTransmutation().recentItemIds().equals(
                java.util.List.of("minecraft:oak_log", "minecraft:cobblestone")), "Matter recent order persistence");
        truth(restored.ownerReturnAnchor().orElseThrow().dimensionId().equals("minecraft:the_nether"), "return anchor");
        ThresholdDefinition restoredThreshold = restoredThresholds.get(thresholdId).orElseThrow();
        truth(restoredThreshold.access().publicAccess(), "threshold public-access persistence");
        truth(restoredThreshold.access().invitedGuests().contains(guest), "threshold invited-guest persistence");
        truth(restoredThreshold.access().canEnter(guest), "threshold guest access");
        truth(restoredThreshold.sourceDimensionId().equals("minecraft:overworld"), "threshold source dimension");
        truth(restoredThreshold.sourcePositions().contains(new DomainPosition(10, 65, 10)), "threshold source positions");

        boolean corruptRejected = false;
        try { VeilboundSnapshotBinaryCodec.decode(payload.substring(0, payload.length() / 2)); }
        catch (IllegalArgumentException expected) { corruptRejected = true; }
        truth(restored.memoryProgress().capturedMemoryId().orElseThrow().equals("veilbound:test_memory"), "captured Memory persists");
        truth(restored.memoryProgress().activeOrreryMemoryIds().equals(java.util.List.of("veilbound:memory/test")), "active Orrery Memories persist");
        truth(corruptRejected, "truncated persistence must be rejected");
        System.out.println("FullPersistenceSelfTest: PASS");
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
