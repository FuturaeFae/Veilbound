package dev.futurae.veilbound.threshold;

import dev.futurae.veilbound.domain.DomainPosition;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class ThresholdRegistryIndexSelfTest {
    public static void main(String[] args) {
        ThresholdRegistry registry = new ThresholdRegistry();
        UUID owner = UUID.randomUUID();
        DomainPosition a = new DomainPosition(2, 64, 2);
        DomainPosition b = new DomainPosition(2, 65, 2);
        ThresholdDefinition first = new ThresholdDefinition(
                UUID.randomUUID(), owner, "minecraft:overworld", Set.of(a, b), DomainPosition.ORIGIN, new ThresholdAccess());
        registry.add(first);

        if (registry.findAt("minecraft:overworld", a).orElseThrow() != first) {
            throw new AssertionError("source index failed to resolve first cell");
        }
        if (registry.findAt("minecraft:the_nether", a).isPresent()) {
            throw new AssertionError("same coordinates in another dimension must not collide");
        }

        ThresholdDefinition overlap = new ThresholdDefinition(
                UUID.randomUUID(), owner, "minecraft:overworld", Set.of(b), DomainPosition.ORIGIN, new ThresholdAccess());
        try {
            registry.add(overlap);
            throw new AssertionError("overlapping active Threshold cells must be rejected");
        } catch (IllegalArgumentException expected) {
            // expected
        }

        if (!registry.removeSystem(first.id())) throw new AssertionError("system removal failed");
        if (registry.findAt("minecraft:overworld", a).isPresent()) {
            throw new AssertionError("source index leaked after removal");
        }

        ThresholdDefinition second = new ThresholdDefinition(
                UUID.randomUUID(), owner, "minecraft:overworld", Set.of(a), DomainPosition.ORIGIN, new ThresholdAccess());
        registry.replaceFromPersistence(List.of(second));
        if (registry.findAt("minecraft:overworld", a).orElseThrow() != second) {
            throw new AssertionError("source index was not rebuilt from persistence");
        }
    }
}
