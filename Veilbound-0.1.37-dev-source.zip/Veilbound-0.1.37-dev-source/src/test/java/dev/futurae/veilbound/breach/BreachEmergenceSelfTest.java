package dev.futurae.veilbound.breach;

import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.stability.StabilityRuntimePolicy;
import java.util.Random;
import java.util.UUID;

public final class BreachEmergenceSelfTest {
    public static void main(String[] args) {
        BreachSpawnPolicy policy = StabilityRuntimePolicy.DEVELOPMENT_DEFAULT.breachPolicy().spawnPolicy();
        Breach minor = breach(BreachSeverity.MINOR, true);
        Breach severe = breach(BreachSeverity.SEVERE, true);
        Breach extreme = breach(BreachSeverity.EXTREME, true);

        for (int i = 0; i < 100; i++) {
            truth(policy.selectCreature(BreachSeverity.MINOR, new Random(i)) == VoidCreatureType.VOID_CRAWLER,
                    "minor breach only selects crawler");
            truth(policy.selectCreature(BreachSeverity.SEVERE, new Random(i)) != VoidCreatureType.NULL_WRAITH,
                    "severe breach never selects wraith");
        }
        truth(policy.creaturePool(BreachSeverity.EXTREME).weight(VoidCreatureType.NULL_WRAITH) > 0,
                "extreme breach can select wraith");

        long due = BreachEmergenceService.initialDueTick(minor, policy, 1000, new Random(1));
        truth(due >= 1600 && due <= 2200, "initial due tick respects minor interval");
        truth(BreachEmergenceService.evaluate(minor, policy, due - 1, due, 0, new Random(2)).status()
                        == BreachEmergenceService.Decision.Status.WAITING,
                "not due yet waits");
        truth(BreachEmergenceService.evaluate(severe, policy, 5000, 5000, policy.localCreatureCap(), new Random(3)).status()
                        == BreachEmergenceService.Decision.Status.CAPPED,
                "local cap blocks emergence");
        var spawn = BreachEmergenceService.evaluate(extreme, policy, 5000, 5000, 0, new Random(4));
        truth(spawn.shouldSpawn(), "due uncapped breach spawns");
        truth(spawn.nextDueTick() > 5000, "spawn schedules next emergence");
        truth(BreachEmergenceService.evaluate(breach(BreachSeverity.EXTREME, false), policy, 5000, 0, 0, new Random(5)).status()
                        == BreachEmergenceService.Decision.Status.INACTIVE,
                "sealed breach is inactive");

        DomainBounds bounds = new DomainBounds(-5, 0, -5, 5, 10, 5);
        for (AxisDirection face : AxisDirection.values()) {
            Breach edge = new Breach(UUID.randomUUID(), facePosition(bounds, face), face, BreachSeverity.SEVERE, true, 1);
            DomainPosition emerged = BreachEmergenceService.emergencePosition(bounds, edge, 2.5, new Random(face.ordinal() + 20));
            truth(bounds.contains(emerged), "emergence stays within usable Domain bounds for " + face);
            truth(isInsideFace(edge.position(), emerged, face), "emergence steps inward from " + face);
        }
        throwsIAE(() -> BreachEmergenceService.emergencePosition(bounds, minor, Double.NaN, new Random(9)),
                "non-finite emergence radius rejected");
        System.out.println("BreachEmergenceSelfTest: PASS");
    }

    private static Breach breach(BreachSeverity severity, boolean open) {
        return new Breach(UUID.randomUUID(), DomainPosition.ORIGIN, AxisDirection.POSITIVE_X, severity, open, 1);
    }

    private static DomainPosition facePosition(DomainBounds b, AxisDirection face) {
        int x = (b.minX() + b.maxX()) / 2;
        int y = (b.minY() + b.maxY()) / 2;
        int z = (b.minZ() + b.maxZ()) / 2;
        return switch (face) {
            case POSITIVE_X -> new DomainPosition(b.maxX(), y, z);
            case NEGATIVE_X -> new DomainPosition(b.minX(), y, z);
            case POSITIVE_Y -> new DomainPosition(x, b.maxY(), z);
            case NEGATIVE_Y -> new DomainPosition(x, b.minY(), z);
            case POSITIVE_Z -> new DomainPosition(x, y, b.maxZ());
            case NEGATIVE_Z -> new DomainPosition(x, y, b.minZ());
        };
    }

    private static boolean isInsideFace(DomainPosition source, DomainPosition emerged, AxisDirection face) {
        return switch (face) {
            case POSITIVE_X -> emerged.x() < source.x();
            case NEGATIVE_X -> emerged.x() > source.x();
            case POSITIVE_Y -> emerged.y() < source.y();
            case NEGATIVE_Y -> emerged.y() > source.y();
            case POSITIVE_Z -> emerged.z() < source.z();
            case NEGATIVE_Z -> emerged.z() > source.z();
        };
    }

    private static void throwsIAE(Runnable action, String message) {
        try { action.run(); }
        catch (IllegalArgumentException expected) { return; }
        throw new AssertionError(message);
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
