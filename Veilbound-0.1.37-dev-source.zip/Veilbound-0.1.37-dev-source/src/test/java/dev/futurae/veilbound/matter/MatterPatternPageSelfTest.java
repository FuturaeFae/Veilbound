package dev.futurae.veilbound.matter;

import java.util.List;
import java.util.Map;
import java.util.Set;

public final class MatterPatternPageSelfTest {
    public static void main(String[] args) {
        MatterCatalog catalog = new MatterCatalog();
        catalog.putExplicit("minecraft:cobblestone", 2, "test");
        catalog.putExplicit("minecraft:diamond", 256, "test");
        catalog.putExplicit("mod:widget", 32, "test");
        MatterPatternPageService pages = new MatterPatternPageService();

        var page = pages.page(Set.of("minecraft:diamond", "minecraft:cobblestone", "mod:widget"),
                catalog, 512, "", MatterPatternPageService.SortMode.COST_ASC, 0, 9);
        eq(3, page.matchingPatterns(), "all learned patterns visible");
        eq("minecraft:cobblestone", page.entries().getFirst().itemId(), "cost sort");
        eq(256, page.entries().getFirst().affordableCount(), "affordable count derives from Matter balance");

        var namespace = pages.page(Set.of("minecraft:diamond", "minecraft:cobblestone", "mod:widget"),
                catalog, 512, "@mod", MatterPatternPageService.SortMode.NAME_ASC, 0, 9);
        eq(1, namespace.matchingPatterns(), "@namespace filter");
        eq("mod:widget", namespace.entries().getFirst().itemId(), "namespace result");

        var named = pages.page(
                Set.of("minecraft:diamond", "minecraft:cobblestone", "mod:widget"),
                catalog, 512, Set.of("minecraft:diamond"), List.of("mod:widget", "minecraft:diamond"),
                Map.of("minecraft:diamond", "Shiny Gem", "minecraft:cobblestone", "Rubble", "mod:widget", "Widget"),
                "shiny", MatterPatternPageService.SortMode.NAME_ASC, MatterPatternPageService.FilterMode.ALL, 0, 9);
        eq(1, named.matchingPatterns(), "display-name search");
        eq("minecraft:diamond", named.entries().getFirst().itemId(), "display-name result");
        truth(named.entries().getFirst().favorite(), "favorite marker");

        var favorites = pages.page(
                Set.of("minecraft:diamond", "minecraft:cobblestone", "mod:widget"),
                catalog, 512, Set.of("minecraft:diamond"), List.of("mod:widget", "minecraft:diamond"), Map.of(),
                "", MatterPatternPageService.SortMode.COST_ASC, MatterPatternPageService.FilterMode.FAVORITES, 0, 9);
        eq(1, favorites.matchingPatterns(), "favorites filter");
        eq("minecraft:diamond", favorites.entries().getFirst().itemId(), "favorites result");

        var recents = pages.page(
                Set.of("minecraft:diamond", "minecraft:cobblestone", "mod:widget"),
                catalog, 512, Set.of(), List.of("mod:widget", "minecraft:cobblestone"), Map.of(),
                "", MatterPatternPageService.SortMode.COST_ASC, MatterPatternPageService.FilterMode.RECENT, 0, 9);
        eq(2, recents.matchingPatterns(), "recent filter");
        eq("mod:widget", recents.entries().getFirst().itemId(), "recent order overrides normal sort");

        System.out.println("MatterPatternPageSelfTest: PASS");
    }

    private static void eq(long expected, long actual, String msg) {
        if (expected != actual) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual);
    }
    private static void eq(String expected, String actual, String msg) {
        if (!expected.equals(actual)) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String msg) {
        if (!value) throw new AssertionError(msg);
    }
}
