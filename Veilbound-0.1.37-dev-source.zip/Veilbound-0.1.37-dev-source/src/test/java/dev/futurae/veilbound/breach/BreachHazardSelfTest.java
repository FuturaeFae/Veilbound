package dev.futurae.veilbound.breach;

import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.stability.StabilityRuntimePolicy;
import java.util.UUID;

public final class BreachHazardSelfTest {
    public static void main(String[] args) {
        BreachHazardPolicy policy = StabilityRuntimePolicy.DEVELOPMENT_DEFAULT.breachPolicy().hazardPolicy();
        Breach minor = breach(BreachSeverity.MINOR, true);
        Breach severe = breach(BreachSeverity.SEVERE, true);
        Breach extreme = breach(BreachSeverity.EXTREME, true);

        var minorExposure = BreachHazardService.evaluate(minor, policy, 0.5, 0.5, 0.5, 40);
        truth(minorExposure.inside(), "minor center is in hazard radius");
        eq(0.0, minorExposure.damage(), "minor hazard is warning-only by default");

        var severeDamage = BreachHazardService.evaluate(severe, policy, 0.5, 0.5, 0.5, 40);
        eq(1.0, severeDamage.damage(), "severe damage cadence");
        var severeBetween = BreachHazardService.evaluate(severe, policy, 0.5, 0.5, 0.5, 41);
        eq(0.0, severeBetween.damage(), "severe damage only on configured cadence");

        var extremeDamage = BreachHazardService.evaluate(extreme, policy, 0.5, 0.5, 0.5, 20);
        eq(2.0, extremeDamage.damage(), "extreme damage cadence");
        truth(extremeDamage.particlesDue(), "particles use independent cadence when coincident");

        var outside = BreachHazardService.evaluate(extreme, policy, 100, 100, 100, 20);
        truth(!outside.inside(), "far target receives no hazard");
        var sealed = BreachHazardService.evaluate(breach(BreachSeverity.EXTREME, false), policy, 0.5, 0.5, 0.5, 20);
        truth(!sealed.inside(), "sealed breach produces no hazard");
        throwsIAE(() -> new BreachHazardPolicy.HazardBand(Double.NaN, 1.0, 20, 1),
                "non-finite hazard radius rejected");
        throwsIAE(() -> new BreachHazardPolicy.HazardBand(1.0, Double.POSITIVE_INFINITY, 20, 1),
                "non-finite hazard damage rejected");
        throwsIAE(() -> BreachHazardService.evaluate(extreme, policy, Double.NaN, 0.0, 0.0, 20),
                "non-finite target coordinates rejected");
        System.out.println("BreachHazardSelfTest: PASS");
    }

    private static Breach breach(BreachSeverity severity, boolean open) {
        return new Breach(UUID.randomUUID(), DomainPosition.ORIGIN, AxisDirection.POSITIVE_Z, severity, open, 1);
    }
    private static void throwsIAE(Runnable action, String message) {
        try { action.run(); }
        catch (IllegalArgumentException expected) { return; }
        throw new AssertionError(message);
    }
    private static void eq(double expected, double actual, String message) {
        if (Double.compare(expected, actual) != 0) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String message) { if (!value) throw new AssertionError(message); }
}
