package dev.futurae.veilbound.memory;

public final class MemoryEffectPolicySelfTest {
    public static void main(String[] args) {
        MemoryEffectPolicy defaults = MemoryEffectPolicy.DEVELOPMENT_DEFAULT;
        truth(defaults.evaluationTicks() > 0, "evaluation cadence is positive");
        truth(defaults.fertilityAttemptsPerPlayer() >= 0, "fertility attempts are bounded");
        rejects(() -> new MemoryEffectPolicy(0, 1, 1, 0, 0, 0), "zero evaluation cadence");
        rejects(() -> new MemoryEffectPolicy(1, 0, 1, 0, 0, 0), "zero weather refresh");
        rejects(() -> new MemoryEffectPolicy(1, 1, 1, 257, 0, 0), "unbounded fertility attempts");
        rejects(() -> new MemoryEffectPolicy(1, 1, 1, 1, 65, 0), "unbounded horizontal radius");
        System.out.println("MemoryEffectPolicySelfTest: PASS");
    }

    private static void rejects(Runnable action, String message) {
        try { action.run(); }
        catch (IllegalArgumentException expected) { return; }
        throw new AssertionError("Expected rejection: " + message);
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
