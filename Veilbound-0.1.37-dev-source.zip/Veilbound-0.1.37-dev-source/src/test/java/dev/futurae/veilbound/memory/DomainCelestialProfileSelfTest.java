package dev.futurae.veilbound.memory;

public final class DomainCelestialProfileSelfTest {
    public static void main(String[] args) {
        var fixed = DomainCelestialProfile.sample(18_000L, false);
        require(close(fixed.sunAngle(), 0.0F), "fixed firmament must be noon");
        require(close(fixed.moonAngle(), 180.0F), "fixed moon must oppose sun");
        require(close(fixed.starBrightness(), 0.0F), "fixed noon must suppress stars");

        var noon = DomainCelestialProfile.sample(6_000L, true);
        var midnight = DomainCelestialProfile.sample(18_000L, true);
        require(close(noon.sunAngle(), 0.0F), "remembered noon sun angle");
        require(close(midnight.sunAngle(), 180.0F), "remembered midnight sun angle");
        require(midnight.starBrightness() > noon.starBrightness(), "night must have more stars");
        require(close(DomainCelestialProfile.sample(30_000L, true).sunAngle(), noon.sunAngle()),
                "clock must wrap every 24000 ticks");
        System.out.println("DomainCelestialProfileSelfTest: PASS");
    }

    private static boolean close(float a, float b) { return Math.abs(a - b) < 0.0001F; }
    private static void require(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
