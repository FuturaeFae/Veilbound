package dev.futurae.veilbound.environment;

import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import dev.futurae.veilbound.memory.MemoryDefinition;
import dev.futurae.veilbound.memory.MemoryEffectIds;
import dev.futurae.veilbound.memory.MemoryRegistry;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class EnvironmentZoneResolverSelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        state.setBounds(new DomainBounds(-10, 0, -10, 10, 10, 10));
        state.unlockFeature(DomainFeature.ENVIRONMENTAL_MASTERY);

        MemoryDefinition sky = new MemoryDefinition("veilbound:sky", "Sky", Set.of(), Map.of(
                MemoryEffectIds.VISUAL_SKY, MemoryEffectIds.OPEN_SKY));
        MemoryDefinition rain = new MemoryDefinition("veilbound:rain", "Rain", Set.of(), Map.of(
                MemoryEffectIds.VISUAL_WEATHER, MemoryEffectIds.GENTLE_RAIN,
                MemoryEffectIds.MECHANIC_WEATHER, MemoryEffectIds.RAIN));
        MemoryDefinition verdant = new MemoryDefinition("veilbound:verdant", "Verdant", Set.of(), Map.of(
                MemoryEffectIds.VISUAL_FLORA, MemoryEffectIds.VERDANT,
                MemoryEffectIds.MECHANIC_FERTILITY, MemoryEffectIds.VERDANT));
        MemoryDefinition calm = new MemoryDefinition("veilbound:calm", "Calm", Set.of(), Map.of(
                MemoryEffectIds.VISUAL_WEATHER, "veilbound:clear"));
        MemoryRegistry registry = new MemoryRegistry();
        registry.replaceAll(List.of(sky, rain, verdant, calm));
        for (MemoryDefinition memory : List.of(sky, rain, verdant, calm)) state.unlockMemory(memory.id());

        DomainBounds overlap = new DomainBounds(-3, 0, -3, 3, 5, 3);
        state.addEnvironmentZone(new EnvironmentZone(UUID.randomUUID(), "Rain Garden", overlap, rain.id(),
                Map.of("priority", "1", "blend", "false")));
        state.addEnvironmentZone(new EnvironmentZone(UUID.randomUUID(), "Verdant Crown", overlap, verdant.id(),
                Map.of("priority", "5", "blend", "true")));

        EnvironmentZoneResolver resolver = new EnvironmentZoneResolver();
        var blended = resolver.resolve(state, DomainPosition.ORIGIN, registry,
                sky.environmentalProfile(), List.of(sky.id()));
        truth(blended.zoned(), "overlap resolves a zone");
        eq("Verdant Crown", blended.primaryZoneName(), "higher priority wins");
        eq(MemoryEffectIds.VERDANT, blended.environmentalProfile().get(MemoryEffectIds.MECHANIC_FERTILITY),
                "primary profile retained");
        eq(MemoryEffectIds.GENTLE_RAIN, blended.environmentalProfile().get(MemoryEffectIds.VISUAL_WEATHER),
                "lower zone fills unclaimed key when blending enabled");
        eq(MemoryEffectIds.OPEN_SKY, blended.environmentalProfile().get(MemoryEffectIds.VISUAL_SKY),
                "global Orrery is lowest-priority blend substrate");

        state.addEnvironmentZone(new EnvironmentZone(UUID.randomUUID(), "Calm Override", overlap, calm.id(),
                Map.of("priority", "10", "blend", "true")));
        var conflict = resolver.resolve(state, DomainPosition.ORIGIN, registry, Map.of(), List.of());
        eq("Calm Override", conflict.primaryZoneName(), "new highest priority selected");
        eq("veilbound:clear", conflict.environmentalProfile().get(MemoryEffectIds.VISUAL_WEATHER),
                "lower conflicting rain cannot overwrite higher priority");

        var outside = resolver.resolve(state, new DomainPosition(9, 1, 9), registry,
                sky.environmentalProfile(), List.of(sky.id()));
        truth(!outside.zoned(), "outside uses global Orrery");
        eq(MemoryEffectIds.OPEN_SKY, outside.environmentalProfile().get(MemoryEffectIds.VISUAL_SKY),
                "global profile preserved outside zones");
        System.out.println("EnvironmentZoneResolverSelfTest: PASS");
    }

    private static void eq(Object expected, Object actual, String label) {
        if (!java.util.Objects.equals(expected, actual)) throw new AssertionError(label + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String label) { if (!value) throw new AssertionError(label); }
}
