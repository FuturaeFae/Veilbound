package dev.futurae.veilbound.domain;

import dev.futurae.veilbound.travel.SafeReturnSearch;
import java.util.HashSet;

public final class SafeReturnSearchSelfTest {
    public static void main(String[] args) {
        var candidates = SafeReturnSearch.candidates();
        truth(!candidates.isEmpty(), "fallback candidates exist");
        truth(candidates.size() == new HashSet<>(candidates).size(), "fallback candidates unique");
        truth(candidates.stream().noneMatch(o -> o.dx() == 0 && o.dy() == 0 && o.dz() == 0),
                "exact anchor is not duplicated in fallback list");
        truth(candidates.stream().allMatch(o -> Math.abs(o.dx()) <= SafeReturnSearch.HORIZONTAL_RADIUS
                        && Math.abs(o.dz()) <= SafeReturnSearch.HORIZONTAL_RADIUS
                        && Math.abs(o.dy()) <= SafeReturnSearch.VERTICAL_RADIUS),
                "all candidates respect search radius");

        var first = candidates.getFirst();
        truth(first.horizontalDistanceSquared() <= 1, "nearest horizontal fallback comes first");
        truth(first.dy() == 0, "same-height fallback is preferred first");

        int up = candidates.indexOf(new SafeReturnSearch.BlockOffset(0, 1, 0));
        int down = candidates.indexOf(new SafeReturnSearch.BlockOffset(0, -1, 0));
        truth(up >= 0 && down >= 0 && up < down, "up is preferred over equally distant down");
        System.out.println("SafeReturnSearchSelfTest: PASS");
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
