package dev.futurae.veilbound.precore;

import dev.futurae.veilbound.domain.DomainState;
import java.util.UUID;

public final class SpatialGeneratorSelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        SpatialGeneratorCostPolicy costs = new SpatialGeneratorCostPolicy(2);
        CondensedCharge charge = CondensedCharge.whole(10_000);
        var plan = SpatialGeneratorPlanner.plan(state, 10, 10, 10, costs, charge);
        truth(plan.allowed(), "10x10x10 should be legal pre-Core");
        eq(10, plan.newBounds().sizeX(), "x span");
        eq(10, plan.newBounds().sizeY(), "y span");
        eq(10, plan.newBounds().sizeZ(), "z span");
        eq(998L * 2L, plan.requiredChargeWholeCeil(), "new-volume charge cost");
        var applied = SpatialGeneratorPlanner.apply(state, plan, charge);
        truth(applied.applied(), "apply pre-Core growth");
        eq(10, state.bounds().sizeX(), "state x span");
        truth(!SpatialGeneratorPlanner.plan(state, 11, 10, 10, costs, charge).allowed(), "11 span rejected");
        state.setBounds(new dev.futurae.veilbound.domain.DomainBounds(-1, 0, -1, 1, 1, 1));
        state.awakenCore(dev.futurae.veilbound.domain.DomainPosition.ORIGIN);
        eq("core_already_active", SpatialGeneratorPlanner.plan(state, 10, 10, 10, costs, charge).reason(), "generator stops after Core");
        System.out.println("SpatialGeneratorSelfTest: PASS");
    }

    private static void eq(long expected, long actual, String msg) { if (expected != actual) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual); }
    private static void eq(String expected, String actual, String msg) { if (!expected.equals(actual)) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual); }
    private static void truth(boolean value, String msg) { if (!value) throw new AssertionError(msg); }
}
