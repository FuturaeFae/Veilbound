package dev.futurae.veilbound.platform.neoforge.travel;

import java.util.UUID;

public final class NeoForgeTransitGuardSelfTest {
    public static void main(String[] args) {
        UUID player = UUID.randomUUID();
        truth(!NeoForgeTransitGuard.isInternal(player), "starts clear");
        boolean result = NeoForgeTransitGuard.run(player, () -> {
            truth(NeoForgeTransitGuard.isInternal(player), "guard active inside action");
            return NeoForgeTransitGuard.run(player, () -> {
                truth(NeoForgeTransitGuard.isInternal(player), "nested guard remains active");
                return true;
            });
        });
        truth(result, "result propagated");
        truth(!NeoForgeTransitGuard.isInternal(player), "nested guard clears fully");

        try {
            NeoForgeTransitGuard.run(player, () -> { throw new IllegalStateException("expected"); });
            throw new AssertionError("exception should propagate");
        } catch (IllegalStateException expected) {
            truth("expected".equals(expected.getMessage()), "original exception propagated");
        }
        truth(!NeoForgeTransitGuard.isInternal(player), "guard clears after exception");
        System.out.println("NeoForgeTransitGuardSelfTest: PASS");
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
