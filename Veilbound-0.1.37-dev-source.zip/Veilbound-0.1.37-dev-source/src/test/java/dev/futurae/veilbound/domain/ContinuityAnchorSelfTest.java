package dev.futurae.veilbound.domain;

import java.util.UUID;

public final class ContinuityAnchorSelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        state.setBounds(new DomainBounds(0, 0, 0, 31, 1, 31));
        state.awakenCore(DomainPosition.ORIGIN);

        var first = ContinuityAnchorService.place(state, new DomainPosition(1, 0, 1), 2);
        var second = ContinuityAnchorService.place(state, new DomainPosition(15, 0, 15), 2);
        truth(first.placed() && second.placed(), "two legal anchors place");
        eq(2, state.continuityAnchors().size(), "both anchors contribute logical load");
        eq(1, ContinuityAnchorService.anchoredChunks(state).size(), "same-chunk anchors collapse to one loaded chunk");

        var capped = ContinuityAnchorService.place(state, new DomainPosition(16, 0, 16), 2);
        truth(!capped.placed() && capped.reason().equals("anchor_cap_reached"), "cap enforced");

        var removed = ContinuityAnchorService.remove(state, new DomainPosition(1, 0, 1));
        truth(removed.removed() && removed.chunkStillAnchored(), "removing one same-chunk anchor leaves chunk anchored");
        eq(1, state.continuityAnchors().size(), "one logical anchor remains");

        DomainState preCore = new DomainState(UUID.randomUUID());
        var denied = ContinuityAnchorService.place(preCore, DomainPosition.ORIGIN, 25);
        truth(!denied.placed() && denied.reason().equals("core_inactive"), "pre-Core placement rejected");
        System.out.println("ContinuityAnchorSelfTest: PASS");
    }

    private static void eq(long expected, long actual, String message) {
        if (expected != actual) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String message) { if (!value) throw new AssertionError(message); }
}
