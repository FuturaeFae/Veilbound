package dev.futurae.veilbound.threshold;

import dev.futurae.veilbound.domain.DomainPosition;
import java.util.Set;
import java.util.UUID;

public final class ThresholdBindingSelfTest {
    public static void main(String[] args) {
        UUID owner = UUID.randomUUID();
        UUID id = UUID.randomUUID();
        ThresholdRegistry registry = new ThresholdRegistry();
        ThresholdDefinition definition = new ThresholdDefinition(
                id, owner, "minecraft:overworld",
                Set.of(new DomainPosition(4, 70, 4), new DomainPosition(4, 71, 4)),
                DomainPosition.ORIGIN, new ThresholdAccess());
        registry.add(definition);
        if (registry.findAt("minecraft:overworld", new DomainPosition(4, 71, 4)).orElseThrow().id().equals(id) == false) {
            throw new AssertionError("source block should resolve threshold binding");
        }
        if (registry.findAt("minecraft:the_nether", new DomainPosition(4, 71, 4)).isPresent()) {
            throw new AssertionError("dimension must be part of threshold source identity");
        }
        System.out.println("ThresholdBindingSelfTest: PASS");
    }
}
