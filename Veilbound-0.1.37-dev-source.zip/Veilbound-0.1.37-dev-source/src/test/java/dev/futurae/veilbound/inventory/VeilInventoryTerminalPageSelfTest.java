package dev.futurae.veilbound.inventory;

import dev.futurae.veilbound.matter.MatterCatalog;
import dev.futurae.veilbound.matter.MatterPatternPageService;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class VeilInventoryTerminalPageSelfTest {
    public static void main(String[] args) {
        MatterCatalog catalog = new MatterCatalog();
        catalog.putExplicit("minecraft:diamond", 8_192L, "test");
        catalog.putExplicit("minecraft:iron_ingot", 256L, "test");

        VeilInventory inventory = new VeilInventory();
        VeilStackKey modded = new VeilStackKey("example:machine_part", "{mode:2}");
        inventory.insert(modded, 7, new VeilStorageCapacity(1_000, 100));

        VeilInventoryTerminalPageService pages = new VeilInventoryTerminalPageService();
        var page = pages.page(
                inventory,
                Set.of("minecraft:diamond", "minecraft:iron_ingot", "example:dormant_old_pattern"),
                catalog,
                16_384L,
                Set.of("minecraft:diamond"),
                List.of("minecraft:iron_ingot"),
                Map.of(modded, "Machine Part"),
                Map.of("minecraft:diamond", "Diamond", "minecraft:iron_ingot", "Iron Ingot"),
                "", MatterPatternPageService.SortMode.NAME_ASC, MatterPatternPageService.FilterMode.ALL,
                0, 36);
        eq(3, page.matchingEntries(), "hybrid page contains two patterns + one physical stack");
        truth(page.entries().stream().anyMatch(e -> !e.pattern() && e.key().equals(modded) && e.storedCount() == 7),
                "unvalued stored stack is visible exactly");
        truth(page.entries().stream().noneMatch(e -> e.key().itemId().equals("example:dormant_old_pattern")),
                "learned pattern with no current value is dormant, not assigned a fallback");

        var favorites = pages.page(
                inventory, Set.of("minecraft:diamond", "minecraft:iron_ingot"), catalog, 16_384L,
                Set.of("minecraft:diamond"), List.of("minecraft:iron_ingot"),
                Map.of(modded, "Machine Part"), Map.of("minecraft:diamond", "Diamond", "minecraft:iron_ingot", "Iron Ingot"),
                "", MatterPatternPageService.SortMode.NAME_ASC, MatterPatternPageService.FilterMode.FAVORITES, 0, 36);
        eq(1, favorites.matchingEntries(), "favorite filter contains patterns only");
        truth(favorites.entries().getFirst().pattern(), "favorite result is a Matter pattern");

        var namespace = pages.page(
                inventory, Set.of("minecraft:diamond"), catalog, 16_384L,
                Set.of(), List.of(), Map.of(modded, "Machine Part"), Map.of("minecraft:diamond", "Diamond"),
                "@example", MatterPatternPageService.SortMode.NAME_ASC, MatterPatternPageService.FilterMode.ALL, 0, 36);
        eq(1, namespace.matchingEntries(), "namespace search includes stored unvalued stacks");
        truth(!namespace.entries().getFirst().pattern(), "namespace result is physical stored item");

        System.out.println("VeilInventoryTerminalPageSelfTest: PASS");
    }

    private static void eq(long expected, long actual, String message) {
        if (expected != actual) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String message) { if (!value) throw new AssertionError(message); }
}
