package dev.futurae.veilbound.domain;

import dev.futurae.veilbound.persistence.VeilboundSnapshotBinaryCodec;
import dev.futurae.veilbound.threshold.ThresholdRegistry;
import java.util.UUID;

/** Fixture encoded by the untouched 0.1.30-dev v12 codec. */
public final class PersistenceV12MigrationSelfTest {
    private static final String V12_PAYLOAD =
            "VkVJTAAAAAwAAAABIiIiIjMzRERVVWZmZmZmZgAAADV2ZWlsYm91bmQ6ZG9tYWluLzIyMjIyMjIyLTMzMzMtNDQ0NC01NTU1LTY2NjY2NjY2NjY2NgAAAAAHW80VACIiIiIzM0REVVVmZmZmZmYAAAALQ09SRV9BQ1RJVkUAAAAIUkVTT05BTlQAAAAAAAAAAAAAAAD////+AAAAAP////4AAAACAAAAAgAAAAIAAAAAAANkDgAAAAAAAAAGAQAAAApQT1NJVElWRV9YAQEBAAAAAgAAAAAAAAAAAQAAAApORUdBVElWRV9YAAAAAQAAAApQT1NJVElWRV9ZAAAAAQAAAApORUdBVElWRV9ZAAAAAQAAAApQT1NJVElWRV9aAAAAAQAAAApORUdBVElWRV9aAAAAAAAAAAAAAAAAAAAAAAAAAQAAABd2ZWlsYm91bmQ6Y29yZV9hd2FrZW5lZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=";

    public static void main(String[] args) {
        var snapshot = VeilboundSnapshotBinaryCodec.decode(V12_PAYLOAD);
        DomainRepository domains = new DomainRepository();
        snapshot.restoreInto(domains, new ThresholdRegistry());
        UUID owner = UUID.fromString("22222222-3333-4444-5555-666666666666");
        DomainRecord record = domains.getRecord(owner).orElseThrow();
        truth(record.identity().seed() == 123456789L, "seed survives");
        truth(record.state().coreTier() == CoreTier.RESONANT, "tier survives");
        truth(record.state().dimensionalEnergy() == 222222L, "DE survives");
        BoundaryPylonState pylon = record.state().pylons().get(AxisDirection.POSITIVE_X);
        truth(pylon.blockPosition().equals(new DomainPosition(2, 0, 0)), "v12 physical binding survives for runtime reconciliation");
        truth(pylon.speed() == BoundaryPylonSpeed.STABLE, "v12 Pylons migrate to Stable speed");
        truth(record.state().completedMilestoneIds().contains("veilbound:core_awakened"), "v12 milestone history survives");
        System.out.println("PersistenceV12MigrationSelfTest: PASS");
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
