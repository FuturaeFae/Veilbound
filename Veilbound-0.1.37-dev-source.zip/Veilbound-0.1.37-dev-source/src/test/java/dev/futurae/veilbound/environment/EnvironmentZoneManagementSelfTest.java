package dev.futurae.veilbound.environment;

import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainState;
import java.util.Map;
import java.util.UUID;

/** Regression coverage for stable named-zone management semantics. */
public final class EnvironmentZoneManagementSelfTest {
    public static void main(String[] args) {
        UUID owner = UUID.randomUUID();
        DomainState state = new DomainState(owner);
        state.unlockFeature(DomainFeature.ENVIRONMENTAL_MASTERY);
        state.unlockMemory("veilbound:gentle_rain");
        state.unlockMemory("veilbound:verdant_growth");
        state.setBounds(new DomainBounds(-10, -2, -10, 10, 10, 10));

        var made = EnvironmentZoneService.create(
                state, "Rain Garden", new DomainBounds(-2, 0, -2, 2, 4, 2),
                "veilbound:gentle_rain", Map.of("priority", "3", "blend", "true"));
        check(made.created(), "zone should create");
        check(!EnvironmentZoneService.create(
                state, " rain garden ", new DomainBounds(3, 0, 3, 4, 2, 4),
                "veilbound:verdant_growth", Map.of()).created(), "names must be case-insensitively unique");

        var renamed = EnvironmentZoneService.rename(state, made.zone().id(), "Canopy Court");
        check(renamed.updated() && "Canopy Court".equals(renamed.zone().name()), "rename should preserve zone identity");
        var configured = EnvironmentZoneService.configure(state, made.zone().id(), 9, false);
        check(configured.updated() && configured.zone().priority() == 9 && !configured.zone().blendWithLowerPriority(),
                "priority/blend should update without replacing identity");
        var retuned = EnvironmentZoneService.retuneMemory(state, made.zone().id(), "veilbound:verdant_growth");
        check(retuned.updated() && "veilbound:verdant_growth".equals(retuned.zone().memoryProfileId()),
                "retune should require and accept an earned Memory");
        check(EnvironmentZoneService.delete(state, made.zone().id()), "delete should remove managed zone");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
