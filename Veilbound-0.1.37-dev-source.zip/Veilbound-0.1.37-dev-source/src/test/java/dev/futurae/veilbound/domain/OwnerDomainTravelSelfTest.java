package dev.futurae.veilbound.domain;

import dev.futurae.veilbound.travel.OwnerDomainTravelService;
import dev.futurae.veilbound.travel.ReturnAnchor;
import java.util.UUID;

public final class OwnerDomainTravelSelfTest {
    public static void main(String[] args) {
        UUID owner = UUID.randomUUID();
        DomainRepository domains = new DomainRepository();
        OwnerDomainTravelService travel = new OwnerDomainTravelService(domains);
        ReturnAnchor firstOutside = new ReturnAnchor("minecraft:overworld", 20.25, 65, -10.75, 40, 5);

        var unbound = travel.request(owner, firstOutside);
        truth(!unbound.allowed() && unbound.reason().equals("domain_not_bound"), "V cannot create a free Domain");

        DomainRecord bound = domains.createRecord(owner, 777L);
        var first = travel.request(owner, firstOutside);
        truth(first.allowed() && first.enteringDomain(), "bound owner enters");
        truth(!first.domainCreated(), "travel never creates Domain");
        truth(first.domain() == bound && first.domain().identity().seed() == 777L, "bound Domain reused");
        truth(first.targetDomainPosition().equals(DomainPosition.ORIGIN), "initial entry is Domain origin");
        truth(first.domain().state().bounds().equals(DomainBounds.initial()), "initial pocket stays 1x1x2");

        ReturnAnchor inside = new ReturnAnchor(DomainIdentity.dimensionIdFor(owner), .5, 0, .5, 0, 0);
        var exit = travel.request(owner, inside);
        truth(exit.allowed() && !exit.enteringDomain(), "inside use exits");
        truth(exit.outsideReturnAnchor().equals(firstOutside), "exact outside anchor returned");
        travel.completeExit(owner);

        ReturnAnchor secondOutside = new ReturnAnchor("minecraft:the_nether", 3.5, 72, 4.5, 180, 0);
        var second = travel.request(owner, secondOutside);
        truth(second.allowed() && second.enteringDomain(), "later outside use enters");
        truth(!second.domainCreated(), "later use reuses same Domain");
        truth(domains.records().size() == 1, "one Domain per owner");
        truth(second.domain().ownerReturnAnchor().orElseThrow().equals(secondOutside), "return anchor updates per visit");
        System.out.println("OwnerDomainTravelSelfTest: PASS");
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
