package dev.futurae.veilbound.domain;

import dev.futurae.veilbound.breach.Breach;
import dev.futurae.veilbound.breach.BreachSeverity;
import dev.futurae.veilbound.persistence.DomainSnapshot;
import java.util.UUID;

public final class PersistenceSelfTest {
    public static void main(String[] args) {
        UUID owner = UUID.randomUUID();
        DomainState original = new DomainState(owner);
        original.setBounds(new DomainBounds(-2, -1, -2, 2, 3, 2));
        original.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        original.awakenCore(DomainPosition.ORIGIN);
        original.setCoreTier(CoreTier.RESONANT);
        original.setDimensionalEnergy(12_345);
        original.setPylon(new BoundaryPylonState(
                AxisDirection.POSITIVE_X, true, true, new DomainPosition(1, 0, 0)));
        original.imposeLaw("veilbound:test_law");
        original.unlockMemory("veilbound:test_memory");
        original.completeMilestone("veilbound:test_milestone");
        original.unlockFeature(DomainFeature.SURVEYING);
        original.addBreach(new Breach(UUID.randomUUID(), DomainPosition.ORIGIN, AxisDirection.POSITIVE_Z, BreachSeverity.SEVERE, true, 44));
        original.addContinuityAnchor(new DomainPosition(1, 0, 1));
        original.setFractureMeter(37.5);
        original.setDayTime(18_765L);
        original.setWeatherState(120, true, 600, true, 240);
        original.setGlobalExpansionEnabled(false);
        original.setSovereigntyUnlocked(true);

        DomainState restored = DomainSnapshot.capture(original).restore();
        truth(restored.ownerId().equals(owner), "owner");
        truth(restored.bounds().equals(original.bounds()), "bounds");
        truth(restored.corePosition().equals(original.corePosition()), "core position");
        truth(restored.coreTier() == CoreTier.RESONANT, "tier");
        eq(12_345, restored.dimensionalEnergy(), "DE");
        truth(restored.pylons().get(AxisDirection.POSITIVE_X).expansionEnabled(), "pylon expansion");
        truth(restored.pylons().get(AxisDirection.POSITIVE_X).blockPosition().equals(new DomainPosition(1, 0, 0)),
                "pylon physical binding");
        truth(restored.imposedLawIds().contains("veilbound:test_law"), "law");
        truth(restored.unlockedMemoryIds().contains("veilbound:test_memory"), "memory");
        truth(restored.completedMilestoneIds().contains("veilbound:test_milestone"), "milestone");
        truth(restored.hasFeature(DomainFeature.SURVEYING), "feature");
        truth(restored.hasOpenBreach(), "breach");
        truth(restored.continuityAnchors().contains(new DomainPosition(1, 0, 1)), "continuity anchor");
        truth(Double.compare(restored.fractureMeter(), 37.5) == 0, "fracture meter");
        eq(18_765L, restored.dayTime(), "day time");
        eq(120, restored.clearWeatherTime(), "clear weather timer");
        truth(restored.raining(), "rain state");
        eq(600, restored.rainTime(), "rain timer");
        truth(restored.thundering(), "thunder state");
        eq(240, restored.thunderTime(), "thunder timer");
        truth(!restored.globalExpansionEnabled(), "global expansion control");
        truth(restored.sovereigntyUnlocked(), "sovereignty");
        System.out.println("PersistenceSelfTest: PASS");
    }

    private static void eq(long expected, long actual, String msg) {
        if (expected != actual) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String msg) { if (!value) throw new AssertionError(msg); }
}
