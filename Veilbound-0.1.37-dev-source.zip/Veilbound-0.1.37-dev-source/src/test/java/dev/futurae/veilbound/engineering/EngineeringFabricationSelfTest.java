package dev.futurae.veilbound.engineering;

import dev.futurae.veilbound.domain.*;
import dev.futurae.veilbound.ontology.PotentialReservoir;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class EngineeringFabricationSelfTest {
    public static void main(String[] args) {
        DomainState domain = new DomainState(UUID.randomUUID());
        domain.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        domain.awakenCore(new DomainPosition(0,0,0));
        domain.setCoreTier(CoreTier.RESONANT);
        domain.setDimensionalEnergy(100_000);
        domain.unlockMemory("veilbound:open_sky");
        domain.imposeLaw("veilbound:preservation");
        EngineeringMatterReservoir matter = new EngineeringMatterReservoir(100_000); matter.insert(50_000);
        PotentialReservoir potential = new PotentialReservoir(10_000); potential.insert(2_000);
        EngineeringInventory inventory = new EngineeringInventory(); inventory.insert("veilbound:phase_coil", 4);
        EngineeringRecipe recipe = new EngineeringRecipe("test", "Test", EngineeringStation.DIMENSIONAL_FABRICATOR,
                List.of(new EngineeringIngredient("veilbound:phase_coil",4)), "veilbound:causal_lattice", 1,
                10_000, 20_000, 1_000, CoreTier.RESONANT,
                Set.of("veilbound:open_sky"), Set.of("veilbound:preservation"), 200);
        var service = new EngineeringFabricationService();
        var result = service.execute(recipe, EngineeringStation.DIMENSIONAL_FABRICATOR, domain, matter, potential, inventory);
        check(result.crafted(), "complete recipe should commit");
        check(inventory.count("veilbound:phase_coil") == 0 && inventory.count("veilbound:causal_lattice") == 1, "physical transaction");
        check(matter.stored() == 40_000 && domain.dimensionalEnergy() == 80_000 && potential.stored() == 1_000, "resource transaction");

        long beforeMatter = matter.stored(), beforeDe = domain.dimensionalEnergy(), beforePotential = potential.stored();
        var fail = service.execute(recipe, EngineeringStation.DIMENSIONAL_FABRICATOR, domain, matter, potential, inventory);
        check(!fail.crafted(), "missing item should fail");
        check(matter.stored()==beforeMatter && domain.dimensionalEnergy()==beforeDe && potential.stored()==beforePotential,
                "failed plan must consume nothing");
        System.out.println("EngineeringFabricationSelfTest PASS");
    }
    private static void check(boolean c,String m){ if(!c) throw new AssertionError(m); }
}
