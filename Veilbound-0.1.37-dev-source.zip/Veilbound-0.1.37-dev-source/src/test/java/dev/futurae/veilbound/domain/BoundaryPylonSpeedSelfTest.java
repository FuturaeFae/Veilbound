package dev.futurae.veilbound.domain;

public final class BoundaryPylonSpeedSelfTest {
    public static void main(String[] args) {
        eq(400, BoundaryPylonSpeed.GENTLE.intervalTicks(200), "Gentle rate");
        eq(200, BoundaryPylonSpeed.STABLE.intervalTicks(200), "Stable 0.1 block/s interval");
        eq(100, BoundaryPylonSpeed.DRIVEN.intervalTicks(200), "Driven rate");
        eq(50, BoundaryPylonSpeed.FORCED.intervalTicks(200), "Forced rate");
        eq(25, BoundaryPylonSpeed.RUPTURE.intervalTicks(200), "Rupture rate");
        eq(1L, BoundaryPylonSpeed.GENTLE.scaleSquared(4L), "Gentle DE/block");
        eq(4L, BoundaryPylonSpeed.STABLE.scaleSquared(4L), "Stable DE/block");
        eq(16L, BoundaryPylonSpeed.DRIVEN.scaleSquared(4L), "Driven DE/block");
        eq(64L, BoundaryPylonSpeed.FORCED.scaleSquared(4L), "Forced DE/block");
        eq(256L, BoundaryPylonSpeed.RUPTURE.scaleSquared(4L), "Rupture DE/block");
        System.out.println("BoundaryPylonSpeedSelfTest: PASS");
    }
    private static void eq(long expected, long actual, String message) {
        if (expected != actual) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }
}
