package dev.futurae.veilbound.precore;

public final class SpatialGeneratorCondensationSelfTest {
    public static void main(String[] args) {
        var policy = SpatialGeneratorRuntimePolicy.DEVELOPMENT_DEFAULT;
        var one = SpatialGeneratorCondensationService.plan(1, 1, 20, policy);
        truth(one.allowed(), "one 1-Matter item should condense");
        eq(20, one.consumedForgeEnergy(), "FE consumed");
        eq(350, one.producedChargeMilli(), "35% must preserve fractional charge");

        var batch = SpatialGeneratorCondensationService.plan(10, 5, 600, policy);
        truth(batch.allowed(), "energy should fund three items");
        eq(3, batch.acceptedItems(), "partial stack acceptance");
        eq(600, batch.consumedForgeEnergy(), "bounded FE consumption");
        eq(10_500, batch.producedChargeMilli(), "35% batch charge");
        eq("insufficient_forge_energy", SpatialGeneratorCondensationService.plan(10, 1, 199, policy).reason(), "underfunded conversion");
        System.out.println("SpatialGeneratorCondensationSelfTest: PASS");
    }
    private static void eq(long e, long a, String m) { if (e != a) throw new AssertionError(m + ": expected=" + e + " actual=" + a); }
    private static void eq(String e, String a, String m) { if (!e.equals(a)) throw new AssertionError(m + ": expected=" + e + " actual=" + a); }
    private static void truth(boolean v, String m) { if (!v) throw new AssertionError(m); }
}
