package dev.futurae.veilbound.inventory;

import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import java.util.UUID;

public final class CoreCapabilityUpgradeSelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        state.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        state.awakenCore(DomainPosition.ORIGIN);
        CoreCapabilityUpgradeService upgrades = new CoreCapabilityUpgradeService();

        state.setCoreTier(CoreTier.ANCHORED);
        truth(!upgrades.feed(state, CoreCapabilityUpgradeService.VEIL_INVENTORY_UPGRADE_ID, 1).accepted(),
                "Inventory upgrade requires Resonant Core");
        state.setCoreTier(CoreTier.RESONANT);
        var inventory = upgrades.feed(state, CoreCapabilityUpgradeService.VEIL_INVENTORY_UPGRADE_ID, 64);
        truth(inventory.accepted() && inventory.consumed() == 1, "one crafted Inventory Upgrade is consumed");
        truth(state.hasFeature(DomainFeature.VEIL_INVENTORY), "Inventory feature unlocked");
        truth(!upgrades.feed(state, CoreCapabilityUpgradeService.VEIL_INVENTORY_UPGRADE_ID, 1).accepted(), "duplicate unlock rejected");

        truth(!upgrades.feed(state, CoreCapabilityUpgradeService.VEIL_TRANSMUTATION_UPGRADE_ID, 1).accepted(),
                "Transmutation upgrade requires Veil Crafting first");
        var crafting = upgrades.feed(state, CoreCapabilityUpgradeService.VEIL_CRAFTING_UPGRADE_ID, 1);
        truth(crafting.accepted(), "separate Crafting Upgrade is accepted after Inventory unlock");
        truth(state.hasFeature(DomainFeature.VEIL_CRAFTING), "Crafting feature unlocked");
        var transmutation = upgrades.feed(state, CoreCapabilityUpgradeService.VEIL_TRANSMUTATION_UPGRADE_ID, 1);
        truth(transmutation.accepted(), "Transmutation Upgrade is accepted after Crafting unlock");
        truth(state.hasFeature(DomainFeature.VEIL_TRANSMUTATION), "Transmutation feature unlocked");
        System.out.println("CoreCapabilityUpgradeSelfTest: PASS");
    }

    private static void truth(boolean value, String message) { if (!value) throw new AssertionError(message); }
}
