package dev.futurae.veilbound.memory;

import java.util.List;
import java.util.Map;
import java.util.Set;

public final class MemoryProfileBlendSelfTest {
    public static void main(String[] args) {
        MemoryDefinition sky = new MemoryDefinition("veilbound:sky", "Sky", Set.of(),
                Map.of("visual.sky", "blue"));
        MemoryDefinition rain = new MemoryDefinition("veilbound:rain", "Rain", Set.of(),
                Map.of("mechanic.weather", "rain"));
        MemoryDefinition redSky = new MemoryDefinition("veilbound:red_sky", "Red Sky", Set.of(),
                Map.of("visual.sky", "red"));
        MemoryProfileBlendService mixer = new MemoryProfileBlendService();

        var compatible = mixer.blend(List.of(sky, rain), Set.of("veilbound:sky", "veilbound:rain"));
        truth(compatible.compatible(), "independent profile keys mix");
        eq("rain", compatible.environmentalProfile().get("mechanic.weather"), "weather profile retained");

        var conflict = mixer.blend(List.of(sky, redSky), Set.of("veilbound:sky", "veilbound:red_sky"));
        truth(!conflict.compatible(), "same-key contradictory profiles conflict");
        truth(conflict.conflicts().contains("visual.sky"), "conflict key reported");

        var locked = mixer.blend(List.of(sky, rain), Set.of("veilbound:sky"));
        truth(!locked.compatible() && "memory_not_learned".equals(locked.reason()), "locked Memories cannot be mixed");
        System.out.println("MemoryProfileBlendSelfTest: PASS");
    }

    private static void eq(String expected, String actual, String msg) {
        if (!expected.equals(actual)) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String msg) { if (!value) throw new AssertionError(msg); }
}
