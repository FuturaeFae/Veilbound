package dev.futurae.veilbound.matter;

import java.util.List;
import java.util.Set;

public final class MatterAdminOverrideSelfTest {
    public static void main(String[] args) {
        MatterCatalog catalog = new MatterCatalog();
        catalog.putBuiltIn("example:ingot", 256L, "baseline");
        catalog.putDatapack("example:ingot", 300L, "datapack");

        MatterReloadService reload = new MatterReloadService(catalog);
        reload.addRecipeSource(() -> List.of(
                recipe("example:plate", "example:ingot", 2),
                recipe("example:casing", "example:plate", 2)));
        reload.reload();
        check(value(catalog, "example:plate") == 600, "datapack baseline should infer plate");
        check(value(catalog, "example:casing") == 1_200, "transitive inference should resolve casing");

        catalog.putAdmin("example:ingot", 100, "command:test");
        reload.recomputeAffected(Set.of("example:ingot"));
        check(value(catalog, "example:ingot") == 100, "admin override must win immediately");
        check(value(catalog, "example:plate") == 200, "targeted recalculation should update direct dependent");
        check(value(catalog, "example:casing") == 400, "targeted recalculation should update transitive dependent");

        catalog.putAdmin("example:ingot", 0, "command:test");
        reload.recomputeAffected(Set.of("example:ingot"));
        check(catalog.amount("example:ingot").isEmpty(), "zero override deliberately makes held item unvalued");
        check(catalog.amount("example:plate").isEmpty(), "zero override must clear stale inferred direct values");
        check(catalog.amount("example:casing").isEmpty(), "zero override must clear stale inferred transitive values");

        check(catalog.removeAdmin("example:ingot"), "clear should remove live override");
        reload.recomputeAffected(Set.of("example:ingot"));
        check(value(catalog, "example:ingot") == 300, "clear should immediately fall back to datapack value");
        check(value(catalog, "example:plate") == 600, "clear should restore direct inferred value");
        check(value(catalog, "example:casing") == 1_200, "clear should restore transitive inferred value");

        System.out.println("MatterAdminOverrideSelfTest PASS");
    }

    private static RecipeMatterModel recipe(String output, String input, int count) {
        return new RecipeMatterModel(output + "_recipe", "crafting",
                List.of(new RecipeMatterModel.IngredientSlot(List.of(new RecipeMatterModel.ItemAmount(input, count)))),
                new RecipeMatterModel.OutputStack(output, 1), List.of());
    }

    private static long value(MatterCatalog catalog, String id) {
        return catalog.amount(id).orElseThrow();
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
