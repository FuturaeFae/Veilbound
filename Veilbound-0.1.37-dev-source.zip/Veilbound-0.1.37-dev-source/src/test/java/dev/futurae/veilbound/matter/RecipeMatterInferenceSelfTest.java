package dev.futurae.veilbound.matter;

import java.util.List;

public final class RecipeMatterInferenceSelfTest {
    public static void main(String[] args) {
        testRecursiveInference();
        testCheapestRecipeWins();
        testUnknownAlternativeBlocksUnsafeGuess();
        testReturnedContainerIsSubtracted();
        testSeedlessCycleRemainsUnresolved();
        testExplicitOverrideWins();
        testSafeReverseFurnaceInference();
        System.out.println("RecipeMatterInferenceSelfTest: PASS");
    }

    private static void testRecursiveInference() {
        MatterCatalog catalog = baseCatalog();
        var plate = recipe("mod:plate", List.of(slot("minecraft:iron_ingot", 1)), "mod:iron_plate", 1, List.of());
        var casing = recipe("mod:casing", List.of(slot("mod:iron_plate", 1), slot("mod:iron_plate", 1)), "mod:machine_casing", 1, List.of());
        new RecipeMatterInferenceEngine().recompute(catalog, List.of(casing, plate));
        eq(100, catalog.amount("mod:iron_plate").orElseThrow(), "plate");
        eq(200, catalog.amount("mod:machine_casing").orElseThrow(), "recursive casing");
    }

    private static void testCheapestRecipeWins() {
        MatterCatalog catalog = baseCatalog();
        var expensive = recipe("mod:x_expensive", List.of(slot("minecraft:iron_ingot", 1)), "mod:x", 1, List.of());
        var cheap = recipe("mod:x_cheap", List.of(slot("minecraft:stick", 1)), "mod:x", 1, List.of());
        new RecipeMatterInferenceEngine().recompute(catalog, List.of(expensive, cheap));
        eq(5, catalog.amount("mod:x").orElseThrow(), "cheapest production path");
    }

    private static void testUnknownAlternativeBlocksUnsafeGuess() {
        MatterCatalog catalog = baseCatalog();
        var tagged = new RecipeMatterModel(
                "mod:tagged",
                "crafting",
                List.of(new RecipeMatterModel.IngredientSlot(List.of(
                        new RecipeMatterModel.ItemAmount("minecraft:iron_ingot", 1),
                        new RecipeMatterModel.ItemAmount("othermod:mystery_ingot", 1)))),
                new RecipeMatterModel.OutputStack("mod:tag_result", 1),
                List.of());
        new RecipeMatterInferenceEngine().recompute(catalog, List.of(tagged));
        truth(catalog.amount("mod:tag_result").isEmpty(), "unknown tag alternative must block inference");
    }

    private static void testReturnedContainerIsSubtracted() {
        MatterCatalog catalog = baseCatalog();
        catalog.putExplicit("minecraft:bucket", 30, "test");
        catalog.putExplicit("minecraft:milk_bucket", 40, "test");
        var recipe = recipe(
                "mod:curd",
                List.of(slot("minecraft:milk_bucket", 1)),
                "mod:curd",
                1,
                List.of(new RecipeMatterModel.OutputStack("minecraft:bucket", 1)));
        new RecipeMatterInferenceEngine().recompute(catalog, List.of(recipe));
        eq(10, catalog.amount("mod:curd").orElseThrow(), "returned bucket");
    }

    private static void testSeedlessCycleRemainsUnresolved() {
        MatterCatalog catalog = baseCatalog();
        var a = recipe("mod:a", List.of(slot("mod:b", 1)), "mod:a", 1, List.of());
        var b = recipe("mod:b", List.of(slot("mod:a", 1)), "mod:b", 1, List.of());
        new RecipeMatterInferenceEngine().recompute(catalog, List.of(a, b));
        truth(catalog.amount("mod:a").isEmpty(), "cycle a unresolved");
        truth(catalog.amount("mod:b").isEmpty(), "cycle b unresolved");
    }

    private static void testExplicitOverrideWins() {
        MatterCatalog catalog = baseCatalog();
        catalog.putExplicit("mod:fixed", 777, "datapack");
        var recipe = recipe("mod:fixed_recipe", List.of(slot("minecraft:stick", 1)), "mod:fixed", 1, List.of());
        new RecipeMatterInferenceEngine().recompute(catalog, List.of(recipe));
        eq(777, catalog.amount("mod:fixed").orElseThrow(), "explicit override");
    }

    private static void testSafeReverseFurnaceInference() {
        MatterCatalog catalog = new MatterCatalog();
        catalog.putBuiltIn("minecraft:iron_ingot", 256, "projecte");
        var smelt = new RecipeMatterModel(
                "minecraft:iron_from_raw_iron",
                "minecraft:smelting",
                List.of(slot("minecraft:raw_iron", 1)),
                new RecipeMatterModel.OutputStack("minecraft:iron_ingot", 1),
                List.of());
        new RecipeMatterInferenceEngine().recompute(catalog, List.of(smelt));
        eq(256, catalog.amount("minecraft:raw_iron").orElseThrow(), "fixed ProjectE output back-propagates through furnace recipe");

        MatterCatalog unsafe = new MatterCatalog();
        unsafe.putBuiltIn("mod:fixed", 100, "test");
        var crafting = recipe("mod:not_reverse_safe", List.of(slot("mod:unknown", 1)), "mod:fixed", 1, List.of());
        new RecipeMatterInferenceEngine().recompute(unsafe, List.of(crafting));
        truth(unsafe.amount("mod:unknown").isEmpty(), "general crafting is not reverse-solved");
    }

    private static MatterCatalog baseCatalog() {
        MatterCatalog catalog = new MatterCatalog();
        catalog.putExplicit("minecraft:iron_ingot", 100, "test");
        catalog.putExplicit("minecraft:stick", 5, "test");
        return catalog;
    }

    private static RecipeMatterModel recipe(String id, List<RecipeMatterModel.IngredientSlot> inputs, String output, int count, List<RecipeMatterModel.OutputStack> returned) {
        return new RecipeMatterModel(id, "crafting", inputs, new RecipeMatterModel.OutputStack(output, count), returned);
    }

    private static RecipeMatterModel.IngredientSlot slot(String item, int count) {
        return new RecipeMatterModel.IngredientSlot(List.of(new RecipeMatterModel.ItemAmount(item, count)));
    }

    private static void eq(long expected, long actual, String message) {
        if (expected != actual) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
