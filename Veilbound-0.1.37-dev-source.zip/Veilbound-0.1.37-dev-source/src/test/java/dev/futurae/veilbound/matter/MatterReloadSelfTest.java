package dev.futurae.veilbound.matter;

import java.util.List;

public final class MatterReloadSelfTest {
    public static void main(String[] args) {
        MatterCatalog catalog = new MatterCatalog();
        catalog.putBuiltIn("minecraft:iron_ingot", 100L, "builtin");

        MatterReloadService reload = new MatterReloadService(catalog);
        reload.addRecipeSource(() -> List.of(new RecipeMatterModel(
                "example:plate",
                "crafting",
                List.of(new RecipeMatterModel.IngredientSlot(List.of(
                        new RecipeMatterModel.ItemAmount("minecraft:iron_ingot", 2)))),
                new RecipeMatterModel.OutputStack("example:iron_plate", 1),
                List.of())));

        reload.reload();
        check(catalog.get("example:iron_plate").orElseThrow().amount() == 200L,
                "first reload should infer the modded plate");

        catalog.putDatapack("minecraft:iron_ingot", 60L, "test_override");
        reload.reload();
        check(catalog.get("example:iron_plate").orElseThrow().amount() == 120L,
                "reload must discard the stale inferred cache and recompute from datapack values");

        catalog.putDatapack("example:iron_plate", 25L, "explicit_plate");
        reload.reload();
        MatterValue plate = catalog.get("example:iron_plate").orElseThrow();
        check(plate.amount() == 25L && plate.source() == MatterValue.Source.DATAPACK,
                "explicit datapack output must beat inference");

        System.out.println("MatterReloadSelfTest PASS");
    }

    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
