package dev.futurae.veilbound.domain;

import dev.futurae.veilbound.persistence.VeilboundSnapshotBinaryCodec;
import dev.futurae.veilbound.threshold.ThresholdRegistry;
import java.util.UUID;

/** Fixture encoded by the untouched 0.1.33-dev v13 codec. v14 discards the removed Core Matter-Intake bit. */
public final class PersistenceV13MigrationSelfTest {
    private static final String V13_PAYLOAD = "VkVJTAAAAA0AAAABMzMzM0REVVVmZnd3d3d3dwAAADV2ZWlsYm91bmQ6ZG9tYWluLzMzMzMzMzMzLTQ0NDQtNTU1NS02NjY2LTc3Nzc3Nzc3Nzc3NwAAAAA63mixADMzMzNERFVVZmZ3d3d3d3cAAAALQ09SRV9BQ1RJVkUAAAAIUkVTT05BTlQAAAAAAAAAAAAAAAD////+AAAAAP////4AAAACAAAAAgAAAAIAAAAAAAUWFQAAAAEAAAARbWluZWNyYWZ0OmRpYW1vbmQAAAAAAAAABQAAAAYBAAAAClBPU0lUSVZFX1gBAQEAAAADAAAAAQAAAAAAAAAGRFJJVkVOAQAAAApORUdBVElWRV9YAAAAAAAABlNUQUJMRQEAAAAKUE9TSVRJVkVfWQAAAAAAAAZTVEFCTEUBAAAACk5FR0FUSVZFX1kAAAAAAAAGU1RBQkxFAQAAAApQT1NJVElWRV9aAAAAAAAABlNUQUJMRQEAAAAKTkVHQVRJVkVfWgAAAAAAAAZTVEFCTEUAAAAAAAAAAAAAAAAAAAABAAAAF3ZlaWxib3VuZDpjb3JlX2F3YWtlbmVkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAaqqqqq7u8zM3d3u7u7u7u4zMzMzRERVVWZmd3d3d3d3AAAAE21pbmVjcmFmdDpvdmVyd29ybGQAAAABAAAACgAAAEAAAAAKAAAAAQAAAAAAAAABAQAAAAGIiIiImZmqqru7zMzMzMzM";

    public static void main(String[] args) {
        var snapshot = VeilboundSnapshotBinaryCodec.decode(V13_PAYLOAD);
        DomainRepository domains = new DomainRepository();
        ThresholdRegistry thresholds = new ThresholdRegistry();
        snapshot.restoreInto(domains, thresholds);
        UUID owner = UUID.fromString("33333333-4444-5555-6666-777777777777");
        DomainRecord record = domains.getRecord(owner).orElseThrow();
        truth(record.identity().seed() == 987654321L, "seed survives");
        truth(record.state().coreTier() == CoreTier.RESONANT, "tier survives");
        truth(record.state().dimensionalEnergy() == 333333L, "DE survives");
        truth(!record.state().globalExpansionEnabled(), "global expansion survives");
        BoundaryPylonState pylon = record.state().pylons().get(AxisDirection.POSITIVE_X);
        truth(pylon.blockPosition().equals(new DomainPosition(3, 1, 0)), "physical Pylon binding survives");
        truth(pylon.speed() == BoundaryPylonSpeed.DRIVEN, "Pylon speed survives");
        truth(record.state().coreUpgradeFedItems().getOrDefault("minecraft:diamond", 0L) == 5L, "Core feed survives");
        truth(record.state().completedMilestoneIds().contains("veilbound:core_awakened"), "milestone survives");
        var threshold = thresholds.get(UUID.fromString("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")).orElseThrow();
        truth(threshold.access().publicAccess(), "Threshold public state survives");
        truth(threshold.access().invitedGuests().contains(UUID.fromString("88888888-9999-aaaa-bbbb-cccccccccccc")), "Threshold invite survives");
        System.out.println("PersistenceV13MigrationSelfTest: PASS");
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
