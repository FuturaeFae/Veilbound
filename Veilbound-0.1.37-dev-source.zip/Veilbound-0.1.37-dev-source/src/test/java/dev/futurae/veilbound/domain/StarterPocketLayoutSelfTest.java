package dev.futurae.veilbound.domain;

public final class StarterPocketLayoutSelfTest {
    public static void main(String[] args) {
        require(StarterPocketLayout.isCanonical(), "starter pocket must remain 1x1x2 above one Void Anchor");
        require(StarterPocketLayout.VOID_ANCHOR_FLOOR.equals(new DomainPosition(0, -1, 0)),
                "Void Anchor must be immediately under Domain origin");
        require(StarterPocketLayout.ARRIVAL_X == 0.5D && StarterPocketLayout.ARRIVAL_Y == 0.0D
                        && StarterPocketLayout.ARRIVAL_Z == 0.5D,
                "arrival must be centered over the Void Anchor");
        System.out.println("StarterPocketLayoutSelfTest: PASS");
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
