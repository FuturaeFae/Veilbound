package dev.futurae.veilbound.matter;

public final class DefaultMatterValuesSelfTest {
    public static void main(String[] args) {
        MatterCatalog catalog = new MatterCatalog();
        DefaultMatterValues.installInto(catalog);

        eq(1, catalog.amount("minecraft:cobblestone").orElseThrow(), "ProjectE cobblestone");
        eq(128, catalog.amount("minecraft:coal").orElseThrow(), "ProjectE coal");
        eq(256, catalog.amount("minecraft:iron_ingot").orElseThrow(), "ProjectE iron");
        eq(2_048, catalog.amount("minecraft:gold_ingot").orElseThrow(), "ProjectE gold");
        eq(8_192, catalog.amount("minecraft:diamond").orElseThrow(), "ProjectE diamond");
        eq(16_384, catalog.amount("minecraft:emerald").orElseThrow(), "ProjectE emerald");
        eq(192, catalog.amount("minecraft:echo_shard").orElseThrow(), "ProjectE echo shard");
        eq(12_288, catalog.amount("minecraft:netherite_scrap").orElseThrow(), "ProjectE netherite scrap");
        eq(40_960, catalog.amount("minecraft:heavy_core").orElseThrow(), "ProjectE heavy core");
        eq(139_264, catalog.amount("minecraft:nether_star").orElseThrow(), "ProjectE nether star");
        eq(262_144, catalog.amount("minecraft:dragon_egg").orElseThrow(), "ProjectE dragon egg");
        eq(16, catalog.amount("minecraft:rabbit_hide").orElseThrow(), "ProjectE rabbit hide");

        check(DefaultMatterValues.PROJECTE_BASELINE.contains("1.1.0"), "baseline provenance should name ProjectE version");
        check(ProjectETagMatterValues.snapshot().get("c:ingots/iron") == 256L, "ProjectE iron tag");
        check(ProjectETagMatterValues.snapshot().get("c:ingots/gold") == 2_048L, "ProjectE gold tag");
        check(ProjectETagMatterValues.snapshot().get("c:ingots/copper") == 128L, "ProjectE copper tag");
        eq(188, DefaultMatterValues.snapshot().size(), "ProjectE direct seed/constants count");
        eq(184, DefaultMatterValues.snapshot().keySet().stream().filter(id -> !id.startsWith("projecte:")).count(),
                "registry-facing ProjectE seed count");
        eq(43, ProjectETagMatterValues.snapshot().size(), "ProjectE tag seed count");
        eq(74, ProjectESpecialMatterRecipeSource.INSTANCE.normalizedRecipes().size(), "ProjectE special conversion count");

        catalog.putDatapack("minecraft:diamond", 7, "test");
        eq(7, catalog.amount("minecraft:diamond").orElseThrow(), "datapack override beats ProjectE baseline");
        System.out.println("DefaultMatterValuesSelfTest: PASS (" + DefaultMatterValues.snapshot().size() + " seeds)");
    }

    private static void eq(long expected, long actual, String message) {
        if (expected != actual) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
