package dev.futurae.veilbound.law;

import dev.futurae.veilbound.domain.DomainState;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class LawEffectResolverSelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        LawDefinition one = new LawDefinition(
                "veilbound:one", "One", 1, Set.of(), Set.of(), Set.of("veilbound:shared", "veilbound:one_effect"));
        LawDefinition two = new LawDefinition(
                "veilbound:two", "Two", 1, Set.of(), Set.of(), Set.of("veilbound:shared", "veilbound:two_effect"));
        LawRegistry registry = new LawRegistry();
        registry.replaceAll(List.of(one, two));
        state.imposeLaw(one.id());
        state.imposeLaw(two.id());
        state.imposeLaw("removedpack:stale_law");

        ActiveLawEffects resolved = new LawEffectResolver().resolve(state, registry);
        truth(resolved.effectIds().equals(Set.of("veilbound:shared", "veilbound:one_effect", "veilbound:two_effect")),
                "effect ids are unioned without duplication");
        truth(resolved.sourceLawIdsByEffect().get("veilbound:shared").equals(Set.of(one.id(), two.id())),
                "shared effect keeps source provenance");
        truth(resolved.missingLawDefinitionIds().equals(List.of("removedpack:stale_law")),
                "removed datapack Law is reported instead of producing effects");
        truth(resolved.has("veilbound:two_effect"), "effect lookup succeeds");
        truth(!resolved.has("veilbound:missing"), "unknown effect lookup fails");

        System.out.println("LawEffectResolverSelfTest: PASS");
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
