package dev.futurae.veilbound.upgrade;

import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import java.util.List;
import java.util.UUID;

public final class CoreTierUpgradeSelfTest {
    public static void main(String[] args) {
        CoreUpgradeDefinition definition = new CoreUpgradeDefinition(
                CoreTier.NASCENT, CoreTier.ANCHORED,
                List.of(new UpgradeIngredient("minecraft:diamond", 4), new UpgradeIngredient("minecraft:echo_shard", 2)));
        CoreUpgradeRegistry registry = new CoreUpgradeRegistry();
        registry.replaceAll(List.of(definition));

        DomainState state = new DomainState(UUID.randomUUID());
        state.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        state.awakenCore(DomainPosition.ORIGIN);
        state.setDimensionalEnergy(19_999);
        CoreTierUpgradeService service = new CoreTierUpgradeService();

        var first = service.feed(state, registry, "minecraft:diamond", 64);
        eq(4, first.consumed(), "feed consumes only missing requirement");
        truth(!first.upgraded(), "partial ingredient set cannot upgrade");
        var second = service.feed(state, registry, "minecraft:echo_shard", 2);
        eq(2, second.consumed(), "second requirement accepted exactly");
        truth(!second.upgraded() && "insufficient_dimensional_energy".equals(second.reason()),
                "complete item requirements wait for DE without losing progress");
        truth(state.coreUpgradeFedItems().size() == 2, "completed item feed remains persisted while waiting for DE");

        state.insertDimensionalEnergy(1);
        var finalize = service.feed(state, registry, "minecraft:diamond", 1);
        eq(0, finalize.consumed(), "finalization touch does not consume excess ingredient");
        truth(finalize.upgraded(), "completed feed plus required DE upgrades Core");
        truth(state.coreTier() == CoreTier.ANCHORED, "Core advanced one tier");
        eq(0, state.dimensionalEnergy(), "Anchored upgrade consumes settled 20,000 DE cost");
        truth(state.coreUpgradeFedItems().isEmpty(), "tier transition clears previous-tier feed progress");

        boolean duplicateRejected = false;
        try { registry.replaceAll(List.of(definition, definition)); }
        catch (IllegalArgumentException expected) { duplicateRejected = true; }
        truth(duplicateRejected, "registry rejects two definitions for the same source tier");
        System.out.println("CoreTierUpgradeSelfTest: PASS");
    }

    private static void eq(long expected, long actual, String message) {
        if (expected != actual) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String message) { if (!value) throw new AssertionError(message); }
}
