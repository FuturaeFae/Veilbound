package dev.futurae.veilbound.matter;

import java.util.List;

public final class ProjectESpecialMatterRecipeSourceSelfTest {
    public static void main(String[] args) {
        MatterCatalog catalog = new MatterCatalog();
        DefaultMatterValues.installInto(catalog);

        // Tiny stand-in for vanilla recipes needed by the ProjectE custom conversions under test.
        List<RecipeMatterModel> vanilla = List.of(
                recipe("gold_block", List.of(slot("minecraft:gold_ingot", 9)), "minecraft:gold_block", 1),
                recipe("bucket", List.of(slot("minecraft:iron_ingot", 1), slot("minecraft:iron_ingot", 1), slot("minecraft:iron_ingot", 1)), "minecraft:bucket", 1),
                recipe("paper", List.of(slot("minecraft:sugar_cane", 1), slot("minecraft:sugar_cane", 1), slot("minecraft:sugar_cane", 1)), "minecraft:paper", 3),
                recipe("stick", List.of(slot("minecraft:planks", 1), slot("minecraft:planks", 1)), "minecraft:stick", 4),
                recipe("snow_block", List.of(slot("minecraft:snowball", 1), slot("minecraft:snowball", 1), slot("minecraft:snowball", 1), slot("minecraft:snowball", 1)), "minecraft:snow_block", 1)
        );
        // Loader-neutral tests do not have live tags, so install the handful of tag values the
        // special conversions depend on just as NeoForgeProjectEMatterSeeder would.
        catalog.putBuiltIn("minecraft:planks", 8, "projecte-tag");
        new RecipeMatterInferenceEngine().recompute(catalog, concat(vanilla, ProjectESpecialMatterRecipeSource.INSTANCE.normalizedRecipes()));

        eq(18_432, catalog.amount("minecraft:gold_block").orElseThrow(), "gold storage block");
        eq(147_584, catalog.amount("minecraft:enchanted_golden_apple").orElseThrow(), "enchanted golden apple ProjectE conversion");
        eq(768, catalog.amount("minecraft:bucket").orElseThrow(), "bucket");
        eq(768, catalog.amount("minecraft:water_bucket").orElseThrow(), "water is FREE in ProjectE fluid mapping");
        eq(832, catalog.amount("minecraft:lava_bucket").orElseThrow(), "lava bucket");
        eq(784, catalog.amount("minecraft:milk_bucket").orElseThrow(), "milk bucket");
        eq(14_336, catalog.amount("minecraft:bell").orElseThrow(), "bell");
        eq(16, catalog.amount("minecraft:honeycomb").orElseThrow(), "one honey bottle maps to three honeycomb");
        eq(4, catalog.amount("minecraft:hanging_roots").orElseThrow(), "hanging roots");
        eq(49, catalog.amount("minecraft:soul_soil").orElseThrow(), "soul soil equivalence");
        eq(16, catalog.amount("minecraft:sculk").orElseThrow(), "sculk from four veins");

        System.out.println("ProjectESpecialMatterRecipeSourceSelfTest: PASS (" +
                ProjectESpecialMatterRecipeSource.INSTANCE.normalizedRecipes().size() + " ProjectE conversions)");
    }

    private static List<RecipeMatterModel> concat(List<RecipeMatterModel> a, java.util.Collection<RecipeMatterModel> b) {
        java.util.ArrayList<RecipeMatterModel> all = new java.util.ArrayList<>(a);
        all.addAll(b);
        return all;
    }
    private static RecipeMatterModel recipe(String id, List<RecipeMatterModel.IngredientSlot> inputs, String output, int count) {
        return new RecipeMatterModel("minecraft:" + id, "minecraft:crafting", inputs, new RecipeMatterModel.OutputStack(output, count), List.of());
    }
    private static RecipeMatterModel.IngredientSlot slot(String item, int count) {
        return new RecipeMatterModel.IngredientSlot(List.of(new RecipeMatterModel.ItemAmount(item, count)));
    }
    private static void eq(long expected, long actual, String label) {
        if (expected != actual) throw new AssertionError(label + ": expected=" + expected + " actual=" + actual);
    }
}
