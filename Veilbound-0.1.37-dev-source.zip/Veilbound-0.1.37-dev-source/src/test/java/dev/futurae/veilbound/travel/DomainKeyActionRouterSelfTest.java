package dev.futurae.veilbound.travel;

import dev.futurae.veilbound.domain.DomainIdentity;
import dev.futurae.veilbound.threshold.GuestThresholdSession;
import java.util.Optional;
import java.util.UUID;

public final class DomainKeyActionRouterSelfTest {
    public static void main(String[] args) {
        UUID player = UUID.randomUUID();
        UUID owner = UUID.randomUUID();
        GuestThresholdSession session = new GuestThresholdSession(
                player,
                owner,
                UUID.randomUUID(),
                new ReturnAnchor("minecraft:overworld", 1.5, 64, -2.5, 90, 5),
                100L);

        var guest = DomainKeyActionRouter.decide(
                player, DomainIdentity.dimensionIdFor(owner), Optional.of(session));
        eq(DomainKeyActionRouter.Action.EXIT_GUEST_DOMAIN, guest.action(), "tracked guest exits visited Domain");
        truth(!guest.clearStaleGuestSession(), "valid guest session retained until successful teleport");

        var own = DomainKeyActionRouter.decide(
                player, DomainIdentity.dimensionIdFor(player), Optional.empty());
        eq(DomainKeyActionRouter.Action.EXIT_OWN_DOMAIN, own.action(), "owner exits own Domain");

        var outside = DomainKeyActionRouter.decide(player, "minecraft:the_nether", Optional.empty());
        eq(DomainKeyActionRouter.Action.ENTER_OWN_DOMAIN, outside.action(), "outside enters own Domain");

        var stale = DomainKeyActionRouter.decide(player, "minecraft:overworld", Optional.of(session));
        eq(DomainKeyActionRouter.Action.ENTER_OWN_DOMAIN, stale.action(), "stale guest session does not hijack V");
        truth(stale.clearStaleGuestSession(), "stale guest session is explicitly cleaned");

        var foreignUntracked = DomainKeyActionRouter.decide(
                player, DomainIdentity.dimensionIdFor(UUID.randomUUID()), Optional.empty());
        eq(DomainKeyActionRouter.Action.DENY_UNTRACKED_FOREIGN_DOMAIN, foreignUntracked.action(),
                "foreign Domain without return anchor is denied");

        System.out.println("DomainKeyActionRouterSelfTest: PASS");
    }

    private static void eq(Object expected, Object actual, String message) {
        if (!expected.equals(actual)) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
