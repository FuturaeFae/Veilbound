package dev.futurae.veilbound.domain;

import dev.futurae.veilbound.travel.OwnerRecallService;
import dev.futurae.veilbound.travel.ReturnAnchor;
import java.util.UUID;

public final class DomainRuntimeLifecycleSelfTest {
    public static void main(String[] args) {
        UUID owner = UUID.fromString("123e4567-e89b-12d3-a456-426614174000");
        DomainRepository repository = new DomainRepository();
        DomainRecord record = repository.createRecord(owner, 987654321L);
        truth(record.identity().dimensionId().equals("veilbound:domain/123e4567-e89b-12d3-a456-426614174000"), "stable dimension id");
        truth(record.identity().seed() == 987654321L, "seed preserved");

        ReturnAnchor outside = new ReturnAnchor("minecraft:overworld", 12.5, 70, -4.5, 35, 10);
        var enter = OwnerRecallService.requestFromOutside(record, outside);
        truth(enter.allowed() && enter.enteringDomain(), "outside recall enters Domain");
        truth(enter.targetDomainId().equals(record.identity().dimensionId()), "entry target");
        truth(record.ownerReturnAnchor().orElseThrow().equals(outside), "outside anchor saved");

        var exit = OwnerRecallService.requestFromInside(record);
        truth(exit.allowed() && !exit.enteringDomain(), "inside recall exits Domain");
        truth(exit.returnAnchor().equals(outside), "exact return anchor preserved");
        OwnerRecallService.completeExit(record);
        truth(record.ownerReturnAnchor().isEmpty(), "anchor clears only after confirmed exit");

        DomainRuntimeTracker tracker = new DomainRuntimeTracker();
        tracker.setLoaded(owner, true);
        tracker.setPlayersInside(owner, 1);
        truth(!tracker.unloadDecision(owner).allowed(), "players block unload");
        tracker.setPlayersInside(owner, 0);
        tracker.setPendingTransits(owner, 1);
        truth(!tracker.unloadDecision(owner).allowed(), "pending transit blocks unload");
        tracker.setPendingTransits(owner, 0);
        truth(tracker.unloadDecision(owner).allowed(), "unused Domain can unload");
        tracker.setLoaded(owner, false);
        truth(tracker.isDormant(owner), "unloaded Domain is dormant");
        System.out.println("DomainRuntimeLifecycleSelfTest: PASS");
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
