package dev.futurae.veilbound.memory;

import dev.futurae.veilbound.domain.DomainFeature;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class MemoryCaptureSelfTest {
    public static void main(String[] args) {
        MemoryDefinition broad = new MemoryDefinition(
                "veilbound:sky", "Sky", Set.of("sky"), Map.of("visual.sky", "blue"),
                Map.of("dimension", "minecraft:overworld"), Set.of(), Set.of(DomainFeature.FIRMAMENT));
        MemoryDefinition exact = new MemoryDefinition(
                "veilbound:rain", "Rain", Set.of("rain"), Map.of("mechanic.weather", "rain"),
                Map.of("dimension", "minecraft:overworld", "weather", "rain"),
                Set.of("veilbound:sky"), Set.of(DomainFeature.WEATHER));
        MemoryCaptureService capture = new MemoryCaptureService();

        var first = capture.choose(List.of(broad, exact),
                Map.of("dimension", "minecraft:overworld", "weather", "rain"), Set.of());
        eq("veilbound:sky", first.memory().id(), "prerequisite blocks advanced Memory");

        var second = capture.choose(List.of(broad, exact),
                Map.of("dimension", "minecraft:overworld", "weather", "rain"), Set.of("veilbound:sky"));
        eq("veilbound:rain", second.memory().id(), "more-specific eligible Memory wins");

        var none = capture.choose(List.of(exact), Map.of("dimension", "minecraft:the_nether"), Set.of("veilbound:sky"));
        truth(!none.capturable(), "mismatched environment is rejected");
        System.out.println("MemoryCaptureSelfTest: PASS");
    }

    private static void eq(String expected, String actual, String msg) {
        if (!expected.equals(actual)) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String msg) { if (!value) throw new AssertionError(msg); }
}
