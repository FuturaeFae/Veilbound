package dev.futurae.veilbound.matter;

import java.util.List;
import java.util.Map;

public final class MatterDatapackSnapshotSelfTest {
    public static void main(String[] args) {
        MatterCatalog catalog = new MatterCatalog();
        catalog.putBuiltIn("minecraft:diamond", 256, "builtin");
        catalog.putDatapack("minecraft:diamond", 999, "old-pack");
        catalog.putDatapack("example:removed_on_reload", 50, "old-pack");

        MatterDatapackSnapshot snapshot = new MatterDatapackSnapshot(
                Map.of(
                        "minecraft:diamond", new MatterDatapackSnapshot.OverrideValue(300, "new-pack"),
                        "example:machine", new MatterDatapackSnapshot.OverrideValue(777, "new-pack")),
                List.of("example warning"));
        snapshot.applyTo(catalog);

        eq(300, catalog.amount("minecraft:diamond").orElseThrow(), "new datapack beats builtin");
        eq(777, catalog.amount("example:machine").orElseThrow(), "new override installed");
        truth(catalog.amount("example:removed_on_reload").isEmpty(), "stale datapack entry removed");
        truth(snapshot.warnings().size() == 1, "warnings retained");

        System.out.println("MatterDatapackSnapshotSelfTest PASS");
    }

    private static void eq(long expected, long actual, String message) {
        if (expected != actual) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
