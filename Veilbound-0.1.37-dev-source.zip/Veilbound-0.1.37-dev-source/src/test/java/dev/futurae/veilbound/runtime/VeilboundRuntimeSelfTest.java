package dev.futurae.veilbound.runtime;

import java.util.UUID;

public final class VeilboundRuntimeSelfTest {
    public static void main(String[] args) {
        VeilboundRuntime runtime = new VeilboundRuntime();
        UUID owner = UUID.randomUUID();
        runtime.domains().create(owner);
        check(runtime.domains().get(owner).isPresent(), "runtime should own the shared Domain repository");
        check(runtime.matter().amount("minecraft:diamond").orElseThrow() == 8_192,
                "default Matter seeds should be installed at runtime creation");
        check(runtime.matter().amount("minecraft:nether_star").orElseThrow()
                        > runtime.matter().amount("minecraft:diamond").orElseThrow(),
                "ProjectE progression anchors should preserve high-value endgame drops");
        System.out.println("VeilboundRuntimeSelfTest: PASS");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
