package dev.futurae.veilbound.memory;

public final class DomainSkyLightProfileSelfTest {
    public static void main(String[] args) {
        var dark = DomainSkyLightProfile.sample(false, false, 6_000L);
        near(dark.gameplaySkyLightLevel(), 0.0F, "no Open Sky remains mechanically dark");
        near(dark.visualSkyLightFactor(), 0.0F, "no Open Sky remains visually dark");

        var fixed = DomainSkyLightProfile.sample(true, false, 18_000L);
        near(fixed.gameplaySkyLightLevel(), 15.0F, "Open Sky without Celestial Cycle is full daylight");
        near(fixed.visualSkyLightFactor(), 1.0F, "Open Sky without Celestial Cycle is fully lit");

        var day = DomainSkyLightProfile.sample(true, true, 6_000L);
        near(day.gameplaySkyLightLevel(), 15.0F, "Celestial daytime restores vanilla gameplay skylight");
        near(day.visualSkyLightFactor(), 1.0F, "Celestial daytime restores vanilla visual skylight");

        var night = DomainSkyLightProfile.sample(true, true, 18_000L);
        near(night.gameplaySkyLightLevel(), 4.0F, "Celestial night uses vanilla 26.2 gameplay minimum");
        near(night.visualSkyLightFactor(), 0.24F, "Celestial night uses vanilla 26.2 visual minimum");

        var beforeMidnight = DomainSkyLightProfile.sample(true, true, 23_900L);
        var afterMidnight = DomainSkyLightProfile.sample(true, true, 100L);
        truth(beforeMidnight.gameplaySkyLightLevel() > 4.0F && beforeMidnight.gameplaySkyLightLevel() < 15.0F,
                "gameplay skylight interpolates across midnight");
        truth(afterMidnight.gameplaySkyLightLevel() > beforeMidnight.gameplaySkyLightLevel(),
                "gameplay skylight continues rising after midnight wrap");
        truth(afterMidnight.visualSkyLightFactor() > beforeMidnight.visualSkyLightFactor(),
                "visual skylight continues rising after midnight wrap");

        var wrapped = DomainSkyLightProfile.sample(true, true, 24_000L + 6_000L);
        near(wrapped.gameplaySkyLightLevel(), day.gameplaySkyLightLevel(), "day profile wraps every 24000 ticks");
        near(wrapped.visualSkyLightFactor(), day.visualSkyLightFactor(), "visual profile wraps every 24000 ticks");
        System.out.println("DomainSkyLightProfileSelfTest: PASS");
    }

    private static void near(float actual, float expected, String message) {
        if (Math.abs(actual - expected) > 0.0002F) {
            throw new AssertionError(message + ": expected " + expected + " but got " + actual);
        }
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
