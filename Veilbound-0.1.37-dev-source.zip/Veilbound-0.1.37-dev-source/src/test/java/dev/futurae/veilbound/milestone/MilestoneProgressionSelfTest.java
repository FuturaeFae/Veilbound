package dev.futurae.veilbound.milestone;

import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.BoundaryPylonState;
import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class MilestoneProgressionSelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        MilestoneRegistry registry = new MilestoneRegistry();
        registry.replaceAll(List.of(
                new MilestoneDefinition(
                        "veilbound:core_awakened", "Awaken the Core", Set.of(),
                        new MilestoneCriteria(true, null, 0, 0, 0, 0, 0, 0, 0, 0, false, Set.of()),
                        Set.of(DomainFeature.MILESTONES)),
                new MilestoneDefinition(
                        "veilbound:anchored_core", "Anchor the Core", Set.of("veilbound:core_awakened"),
                        new MilestoneCriteria(false, CoreTier.ANCHORED, 0, 0, 0, 0, 0, 0, 0, 0, false, Set.of()),
                        Set.of()),
                new MilestoneDefinition(
                        "veilbound:first_memory", "Archive a Memory", Set.of("veilbound:core_awakened"),
                        new MilestoneCriteria(false, null, 1, 0, 0, 0, 0, 0, 0, 0, false, Set.of()),
                        Set.of()),
                new MilestoneDefinition(
                        "veilbound:environmental_mastery", "Environmental Mastery",
                        Set.of("veilbound:anchored_core", "veilbound:first_memory"),
                        new MilestoneCriteria(false, CoreTier.ANCHORED, 3, 0, 0, 0, 0, 0, 0, 0, false, Set.of()),
                        Set.of(DomainFeature.ENVIRONMENTAL_MASTERY)),
                new MilestoneDefinition(
                        "veilbound:first_pylon", "Bind a Pylon", Set.of("veilbound:core_awakened"),
                        new MilestoneCriteria(false, null, 0, 1, 0, 0, 0, 0, 0, 0, false, Set.of()), Set.of()),
                new MilestoneDefinition(
                        "veilbound:first_threshold", "Open a Threshold", Set.of("veilbound:core_awakened"),
                        new MilestoneCriteria(false, null, 0, 0, 0, 1, 0, 0, 0, 0, false, Set.of()), Set.of())));

        MilestoneService service = new MilestoneService();
        truth(service.evaluate(state, registry, 0).completedNow().isEmpty(), "fresh pre-Core Domain completes nothing");

        state.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        state.awakenCore(DomainPosition.ORIGIN);
        var awakened = service.evaluate(state, registry, 0);
        truth(awakened.completedNow().stream().anyMatch(m -> m.id().equals("veilbound:core_awakened")), "Core milestone completes");
        truth(state.hasFeature(DomainFeature.MILESTONES), "milestone capability reward");

        state.setCoreTier(CoreTier.ANCHORED);
        state.unlockMemory("veilbound:one");
        state.unlockMemory("veilbound:two");
        state.unlockMemory("veilbound:three");
        var mastery = service.evaluate(state, registry, 0);
        truth(mastery.completedNow().stream().anyMatch(m -> m.id().equals("veilbound:anchored_core")), "Anchored prerequisite completes");
        truth(mastery.completedNow().stream().anyMatch(m -> m.id().equals("veilbound:first_memory")), "Memory prerequisite completes");
        truth(mastery.completedNow().stream().anyMatch(m -> m.id().equals("veilbound:environmental_mastery")), "dependent milestone chains in one evaluation");
        truth(state.hasFeature(DomainFeature.ENVIRONMENTAL_MASTERY), "Environmental Mastery unlocks");

        state.setPylon(new BoundaryPylonState(
                AxisDirection.POSITIVE_X, false, true, new DomainPosition(1, 0, 0)));
        var infrastructure = service.evaluate(state, registry, 1);
        truth(infrastructure.completedNow().stream().anyMatch(m -> m.id().equals("veilbound:first_pylon")), "physical Pylon criterion");
        truth(infrastructure.completedNow().stream().anyMatch(m -> m.id().equals("veilbound:first_threshold")), "Threshold criterion");
        truth(service.evaluate(state, registry, 1).completedNow().isEmpty(), "milestones are one-shot");
        System.out.println("MilestoneProgressionSelfTest: PASS");
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
