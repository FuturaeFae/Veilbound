package dev.futurae.veilbound.stability;

import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.BoundaryPylonState;
import dev.futurae.veilbound.domain.BoundaryPylonSpeed;
import dev.futurae.veilbound.domain.DomainState;
import java.util.UUID;

public final class StabilitySelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        state.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        state.awakenCore(DomainPosition.ORIGIN);
        state.setPylon(new BoundaryPylonState(AxisDirection.POSITIVE_X, true, true, new DomainPosition(2, 0, 0)));
        state.setPylon(new BoundaryPylonState(AxisDirection.NEGATIVE_X, true, true, new DomainPosition(-2, 0, 0)));
        StabilityPolicy policy = new StabilityPolicy(100, 10, 20, 15, .5, .75, 1.0);
        StabilitySnapshot stable = StabilityCalculator.calculate(state, 0, 0, policy);
        eq(2, stable.activeExpansionPylons(), "two active pylons");
        truth(stable.band() == StabilityBand.STABLE, "20/100 stable");
        StabilitySnapshot critical = StabilityCalculator.calculate(state, 2, 1, policy);
        truth(critical.band() == StabilityBand.CRITICAL, "75/100 critical");
        state.setPylon(new BoundaryPylonState(AxisDirection.POSITIVE_X, true, true, new DomainPosition(2, 0, 0), BoundaryPylonSpeed.DRIVEN));
        StabilitySnapshot driven = StabilityCalculator.calculate(state, 0, 0, policy);
        truth(Double.compare(driven.load(), 50.0) == 0, "Driven pylon squares load: 40 + Stable 10");

        StabilityRuntimePolicy defaults = StabilityRuntimePolicy.DEVELOPMENT_DEFAULT;
        truth(defaults.capacity(dev.futurae.veilbound.domain.CoreTier.NASCENT) == 100.0, "Nascent capacity default");
        truth(defaults.capacity(dev.futurae.veilbound.domain.CoreTier.TRANSCENDENT) == 520.0, "Transcendent capacity default");
        truth(defaults.activePylonLoad() == 4.0, "Pylon +4 load default");
        truth(defaults.thresholdLoad() == 6.0, "Threshold +6 load default");
        truth(defaults.continuityAnchorLoad() == 4.0, "Anchor +4 load default");
        truth(defaults.maxContinuityAnchors() == 25, "25 Anchor cap default");
        System.out.println("StabilitySelfTest: PASS");
    }

    private static void eq(long expected, long actual, String msg) {
        if (expected != actual) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String msg) { if (!value) throw new AssertionError(msg); }
}
