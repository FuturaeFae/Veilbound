package dev.futurae.veilbound.inventory;

import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import java.util.List;
import java.util.UUID;

public final class VeilCraftingSelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        state.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        state.awakenCore(DomainPosition.ORIGIN);
        state.setCoreTier(CoreTier.RESONANT);
        state.unlockFeature(DomainFeature.VEIL_INVENTORY);
        state.unlockFeature(DomainFeature.VEIL_CRAFTING);
        VeilStorageCapacity capacity = VeilStoragePolicy.RESONANT;
        VeilInventory inv = new VeilInventory();
        VeilStackKey oak = VeilStackKey.plain("minecraft:oak_planks");
        VeilStackKey birch = VeilStackKey.plain("minecraft:birch_planks");
        VeilStackKey bucket = VeilStackKey.plain("minecraft:bucket");
        VeilStackKey result = VeilStackKey.plain("minecraft:crafting_table");
        inv.insert(oak, 2, capacity);
        inv.insert(birch, 2, capacity);
        inv.insert(bucket, 1, capacity);

        VeilCraftingService service = new VeilCraftingService();
        var preview = service.preview(state, inv, capacity,
                List.of(new VeilCraftingService.IngredientRequest(List.of(oak, birch), 4)),
                List.of(new VeilCraftingService.ProducedStack(result, 1),
                        new VeilCraftingService.ProducedStack(bucket, 1)));
        truth(preview.crafted(), "preview uses the same validation as commit");
        eq(5, inv.totalItems(), "preview never mutates storage");
        eq(2, inv.count(oak), "preview leaves oak untouched");
        eq(2, inv.count(birch), "preview leaves birch untouched");

        var success = service.craft(state, inv, capacity,
                List.of(new VeilCraftingService.IngredientRequest(List.of(oak, birch), 4)),
                List.of(new VeilCraftingService.ProducedStack(result, 1),
                        new VeilCraftingService.ProducedStack(bucket, 1)));
        truth(success.crafted(), "craft succeeds by pulling matching alternatives from storage");
        eq(0, inv.count(oak), "oak consumed");
        eq(0, inv.count(birch), "birch consumed");
        eq(1, inv.count(result), "result returned to storage");
        eq(2, inv.count(bucket), "remainder/container returned safely");

        long before = inv.totalItems();
        var missing = service.craft(state, inv, capacity,
                List.of(new VeilCraftingService.IngredientRequest(List.of(oak), 9)),
                List.of(new VeilCraftingService.ProducedStack(result, 99)));
        truth(!missing.crafted(), "missing ingredients reject craft");
        eq(before, inv.totalItems(), "failed craft is atomic");
        eq(1, inv.count(result), "failed craft does not create output");

        VeilInventory tiny = new VeilInventory();
        VeilStorageCapacity tinyCapacity = new VeilStorageCapacity(1, 1);
        tiny.insert(oak, 1, tinyCapacity);
        var overflow = service.craft(state, tiny, tinyCapacity,
                List.of(new VeilCraftingService.IngredientRequest(List.of(oak), 1)),
                List.of(new VeilCraftingService.ProducedStack(result, 2)));
        truth(!overflow.crafted(), "output capacity is preflighted");
        eq(1, tiny.count(oak), "capacity failure leaves ingredient untouched");
        System.out.println("VeilCraftingSelfTest: PASS");
    }

    private static void eq(long expected, long actual, String message) {
        if (expected != actual) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String message) { if (!value) throw new AssertionError(message); }
}
