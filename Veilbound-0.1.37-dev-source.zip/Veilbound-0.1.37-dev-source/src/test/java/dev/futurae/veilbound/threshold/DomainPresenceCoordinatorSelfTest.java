package dev.futurae.veilbound.threshold;

import dev.futurae.veilbound.travel.ReturnAnchor;

import dev.futurae.veilbound.domain.DomainPosition;
import java.util.UUID;

public final class DomainPresenceCoordinatorSelfTest {
    public static void main(String[] args) {
        UUID owner = UUID.randomUUID();
        UUID a = UUID.randomUUID();
        UUID b = UUID.randomUUID();
        ThresholdSessionManager sessions = new ThresholdSessionManager();
        DomainPresenceCoordinator presence = new DomainPresenceCoordinator(sessions);
        ThresholdAccess access = new ThresholdAccess();
        access.setPublicAccess(true);
        ThresholdDefinition threshold = new ThresholdDefinition(
                UUID.randomUUID(), owner, DomainPosition.ORIGIN, access);
        ReturnAnchor anchorA = new ReturnAnchor("minecraft:overworld", 1.25, 70, 2.5, 20, 5);
        ReturnAnchor anchorB = new ReturnAnchor("minecraft:overworld", 100.5, 64, -20.5, 0, 0);
        check(sessions.beginGuestEntry(threshold, a, anchorA, 1, true, true).allowed(), "guest A entry");
        check(sessions.beginGuestEntry(threshold, b, anchorB, 2, true, true).allowed(), "guest B entry");

        var evacuated = presence.ownerDisconnected(owner);
        check(evacuated.size() == 2, "both guests must evacuate");
        check(evacuated.stream().anyMatch(s -> s.guestId().equals(a) && s.returnAnchor().equals(anchorA)),
                "guest A must retain its own return anchor");
        check(evacuated.stream().anyMatch(s -> s.guestId().equals(b) && s.returnAnchor().equals(anchorB)),
                "guest B must retain its own return anchor");
        check(sessions.activeSessions().isEmpty(), "sessions must be removed before teleport execution");
        System.out.println("DomainPresenceCoordinatorSelfTest: PASS");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
