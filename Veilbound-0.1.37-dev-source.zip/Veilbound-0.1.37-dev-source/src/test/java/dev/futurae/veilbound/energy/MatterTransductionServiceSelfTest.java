package dev.futurae.veilbound.energy;

import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import dev.futurae.veilbound.matter.MatterTransmutationState;
import java.util.UUID;

public final class MatterTransductionServiceSelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        state.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        state.awakenCore(DomainPosition.ORIGIN);
        // Empty the one-time Nascent ignition reserve so this test measures only Transducer output.
        state.setDimensionalEnergy(0);
        TransductionPolicy policy = new TransductionPolicy(10, 2);
        long transducerMatter = 20L;

        // Keep a terminal reserve beside the test to prove Transducer conversion cannot touch it.
        MatterTransmutationState veilInventoryMatter = new MatterTransmutationState();
        veilInventoryMatter.addMatter(999L);

        var offline = MatterTransductionService.transduce(state, transducerMatter, 1_000, policy, false);
        eq(false, offline.converted(), "offline rejected");
        eq(999L, veilInventoryMatter.storedMatter(), "offline leaves Veil Inventory Matter");
        eq(0L, state.dimensionalEnergy(), "offline leaves DE");

        var converted = MatterTransductionService.transduce(state, transducerMatter, 100, policy, true);
        eq(true, converted.converted(), "Transducer conversion uses only its local Matter/FE buffers and the DE-only Core");
        eq(10L, converted.matterConsumed(), "local Matter consumed");
        eq(100L, converted.forgeEnergyConsumed(), "FE consumed");
        eq(5L, converted.dimensionalEnergyProduced(), "DE produced");
        eq(999L, veilInventoryMatter.storedMatter(), "Veil Inventory Matter remains completely separate");
        eq(5L, state.dimensionalEnergy(), "Core filled");

        var noFe = MatterTransductionService.transduce(state, transducerMatter - converted.matterConsumed(), 0, policy, true);
        eq(false, noFe.converted(), "zero FE rejected");
        eq(999L, veilInventoryMatter.storedMatter(), "failed conversion still cannot touch terminal Matter");
        eq(5L, state.dimensionalEnergy(), "failed conversion preserves DE");
        System.out.println("MatterTransductionServiceSelfTest: PASS");
    }

    private static void eq(Object expected, Object actual, String label) {
        if (!java.util.Objects.equals(expected, actual)) throw new AssertionError(label + ": expected=" + expected + " actual=" + actual);
    }
}
