package dev.futurae.veilbound.energy;

import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import java.util.UUID;

public final class DimensionalTransducerSelfTest {
    public static void main(String[] args) {
        DomainState preCore = new DomainState(UUID.randomUUID());
        eq("core_inactive", DimensionalTransducer.transduce(preCore, 10, 1_000, new TransductionPolicy(10, 2), true).reason(), "pre-Core reject");

        DomainState state = new DomainState(UUID.randomUUID());
        state.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        state.awakenCore(DomainPosition.ORIGIN);
        // Awakening intentionally grants the Nascent ignition reserve needed to bootstrap the first engineering tree.
        state.setDimensionalEnergy(0);
        var offline = DimensionalTransducer.transduce(state, 10, 1_000, new TransductionPolicy(10, 2), false);
        eq("owner_offline", offline.reason(), "offline reject");
        var result = DimensionalTransducer.transduce(state, 10, 1_000, new TransductionPolicy(10, 2), true);
        truth(result.converted(), "conversion occurs");
        eq(10, result.matterConsumed(), "matter consumed");
        eq(100, result.forgeEnergyConsumed(), "FE consumed");
        eq(5, result.dimensionalEnergyProduced(), "DE produced");
        eq(5, state.dimensionalEnergy(), "Core gets DE only");
        System.out.println("DimensionalTransducerSelfTest: PASS");
    }

    private static void eq(long expected, long actual, String msg) {
        if (expected != actual) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual);
    }
    private static void eq(String expected, String actual, String msg) {
        if (!expected.equals(actual)) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String msg) { if (!value) throw new AssertionError(msg); }
}
