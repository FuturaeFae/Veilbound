package dev.futurae.veilbound.domain;

import java.util.UUID;

public final class DomainIdentityParsingSelfTest {
    public static void main(String[] args) {
        UUID owner = UUID.fromString("123e4567-e89b-12d3-a456-426614174000");
        String canonical = DomainIdentity.dimensionIdFor(owner);
        eq(owner, DomainIdentity.ownerFromDimensionId(canonical).orElseThrow(), "canonical Domain parses");
        truth(DomainIdentity.ownerFromDimensionId("minecraft:overworld").isEmpty(), "vanilla dimension rejected");
        truth(DomainIdentity.ownerFromDimensionId("veilbound:domain/not-a-uuid").isEmpty(), "invalid UUID rejected");
        truth(DomainIdentity.ownerFromDimensionId("veilbound:domain/123E4567-E89B-12D3-A456-426614174000").isEmpty(),
                "non-canonical uppercase path rejected");
        truth(DomainIdentity.ownerFromDimensionId(canonical + "/extra").isEmpty(), "extra path rejected");
        System.out.println("DomainIdentityParsingSelfTest: PASS");
    }

    private static void eq(Object expected, Object actual, String message) {
        if (!expected.equals(actual)) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
