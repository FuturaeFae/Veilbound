package dev.futurae.veilbound.inventory;

public final class VeilInventoryPageSelfTest {
    public static void main(String[] args) {
        VeilInventory inventory = new VeilInventory();
        VeilStorageCapacity capacity = new VeilStorageCapacity(10_000, 100);
        for (int i = 22; i >= 0; i--) {
            inventory.insert(VeilStackKey.plain("test:item_" + String.format("%02d", i)), i + 1L, capacity);
        }

        VeilInventoryPageService service = new VeilInventoryPageService();
        var first = service.page(inventory, 0, 9);
        eq(0, first.page(), "first page index");
        eq(3, first.pageCount(), "page count");
        eq(9, first.entries().size(), "first page size");
        eq("test:item_00", first.entries().get(0).key().itemId(), "deterministic sort");

        var last = service.page(inventory, 99, 9);
        eq(2, last.page(), "high requested page clamps");
        eq(5, last.entries().size(), "last page size");
        eq("test:item_18", last.entries().get(0).key().itemId(), "last page starts at expected key");

        var bounded = service.page(inventory, -10, 999);
        eq(0, bounded.page(), "negative page clamps");
        eq(VeilInventoryPageService.MAX_PAGE_SIZE, bounded.pageSize(), "page size is bounded");
        System.out.println("VeilInventoryPageSelfTest: PASS");
    }

    private static void eq(long expected, long actual, String message) {
        if (expected != actual) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }

    private static void eq(String expected, String actual, String message) {
        if (!expected.equals(actual)) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }
}
