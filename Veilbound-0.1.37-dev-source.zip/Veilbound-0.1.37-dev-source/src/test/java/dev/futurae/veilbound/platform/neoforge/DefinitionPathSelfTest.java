package dev.futurae.veilbound.platform.neoforge;

import net.minecraft.resources.Identifier;

public final class DefinitionPathSelfTest {
    public static void main(String[] args) {
        eq("veilbound:gentle_gravity", NeoForgeDefinitionJson.idFromResource(
                Identifier.fromNamespaceAndPath("veilbound", "veilbound/laws/gentle_gravity.json"),
                NeoForgeLawReloadListener.DIRECTORY), "law id");
        eq("examplemod:skies/ashen", NeoForgeDefinitionJson.idFromResource(
                Identifier.fromNamespaceAndPath("examplemod", "veilbound/memories/skies/ashen.json"),
                NeoForgeMemoryReloadListener.DIRECTORY), "nested memory id");
        truth(NeoForgeDefinitionJson.idFromResource(
                Identifier.fromNamespaceAndPath("veilbound", "veilbound/laws/bad.txt"),
                NeoForgeLawReloadListener.DIRECTORY) == null, "non-json rejected");
        System.out.println("DefinitionPathSelfTest: PASS");
    }

    private static void eq(String expected, String actual, String msg) {
        if (!expected.equals(actual)) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String msg) { if (!value) throw new AssertionError(msg); }
}
