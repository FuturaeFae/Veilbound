package dev.futurae.veilbound.domain;

import dev.futurae.veilbound.energy.MatterTransductionService;
import dev.futurae.veilbound.energy.TransductionPolicy;
import java.util.UUID;

public final class CoreControlSelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        truth(!CoreControlService.toggleExpansion(state).toggled(), "pre-Core expansion control rejected");

        state.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        state.awakenCore(DomainPosition.ORIGIN);
        truth(state.dimensionalEnergy() == state.coreTier().dimensionalEnergyCapacity(), "awakening grants the one-time Nascent ignition reserve");
        state.setDimensionalEnergy(0);
        truth(state.globalExpansionEnabled(), "global expansion defaults on");

        state.setPylon(new BoundaryPylonState(AxisDirection.POSITIVE_X, true, true, new DomainPosition(2, 0, 0)));
        var expansionOff = CoreControlService.toggleExpansion(state);
        truth(expansionOff.toggled() && !expansionOff.enabled(), "Core toggles global expansion off");
        var denied = ExpansionGovernor.planOneBlock(
                state, AxisDirection.POSITIVE_X, new ExpansionPolicy(1, 4064, 0), true);
        truth(!denied.allowed() && "global_expansion_disabled".equals(denied.reason()),
                "global Core switch dominates directional Pylon enable");

        long transducerMatter = 10L;
        var conversion = MatterTransductionService.transduce(
                state, transducerMatter, 100, new TransductionPolicy(10, 2), true);
        truth(conversion.converted(), "Transducer feeds the DE-only Core from its own Matter/FE buffers");
        truth(conversion.matterConsumed() == 10 && state.dimensionalEnergy() == 5,
                "Transducer consumes only its own offered Matter and feeds DE");

        truth(CoreControlService.toggleExpansion(state).enabled(), "expansion can be re-enabled");
        System.out.println("CoreControlSelfTest: PASS");
    }

    private static void truth(boolean value, String label) {
        if (!value) throw new AssertionError(label);
    }
}
