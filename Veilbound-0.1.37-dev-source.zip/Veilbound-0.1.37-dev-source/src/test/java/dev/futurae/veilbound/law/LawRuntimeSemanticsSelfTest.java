package dev.futurae.veilbound.law;

import java.util.List;
import java.util.Map;
import java.util.Set;

public final class LawRuntimeSemanticsSelfTest {
    public static void main(String[] args) {
        LawRuntimeSemantics semantics = new LawRuntimeSemantics();
        ActiveLawEffects active = new ActiveLawEffects(
                Set.of(
                        LawEffectIds.HOSTILITY,
                        LawEffectIds.FLAME,
                        LawEffectIds.CONFLICT,
                        LawEffectIds.TIME,
                        "addon:custom_effect"),
                Map.of(),
                List.of());

        LawRuntimeSemantics.Snapshot snapshot = semantics.snapshot(active);
        truth(snapshot.hostility(), "Hostility");
        truth(!snapshot.fauna(), "Fauna stays off");
        truth(snapshot.flame(), "Flame");
        truth(snapshot.conflict(), "Conflict");
        truth(snapshot.time(), "Time");
        truth(!snapshot.weather(), "Weather stays off");
        truth(snapshot.unknownEffectIds().equals(Set.of("addon:custom_effect")), "unknown addon effect remains inert");
        truth(semantics.allowNaturalSpawn(active, true), "natural monster allowed by Hostility");
        truth(!semantics.allowNaturalSpawn(active, false), "natural passive denied without Fauna");

        ActiveLawEffects faunaOnly = new ActiveLawEffects(Set.of(LawEffectIds.FAUNA), Map.of(), List.of());
        truth(!semantics.allowNaturalSpawn(faunaOnly, true), "Fauna does not enable monsters");
        truth(semantics.allowNaturalSpawn(faunaOnly, false), "Fauna enables passive categories");

        System.out.println("LawRuntimeSemanticsSelfTest: PASS");
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
