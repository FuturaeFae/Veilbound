package dev.futurae.veilbound.ritual;

import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainRepository;
import java.util.UUID;

public final class GenesisSeedSelfTest {
    public static void main(String[] args) {
        UUID owner = UUID.randomUUID();
        DomainRepository domains = new DomainRepository();
        domains.setSeedSupplier(() -> 2468L);
        var first = GenesisSeedService.bind(domains, owner);
        truth(first.bound(), "first Seed binds Domain");
        truth(first.domain().identity().seed() == 2468L, "repository seed supplier used");
        truth(first.domain().state().bounds().equals(DomainBounds.initial()), "fresh Domain is 1x1x2");
        truth(domains.records().size() == 1, "one Domain created");
        var duplicate = GenesisSeedService.bind(domains, owner);
        truth(!duplicate.bound() && duplicate.reason().equals("domain_already_bound"), "second Seed refused");
        truth(domains.records().size() == 1, "no duplicate Domain");
        System.out.println("GenesisSeedSelfTest: PASS");
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
