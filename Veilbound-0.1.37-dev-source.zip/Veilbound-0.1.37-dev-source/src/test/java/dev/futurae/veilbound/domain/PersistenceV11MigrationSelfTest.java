package dev.futurae.veilbound.domain;

import dev.futurae.veilbound.persistence.VeilboundSnapshotBinaryCodec;
import dev.futurae.veilbound.threshold.ThresholdRegistry;
import java.util.UUID;

/** Fixture was encoded by the untouched 0.1.27-dev v11 codec. */
public final class PersistenceV11MigrationSelfTest {
    private static final String V11_PAYLOAD =
            "VkVJTAAAAAsAAAABERERESIiMzNERFVVVVVVVQAAADV2ZWlsYm91bmQ6ZG9tYWluLzExMTExMTExLTIyMjItMzMzMy00NDQ0LTU1NTU1NTU1NTU1NQAAAAA63mixABEREREiIjMzRERVVVVVVVUAAAALQ09SRV9BQ1RJVkUAAAAIQU5DSE9SRUQAAAAAAAAAAAAAAAD/////AAAAAP////8AAAABAAAAAQAAAAEAAAAAAACoygAAAAEAAAARbWluZWNyYWZ0OmRpYW1vbmQAAAAAAAAAAwAAAAYBAAAAClBPU0lUSVZFX1gBAQEAAAABAAAAAAAAAAABAAAACk5FR0FUSVZFX1gAAAABAAAAClBPU0lUSVZFX1kAAAABAAAACk5FR0FUSVZFX1kAAAABAAAAClBPU0lUSVZFX1oAAAABAAAACk5FR0FUSVZFX1oAAAAAAAAAAAAAAQAAABJ2ZWlsYm91bmQ6b3Blbl9za3kAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==";

    public static void main(String[] args) {
        var snapshot = VeilboundSnapshotBinaryCodec.decode(V11_PAYLOAD);
        DomainRepository domains = new DomainRepository();
        ThresholdRegistry thresholds = new ThresholdRegistry();
        snapshot.restoreInto(domains, thresholds);
        UUID owner = UUID.fromString("11111111-2222-3333-4444-555555555555");
        DomainRecord record = domains.getRecord(owner).orElseThrow();
        truth(record.identity().seed() == 987_654_321L, "seed survives");
        truth(record.state().coreTier() == CoreTier.ANCHORED, "tier survives");
        truth(record.state().dimensionalEnergy() == 43_210L, "DE survives");
        truth(record.state().unlockedMemoryIds().contains("veilbound:open_sky"), "Memory survives");
        truth(record.state().pylons().get(AxisDirection.POSITIVE_X).blockPosition().equals(new DomainPosition(1, 0, 0)),
                "physical Pylon binding survives");
        truth(record.state().coreUpgradeFedItems().getOrDefault("minecraft:diamond", 0L) == 3L,
                "Core feed progress survives");
        truth(record.state().completedMilestoneIds().isEmpty(), "v11 starts with no synthetic milestone history");
        System.out.println("PersistenceV11MigrationSelfTest: PASS");
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
