package dev.futurae.veilbound.inventory;

import dev.futurae.veilbound.domain.CoreTier;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import dev.futurae.veilbound.matter.MatterCatalog;
import dev.futurae.veilbound.matter.MatterTransmutationService;
import dev.futurae.veilbound.matter.MatterTransmutationState;
import java.util.List;
import java.util.UUID;

public final class VeilTransmutationSelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        state.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        state.awakenCore(DomainPosition.ORIGIN);
        state.setCoreTier(CoreTier.RESONANT);
        state.unlockFeature(DomainFeature.VEIL_INVENTORY);
        state.unlockFeature(DomainFeature.VEIL_CRAFTING);
        state.unlockFeature(DomainFeature.VEIL_TRANSMUTATION);

        MatterCatalog catalog = new MatterCatalog();
        catalog.putExplicit("minecraft:cobblestone", 8L, "test");
        catalog.putExplicit("minecraft:stone", 10L, "test");
        MatterTransmutationState matter = new MatterTransmutationState();
        MatterTransmutationService transmutation = new MatterTransmutationService();
        VeilStackKey cobble = VeilStackKey.plain("minecraft:cobblestone");

        var absorbed = transmutation.absorb(state, matter, catalog, cobble, 4);
        truth(absorbed.absorbed(), "valued deposit is absorbed directly into Matter");
        eq(32, matter.storedMatter(), "full valued stack becomes Matter");
        truth(matter.knows(cobble.itemId()), "valued deposit permanently learns the pattern");

        var synthesized = transmutation.synthesize(state, matter, catalog, cobble.itemId(), 3);
        truth(synthesized.synthesized(), "learned valued pattern can be pulled back out");
        eq(3, synthesized.itemCount(), "requested items synthesized");
        eq(24, synthesized.matterSpent(), "withdrawal costs authoritative Matter value");
        eq(8, matter.storedMatter(), "Matter debited after synthesis");

        // No fallback: an unvalued item cannot be absorbed or learned as a Matter pattern.
        VeilStackKey unknown = VeilStackKey.plain("example:unvalued_item");
        var unvalued = transmutation.absorb(state, matter, catalog, unknown, 2);
        truth(!unvalued.absorbed() && unvalued.reason().equals("matter_value_missing"),
                "unvalued item is rejected by transmutation");
        truth(!matter.knows(unknown.itemId()), "unvalued item never learns a Matter pattern");

        // Component-bearing valued input is deliberately canonicalized: the base pattern is learned
        // and valued, but the arbitrary component state is not reproducible.
        VeilStackKey customStone = new VeilStackKey("minecraft:stone", "{custom:1}");
        var custom = transmutation.absorb(state, matter, catalog, customStone, 1);
        truth(custom.absorbed(), "component-bearing valued deposit is consumed");
        truth(custom.canonicalizedComponentState(), "custom valued state is explicitly canonicalized");
        truth(matter.knows("minecraft:stone"), "base item pattern learned from valued component variant");

        // Transmutation migration converts only valued stacks. Unvalued exact stacks survive.
        VeilInventory legacy = new VeilInventory();
        legacy.insert(cobble, 2, VeilStoragePolicy.RESONANT);
        legacy.insert(customStone, 1, VeilStoragePolicy.RESONANT);
        VeilStackKey exactUnvalued = new VeilStackKey("example:unvalued_item", "{variant:7}");
        legacy.insert(exactUnvalued, 5, VeilStoragePolicy.RESONANT);
        long beforeMigration = matter.storedMatter();
        var migration = transmutation.migrateLegacyInventory(state, legacy, matter, catalog);
        truth(migration.migrated(), "hybrid inventory migration succeeds");
        eq(5, legacy.totalItems(), "only unvalued physical items remain after migration");
        eq(5, legacy.count(exactUnvalued), "unvalued exact component state is preserved");
        eq(beforeMigration + 26, matter.storedMatter(), "valued legacy contents become Matter using base values");
        eq(1, migration.canonicalizedComponentVariants(), "only valued component variant is canonicalized");

        // A later datapack valuation automatically reconciles the previously-unvalued stored item.
        catalog.putExplicit("example:unvalued_item", 4L, "test-reload");
        var reloadMigration = transmutation.migrateLegacyInventory(state, legacy, matter, catalog);
        truth(reloadMigration.migrated(), "reconciliation after value reload succeeds");
        eq(0, legacy.totalItems(), "newly-valued stored item is converted on reconciliation");
        eq(beforeMigration + 46, matter.storedMatter(), "newly-valued stored stack credits exact Matter");
        truth(matter.knows("example:unvalued_item"), "newly-valued item learns its pattern at conversion time");

        // Mixed crafting consumes physical unvalued ingredients and synthesizes valued ones.
        MatterCatalog craftCatalog = new MatterCatalog();
        craftCatalog.putExplicit("minecraft:cobblestone", 8L, "test");
        MatterTransmutationState craftMatter = new MatterTransmutationState();
        craftMatter.learn(cobble.itemId());
        craftMatter.addMatter(64);
        VeilInventory mixedInventory = new VeilInventory();
        VeilStackKey physicalOnly = VeilStackKey.plain("example:physical_only");
        mixedInventory.insert(physicalOnly, 2, VeilStoragePolicy.RESONANT);
        VeilCraftingService crafting = new VeilCraftingService();
        var valuedIngredient = new VeilCraftingService.IngredientRequest(
                List.of(cobble), 4,
                List.of(new VeilCraftingService.SynthesisCandidate(cobble, 8L)));
        var physicalIngredient = new VeilCraftingService.IngredientRequest(List.of(physicalOnly), 2);
        var craft = crafting.craftWithMatter(state, mixedInventory, VeilStoragePolicy.RESONANT,
                List.of(valuedIngredient, physicalIngredient), List.of(), craftMatter);
        truth(craft.crafted(), "hybrid Matter + physical craft succeeds");
        eq(1, craft.consumed().size(), "unvalued physical ingredient is consumed from inventory");
        eq(2, craft.consumed().getFirst().count(), "exact physical count consumed");
        eq(4, craft.synthesized().getFirst().count(), "valued ingredient is synthesized");
        eq(32, craft.matterSpent(), "craft charges exact valued ingredient cost");
        eq(32, craftMatter.storedMatter(), "craft Matter debit committed atomically");
        eq(0, mixedInventory.totalItems(), "consumed unvalued stack is removed");

        MatterTransmutationState noPattern = new MatterTransmutationState();
        noPattern.addMatter(1_000);
        var patternMissing = crafting.previewWithMatter(state, new VeilInventory(), VeilStoragePolicy.RESONANT,
                List.of(valuedIngredient), List.of(), noPattern);
        truth(!patternMissing.crafted() && patternMissing.reason().equals("pattern_missing"),
                "unlearned valued pattern blocks virtual ingredient");
        eq(1_000, noPattern.storedMatter(), "failed preview never spends Matter");

        System.out.println("VeilTransmutationSelfTest: PASS");
    }

    private static void eq(long expected, long actual, String message) {
        if (expected != actual) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String message) { if (!value) throw new AssertionError(message); }
}
