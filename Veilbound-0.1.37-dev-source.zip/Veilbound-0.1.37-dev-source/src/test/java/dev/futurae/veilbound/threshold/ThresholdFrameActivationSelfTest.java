package dev.futurae.veilbound.threshold;

import dev.futurae.veilbound.domain.DomainPosition;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class ThresholdFrameActivationSelfTest {
    public static void main(String[] args) {
        UUID player = UUID.randomUUID();
        List<DomainPosition> frames = List.of(
                new DomainPosition(0, 0, 0),
                new DomainPosition(1, 0, 0),
                new DomainPosition(1, 1, 0),
                new DomainPosition(10, 10, 10));

        ThresholdFrameActivationService.ActivationDecision denied = ThresholdFrameActivationService.activate(
                player, false, frames, new DomainPosition(0, 0, 0), 32);
        if (denied.allowed() || !"no_bound_domain".equals(denied.reason())) {
            throw new AssertionError("Activation should require a bound domain");
        }

        ThresholdFrameActivationService.ActivationDecision allowed = ThresholdFrameActivationService.activate(
                player, true, frames, new DomainPosition(0, 0, 0), 32);
        if (!allowed.allowed()) throw new AssertionError("Bound player should activate connected frames");
        Set<DomainPosition> expected = Set.of(
                new DomainPosition(0, 0, 0),
                new DomainPosition(1, 0, 0),
                new DomainPosition(1, 1, 0));
        if (!allowed.connectedStructure().equals(expected)) {
            throw new AssertionError("Connected component should exclude disjoint frames: " + allowed.connectedStructure());
        }

        ThresholdFrameActivationService.ActivationDecision notFrame = ThresholdFrameActivationService.activate(
                player, true, frames, new DomainPosition(5, 5, 5), 32);
        if (notFrame.allowed() || !"not_threshold_frame".equals(notFrame.reason())) {
            throw new AssertionError("Non-frame clicks must be denied");
        }
    }
}
