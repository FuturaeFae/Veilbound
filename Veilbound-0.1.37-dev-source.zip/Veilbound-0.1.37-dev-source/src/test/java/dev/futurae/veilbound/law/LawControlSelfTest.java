package dev.futurae.veilbound.law;

import dev.futurae.veilbound.domain.DomainState;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class LawControlSelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        LawDefinition foundation = new LawDefinition(
                "veilbound:foundation", "Foundation", 1, Set.of(), Set.of(), Set.of("veilbound:test_foundation"));
        LawDefinition dependent = new LawDefinition(
                "veilbound:dependent", "Dependent", 2, Set.of(foundation.id()), Set.of(), Set.of("veilbound:test_dependent"));
        LawDefinition conflict = new LawDefinition(
                "veilbound:conflict", "Conflict", 3, Set.of(), Set.of(foundation.id()), Set.of());
        LawRegistry registry = new LawRegistry();
        registry.replaceAll(List.of(dependent, conflict, foundation));

        LawControlService controls = new LawControlService();
        truth(controls.orderedDefinitions(registry).stream().map(LawDefinition::displayName).toList()
                .equals(List.of("Conflict", "Dependent", "Foundation")), "catalog ordering is deterministic");
        truth(!controls.toggle(state, registry, dependent.id()).changed(), "dependent Law is gated by prerequisite");
        truth(controls.toggle(state, registry, foundation.id()).changed(), "foundation Law imposes");
        truth(controls.toggle(state, registry, dependent.id()).changed(), "dependent Law imposes after prerequisite");
        truth(!controls.toggle(state, registry, foundation.id()).changed(), "required prerequisite cannot be repealed");
        truth(!controls.toggle(state, registry, conflict.id()).changed(), "incompatible Law cannot be imposed");
        truth(controls.toggle(state, registry, dependent.id()).changed(), "dependent Law repeals");
        truth(controls.toggle(state, registry, foundation.id()).changed(), "foundation Law repeals after dependent");
        truth(!controls.toggle(state, registry, "veilbound:missing").changed(), "missing definitions are denied");

        System.out.println("LawControlSelfTest: PASS");
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
