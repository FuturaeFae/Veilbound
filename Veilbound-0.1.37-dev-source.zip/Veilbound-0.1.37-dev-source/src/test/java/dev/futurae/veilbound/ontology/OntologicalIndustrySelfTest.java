package dev.futurae.veilbound.ontology;

import dev.futurae.veilbound.domain.*;
import dev.futurae.veilbound.matter.MatterTransmutationState;
import java.util.UUID;

public final class OntologicalIndustrySelfTest {
    public static void main(String[] args) {
        var harvest = new OntologicalHarvesterService();
        var policy = OntologicalHarvesterPolicy.defaults();
        var stable = harvest.plan(8, OntologicalMode.STABLE, 0, 0, policy);
        var driven = harvest.plan(8, OntologicalMode.DRIVEN, 0, 0, policy);
        check(driven.potential() == stable.potential()*2, "production should scale linearly with mode speed");
        check(Math.abs(driven.stabilityLoad() - stable.stabilityLoad()*4) < 0.0001, "stability load should scale quadratically");
        check(harvest.plan(8, OntologicalMode.STABLE, 100, 1, policy).potential() > stable.potential(), "instability should increase yield");

        DomainState domain = new DomainState(UUID.randomUUID());
        domain.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        domain.awakenCore(new DomainPosition(0,0,0)); domain.setCoreTier(CoreTier.ANCHORED); domain.setDimensionalEnergy(10_000);
        MatterTransmutationState matter = new MatterTransmutationState();
        PotentialReservoir reservoir = new PotentialReservoir(10_000); reservoir.insert(100);
        var result = new OntologicalCompilerService().compile(domain, matter, reservoir, 100, OntologicalCompilerPolicy.defaults());
        check(result.compiled() && result.potentialConsumed()==100, "compiler should consume requested available potential");
        check(result.dimensionalEnergyConsumed()==3_200 && result.matterProduced()==25_600, "default conversion");
        check(domain.dimensionalEnergy()==6_800 && matter.storedMatter()==25_600 && reservoir.stored()==0, "resources should remain separated");
        System.out.println("OntologicalIndustrySelfTest PASS");
    }
    private static void check(boolean c,String m){ if(!c) throw new AssertionError(m); }
}
