package dev.futurae.veilbound.domain;

import java.util.UUID;

public final class VeilBoundarySelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        state.setBounds(new DomainBounds(-2, -1, -3, 4, 5, 6));
        state.awakenCore(DomainPosition.ORIGIN);
        truth(VeilBoundaryService.usable(state, new DomainPosition(4, 5, 6)), "inclusive usable edge");
        truth(!VeilBoundaryService.usable(state, new DomainPosition(5, 5, 6)), "outside usable edge");
        truth(VeilBoundaryService.inVisualVeilShell(state, new DomainPosition(14, 0, 0), 10), "10-block Veil shell");
        truth(!VeilBoundaryService.inVisualVeilShell(state, new DomainPosition(15, 0, 0), 10), "beyond 10-block shell");
        DomainPosition expected = BoundaryPylonBindingService.expectedPosition(state, AxisDirection.POSITIVE_X);
        truth(expected.equals(new DomainPosition(5, 0, 0)), "Pylon is one block into Veil");
        BoundaryPylonBindingService.bind(state, AxisDirection.POSITIVE_X, expected);
        truth(VeilBoundaryService.pylonException(state, expected), "bound Pylon is explicit shell exception");
        truth(VeilBoundaryService.clampToUsable(state, new DomainPosition(99, -99, 2)).equals(new DomainPosition(4, -1, 2)), "clamp");
        System.out.println("VeilBoundarySelfTest: PASS");
    }
    private static void truth(boolean value, String message) { if (!value) throw new AssertionError(message); }
}
