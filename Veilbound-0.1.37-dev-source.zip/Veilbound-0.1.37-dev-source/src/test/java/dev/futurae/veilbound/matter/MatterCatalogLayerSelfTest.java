package dev.futurae.veilbound.matter;

public final class MatterCatalogLayerSelfTest {
    public static void main(String[] args) {
        MatterCatalog catalog = new MatterCatalog();
        catalog.putBuiltIn("minecraft:diamond", 1_000, "veilbound-default");
        eq(1_000, catalog.amount("minecraft:diamond").orElseThrow(), "builtin");
        catalog.putDatapack("minecraft:diamond", 777, "test-pack");
        eq(777, catalog.amount("minecraft:diamond").orElseThrow(), "datapack priority");
        truth(catalog.get("minecraft:diamond").orElseThrow().source() == MatterValue.Source.DATAPACK, "source");
        catalog.clearDatapack();
        eq(1_000, catalog.amount("minecraft:diamond").orElseThrow(), "builtin restored after datapack clear");
        catalog.putDatapack("minecraft:diamond", 0, "explicitly-unvalued");
        truth(catalog.amount("minecraft:diamond").isEmpty(), "zero override is operationally unvalued");
        eq(0, catalog.get("minecraft:diamond").orElseThrow().amount(), "zero override remains authoritative in catalog");
        System.out.println("MatterCatalogLayerSelfTest: PASS");
    }

    private static void eq(long expected, long actual, String msg) {
        if (expected != actual) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String msg) { if (!value) throw new AssertionError(msg); }
}
