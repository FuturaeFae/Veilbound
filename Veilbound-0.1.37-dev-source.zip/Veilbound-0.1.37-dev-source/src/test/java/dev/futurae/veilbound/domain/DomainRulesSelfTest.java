package dev.futurae.veilbound.domain;

import dev.futurae.veilbound.breach.Breach;
import dev.futurae.veilbound.breach.BreachSeverity;
import java.util.UUID;

public final class DomainRulesSelfTest {
    public static void main(String[] args) {
        testInitialPocketAndCoreRitual();
        testExpansionOwnerAndPylonRules();
        testBreachGloballyStopsExpansion();
        testVerticalHardCeiling();
        System.out.println("DomainRulesSelfTest: PASS");
    }

    private static void testInitialPocketAndCoreRitual() {
        DomainState state = new DomainState(UUID.randomUUID());
        eq(1, state.bounds().sizeX(), "initial x");
        eq(2, state.bounds().sizeY(), "initial y");
        eq(1, state.bounds().sizeZ(), "initial z");
        truth(!state.coreActive(), "Core must not exist before ritual");
        expectThrows(() -> state.insertDimensionalEnergy(1), "pre-Core cannot store DE");
        expectThrows(() -> state.awakenCore(new DomainPosition(1, 0, 0)), "initial ritual must be origin");
        expectThrows(() -> state.awakenCore(DomainPosition.ORIGIN), "standing pocket is too small for Core ritual");
        state.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        truth(state.hasInitialCoreSpace(), "3x3 footprint with 2-block height supports ritual");
        state.awakenCore(DomainPosition.ORIGIN);
        truth(state.coreActive(), "Core active after origin ritual");
    }

    private static void testExpansionOwnerAndPylonRules() {
        DomainState state = activeDomain();
        state.insertDimensionalEnergy(1_000);
        ExpansionPolicy policy = new ExpansionPolicy(10, 64, 0);
        var deniedOffline = ExpansionGovernor.planOneBlock(state, AxisDirection.POSITIVE_X, policy, false);
        eq("owner_offline", deniedOffline.reason(), "offline reason");
        var deniedToggle = ExpansionGovernor.planOneBlock(state, AxisDirection.POSITIVE_X, policy, true);
        eq("pylon_offline", deniedToggle.reason(), "missing physical pylon reason");
        state.setPylon(new BoundaryPylonState(AxisDirection.POSITIVE_X, true, true, new DomainPosition(1, 0, 0)));
        var allowed = ExpansionGovernor.planOneBlock(state, AxisDirection.POSITIVE_X, policy, true);
        truth(allowed.allowed(), "enabled pylon should expand");
        long before = state.dimensionalEnergy();
        truth(ExpansionGovernor.apply(state, allowed), "apply expansion");
        eq(before - allowed.dimensionalEnergyCost(), state.dimensionalEnergy(), "DE spent exactly once");
    }

    private static void testBreachGloballyStopsExpansion() {
        DomainState state = activeDomain();
        state.insertDimensionalEnergy(1_000);
        state.setPylon(new BoundaryPylonState(AxisDirection.POSITIVE_Z, true, true, new DomainPosition(0, 0, 1)));
        state.addBreach(new Breach(UUID.randomUUID(), new DomainPosition(0, 0, 0), AxisDirection.POSITIVE_X, BreachSeverity.MINOR, true, 1));
        var decision = ExpansionGovernor.planOneBlock(state, AxisDirection.POSITIVE_Z, new ExpansionPolicy(1, 64, 0), true);
        truth(!decision.allowed(), "open breach blocks all expansion");
        eq("breach_open", decision.reason(), "breach reason");
    }

    private static void testVerticalHardCeiling() {
        expectThrows(() -> new ExpansionPolicy(1, ExpansionPolicy.ABSOLUTE_MAX_VERTICAL_SPAN + 1, 0), "absolute cap");
        DomainState state = activeDomain();
        state.setBounds(new DomainBounds(0, 0, 0, 0, 4_063, 0));
        state.insertDimensionalEnergy(100);
        state.setPylon(new BoundaryPylonState(AxisDirection.POSITIVE_Y, true, true, new DomainPosition(0, 1, 0)));
        var decision = ExpansionGovernor.planOneBlock(state, AxisDirection.POSITIVE_Y,
                new ExpansionPolicy(1, ExpansionPolicy.ABSOLUTE_MAX_VERTICAL_SPAN, 0), true);
        truth(!decision.allowed(), "cannot exceed 4064 vertical span");
        eq("vertical_cap", decision.reason(), "vertical cap reason");
    }

    private static DomainState activeDomain() {
        DomainState state = new DomainState(UUID.randomUUID());
        state.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        state.awakenCore(DomainPosition.ORIGIN);
        return state;
    }

    private static void eq(long expected, long actual, String msg) {
        if (expected != actual) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual);
    }
    private static void eq(String expected, String actual, String msg) {
        if (!expected.equals(actual)) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String msg) { if (!value) throw new AssertionError(msg); }
    private static void expectThrows(Runnable action, String msg) {
        try { action.run(); } catch (RuntimeException expected) { return; }
        throw new AssertionError(msg + ": expected exception");
    }
}
