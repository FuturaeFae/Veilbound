package dev.futurae.veilbound.domain;

import java.util.UUID;

public final class ExpansionCycleSelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        state.setBounds(new DomainBounds(-1, 0, -1, 1, 1, 1));
        state.awakenCore(DomainPosition.ORIGIN);
        state.setDimensionalEnergy(25_000L);
        state.setPylon(new BoundaryPylonState(AxisDirection.POSITIVE_X, true, true, new DomainPosition(2, 0, 0)));
        state.setPylon(new BoundaryPylonState(AxisDirection.POSITIVE_Z, true, true, new DomainPosition(0, 0, 2)));

        DomainBounds before = state.bounds();
        ExpansionCycleService.CycleResult cycle = ExpansionCycleService.runCycle(
                state,
                new ExpansionPolicy(4L, 4_064, 0),
                true);

        check(cycle.expandedDirectionCount() == 2, "both enabled pylons should grow in one cycle");
        check(state.bounds().maxX() == before.maxX() + 1, "+X should grow");
        check(state.bounds().maxZ() == before.maxZ() + 1, "+Z should grow");

        state.addBreach(new dev.futurae.veilbound.breach.Breach(
                UUID.randomUUID(),
                DomainPosition.ORIGIN,
                AxisDirection.POSITIVE_X,
                dev.futurae.veilbound.breach.BreachSeverity.MINOR,
                true,
                0L));
        ExpansionCycleService.CycleResult blocked = ExpansionCycleService.runCycle(
                state,
                new ExpansionPolicy(4L, 4_064, 0),
                true);
        check(blocked.expandedDirectionCount() == 0, "an open breach must halt all expansion");
        check(blocked.directions().stream().allMatch(r -> "breach_open".equals(r.reason())),
                "all enabled pylons should report the breach gate");

        System.out.println("ExpansionCycleSelfTest PASS");
    }

    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
