package dev.futurae.veilbound.memory;

import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainState;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class MemoryProgressionSelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        MemoryProgressState progress = new MemoryProgressState();
        MemoryDefinition sky = new MemoryDefinition(
                "veilbound:sky", "Sky", Set.of(), Map.of("visual.sky", "blue"),
                Map.of("dimension", "minecraft:overworld"), Set.of(), Set.of(DomainFeature.FIRMAMENT));
        MemoryRegistry registry = new MemoryRegistry();
        registry.replaceAll(List.of(sky));

        truth(state.unlockedMemoryIds().isEmpty(), "new Domain starts with no learned Memories");
        truth(progress.capturedMemoryId().isEmpty(), "new Domain starts with no captured Memory");
        truth(progress.activeOrreryMemoryIds().isEmpty(), "new Domain starts with no active Orrery Memories");

        var archive = new MemoryArchiveService().archive(state, sky.id(), registry);
        truth(archive.archived(), "Archive commits the Memory carried by a physical Vessel");
        truth(state.unlockedMemoryIds().contains(sky.id()), "archived Memory becomes earned");
        truth(progress.capturedMemoryId().isEmpty(), "new item-local capture path does not create Domain-global pending state");

        DomainState legacyState = new DomainState(UUID.randomUUID());
        MemoryProgressState legacyProgress = new MemoryProgressState();
        truth(legacyProgress.capture(sky.id()).captured(), "legacy pending capture can still be represented for migration");
        truth(new MemoryArchiveService().archiveCaptured(legacyState, legacyProgress, registry).archived(),
                "legacy v7-v10 pending capture remains losslessly archivable");
        truth(legacyProgress.capturedMemoryId().isEmpty(), "legacy archive path clears migrated pending state");

        DomainOrreryService orrery = new DomainOrreryService();
        var selected = orrery.select(state, progress, registry, List.of(sky.id()));
        truth(selected.selected(), "earned Memory can activate in Orrery");
        truth(progress.activeOrreryMemoryIds().equals(List.of(sky.id())), "Orrery selection persists in state");

        DomainState lockedState = new DomainState(UUID.randomUUID());
        MemoryProgressState lockedProgress = new MemoryProgressState();
        truth(!orrery.select(lockedState, lockedProgress, registry, List.of(sky.id())).selected(),
                "unearned Memory cannot activate in Orrery");
        System.out.println("MemoryProgressionSelfTest: PASS");
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
