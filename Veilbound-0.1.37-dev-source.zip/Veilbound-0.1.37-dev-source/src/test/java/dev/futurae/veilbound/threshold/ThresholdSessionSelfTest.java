package dev.futurae.veilbound.threshold;

import dev.futurae.veilbound.travel.ReturnAnchor;

import dev.futurae.veilbound.domain.DomainPosition;
import java.util.List;
import java.util.UUID;

public final class ThresholdSessionSelfTest {
    public static void main(String[] args) {
        UUID owner = UUID.randomUUID();
        UUID guestA = UUID.randomUUID();
        UUID guestB = UUID.randomUUID();
        ThresholdAccess access = new ThresholdAccess();
        access.invite(guestA);
        access.invite(guestB);
        ThresholdDefinition threshold = new ThresholdDefinition(UUID.randomUUID(), owner, DomainPosition.ORIGIN, access);
        ThresholdSessionManager sessions = new ThresholdSessionManager();
        ReturnAnchor a = new ReturnAnchor("minecraft:overworld", 1, 64, 2, 10, 20);
        ReturnAnchor b = new ReturnAnchor("minecraft:the_nether", 8, 70, 9, 30, 40);

        eq("owner_offline", sessions.beginGuestEntry(threshold, guestA, a, 1, false, false).reason(), "offline owner");
        eq("owner_not_inside_domain", sessions.beginGuestEntry(threshold, guestA, a, 1, true, false).reason(), "owner outside");
        truth(sessions.beginGuestEntry(threshold, guestA, a, 2, true, true).allowed(), "guest A allowed");
        truth(sessions.beginGuestEntry(threshold, guestB, b, 3, true, true).allowed(), "guest B allowed");
        eq(2, sessions.sessionsForOwner(owner).size(), "non-destructive evacuation plan");
        truth(sessions.completeGuestEvacuation(guestA, owner), "one guest completes after teleport");
        eq(1, sessions.sessionsForOwner(owner).size(), "failed/unattempted guest remains tracked");
        truth(!sessions.completeGuestEvacuation(guestB, UUID.randomUUID()), "wrong owner cannot complete guest");
        List<GuestThresholdSession> evacuated = sessions.evacuateOwnerDomain(owner);
        eq(1, evacuated.size(), "remaining guest evacuated");
                truth(evacuated.stream().anyMatch(s -> s.guestId().equals(guestB) && s.returnAnchor().equals(b)), "B keeps own anchor");
        eq(0, sessions.activeSessions().size(), "sessions cleared");
        System.out.println("ThresholdSessionSelfTest: PASS");
    }

    private static void eq(long expected, long actual, String msg) {
        if (expected != actual) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual);
    }
    private static void eq(String expected, String actual, String msg) {
        if (!expected.equals(actual)) throw new AssertionError(msg + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String msg) { if (!value) throw new AssertionError(msg); }
}
