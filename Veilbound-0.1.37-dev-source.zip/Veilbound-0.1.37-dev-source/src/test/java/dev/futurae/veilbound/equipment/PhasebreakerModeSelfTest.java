package dev.futurae.veilbound.equipment;
public final class PhasebreakerModeSelfTest { public static void main(String[] args){
    assert PhasebreakerMode.fromId(0)==PhasebreakerMode.NORMAL;
    assert PhasebreakerMode.fromId(3)==PhasebreakerMode.PHASE;
    assert PhasebreakerMode.fromId(99)==PhasebreakerMode.NORMAL;
    assert PhasebreakerMode.PHASE.next()==PhasebreakerMode.NORMAL;
    assert PhasebreakerMode.VEIN.maxExtraBlocks()==16;
    System.out.println("PhasebreakerModeSelfTest PASS");
}}
