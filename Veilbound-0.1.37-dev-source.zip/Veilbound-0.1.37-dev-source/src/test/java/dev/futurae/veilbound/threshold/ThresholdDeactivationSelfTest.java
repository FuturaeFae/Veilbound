package dev.futurae.veilbound.threshold;

import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.travel.ReturnAnchor;
import java.util.Set;
import java.util.UUID;

public final class ThresholdDeactivationSelfTest {
    public static void main(String[] args) {
        ThresholdRegistry registry = new ThresholdRegistry();
        ThresholdSessionManager sessions = new ThresholdSessionManager();
        ThresholdDeactivationService service = new ThresholdDeactivationService(registry, sessions);

        UUID owner = UUID.randomUUID();
        UUID thresholdId = UUID.randomUUID();
        DomainPosition a = new DomainPosition(1, 2, 3);
        DomainPosition b = new DomainPosition(1, 3, 3);
        ThresholdAccess access = new ThresholdAccess();
        UUID guest = UUID.randomUUID();
        access.invite(guest);
        ThresholdDefinition threshold = new ThresholdDefinition(
                thresholdId, owner, "minecraft:overworld", Set.of(a, b), DomainPosition.ORIGIN, access);
        registry.add(threshold);

        var entry = sessions.beginGuestEntry(
                threshold,
                guest,
                new ReturnAnchor("minecraft:overworld", 10.5, 64, 20.5, 0, 0),
                5,
                true,
                true);
        if (!entry.allowed()) throw new AssertionError("guest entry setup failed");

        var plan = service.plan("minecraft:overworld", b);
        if (!plan.allowed()) throw new AssertionError("portal cell should resolve to whole Threshold");
        if (plan.plan().guests().size() != 1 || !plan.plan().guests().getFirst().guestId().equals(guest)) {
            throw new AssertionError("deactivation should target only guests using this Threshold");
        }
        if (service.commit(plan.plan()).success()) {
            throw new AssertionError("binding must remain while a guest still depends on it");
        }
        if (registry.get(thresholdId).isEmpty()) throw new AssertionError("failed commit removed binding");

        sessions.endGuestSession(guest);
        var committed = service.commit(plan.plan());
        if (!committed.success()) throw new AssertionError("commit should succeed after guest evacuation: " + committed.reason());
        if (registry.get(thresholdId).isPresent()) throw new AssertionError("binding should be removed after commit");
    }
}
