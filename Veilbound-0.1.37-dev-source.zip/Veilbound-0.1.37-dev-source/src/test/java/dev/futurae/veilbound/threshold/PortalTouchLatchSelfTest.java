package dev.futurae.veilbound.threshold;

import java.util.UUID;

public final class PortalTouchLatchSelfTest {
    public static void main(String[] args) {
        PortalTouchLatch latch = new PortalTouchLatch();
        UUID player = UUID.randomUUID();
        if (latch.isArmed(player)) throw new AssertionError("fresh latch must be clear");
        latch.arm(player);
        if (!latch.isArmed(player) || latch.armedCount() != 1) throw new AssertionError("arm failed");
        latch.arm(player);
        if (latch.armedCount() != 1) throw new AssertionError("arming must be idempotent");
        latch.clear(player);
        if (latch.isArmed(player) || latch.armedCount() != 0) throw new AssertionError("clear failed");
        System.out.println("PortalTouchLatchSelfTest: PASS");
    }
}
