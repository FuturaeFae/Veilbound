package dev.futurae.veilbound.domain;

import java.util.UUID;

public final class BoundaryPylonBindingSelfTest {
    public static void main(String[] args) {
        DomainPosition core = DomainPosition.ORIGIN;
        eq(AxisDirection.POSITIVE_X, BoundaryPylonBindingService.inferDirection(core, new DomainPosition(5, 1, 0)).orElseThrow(), "+X");
        eq(AxisDirection.NEGATIVE_Y, BoundaryPylonBindingService.inferDirection(core, new DomainPosition(0, -4, 1)).orElseThrow(), "-Y");
        truth(BoundaryPylonBindingService.inferDirection(core, new DomainPosition(3, 3, 0)).isEmpty(), "ties are ambiguous");

        DomainState state = new DomainState(UUID.randomUUID());
        state.setBounds(new DomainBounds(-2, -1, -2, 2, 2, 2));
        state.awakenCore(DomainPosition.ORIGIN);
        for (BoundaryPylonState pylon : state.pylons().values()) {
            truth(!pylon.online() && !pylon.bound(), "new Core starts with no imaginary physical pylons");
        }

        DomainPosition first = BoundaryPylonBindingService.expectedPosition(state, AxisDirection.POSITIVE_X);
        var bound = BoundaryPylonBindingService.bind(state, AxisDirection.POSITIVE_X, first);
        truth(bound.bound() && bound.state().online() && first.equals(bound.state().blockPosition()), "physical pylon binds exact block");
        truth(!BoundaryPylonBindingService.bind(state, AxisDirection.POSITIVE_X, new DomainPosition(1, 0, 0)).bound(),
                "second physical pylon cannot steal an occupied direction");

        eq(new DomainPosition(3, 0, 0), first, "Pylon sits one block into +X Veil");
        var enabled = BoundaryPylonBindingService.toggleExpansion(state, AxisDirection.POSITIVE_X, first);
        truth(enabled.toggled() && enabled.state().expansionEnabled(), "bound pylon toggles expansion");
        var speed = BoundaryPylonBindingService.cycleSpeed(state, AxisDirection.POSITIVE_X);
        truth(speed.changed() && speed.state().speed() == BoundaryPylonSpeed.DRIVEN, "Stable cycles to Driven");
        truth(!BoundaryPylonBindingService.unbindIfMatching(state, AxisDirection.POSITIVE_X, new DomainPosition(1, 0, 0)),
                "breaking unrelated duplicate does not disable binding");
        truth(BoundaryPylonBindingService.unbindIfMatching(state, AxisDirection.POSITIVE_X, first),
                "breaking exact physical pylon clears binding");
        truth(!state.pylons().get(AxisDirection.POSITIVE_X).online()
                        && !state.pylons().get(AxisDirection.POSITIVE_X).expansionEnabled(),
                "unbinding fails closed and pauses expansion");
        System.out.println("BoundaryPylonBindingSelfTest: PASS");
    }

    private static void eq(Object expected, Object actual, String message) {
        if (!expected.equals(actual)) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String message) { if (!value) throw new AssertionError(message); }
}
