package dev.futurae.veilbound.ritual;

import dev.futurae.veilbound.breach.Breach;
import dev.futurae.veilbound.breach.BreachSeverity;
import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import java.util.UUID;

public final class CoreRelocationSelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        state.setBounds(new DomainBounds(-4, 0, -4, 4, 6, 4));
        state.awakenCore(DomainPosition.ORIGIN);
        state.setDimensionalEnergy(20_000L);
        DomainPosition target = new DomainPosition(2, 1, -1);
        var plan = CoreRelocationService.plan(state, target);
        truth(plan.allowed() && plan.dimensionalEnergyCost() == 10_000L, "valid relocation");
        truth(CoreRelocationService.apply(state, plan), "commit");
        truth(state.corePosition().equals(target), "Core moved");
        truth(state.dimensionalEnergy() == 10_000L, "DE paid");
        truth(CoreRelocationService.plan(state, new DomainPosition(2, 5, -1)).reason().equals("insufficient_headroom"), "arrival headroom");
        state.addBreach(new Breach(UUID.randomUUID(), target, AxisDirection.POSITIVE_X, BreachSeverity.MINOR, true, 1L));
        truth(CoreRelocationService.plan(state, DomainPosition.ORIGIN).reason().equals("breach_open"), "Breach gate");
        System.out.println("CoreRelocationSelfTest: PASS");
    }
    private static void truth(boolean value, String message) { if (!value) throw new AssertionError(message); }
}
