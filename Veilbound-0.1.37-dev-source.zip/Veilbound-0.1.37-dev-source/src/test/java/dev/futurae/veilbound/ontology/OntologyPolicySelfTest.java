package dev.futurae.veilbound.ontology;

/** Regression coverage for reloadable ontology balance replacement and validation. */
public final class OntologyPolicySelfTest {
    private OntologyPolicySelfTest() {}

    public static void main(String[] args) {
        var harvester = new OntologicalHarvesterPolicy(7, 12, 0.5, 2.0, 0.25);
        var compiler = new OntologicalCompilerPolicy(1024, 40, 64);
        var replacement = new OntologyRuntimePolicy(harvester, compiler);
        var registry = new OntologyPolicyRegistry();
        registry.replace(replacement);

        check(registry.policy() == replacement, "replace-all registry should expose the exact replacement snapshot");
        check(registry.policy().harvester().potentialPerVanePerCycle() == 7, "harvester policy value lost");
        check(registry.policy().harvester().maxContributingVanes() == 12, "harvester vane cap lost");
        check(registry.policy().compiler().matterPerPotential() == 1024, "compiler Matter ratio lost");
        check(registry.policy().compiler().dimensionalEnergyPerPotential() == 40, "compiler DE ratio lost");
        check(registry.policy().compiler().maxPotentialPerCycle() == 64, "compiler cycle cap lost");

        expectIllegal(() -> new OntologicalHarvesterPolicy(0, 1, 0, 0, 0));
        expectIllegal(() -> new OntologicalHarvesterPolicy(1, 0, 0, 0, 0));
        expectIllegal(() -> new OntologicalHarvesterPolicy(1, 1, -0.01, 0, 0));
        expectIllegal(() -> new OntologicalCompilerPolicy(0, 1, 1));
        expectIllegal(() -> new OntologicalCompilerPolicy(1, 0, 1));
        expectIllegal(() -> new OntologicalCompilerPolicy(1, 1, 0));

        System.out.println("OntologyPolicySelfTest PASS");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static void expectIllegal(Runnable action) {
        try {
            action.run();
            throw new AssertionError("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }
}
