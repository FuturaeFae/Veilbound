package dev.futurae.veilbound.breach;

import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import dev.futurae.veilbound.stability.StabilityBand;
import dev.futurae.veilbound.stability.StabilityRuntimePolicy;
import dev.futurae.veilbound.stability.StabilitySnapshot;
import java.util.Random;
import java.util.UUID;

public final class BreachRuntimeSelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        state.setBounds(new DomainBounds(-8, 0, -8, 8, 7, 8));
        state.awakenCore(DomainPosition.ORIGIN);
        state.setDimensionalEnergy(10_000);
        BreachRuntimePolicy policy = StabilityRuntimePolicy.DEVELOPMENT_DEFAULT.breachPolicy();

        state.setFractureMeter(10.0);
        var stable = BreachRuntimeService.evaluate(
                state, snapshot(StabilityBand.STABLE), policy, 20, new Random(1));
        eq(8.0, stable.fractureMeter(), "stable Domain heals fracture progress");
        truth(stable.formedBreach() == null, "stable Domain forms no Breach");

        state.setFractureMeter(99.0);
        var critical = BreachRuntimeService.evaluate(
                state, snapshot(StabilityBand.CRITICAL), policy, 40, new Random(2));
        Breach breach = critical.formedBreach();
        truth(breach != null, "critical threshold forms Breach");
        truth(breach.severity() == BreachSeverity.SEVERE, "critical breach is severe");
        truth(state.bounds().contains(breach.position()), "breach lies on Domain bounds");
        truth(onFace(state.bounds(), breach), "breach is on selected Veil face");
        eq(1.0, state.fractureMeter(), "forming breach subtracts one fracture threshold");
        truth(state.hasOpenBreach(), "open breach persisted in Domain state");

        long cost = policy.stitcherDimensionalEnergyCost(BreachSeverity.SEVERE);
        var sealed = BreachService.sealWithStitcher(state, breach.id(), cost);
        truth(sealed.sealed(), "Stitcher seals breach");
        eq(10_000L - cost, state.dimensionalEnergy(), "Stitcher consumes exact DE cost");
        truth(!state.hasOpenBreach(), "sealed breach releases global expansion lock");
        System.out.println("BreachRuntimeSelfTest: PASS");
    }

    private static StabilitySnapshot snapshot(StabilityBand band) {
        return new StabilitySnapshot(0, 100, 0, band, 0, 0, 0);
    }

    private static boolean onFace(DomainBounds b, Breach breach) {
        DomainPosition p = breach.position();
        return switch (breach.veilFace()) {
            case POSITIVE_X -> p.x() == b.maxX();
            case NEGATIVE_X -> p.x() == b.minX();
            case POSITIVE_Y -> p.y() == b.maxY();
            case NEGATIVE_Y -> p.y() == b.minY();
            case POSITIVE_Z -> p.z() == b.maxZ();
            case NEGATIVE_Z -> p.z() == b.minZ();
        };
    }

    private static void eq(long expected, long actual, String message) {
        if (expected != actual) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }
    private static void eq(double expected, double actual, String message) {
        if (Double.compare(expected, actual) != 0) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String message) { if (!value) throw new AssertionError(message); }
}
