package dev.futurae.veilbound.memory;

import dev.futurae.veilbound.domain.DomainState;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class MemoryEnvironmentRuntimeSelfTest {
    public static void main(String[] args) {
        DomainState state = new DomainState(UUID.randomUUID());
        MemoryProgressState progress = new MemoryProgressState();
        MemoryRegistry registry = new MemoryRegistry();
        MemoryDefinition sky = new MemoryDefinition("veilbound:sky", "Sky", Set.of(), Map.of(
                MemoryEffectIds.VISUAL_SKY, MemoryEffectIds.OPEN_SKY,
                MemoryEffectIds.MECHANIC_ILLUMINATION, MemoryEffectIds.NATURAL_DAYLIGHT));
        MemoryDefinition rain = new MemoryDefinition("veilbound:rain", "Rain", Set.of(), Map.of(
                MemoryEffectIds.VISUAL_WEATHER, MemoryEffectIds.GENTLE_RAIN,
                MemoryEffectIds.MECHANIC_WEATHER, MemoryEffectIds.RAIN));
        registry.replaceAll(List.of(sky, rain));
        MemoryEnvironmentRuntime runtime = new MemoryEnvironmentRuntime();

        var empty = runtime.resolve(state, progress, registry);
        truth(!empty.active(), "fresh Domain has no active environmental profile");
        truth(!empty.semantics().openSky(), "fresh Domain does not gain Open Sky semantics");

        state.unlockMemory(sky.id());
        state.unlockMemory(rain.id());
        progress.setActiveOrreryMemoryIds(List.of(sky.id(), rain.id()));
        var blended = runtime.resolve(state, progress, registry);
        truth(blended.active(), "compatible earned Memories resolve");
        truth(blended.semantics().openSky(), "Open Sky visual semantics resolve");
        truth(blended.semantics().naturalDaylight(), "illumination semantics resolve");
        truth(blended.semantics().gentleRainVisual(), "rain visual semantics resolve");

        MemoryRuntimeSemantics.Snapshot rainOnly = new MemoryRuntimeSemantics().snapshot(Map.of(
                MemoryEffectIds.VISUAL_WEATHER, MemoryEffectIds.GENTLE_RAIN,
                MemoryEffectIds.MECHANIC_WEATHER, MemoryEffectIds.RAIN));
        truth(rainOnly.visibleFirmament(), "higher-order rain visual carries its prerequisite firmament");
        truth(!rainOnly.naturalDaylight(), "implied firmament does not silently activate Open Sky mechanics");
        truth(blended.semantics().rainWeather(), "rain mechanic semantics resolve");

        registry.replaceAll(List.of(sky));
        var stale = runtime.resolve(state, progress, registry);
        truth(!stale.active() && "memory_definition_missing".equals(stale.reason()),
                "removed datapack Memory makes stale active selection inert");
        truth(stale.environmentalProfile().isEmpty(), "stale selection cannot leak prior effects");

        MemoryRuntimeSemantics.Snapshot unknown = new MemoryRuntimeSemantics().snapshot(Map.of(
                "visual.sky", "addon:alien_sky", "mechanic.gravity", "addon:low"));
        truth(!unknown.openSky(), "unknown visual value is inert in base runtime");
        truth("addon:low".equals(unknown.mechanicProfile().get("mechanic.gravity")),
                "unknown extension key is retained for integrations");
        System.out.println("MemoryEnvironmentRuntimeSelfTest: PASS");
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
