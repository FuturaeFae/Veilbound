package dev.futurae.veilbound.environment;

import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainFeature;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainState;
import java.util.UUID;

public final class EnvironmentZoneSelectionSelfTest {
    public static void main(String[] args) {
        UUID owner = UUID.randomUUID();
        DomainState state = new DomainState(owner);
        state.setBounds(new DomainBounds(-8, -2, -8, 8, 8, 8));
        state.unlockFeature(DomainFeature.ENVIRONMENTAL_MASTERY);
        state.unlockMemory("veilbound:gentle_rain");
        var selections = new EnvironmentZoneSelectionService();

        check(selections.begin(owner, "veilbound:gentle_rain", "Rain Garden").begun(), "begin");
        check(selections.markCorner(owner, state, new DomainPosition(-2, 0, -3)).corner() == 1, "corner A");
        check(!selections.confirm(owner, state).created(), "cannot confirm before B");
        check(selections.markCorner(owner, state, new DomainPosition(4, 5, 2)).corner() == 2, "corner B");
        var result = selections.confirm(owner, state);
        check(result.created(), "complete selection creates zone");
        check(result.zone().bounds().equals(new DomainBounds(-2, 0, -3, 4, 5, 2)), "bounds normalize corners");
        check(selections.selection(owner).isEmpty(), "confirmation clears temporary session");
    }

    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
