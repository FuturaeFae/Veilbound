package dev.futurae.veilbound.energy;

import dev.futurae.veilbound.matter.MatterCatalog;

public final class TransducerMatterInputSelfTest {
    public static void main(String[] args) {
        MatterCatalog catalog = new MatterCatalog();
        catalog.putBuiltIn("minecraft:cobblestone", 1L, "test");
        catalog.putBuiltIn("minecraft:diamond", 250L, "test");

        var diamond = TransducerMatterInputService.plan(catalog, "minecraft:diamond", 4, 0L, 1_000L);
        truth(diamond.accepted(), "valued physical input accepted");
        eq(4, diamond.itemsConsumed(), "all diamonds accepted");
        eq(1_000L, diamond.matterAdded(), "physical items become local Matter");

        var partial = TransducerMatterInputService.plan(catalog, "minecraft:diamond", 4, 800L, 1_000L);
        truth(!partial.accepted(), "one diamond cannot fit into only 200 Matter room");
        eq("matter_buffer_full", partial.reason(), "high-value item is not partially destroyed");

        var cobblePartial = TransducerMatterInputService.plan(catalog, "minecraft:cobblestone", 500, 800L, 1_000L);
        truth(cobblePartial.accepted(), "smaller valued items can partially insert");
        eq(200, cobblePartial.itemsConsumed(), "only capacity-fitting item count consumed");
        eq(200L, cobblePartial.matterAdded(), "partial stack value exact");

        // Missing valuation is missing everywhere. Unknown items remain in the pipe/source inventory.
        truth(catalog.amount("example:unknown").isEmpty(), "unknown item has no invented Matter value");
        var unknown = TransducerMatterInputService.plan(catalog, "example:unknown", 64, 0L, 1_000L);
        truth(!unknown.accepted(), "unvalued input rejected");
        eq("no_matter_value", unknown.reason(), "Transducer rejects genuinely unvalued items");

        System.out.println("TransducerMatterInputSelfTest: PASS");
    }

    private static void eq(long expected, long actual, String label) {
        if (expected != actual) throw new AssertionError(label + ": expected=" + expected + " actual=" + actual);
    }
    private static void eq(int expected, int actual, String label) {
        if (expected != actual) throw new AssertionError(label + ": expected=" + expected + " actual=" + actual);
    }
    private static void eq(String expected, String actual, String label) {
        if (!expected.equals(actual)) throw new AssertionError(label + ": expected=" + expected + " actual=" + actual);
    }
    private static void truth(boolean value, String label) { if (!value) throw new AssertionError(label); }
}
