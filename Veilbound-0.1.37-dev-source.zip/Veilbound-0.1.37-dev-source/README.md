# Veilbound

Veilbound is a NeoForge 26.2 mod about creating, expanding, stabilizing, and governing one private personal reality beyond the Veil.

## Development status — 0.1.37-dev

This repository is the active implementation source. The current design is centered on one UUID-owned personal Domain that begins sterile and grows into a large dimensional-engineering system.

Current authoritative behavior includes:

- Genesis Seed binding, V-key owner/guest travel, the reusable Void Anchor starter foothold, Spatial Generator pre-Core expansion, and the fixed 50,000-Condensed-Charge Core awakening ritual;
- a **DE-only Dimensional Core** with no Matter-ingestion/aura path;
- moving face-bound Boundary Pylons, the impassable Veil, 0.1 block/s Stable expansion, five Pylon speed modes, fracture/Stability, natural Breaches, Veil Stitcher repair, Thresholds, Continuity Anchors, Laws, Memories, Orrery profiles, and Environmental Zones;
- ProjectE-compatible Matter values, no fallback Matter value, hybrid Veil Inventory storage, immediate valued-item transmutation/pattern learning, and exact storage for unvalued stacks;
- a physical Dimensional Transducer whose local item-Matter + FE creates Core DE without reading Veil Inventory Matter;
- live persistent held-item Matter commands (`/veilbound matter get`, `set`, `clear`) with targeted dependent-value recomputation instead of a full reload;
- Dimensional Fabricator and Veil Foundry manufacturing with physical components, station-local Matter, Potential, Core DE, Memories, Laws, tier prerequisites, persistent timed jobs, and automation ports;
- 96 dimensional-engineering recipes covering Core Assemblies, Law Axioms, ontology machinery, worldline/causal/axiomatic/paradox megastructures, tools, armor, and the Veil Lance;
- Probability Vanes + Ontological Harvester + Potential + Ontological Compiler as the boundary-driven renewable Matter industry, with live Harvester load feeding Domain Stability, reloadable balance, and a server-authoritative live control/telemetry console;
- animated Resonant/Phase/Mnemonic/Causalite/Axiomite/Paradox materials and Domain-expansion accretion generation instead of generic Overworld ore spam;
- Breach-only Veil materials, dedicated Void Crawler/Rift Stalker/Null Wraith render identities, and the FE + Core-DE **Veil Lance**, which deliberately creates a normal Severe or Extreme Breach against a real unobstructed Domain boundary;
- active Phasebreaker, Boundary Spade, Rift Cutter, Resonance Multitool, real Phaseweave/Causal/Sovereign armor, Sovereign in-Domain flight, and Sovereign remote Core controls;
- an in-game Veil Engineering Codex plus maintained player documentation in `docs/player-guide.md`, `docs/dimensional-engineering.md`, `docs/matter-industry.md`, and `docs/progression-trees.md`.

## Current validation

The loader-neutral suite currently passes **74/74 self-tests**, including the real v13→v14 migration fixture emitted by the untouched 0.1.33 codec. Strict duplicate-key parsing passes **502/502 bundled JSON resources** plus **44/44 animation metadata files**. The engineering graph contains **96 recipes with zero duplicate outputs, dependency cycles, tier inversions, or Core-DE-capacity violations**. Registered resource coverage is **128/128 item models**, **128/128 modern client-item definitions**, and **32/32 blockstates**.

Persistence schema is **14** and custom network protocol is **14**. Full Java 25 + NeoForge 26.2 Gradle/JAR execution is still not claimed in this Java-21 environment; platform-facing additions are source/API-audited instead.

See [`docs/player-guide.md`](docs/player-guide.md) for the survival path, [`docs/dimensional-engineering.md`](docs/dimensional-engineering.md) for fabrication, [`docs/matter-industry.md`](docs/matter-industry.md) for resource separation and Matter production, [`docs/progression-trees.md`](docs/progression-trees.md) for dependency order, [`docs/matter-values.md`](docs/matter-values.md) for valuation, and [`docs/datapack-definitions.md`](docs/datapack-definitions.md) for data formats.

## Matter inference safety

Recipe inference uses the cheapest fully understood production path, output-count division, known returned/remainder value subtraction, recursive resolution, and seedless-cycle rejection. An unknown alternative keeps the recipe unresolved rather than allowing a potentially inflated Matter value. Datapack values always override inference.

## Visual assets

The engineering expansion includes animated dimensional resource/machine textures, animated tool and armor inventory icons, and additional animated Ascendant/Transcendent megastructure blocks. Threshold Frame/Portal retain their custom pass. Phaseweave, Causal, and Sovereign armor own separate NeoForge equipment assets and layered Veilbound humanoid/leggings textures instead of borrowing Diamond/Netherite worn visuals. Void Crawler, Rift Stalker, and Null Wraith now also use dedicated Veilbound entity renderers/textures while retaining the stable locomotion/model contracts of their parent silhouettes.

## Build baseline

- Minecraft 26.2
- NeoForge 26.2.0.75
- Java 25
- ModDevGradle 2.0.146
- Gradle 9.2.1 wrapper configuration

The source is configured for the official NeoForge 26.2 ModDevGradle workflow. The current execution sandbox exposes Java 21 and does not have the Java 25 game/NeoForge toolchain cached, so loader-neutral code is compiled/tested here and platform-facing calls are source-audited against the 26.2 API. This is not a substitute for a real Java 25 NeoForge client/server compile and runtime test.

## 0.1.37-dev ontology-console + Breach identity checkpoint

- Replaces hardcoded ontology-industry runtime balance with the reloadable `data/veilbound/veilbound/balance/ontology_industry.json` policy while keeping the previous values as validated development defaults.
- Adds a live owner-only **Ontology Console** for both Ontological Harvester and Ontological Compiler. It refreshes telemetry every second and exposes Potential capacity, boundary vane contribution, production, Stability load, fracture/open-Breach yield multiplier, Core DE, Matter reserve, and active conversion ratios.
- Harvester mode selection (Quiet/Stable/Driven/Paradox) is available directly in the console. Every action is server-authoritative: distance, owner UUID, machine type, and Domain identity are revalidated before mutation or telemetry is returned.
- Bumps the custom network protocol to **14** for the bounded ontology action/snapshot payloads. Persistence remains schema 14 because this pass adds no new persisted Domain fields.
- Gives **Void Crawler**, **Rift Stalker**, and **Null Wraith** dedicated Veilbound renderers and custom entity textures. Their inherited parent locomotion/model silhouettes remain intentionally stable, but they no longer surface as vanilla Spider/Enderman/Vex skins.
- Keeps Breach fauna programmatic/Breach-linked and preserves their current physical Veil-material loot roles; this visual pass does not turn them into normal biome spawns or generic farm mobs.
- Adds regression coverage for replace-all ontology policy validation and updates player/datapack documentation so the industrial loop and tunable values are discoverable without reading source.

## 0.1.35-dev megastructure + equipment-asset checkpoint

- Expands the engineering graph from 69 to **96 unique outputs**, adding continuity/worldline, mnemonic/axiomatic, causal, paradox/singularity, and structural branches that converge into physical capstone megastructure blocks.
- Adds animated **Worldline Lattice**, **Paradox Containment**, **Sovereign Conduit**, and **Crowned Singularity** blocks as real Transcendent Core inputs rather than decorative trophies.
- Makes the final Transcendent Core Assembly cost **268,435,456 Matter + 24,000,000 DE + 262,144 Potential**, plus eight Transcendent Frameworks, four Sovereign Computation Cores, 16 Sovereign Alloy, the four megastructure blocks, the Ascendant assembly, all current Memories, and all ten built-in Laws.
- Turns Sovereign Regalia into a separate post-Transcendent megaproject through Eventide Plates, Sovereign Servos, Regalia Cores, and Absolute Boundary Nodes. The Sovereign Chestplate final job alone costs **268,435,456 Matter + 160,000,000 DE + 196,608 Potential** before nested component costs.
- Gives Phaseweave, Causal, and Sovereign armor dedicated NeoForge 26.2 equipment assets with layered custom worn textures rather than vanilla Diamond/Netherite visuals.
- Adds missing Minecraft 26.2 client-item definitions across the full registry: all **128 registered item forms** now explicitly route through `assets/veilbound/items/<id>.json` to their item model.
- Current resource/progression audit: **501/501 strict JSON**, **44/44 animation metadata**, **128/128 item models/client-item definitions**, **32/32 blockstates**, and a **96-output** acyclic tier/capacity-valid engineering graph. Loader-neutral executable regressions remain **73/73 PASS**.

## 0.1.34-dev dimensional-engineering checkpoint

- Removes Core Matter Intake entirely; persistence v14 reads and discards the old v10-v13 toggle for migration only.
- Adds live persistent held-item Matter commands (`get`, `set`, `clear`) with dependency-limited recomputation and no full `/reload`.
- Adds Dimensional Fabricator + Veil Foundry, 69 data-driven engineering recipes, machine-local fabrication Matter/Potential, and tier/capacity-validated Core Assembly progression.
- Adds Probability Vanes, Ontological Harvester, Potential, and Ontological Compiler for boundary-driven Matter industry whose live load feeds Domain Stability.
- Adds animated Veil accretion materials and Breach-only Paradox/reward materials.
- Adds the FE + Core-DE **Veil Lance** for deliberate Severe/Extreme Breach creation against a real Domain boundary.
- Adds active Phasebreaker, Boundary Spade, Rift Cutter, Resonance Multitool, real Phaseweave/Causal/Sovereign armor, Sovereign in-Domain flight, and Sovereign remote Core controls.
- Adds the in-game Veil Engineering Codex and maintained player/progression/industry documentation under `docs/`.

Older checkpoint sections below are historical implementation notes; when they conflict with this current section or the current player docs, the newer behavior above is authoritative.

## 0.1.33-dev hybrid Veil Inventory checkpoint

- Removed the terminal-only **1-Matter fallback** completely. An item either has a real positive built-in/datapack/inferred Matter value or it is unvalued. An explicit value of `0` is treated as intentionally unvalued while still blocking recipe inference from replacing that decision.
- After the Veil Transmutation Upgrade, valued deposits are immediately converted to Matter and teach their canonical base-item pattern. Unvalued deposits remain exact physical stacks in Veil Inventory, including component-bearing variants.
- Transmutation migration/reconciliation converts only valued stored stacks. Unvalued stacks survive in storage; if a later datapack/reload gives one a real Matter value, it is converted and learned on the next reconciliation.
- The top-level UI remains exactly **Inventory / Craftables**. The Inventory tab is now hybrid: learned valued patterns and physical unvalued stacks are browsed together; Favorites/Recent apply only to Matter patterns.
- Veil Interface automation mirrors the same rule: valued insertion becomes Matter/pattern knowledge, unvalued insertion remains physical storage, valued extraction synthesizes, and unvalued extraction returns the exact stored stack.
- Wireless crafting is hybrid as well: learned valued ingredients may be synthesized from Matter while unvalued ingredients are consumed from physical Veil Inventory. This also fixes the older `craftWithMatter` path that incorrectly delegated to a Matter-only evaluator.
- Unvalued items are ineligible for every Matter-powered machine path, including the Dimensional Transducer and Spatial Generator condensation. There is no fallback value for those systems to borrow. The historical Core Matter Intake path was removed entirely in 0.1.34.
- Persistence remains schema **13** and networking remains protocol **12**; the existing save format already stores Veil Inventory stacks and Matter/pattern state separately.
- Current loader-neutral regression suite: **68/68 PASS**.

## 0.1.32-dev ProjectE Matter compatibility checkpoint

- Veilbound Matter now uses the **ProjectE EMC numeric scale** instead of the earlier custom anchor table. The compatibility baseline is ProjectE 1.1.0 / Minecraft 1.21.1: 184 registry-facing seed entries plus 4 internal graph constants, 43 tag/material equivalence seeds, and 74 special ProjectE conversions are mirrored before normal recipe inference.
- Representative parity anchors are cobblestone 1, coal/copper 128, iron 256, gold 2,048, diamond 8,192, echo shard 192, netherite scrap 12,288, emerald 16,384, heavy core 40,960, nether star 139,264, and dragon egg 262,144. Datapack values remain authoritative overrides.
- ProjectE itself derives most final EMC values from its conversion graph rather than shipping one flat all-item table. Veilbound now follows that same architecture: normal loaded recipes derive craftables, ProjectE-only world/fluid/special equivalences are supplied explicitly, and one-input furnace recipes can safely propagate a fixed output value back to the raw input.
- Minecraft 26.2 additions and modded items can inherit compatible Matter through recipes/tags even though ProjectE's public branch is still 1.21.1. Items with no resolvable ProjectE-compatible value are unvalued and, as of 0.1.33, remain physical Veil Inventory stacks instead of being assigned a fallback.
- Matter terminal patterns remain canonical item identities. Component/NBT variants are intentionally normalized instead of cloning arbitrary state; this means component-specific ProjectE EMC variants are not reproduced.
- Transducer and Core Intake conversion ratios were rescaled independently from item Matter values so adopting ProjectE's larger accounting unit does not accidentally make DE progression ~30× easier: the current reloadable development defaults are 32 Matter/DE + 3 FE/Matter for the Transducer and 320 Matter/DE for direct Core Intake.

## 0.1.31-dev consistency/correction checkpoint

- New players no longer receive a Domain from the V key. A **Genesis Seed** creates/binds the one UUID-owned Domain; existing persisted Domains are preserved.
- Restored the settled physical Core controls: empty-hand use toggles global Expansion; sneak + empty-hand use toggles Matter Intake; a Resonance Lens opens Domain Controls.
- Core Matter Intake is now its own visible loose-item aura and defaults **OFF** for newly created Domains. It considers only actual Matter-valued dropped item entities after a safety grace period. It never reads Veil Inventory Matter or the Transducer's machine-local Matter. Direct Core assimilation is intentionally inefficient; **0.1.32 supersedes this checkpoint's 10-Matter development ratio with 320 ProjectE-scale Matter → 1 DE**.
- The Dimensional Transducer is fully separate: piped/hopper-fed Matter-valued items enter its persistent local Matter buffer, FE enters its energy buffer, and only those two local buffers create DE. Unvalued items are rejected by the Transducer, and the Core Matter Intake toggle does not stop Transducer operation.
- Boundary Pylons now live one block beyond their assigned usable-space face in the impassable Veil and move outward with that face. Stable growth is the settled **0.1 block/s**; Gentle/Stable/Driven/Forced/Rupture are **0.5×/1×/2×/4×/8×**, with DE and Stability Load scaling by speed squared.
- The physical Domain dimension now spans the full legal **4,064-block** custom-dimension envelope (`min_y=-2032`, `height=4064`), so the configured vertical cap is actually reachable.
- The sterile Domain biome now carries a conservative Overworld-like baseline spawn pool. Hostility/Fauna Laws remain the server-authoritative gate, so fresh Domains still naturally spawn nothing; imposing those Laws can now actually enable valid natural spawns on terrain/habitat the owner builds.
- Axiom Monoliths now match the settled physical Law design: one Law-specific Axiom item is consumed to permanently dedicate a fresh Monolith, then empty-hand use toggles only that Law. There is no sneak-cycle/reassignment shortcut.
- 0.1.31 temporarily restored the earlier custom Matter anchors; **0.1.32 supersedes that scale with ProjectE-compatible EMC values**.
- Persistence schema is **13** for Pylon speed; a real v12 payload from 0.1.30 decodes successfully and defaults legacy Pylons to Stable speed. Network protocol is **12** for the expanded Domain Controls action surface.
- Current validation: **68/68 loader-neutral self-tests PASS** and **130/130 strict bundled JSON resources PASS**.

## 0.1.5-dev travel/runtime checkpoint

Veilbound contains a lazy NeoForge runtime Domain level service. A persisted personal Domain is reconstructed only when needed as a normal `ServerLevel` using its stable UUID-derived dimension id and persisted seed. Dormant Domains are saved and removed from the live world map only after the central unload gate confirms that no players, forced chunks, pending transits, or active runtime requirements still depend on them.

Fresh runtime Domains use an empty `FlatLevelSource` with `minecraft:the_void`, no layers, no structures, no custom spawners, and vanilla mob spawning disabled. The canonical starter pocket is usable space `(0,0,0)` through `(0,1,0)` with one reusable Void Anchor at `(0,-1,0)` and centered owner arrival at `(0.5,0,0.5)`. Its one-time initialization flag is persisted so crash recovery can finish creation without ever respawning a starter anchor after the owner intentionally moves it.

The 0.1.5 server-side owner travel executor originally supported first-entry auto-creation; **0.1.31 supersedes that behavior**. A Genesis Seed must now create/bind the one UUID-owned Domain before V can enter it. The executor still preserves exact outside return anchors, nearby collision-safe fallback search, server-spawn fallback, guest-by-guest Threshold evacuation before owner exit, and safe post-exit Domain unloading. Client input/network binding is now implemented: V is registered as the default Enter / Exit Domain key, the client sends an empty serverbound request payload, and the server authoritatively routes it to owner entry, owner exit, or guest exit. A tracked guest pressing V inside another player's Domain returns to that guest's exact saved entry anchor and only closes the guest session after a successful teleport.

## 0.1.6-dev input/network checkpoint

- Default Domain travel key: `V` (fully rebindable through Minecraft Controls).
- The client packet carries no coordinates, owner id, or target dimension; the server derives all travel state.
- Pressing V outside a Domain enters/reuses the player's own UUID Domain.
- Pressing V in the player's own Domain exits to the saved outside return anchor.
- Pressing V during a valid guest Threshold session exits the visited Domain to that exact guest-entry anchor.
- Stale guest sessions are cleared if another system moved the player out-of-band.
- Being inside an untracked foreign Domain is denied rather than inventing an unsafe return destination.


## 0.1.8-dev Threshold frame activation checkpoint

- Added **Threshold Frame**, a climbable frame block inspired by the provided model direction and meant to be used as buildable portal scaffolding.
- Added **Threshold Portal**, the activated full-block portal body produced when a connected frame structure is bound.
- A crouching player who already has a personal Domain can shift-right-click any Threshold Frame block to activate that entire connected frame component at once.
- Activation is server-authoritative and never trusts the client to decide which surrounding frame blocks belong to the structure.
- If the activation happens inside the owner's own Domain dimension, a private permanent Threshold definition is also registered immediately so the visual structure lines up with the settled access system.

## 0.1.9-dev persistent Threshold transit checkpoint

- Activated Threshold structures now persist their source dimension and complete connected block set, so portal blocks can recover the correct owner/binding after a server restart.
- Walking into an outside Threshold Portal now performs real server-authoritative travel. The owner can always use their own portal; guests must satisfy the Threshold access list and the owner must be online and physically inside their Domain.
- Guest entry captures the exact source dimension/coordinates/yaw/pitch before teleporting. Leaving through V or an active Threshold inside the visited Domain returns that guest to the captured entry anchor.
- A Threshold built inside its owner's Domain acts as a controlled exit point: the owner returns to their saved outside recall anchor, and tracked guests return to their individual entry anchors.
- Portal bodies are non-colliding full-block volumes so walking through them can trigger travel instead of behaving like solid cubes.
- Persistence format is now v3; v1/v2 Threshold entries remain readable and are restored as legacy bindings without source-structure coordinates.


## 0.1.10-dev shader checkpoint

- Active Threshold cells now own lightweight render-only block entities; link/access data remains centralized in the persistent Threshold registry rather than duplicated into every cell.
- The old animated-texture world rendering has been replaced by a genuine shader-backed block-entity renderer.
- Threshold rendering submits Minecraft's End-Portal render pipeline as a complete cube, producing a full-block spatial/depth distortion effect on every activated frame cell.
- The block's normal baked model is invisible in-world so there is no z-fighting or translucent cube layered over the shader.
- This reuses Minecraft's maintained shader pipeline without inheriting vanilla End Portal teleport behavior; Veilbound's own touch transit and access rules remain authoritative.
- Successful portal transit arms a one-shot touch latch that clears only after the player physically leaves the portal volume, preventing exact-return anchors from causing immediate re-entry loops without an arbitrary timer.


## 0.1.11-dev Threshold teardown checkpoint

- Breaking any active Threshold Portal cell is intercepted server-side and treated as a request to deactivate the entire persistent Threshold structure.
- Only guests whose active visit entered through that exact Threshold are evacuated; guests using another Threshold owned by the same Domain owner are unaffected.
- Every targeted guest must return successfully to the saved per-player entry anchor before structure removal can commit. An unavailable/offline/stuck guest leaves the Threshold active rather than deleting their return path.
- All persisted portal cells are restored to Threshold Frame blocks as one transaction. Failed world mutation rolls already-restored cells back to portal states.
- The persistent Threshold binding is removed only after guest evacuation and complete frame restoration; a failed binding commit rolls the visual structure back to active portal cells.
- Active Threshold Portal blocks have extreme explosion resistance so non-player destruction cannot bypass the teardown transaction and strand stale portal state.


## 0.1.12-dev Threshold registry/integrity checkpoint

- Active Threshold source cells are now indexed by `(dimension, block position)`, making portal touch/deactivation lookup constant-time instead of scanning every Threshold.
- Active bindings may not overlap the same portal cell; conflicting runtime or persisted bindings are rejected as invalid state.
- The source index is rebuilt from persistence and cleaned atomically when a Threshold is removed.
- Threshold activation is now transactional: every connected frame cell must convert successfully before the binding commits, and any failed cell update or rejected registration restores all already-converted cells to their original frame states.
- The 0.1.11 whole-structure teardown transaction remains in force: targeted guests evacuate first, all source cells restore together, then the binding is removed.
## 0.1.13-dev Veil Inventory backend checkpoint

- Added persistent, slotless Veil Inventory storage directly to each owner's Domain record. Stack identity includes opaque canonical component data so differently-NBT/componented modded items never merge accidentally.
- The finalized storage progression is enforced centrally: Resonant 65,536 items / 256 exact stack types, Ascendant 1,048,576 / 1,024, Transcendent 16,777,216 / 4,096, and effectively unlimited storage after Sovereignty.
- The Veil Inventory remains locked until a `veilbound:veil_inventory_upgrade` is fed to an active Resonant-or-better Core. The separate `veilbound:veil_crafting_upgrade` requires the base inventory first and unlocks the crafting capability state.
- Wireless storage access is owner-only. Guests cannot open or manage another owner's storage.
- Physical Veil Interface authorization is modeled as owner-bound automation that works only while that owner is online and intentionally does not require their personal Domain `ServerLevel` to be loaded. The actual NeoForge block/capability adapter is the next platform-facing slice.
- Added atomic crafting-side storage transactions: ingredient alternatives can be pulled from Veil Inventory, while crafted outputs and container/remainder items are preflighted against capacity and committed together. Missing ingredients or insufficient output capacity leave the inventory unchanged.
- Persistence format is now v4. v1-v3 saves remain readable and restore with an empty Veil Inventory.
- The dev artifact still uses the existing compile-only platform boundary: the new backend is included and regression-tested, but the actual Veil Inventory screen, network payloads, Core item interaction, Veil Interface block entity/capability adapter, recipes, and client keybinding are not yet registered in this checkpoint.


## 0.1.14-dev Veil Inventory platform checkpoint

- Added the first NeoForge-facing wireless Veil Inventory implementation. The default key is `B`; the existing configurable `V` Domain-travel binding remains unchanged.
- Inventory opening, paging, held-stack deposits, one-item withdrawals, and full-stack withdrawals are server-authoritative. The client receives bounded snapshots and cannot directly edit stored counts.
- Added deterministic bounded paging for the slotless digital inventory. Exact component-sensitive stack identities remain separate throughout storage, networking, and display.
- Added physical `Veil Interface` block + block entity. It binds to the placing player, stores only that owner UUID locally, and resolves the actual digital contents from the owner's persistent Domain record.
- Added a NeoForge 26.2 `ResourceHandler<ItemResource>` capability for generic automation. Access is available only while the bound owner is online and does not require the owner's personal Domain `ServerLevel` to remain loaded.
- Interface transfers use transaction snapshots so aborted external transfers restore the exact prior Veil Inventory contents.
- Added `Veil Inventory Upgrade` and `Veil Crafting Upgrade` items plus Core-feeding interaction. Only the owner's actual physical Core accepts these upgrades; invalid/duplicate/too-early feeds are rejected without consuming the item.
- Added initial recipes, item definitions/models, language entries, and a survival drop loot table for the Veil Interface. Current visuals and recipe ingredients are development placeholders pending the final art/balance pass.
- Updated play networking to protocol 2 for Veil Inventory actions/snapshots. The 26.2 GUI migration uses `Minecraft.gui.screen()` / `Minecraft.gui.setScreen(...)`.
- Added a paging self-test; all 31 loader-neutral self-tests pass in the current execution environment.

### 0.1.14 validation limitation

This environment currently provides Java 21 only and has no Gradle installation/cached NeoForge 26.2 userdev toolchain. Minecraft 26.2 development targets Java 25. The 0.1.14 source has therefore been static/API-audited and its loader-neutral tests run, but a truthful NeoForge Gradle compile and real client/server runtime pass still must be performed before publishing a 0.1.14 JAR. The last fully packaged development JAR remains 0.1.13-dev.

## 0.1.15-dev wireless crafting checkpoint

- Added the player-facing 3x3 wireless crafting grid inside Veil Inventory when the `Veil Crafting Upgrade` is unlocked.
- Grid cells hold exact `ItemResource` identities, preserving data components instead of collapsing variants to a bare item id.
- Crafting is server-authoritative: the client submits only the proposed nine input resources, while the server resolves the loaded crafting recipe, output, and remainder/container stacks.
- Added live server-side craft preview. The same storage validation path is used for preview and commit, so missing ingredients and item/type-capacity failures are reported before mutation.
- Craft commits remain atomic through `VeilCraftingService`: ingredients are consumed and output/remainders are returned to Veil Inventory together, or the inventory is left unchanged.
- A successful craft refreshes the same Veil Inventory page instead of forcing the player back to page 1.
- Play networking is now protocol 3 with bounded nine-cell crafting requests and server-authoritative preview payloads.
- Loader-neutral crafting tests now cover successful preview-without-mutation in addition to commit/rollback behavior.

### 0.1.15 validation limitation

The available runtime still has Java 21 and no locally usable Gradle/NeoForge 26.2 userdev toolchain. The source is therefore validated with loader-neutral tests, JSON parsing, and current NeoForge 26.2 API/source auditing, but no 0.1.15 JAR is claimed. A Java 25 NeoForge Gradle compile plus real client/server acceptance remains required before this checkpoint can become the next binary.






## 0.1.20-dev Axiom/Law checkpoint

- The Axiom Monolith is a stateful owner-bound block entity. A fresh Monolith consumes one Law-specific Axiom item to permanently dedicate itself to that datapack Law.
- Once dedicated, empty-hand right-click imposes or repeals only that Law. There is no sneak-cycle shortcut and an attuned Monolith cannot be reassigned.
- Monolith control is restricted to the owner inside that owner's own Domain and requires an awakened Dimensional Core.
- Law prerequisite, incompatibility and dependent-repeal checks remain centralized in the loader-neutral Law service.
- Active Law effect ids now resolve deterministically from persisted imposed Laws, retain source-Law provenance for debugging/auditing, and treat removed datapack definitions as inert rather than fabricating effects or silently deleting saved state.
- No default/starter Laws are granted or silently installed by this checkpoint. Definitions remain datapack-driven.
- Loader-neutral regression suite: **41/41 PASS**. Bundled JSON resource audit: **77/77 PASS**.

The concrete gameplay adapters behind individual Law effect ids remain a later platform-facing slice; this checkpoint establishes the physical control path and safe effect-resolution boundary without inventing unapproved Law content.

## 0.1.19-dev checkpoint

- Fresh Domains still begin with **zero Memories**. Memory definitions are only earnable content; none are auto-granted.
- Mnemonic Vessel capture now persists separately from permanent Archive knowledge. Only Archive ingestion permanently earns a Memory, and the Domain Orrery can invoke only earned Memories.
- Boundary Pylons physically bind to an unambiguous Core-relative axis, can toggle continuous growth for that face, and are taken offline when broken. Growth runs from a datapack-reloadable policy and still obeys owner-online, Core, Breach, tier-cap and Dimensional Energy rules.
- The physical Dimensional Transducer is owner-bound and exposes separate transactional item and FE capabilities. Piped/hopper-fed Matter-valued items are consumed into the Transducer's own persistent local Matter reservoir; FE is buffered separately; cycles consume only those local buffers to create Core Dimensional Energy. Veil Inventory Matter is never read, drained, taught, or modified by the Transducer. Conversion ratios, cadence, FE limits and local Matter capacity are datapack-reloadable balance values.
- Matter/FE/DE conversion is committed through a loader-neutral atomic service so failed conversions do not consume Matter or produce DE.
- The Resonance Lens now reports Domain dimensions, Core tier/DE, Matter, earned Memory count, active expansion pylons, open Breaches and active Orrery profile in-world.

## 0.1.18-dev terminal polish + Memory foundation checkpoint

- Polished the two-tab Matter terminal around normal play: server-side search, `@namespace` filtering, deterministic sort, persistent Favorites and Recents, All/Favorites/Recent Inventory filters, richer Matter/recipe tooltips, and bounded quantity controls.
- Inventory synthesis and Craftables crafting now support quantity cycles of 1/4/8/16/32/64 while the server remains authoritative over learned patterns, Matter cost, recipe validity, and output.
- Search/sort/filter/page state is carried through refreshes and mutations rather than resetting after every action.
- Persistence codec v6 retains terminal favorites/recents with backward reads for supported earlier saves; play networking is protocol 7 for the expanded terminal state.
- Memory datapacks now support `capture_conditions`, prerequisite-aware environmental matching, and conservative profile blending for the future Mnemonic Vessel / Memory Archive / Domain Orrery gameplay layer.
- Added built-in earnable Memory definitions: Open Sky, Gentle Rain, Verdant Growth, and Celestial Cycle.
- Added survival self-drop loot tables for the reusable Transducer, Pylon, Orrery, Memory Archive, Axiom Monolith, Continuity Anchor, and Threshold Frame.
- Loader-neutral regression suite: **36/36 PASS**. JSON resource audit: **75/75 PASS**.

The physical Mnemonic Vessel capture event, Archive/Orrery in-world interactions, Memory visual/mechanical application, Law controls/effects, remaining physical Domain devices, breach runtime events, and a Java 25 NeoForge client/server compile remain future platform-facing slices.

## 0.1.17-dev Matter terminal checkpoint (historical; storage/fallback semantics superseded by 0.1.33)

- Historical 0.1.17 behavior converted Veil Inventory into a Matter-only terminal. **0.1.33 supersedes this with hybrid storage**, retaining only genuinely unvalued physical stacks.
- Installing the upgrade atomically migrates all legacy Veil Inventory contents into Matter and permanent learned base-item patterns.
- Historical 0.1.17 behavior assigned every deposited item a terminal value using a 1-Matter fallback. **0.1.33 removes this fallback**; unvalued items now remain physical storage and do not learn patterns.
- Depositing any stack immediately teaches its base item pattern and converts the entire offered count into Matter. Arbitrary component/NBT state is intentionally canonicalized and is never reproduced by the learned pattern.
- Pattern withdrawal synthesizes canonical items directly from Matter; affordability is `stored Matter / item Matter value`.
- Historical 0.1.17 crafting was Matter-only. **0.1.33 restores physical consumption for unvalued ingredients** while valued ingredients remain pattern-synthesized.
- Crafted outputs and recipe remainders are delivered to the player (falling back to a world drop if inventory insertion leaves a remainder), not returned to hidden Veil storage.
- Historical 0.1.17 Interface behavior was Matter-only. **0.1.33 makes the Interface hybrid**: valued resources transmute/synthesize, unvalued resources insert/extract exact physical stacks.
- Pattern paging now exposes per-item Matter cost and affordable count.
- Inventory and Craftables paging now carries up to 36 icon entries per page for dense terminal-style browsing.

### Terminal frontend
- **Inventory**: permanent learned-pattern icon catalog. Depositing an item immediately learns its base pattern and converts the stack to Matter; selecting an icon shows its Matter cost/affordability and Pull 1 / Pull Stack actions.
- **Craftables**: dense server-generated recipe-output icon catalog with a **Currently Craftable / All Crafts** toggle. Selecting an output shows its canonical 3×3 ingredient layout and Craft action. Currently Craftable requires every ingredient pattern to be learned and enough Matter for the entire craft.
- Recipe selection never trusts a client-provided output: it only supplies a canonical 3×3 proposal to the existing server-authoritative crafting matcher.
- Recipes that require arbitrary component/NBT-bearing ingredient state are not auto-synthesized from a base pattern.

## 0.1.16-dev native Matter transmutation checkpoint

- Replaced the planned ProjectE-specific dependency with a Veilbound-native **Veil Transmutation Upgrade** layered on top of Veil Inventory + Veil Crafting.
- Added a persistent per-owner Matter reserve and permanent learned base-item patterns. Existing eligible stored items are learned when the upgrade is installed; later eligible deposits auto-learn.
- Canonical/default-component items can be deliberately converted from Veil Inventory into Matter at the same authoritative Matter value used by Veilbound's built-in/datapack/recipe-inference catalog.
- Matter-aware wireless crafting consumes real stored ingredients first, then synthesizes only the missing amount from learned patterns and deducts the exact Matter cost.
- Craft preview and commit share the same Matter-aware preflight, including output capacity, missing-pattern, insufficient-Matter, and overflow checks.
- Component-bearing variants are deliberately excluded from generic synthesis/base-item conversion so learned patterns cannot clone enchantments, custom data, damage, filled containers, or similar state.
- Veil Inventory server snapshots now include Matter balance and learned-pattern count, plus a server-authoritative stack-to-Matter action.
- Persistence format is now v5; v1-v4 payloads remain readable and restore with an empty Matter reserve/pattern set.
- Play networking is protocol 4 for the expanded inventory state/actions.
- Loader-neutral suite: **32/32 PASS**. JSON resource audit: **64/64 PASS**.

The terminal frontend direction is now two top-level tabs only: **Inventory** and **Craftables**. Craftables will expose a **Currently Craftable / All Crafts** toggle; Matter-backed virtual ingredients participate in the Currently Craftable calculation when the required pattern is learned and sufficient Matter is available.


## 0.1.21-dev Continuity/Stability/Breach checkpoint

- Continuity Anchor is now a persistent owner-bound block entity rather than a decorative registration. A successful placement inside the owner’s active Domain registers that exact position in Domain state.
- Continuity Anchors are one-chunk loaders. NeoForge chunk tickets use the Anchor block position as their source, are restored when the owner logs in, and are removed before normal Domain unload processing when the owner logs out. Multiple Anchors in one chunk each contribute Stability Load but the runtime tracks one loaded chunk for unload accounting.
- The default Continuity Anchor cap is 25 per Domain and is reloadable through `data/veilbound/veilbound/balance/domain_stability.json`.
- Stability defaults now match the settled design: Core capacities 100 / 160 / 240 / 360 / 520, active Pylon +4 load, permanent Threshold +6 load, Continuity Anchor +4 load. The Stable/Strained/Critical/Rupturing stability bands are represented as load-ratio boundaries 0.35 / 0.65 / 0.85.
- Domains now persist a fracture meter. While the owner is online, the server evaluates stability on a reloadable cadence; low stability builds fracture and can open a Minor/Severe/Extreme Breach on one of the six current Domain faces.
- Open Breaches continue to hard-lock all Domain expansion through the existing expansion governor until every Breach is sealed.
- Veil Stitcher is now functional in the owner’s Domain. Right-clicking near an open Breach selects the nearest Breach within the reloadable range and atomically spends the severity-specific Dimensional Energy cost to seal it.
- Resonance Lens now reports current Stability percentage/band, load/capacity, fracture progress, and Continuity Anchor count in addition to the existing Domain summary.
- Persistence payload version is now v8. v1–v7 payloads remain readable; older payloads restore with zero Continuity Anchors and zero fracture progress.
- Fracture accumulation rates, Stitcher range/costs, open-Breach cap, and future intruder cadence in the bundled balance file are development tuning values rather than newly frozen design invariants. Dedicated Veil creature entities are still a later platform slice; this checkpoint does not substitute vanilla mobs for them.


## 0.1.22-dev Breach fauna/hazard checkpoint

- Added three dedicated Veilbound hostile entity types: **Void Crawler**, **Rift Stalker**, and **Null Wraith**. Their factories create Veilbound subclasses rather than substituting vanilla mobs into the Breach system.
- Creature roles use proven vanilla locomotion foundations while remaining separate entity types: Crawlers inherit wall-climbing spider movement, Stalkers inherit Enderman pursuit/teleport movement, and Wraiths inherit Vex flight/phasing. All three add unconditional nearby-player targeting so their hostility does not depend on spider light level, Enderman eye contact, or an Evoker owner.
- At the 0.1.22 checkpoint, Breach fauna were programmatic-only gameplay entities with no natural spawn tables, spawn eggs, loot table, or vanilla XP. **Later checkpoints supersede only the loot-table portion:** they remain Breach-only/programmatic and XP-free, but now award Veilbound physical materials.
- Every spawned intruder persists the owning Domain UUID and source Breach UUID. The live Breach coordinator removes linked fauna when the Breach is sealed/invalid or when a creature escapes the configured source tether radius.
- Linked Breach fauna are denied mob griefing through NeoForge's mob-grief decision event, preventing inherited Enderman block pickup/placement from rearranging a player's Domain.
- Added reloadable, severity-specific emergence intervals and weighted fauna pools. Bundled development tuning keeps Minor Breaches Crawler-only, introduces Stalkers at Severe, and introduces Wraiths only at Extreme.
- Emergence positions are chosen just inside the Breach's current Veil face, tangent-jittered, and clamped to current usable Domain bounds. This geometry is loader-neutral and covered for all six faces.
- Added reloadable proximity hazards around open Breaches. Minor is visual-only by default; Severe and Extreme add cadence-based magic damage plus severity-scaled particles. Sealed Breaches produce neither hazard nor new intruders.
- Existing Breaches continue to run hazards/emergence only while their Domain level is already live; the coordinator does not wake dormant personal Domain levels merely to spawn threats.
- At the 0.1.22 checkpoint, client visuals reused the corresponding vanilla parent renderers/textures. **0.1.36 supersedes this visual placeholder:** the creatures now have dedicated Veilbound renderer classes and textures while deliberately retaining the parent locomotion/model silhouettes.
- Spawn/hazard cadence, weights, radii, cap, damage, and particles remain reloadable development balance values rather than newly frozen design invariants.


## 0.1.23-dev concrete Law runtime checkpoint

- Added the first complete built-in Law catalog as datapack definitions: **Hostility, Fauna, Flame, Ruin, Grief, Conflict, Descent, Preservation, Time, and Weather**. Their existence in the registry does not impose them; fresh Domains still begin with no imposed Laws.
- Added loader-neutral built-in effect semantics keyed by `veilbound:hostility`, `veilbound:fauna`, `veilbound:flame`, `veilbound:ruin`, `veilbound:grief`, `veilbound:conflict`, `veilbound:descent`, `veilbound:preservation`, `veilbound:time`, and `veilbound:weather`. Unknown/add-on effect ids remain inert in the built-in bridge rather than receiving guessed behavior.
- Replaced Domain inheritance of Overworld day/weather/game-rule state with `VeilboundDomainLevelData`, a per-Domain mutable level-data boundary. Only Law-owned mechanics are sovereign; unrelated gamerules continue to mirror the server's Overworld gamerules while the Domain is live.
- **Hostility** gates natural monster spawning. **Fauna** gates other natural mob categories. Commands, spawners, Breach emergence, and other non-`NATURAL` spawn reasons are not rewritten into natural spawning.
- **Flame** controls the Domain's fire-spread radius, restoring the server's normal configured radius while imposed and forcing it to zero while repealed.
- **Ruin** controls explosion block destruction without canceling entity damage/knockback. **Grief** controls the Domain-local mob-grief gamerule.
- **Conflict** controls Domain-local PvP, **Descent** controls fall damage, and **Preservation** controls keep-inventory.
- **Time** controls mechanical day-time progression. **Weather** controls weather progression; repealing Weather also clears an existing Domain storm instead of freezing rain/thunder indefinitely.
- Domain day time and weather timers/flags now persist independently across unload/restart. Persistence payload version is **v9**; v1-v8 payloads remain readable and receive safe clear-weather/time-zero defaults for the newly introduced fields.
- A real v8 payload generated with the untouched 0.1.22 codec was decoded by the v9 codec during validation, preserving prior Core/Anchor/fracture/Sovereignty data while defaulting only the new environment fields.
- Loader-neutral regression suite: **46/46 PASS**. Bundled JSON audit: **88/88 PASS**.


## 0.1.25-dev per-Domain Open Sky illumination checkpoint

- Replaced the temporary inert `mechanic.illumination` fallback with a real per-personal-Domain Minecraft 26.2 environment-attribute projection. Each live `VeilboundServerLevel` owns its own sky-light runtime; no Open Sky state is written to the Overworld or another player's Domain.
- The static `veilbound:domain` dimension type remains fail-closed at gameplay sky light `0` and visual sky-light factor `0`. If the live override is absent or fails to install, fresh Domains therefore remain dark rather than gaining free illumination.
- **Open Sky without Celestial Cycle** restores full daylight (`gameplay/sky_light_level = 15`, `visual/sky_light_factor = 1`) for that Domain.
- **Open Sky + Celestial Cycle** follows the vanilla 26.2 Overworld day/night brightness curves, but samples them from the Domain's own persisted remembered clock. Time can therefore freeze or advance independently according to the Domain's Law/Memory state.
- Server-side mechanics such as natural-spawn light checks and daylight-detector-style queries read the Domain-specific gameplay sky-light value. The matching client visual factor is installed only for Veilbound personal Domain levels.
- Client projection uses a narrow client-only Mixin accessor because Minecraft 26.2 exposes `ClientLevel.environmentAttributes` as a private final field with no setter. No vanilla method is overwritten or redirected.
- Environment-attribute caches and derived sky brightness are refreshed immediately when the Open Sky state changes and as the remembered celestial clock advances.
- Environmental Zones remain local visual/profile overlays. Because `minecraft:gameplay/sky_light_level` is a whole-dimension gameplay attribute, a zone cannot give only one guest a different mechanical skylight value inside the same owner's Domain; the global Orrery controls the Domain-wide mechanical illumination substrate.
- Persistence stays at v10; this checkpoint adds no new persisted fields.
- Loader-neutral regression suite: **54/54 PASS**. Strict bundled JSON audit: **91/91 PASS**.

## 0.1.27-dev physical Pylon + Vessel ownership + Core-tier progression checkpoint

- Boundary Pylons now bind an axis to one exact physical block position. A fresh Domain no longer starts with six imaginary online Pylons, duplicate placement cannot steal a face, and only breaking the actually bound Pylon takes that direction offline.
- New Mnemonic Vessel captures are stored on the individual unstackable Vessel ItemStack through a persistent data component. The old Domain-global pending-capture field remains only as a v7-v10 migration bridge and transfers into a held Vessel on first use.
- Core-tier upgrades are now mechanically live through datapack definitions in `data/<namespace>/veilbound/core_upgrades/`. Required items are fed incrementally into the owner's physical Core, progress persists, excess held items are not consumed, and the final transition also pays the destination tier's existing DE upgrade cost.
- Veilbound deliberately provides no built-in Core-tier ingredient definitions yet. This checkpoint wires the progression engine without inventing progression recipes that have not been approved.
- Persistence is schema v11. Legacy v10 Pylons migrate fail-closed because old saves had no physical binding position; legacy pending Memory capture remains recoverable; Core-tier feed progress begins empty.
- No custom network payload shape changed in this checkpoint, so the 0.1.26 network protocol remains version 9.

## 0.1.26-dev pre-Core Spatial Generator + Core awakening checkpoint

- Turned the Spatial Generator into a persistent handheld pre-Core device with a NeoForge item-energy capability. It stores FE and **one** Condensed Charge resource directly on the stack rather than treating Matter-derived charge and FE-derived charge as separate currencies.
- Locked the accepted pre-Core conversion efficiency at **35%**. Fractional results are stored internally as milli-Condensed-Charge so small Matter inputs do not lose value to integer rounding.
- Added server-authoritative Matter + FE condensation from the non-generator hand. Only items with an actual Matter catalog value are accepted; FE consumption bounds how much of a stack can be converted in one action.
- Added pre-Core X/Y/Z expansion controls with the settled **10-block maximum usable span per axis**. Expansion is symmetric and spends only Condensed Charge. The provisional `20 FE / raw Matter` and `1 Condensed Charge / newly usable block` values remain datapack-reloadable development tuning rather than frozen balance.
- Added the physical **Nucleus Catalyst + 50,000 Condensed Charge** Core-awakening path. Awakening requires at least a **3×3×2** usable pre-Core Domain, proximity to the fixed origin, and a replaceable origin cell; it places the Dimensional Core at `(0,0,0)` and activates the existing Nascent Core state atomically with block rollback on state failure.
- Fixed owner Domain arrival after Core awakening so the normal Domain key places the owner safely on top of the origin Core instead of inside its block.
- Extended the Resonance Lens with truthful pre-Core guidance: it reports current pre-Core dimensions, the 10-block axis limit, and the 50,000-charge awakening requirement instead of presenting an inactive Domain as though a Nascent Core already existed.
- Added a compact Spatial Generator screen and network payloads for condensation, axis growth, and awakening. Network protocol is now **9**.
- The Nucleus Catalyst intentionally has no finalized survival recipe in this checkpoint because its material recipe has not been balance-locked; it is present for development/testing without inventing an authoritative recipe.
- Loader-neutral regression suite: **55/55 PASS**. Strict bundled JSON audit: **94/94 PASS**.



## 0.1.28-dev milestone/progression checkpoint

- Added persistent data-driven Milestones with explicit prerequisites, accomplishment criteria, and one-shot feature rewards.
- Built-in milestones cover Core awakening/tiering, physical Pylons, stable expansion, archived Memories, Environmental Zones, Laws, Thresholds, and Sovereignty without granting any starter progress.
- **Environmental Mastery** now has a real earned path: an Anchored Core plus three archived Memories, with prerequisite milestone completion evaluated server-side.
- Milestone progress is persisted in schema **v12**. A real v11 payload produced by the untouched 0.1.27 codec migrates successfully with existing Domain state intact and no fabricated historical milestone completion.
- Resonance Lens feedback now reports milestone progress and Core-tier upgrade feed/DE status.
- Core-tier material requirements remain datapack-defined; Veilbound still does not invent built-in tier ingredients.

## 0.1.29-dev Memory Management checkpoint

- Added one owner-only **Memory Management** screen with Archive, Orrery, and Zones tabs.
- Archive shows every known definition, archived state, prerequisites, tags, capture conditions, and Vessel ingestion guidance.
- Orrery supports server-authoritative multi-Memory activation/deactivation and clearing while preserving Memory compatibility rules.
- Zones exposes the existing no-marker Environmental Zone system with persisted priority, lower-priority blending, Memory retuning, rename, and delete controls.
- Every mutation is revalidated on the server; forged client actions cannot retune a zone to an unarchived Memory or bypass Environmental Mastery.
- Archive ingestion still requires a real captured Mnemonic Vessel; the UI does not grant Memories.

## 0.1.30-dev Domain Controls checkpoint

- Added one owner-only **Domain Controls** screen with Core, Pylons, and Thresholds tabs.
- At this historical checkpoint, Core controls exposed tier, DE/capacity, usable dimensions, fracture, global expansion, and the then-present Matter Intake state. **0.1.34 removes Matter Intake entirely; the Core is DE-only.**
- Pylon controls expose all six Core-relative faces, physical binding positions, online state, and per-face expansion toggles.
- Threshold controls expose permanent Threshold source/destination information, private/public access, and persistent UUID guest invitations. Existing invited UUIDs remain manageable even while the guest is offline so access can always be revoked.
- Historical 0.1.30 behavior opened Domain Controls from empty-hand Core use. 0.1.31 temporarily restored an old Matter Intake shortcut; **0.1.34 supersedes both**: empty-hand Core use toggles global Expansion, while sneak + empty-hand opens Domain Controls because the Core is now DE-only. Sneak-use on a bound Pylon still opens the Pylons tab; normal use remains the quick expansion toggle.
- Direct packets are rejected unless the sender owns the active Domain they are currently inside. Threshold and Pylon mutations are re-resolved from persisted server state rather than trusting client coordinates or ownership claims.
- At this historical checkpoint the network protocol was **11** and persistence schema **12**. 0.1.31 advances them to protocol **12** and schema **13**.
- Historical 0.1.30 validation: **58/58** loader-neutral regressions and **107/107** JSON resources.
- Ingredient recipes not selected at that checkpoint remained undefined; later implementation may now choose unspecified progression details while preserving explicit Veilbound decisions.
