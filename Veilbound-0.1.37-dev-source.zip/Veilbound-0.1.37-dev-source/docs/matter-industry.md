# Matter, Potential, and DE Industry

Veilbound deliberately separates its major resources.

## Veil Inventory Matter

Matter is an accounting representation of Matter-valued items stored by the owner's Veil Inventory. Valued deposits are transmuted and teach a canonical pattern. Unvalued items remain physical stacks. There is no 1-Matter fallback.

## Machine-local fabrication Matter

The Dimensional Fabricator and Veil Foundry can maintain their own local Matter feed for recipes. This prevents early Core progression from requiring Veil Inventory features that unlock later. A station's Matter is not the Core's resource and is not silently pulled from Veil Inventory.

## Dimensional Transducer

The Transducer accepts physical Matter-valued item input and FE. Items are immediately converted into that Transducer's local Matter reservoir. A conversion cycle consumes local Matter + FE and adds DE to the owner's Core. Unvalued items are rejected. The Core remains DE-only.

## Potential

Potential describes unresolved possible material states. It is neither FE, Matter, nor DE.

Probability Vanes must be exposed to a current Domain boundary. An Ontological Harvester counts valid exposed Vanes and produces Potential based on operating mode and current instability. Higher fracture and open Breaches can increase yield, creating a deliberate risk/reward loop.

Harvester modes increase production and Stability load nonlinearly. The live load is published into the Domain Stability calculation and expires automatically if the machine stops ticking or unloads.

Empty-hand use on an owned Harvester opens the **Ontology Console**. The console refreshes from the server once per second and shows stored/capacity Potential, contributing boundary Vanes, the last production cycle, live Stability load, fracture meter, open Breaches, and the resulting instability yield multiplier. Quiet/Stable/Driven/Paradox mode buttons change operating mode without breaking/replacing the machine. Sneak + empty-hand use still provides the quick cycle gesture and then opens the same console.

## Ontological Compiler

The Compiler converts Potential + Core DE into Veil Inventory Matter. The Core is supplying dimensional authority/energy; the Potential is supplying possible material states. The resulting Matter belongs to Veil Inventory, not the Core.

Empty-hand use on an owned Compiler opens its Ontology Console. It shows the Compiler Potential reservoir, Core DE reserve/capacity, current compiler status, Matter reserve, Matter/Potential and DE/Potential ratios, and the cycle cap. The UI is telemetry/control only; server-side machine ownership and Domain identity remain authoritative.

## Reloadable ontology balance

The ontology industry is tuned by:

`data/veilbound/veilbound/balance/ontology_industry.json`

The Harvester block controls Potential per contributing Vane, the Vane cap, Stability-load basis, full-fracture yield bonus, and per-open-Breach yield bonus. The Compiler block controls Matter per Potential, Core DE per Potential, and the maximum Potential collapsed per cycle. The bundled values preserve the established 0.1.34/0.1.35 balance; a higher-priority datapack may replace them without changing code. Invalid policy values are rejected as a unit and Veilbound falls back to the bundled validated development policy rather than partially applying a broken economy.

## Breach materials

Breach creatures and Paradox accretions produce special physical materials such as Veil Residue, Fractured Essence, Causal Shards, Unresolved Matter, and Paradox Crystals. They are deliberately unvalued so they cannot be bypassed by transmutation. Advanced engineering recipes consume them directly.

## Live Matter overrides

Server operators can hold an item and use:

- `/veilbound matter get`
- `/veilbound matter set <value>`
- `/veilbound matter clear`

A set override is persisted in world SavedData and takes effect immediately. Veilbound recomputes only recipe values transitively dependent on that item, so a single change does not require a full datapack reload. `set 0` deliberately marks the item unvalued. `clear` removes the admin override and falls back to datapack, ProjectE-compatible seed/tag conversion, or recipe inference.
