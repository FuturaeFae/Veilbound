# Progression Trees

This document is a human-readable map of the engineering graph. Exact component counts and costs are data-driven under `data/veilbound/veilbound/engineering_recipes/` and should be checked in the in-game station UI for the installed datapack set.

## Bootstrap

Genesis Seed
→ personal sterile Domain
→ Spatial Generator + FE + valued material
→ Condensed Charge
→ pre-Core expansion
→ Resonant accretion
→ 3×3×2 minimum pocket
→ Nucleus Catalyst + 50,000 Condensed Charge
→ Nascent Dimensional Core

## Nascent engineering

Resonant Frame Segment
+ Phase Coil
+ Phase Logic Array
+ Dimensional Capacitor
→ early Boundary/diagnostic/fabrication components
→ Anchored Core Assembly
→ Anchored Core

The Anchored assembly intentionally requires no Potential, preventing a bootstrap loop.

## Anchored engineering

Anchored Core
→ Probability Vanes
→ Ontological Harvester
→ first Potential
→ Memory Archive / Mnemonic Vessel / Orrery path
→ Causal Lattice / Mnemonic Matrix / Continuity Inductor / Pattern Matrix
→ Boundary Skeleton
→ Dimensional Transducer
→ Resonant Core Assembly
→ Resonant Core

## Resonant engineering

Resonant Core
→ broader accretion materials
→ Ontological Compiler
→ renewable Matter industry
→ Transmutation Lattice / Material Phase Regulator
→ Causal Processor (includes Breach-derived Causal Shards)
→ Axiomatic Controller
→ Ontological Matrix (includes Veil Residue)
→ Singularity Regulator (Paradox Crystal)
→ Veil Foundry
→ Veil Lance
→ advanced Veilforged tools and Phaseweave armor
→ Ascendant Core Assembly
→ Ascendant Core

## Ascendant engineering

Ascendant Core
→ Law Kernel (Paradox material)
→ dedicated Law Axioms / Axiom Monoliths / imposed Laws
→ Causal Steel + Axiomatic Glass + Continuity Crystal + Folded Matter

The capstone then splits into several simultaneous industrial branches:

**Continuity/worldline branch**
Continuity Spindle + Causal Clock
→ Worldline Bearing
→ Continuity Flywheel

**Axiom/Memory computation branch**
Axiom Bus → Axiom Shunt
Mnemonic Prism → Memory Refractor
→ Transfinite Logic Array

**Paradox/singularity branch**
Ontology Pump + Void Pressure Regulator
→ Paradox Governor
→ Horizon Lens
→ Singularity Crown

**Structural branch**
Phase Compression Ring + Continuity Spindle + Boundary Skeleton
→ Invariant Mesh
→ Causal Manifold
→ Reality Lattice
→ Domain Spine

These branches converge into physical megastructure modules:

Domain Spine + Invariant Mesh
→ Worldline Lattice Block

Singularity Crown + continuity/axiomatic material
→ Paradox Containment Block

Worldline Bearing + Transfinite Logic + Sovereign Alloy
→ Sovereign Conduit Block

Singularity Crown + containment + ontology hardware
→ Crowned Singularity Block

The upper branch also deepens Sovereign Alloy, Folded Space Brace, and Sovereign Computation Core rather than allowing them to bypass the new subassemblies.

8× Transcendent Framework
+ 4× Sovereign Computation Core
+ 16× Sovereign Alloy
+ Worldline Lattice / Paradox Containment / Sovereign Conduit / Crowned Singularity modules
+ Ascendant Core Assembly
+ all four built-in Memories
+ all ten built-in Laws
+ 268,435,456 Matter
+ 24,000,000 DE
+ 262,144 Potential
→ Transcendent Core Assembly
→ Transcendent Core

## Transcendent equipment

Transcendent Core
→ Eventide Plates
+ Sovereign Servos
+ Regalia Cores
+ Absolute Boundary Nodes
→ Sovereign Regalia
→ highest Domain-linked equipment capabilities.

The Regalia branch is intentionally a second megaproject after Core progression instead of a cheap victory lap. The Sovereign Chestplate final job costs 268,435,456 Matter and 160,000,000 DE before nested component costs.

## Breach branch

Natural instability or Veil Lance
→ Severe/Extreme Breaches
→ Veil creatures + Paradox accretions
→ Veil Residue / Fractured Essence / Causal Shards / Unresolved Matter / Paradox Crystal
→ causal, ontological, Law, Rift Cutter, singularity, and sovereign component branches.

This branch cannot be skipped by Matter synthesis because Breach-specific materials are intentionally unvalued.
