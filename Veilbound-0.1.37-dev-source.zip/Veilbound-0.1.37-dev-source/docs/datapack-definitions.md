# Data-driven Laws, Memories, and Core Upgrades

Veilbound loads Laws, Memories, and sequential Core-tier upgrade requirements from server datapacks. The resource namespace becomes the definition namespace and the path beneath the Veilbound directory becomes the definition path, so normal datapack priority overrides matching definitions.

## Laws

`data/<namespace>/veilbound/laws/<path>.json`

Example: `data/veilbound/veilbound/laws/gentle_gravity.json`

```json
{
  "display_name": "Gentle Gravity",
  "progression_weight": 2,
  "axiom_item": "example:axiom_of_gentle_gravity",
  "prerequisites": [],
  "incompatible_laws": [],
  "effects": ["veilbound:gentle_gravity"]
}
```

`display_name` is required. The remaining fields are optional for compatibility, but a player-attainable Law should define `axiom_item`. `effects` contains handler IDs; definitions do not directly execute arbitrary datapack code. `axiom_item` must name a real registered item. Give each loaded Law a unique Axiom item; if two Laws resolve to the same item, physical attunement fails closed instead of choosing one arbitrarily.

A fresh physical Axiom Monolith has no Law. Inserting/right-clicking it with the configured Law-specific Axiom consumes exactly one Axiom item and **permanently dedicates that Monolith to that Law**. Its attunement cannot then be cycled, replaced, or cleared. Empty-hand right-click imposes/repeals only that dedicated Law after server-side prerequisite and incompatibility validation. No Law is auto-granted merely because its definition exists.

Active `effects` are resolved only from currently imposed Laws. Multiple Laws may request the same effect id; the runtime deduplicates the effect while retaining source-Law provenance. If an imposed Law definition disappears after datapack reload, that persisted Law id becomes inert and is reported as missing rather than being silently erased. Concrete gameplay behavior for an effect id is supplied only by registered Veilbound platform code, never arbitrary datapack execution.


### Bundled built-in Law effects

Veilbound currently ships definitions for the following accepted Law set. These files make the Laws available to the Axiom Monolith registry; **none are imposed automatically**.

| Law | Effect id | Built-in server behavior |
| --- | --- | --- |
| Hostility | `veilbound:hostility` | Allows natural monster spawning in the Domain. |
| Fauna | `veilbound:fauna` | Allows other natural mob categories in the Domain. |
| Flame | `veilbound:flame` | Enables fire spread using the server's normal configured fire-spread radius. |
| Ruin | `veilbound:ruin` | Allows explosions to modify blocks; without it, blast entity effects remain but the affected-block list is cleared. |
| Grief | `veilbound:grief` | Enables the Domain-local mob-grief gamerule. |
| Conflict | `veilbound:conflict` | Enables Domain-local PvP. |
| Descent | `veilbound:descent` | Enables fall damage. |
| Preservation | `veilbound:preservation` | Enables keep-inventory. |
| Time | `veilbound:time` | Enables mechanical day-time progression. |
| Weather | `veilbound:weather` | Enables weather progression; repealing it clears an existing storm. |

Hostility/Fauna intentionally gate only vanilla `NATURAL` spawn attempts. Commands, spawners, Breach fauna, and other explicit/non-natural spawn reasons are not reclassified. Unknown effect ids are ignored by the built-in adapter and remain available for future/add-on handlers.

## Memories

`data/<namespace>/veilbound/memories/<path>.json`

Example: `data/veilbound/veilbound/memories/ashen_twilight.json`

```json
{
  "display_name": "Ashen Twilight",
  "tags": ["sky", "fog"],
  "environmental_profile": {
    "visual.sky": "veilbound:ashen_twilight",
    "visual.fog": "veilbound:ashen_haze"
  },
  "capture_conditions": {
    "dimension": "minecraft:overworld",
    "sky": "visible",
    "time_band": "night"
  },
  "prerequisites": [],
  "unlocked_features": ["FIRMAMENT", "AMBIENCE"]
}
```

`display_name` is required. `unlocked_features` must name Veilbound `DomainFeature` values; names are case-insensitive. `capture_conditions` is an optional exact-match map used by the Mnemonic Vessel capture layer; a value of `*` accepts any observed value. Definitions with no capture conditions are never auto-captured accidentally. Prerequisite Memories must already be archived/unlocked before a dependent Memory can be captured.

Environmental profile keys/values are intentionally string identifiers so rendering/environment adapters can evolve without embedding client implementation details into the persistent Domain model. Prefer namespaced profile families such as `visual.*` and `mechanic.*`; the Orrery blend layer can combine compatible profiles and explicitly rejects contradictory values for the same key.

Malformed individual definitions are ignored with a warning rather than crashing the entire server reload. A successful reload replaces the corresponding runtime registry, which also removes stale definitions that disappeared from the active datapack set.

## Milestones

`data/<namespace>/veilbound/milestones/<path>.json`

Milestones are server-authoritative, durable progression accomplishments. Fresh Domains start with **zero completed milestones**. A definition existing in a datapack does not itself complete anything; the configured criteria must become true and every prerequisite milestone must already be complete. Completion is persisted permanently and any `unlocked_features` reward is applied once.

```json
{
  "display_name": "Environmental Mastery",
  "prerequisites": ["veilbound:first_memory_archived", "veilbound:anchored_core"],
  "criteria": {
    "minimum_core_tier": "anchored",
    "minimum_archived_memories": 3
  },
  "unlocked_features": ["ENVIRONMENTAL_MASTERY"]
}
```

Supported criteria are: `core_active`, `minimum_core_tier`, `minimum_archived_memories`, `minimum_bound_pylons`, `minimum_environment_zones`, `minimum_permanent_thresholds`, `minimum_imposed_laws`, `minimum_size_x`, `minimum_size_y`, `minimum_size_z`, `sovereignty_unlocked`, and `required_features`. Counts/sizes default to zero, booleans default to false, and omitted tier/feature constraints impose no requirement. A Pylon counts only when it is physically bound and online.

Bundled 0.1.28 progression records Core awakening and each Core tier, first physical Pylon, first stable 5×2×5 Core-era expansion, first archived Memory, first Law, first permanent Threshold, first Environmental Zone, and Sovereignty. The only new built-in capability reward in this checkpoint is **Environmental Mastery**, earned at Anchored Core after three Memories have been archived. This deliberately does not auto-unlock unfinished Relic/Anomaly content or replace the separately fed Veil Inventory/Crafting/Transmutation upgrades. Datapacks may replace these milestone resources normally.

## Core tier upgrades

`data/<namespace>/veilbound/core_upgrades/<path>.json`

Example schema for a **server/datapack-defined** Nascent → Anchored upgrade:

```json
{
  "from": "nascent",
  "to": "anchored",
  "ingredients": [
    { "item": "example:stabilized_matrix", "count": 4 },
    { "item": "example:anchor_crystal", "count": 1 }
  ]
}
```

Core upgrades must advance exactly one tier. Ingredient entries are fed directly into the owner's physical Dimensional Core and each item id may appear only once in a definition. Counts must be positive. Partial progress is persistent and lossless: the Core consumes only the remaining amount it needs, so a larger held stack is never swallowed wholesale.

After every configured ingredient has been fed, the upgrade also consumes the destination tier's existing Dimensional Energy transition cost: **20,000 DE** for Anchored, **200,000 DE** for Resonant, **2,000,000 DE** for Ascendant, and **20,000,000 DE** for Transcendent. If the Core does not yet hold enough DE, completed item progress remains stored and the tier does not advance.

Veilbound intentionally ships **no built-in Core-tier ingredient definitions through 0.1.31-dev**. The runtime and datapack format are implemented, but actual progression ingredients are left undefined until their recipes are deliberately finalized rather than being invented by the implementation. With no matching definition for the current tier, item feeding simply remains inactive.

Malformed definitions are ignored with a warning. Reloading replaces the Core-upgrade registry, so removed datapack definitions cannot remain active as stale runtime recipes.

## Domain stability and Breach balance

Veilbound's built-in Domain stability policy is loaded from:

`data/veilbound/veilbound/balance/domain_stability.json`

This is a single replaceable policy resource rather than a directory of independent definitions. A higher-priority datapack can replace that resource to rebalance the server without changing Java code.

```json
{
  "evaluation_ticks": 20,
  "max_continuity_anchors": 25,
  "capacity_by_core_tier": {
    "nascent": 100.0,
    "anchored": 160.0,
    "resonant": 240.0,
    "ascendant": 360.0,
    "transcendent": 520.0
  },
  "loads": {
    "active_pylon": 4.0,
    "permanent_threshold": 6.0,
    "continuity_anchor": 4.0
  },
  "load_ratio_bands": {
    "strained": 0.35,
    "critical": 0.65,
    "rupturing": 0.85
  },
  "breach": {
    "fracture_delta_per_evaluation": {
      "stable": -2.0,
      "strained": 0.5,
      "critical": 2.0,
      "rupturing": 5.0
    },
    "fracture_threshold": 100.0,
    "maximum_fracture_meter": 300.0,
    "max_open_breaches": 3,
    "stitcher_range": 6.0,
    "stitcher_de_cost": {
      "minor": 1000,
      "severe": 5000,
      "extreme": 25000
    }
  }
}
```

The Core capacities, default Pylon/Threshold/Continuity Anchor loads, stability-band boundaries, and default 25-Anchor cap match the settled Veilbound design. Fracture rates, Stitcher range/costs, simultaneous-Breach cap, evaluation cadence, and intruder cadence are development balance values and intentionally remain easy to retune. Invalid/non-finite policy values reject that reload payload and fall back to the bundled development policy rather than poisoning live stability calculations.

## Spatial Generator balance

Veilbound's pre-Core Spatial Generator development balance is loaded from:

`data/veilbound/veilbound/balance/spatial_generator.json`

```json
{
  "forge_energy_per_raw_matter": 20,
  "condensed_charge_per_new_block": 1
}
```

Only these two values are intended to be datapack-tunable in this policy. The conversion efficiency remains fixed at **35%**, the pre-Core usable span remains capped at **10 blocks per axis**, and initial Core awakening remains fixed at **50,000 Condensed Charge**. The bundled 20 FE/raw-Matter and 1 Condensed-Charge/new-block values are development tuning and may be rebalanced without changing the settled progression model. Invalid values reject the reload payload and fall back to the bundled development policy.


## Dimensional Transducer balance

`data/veilbound/veilbound/balance/dimensional_transducer.json`

```json
{
  "cycle_ticks": 20,
  "forge_energy_capacity": 1000000,
  "max_forge_energy_input": 100000,
  "forge_energy_per_matter": 3,
  "matter_per_dimensional_energy": 32,
  "matter_capacity": 32000000
}
```

The Transducer exposes separate item and FE capabilities. Accepted physical item input is immediately valued through the normal Matter catalog and stored only in that Transducer's local Matter reservoir. It never reads or drains Veil Inventory Matter. The Core stores DE only and has no Matter-ingestion path. The bundled 32 Matter/DE and 3 FE/Matter defaults deliberately keep machine output near the earlier pre-ProjectE development balance despite the much larger ProjectE numeric Matter scale; item Matter value and DE conversion efficiency are separate balance concepts.

## Ontological industry balance

Veilbound's boundary-observation Matter industry is loaded from:

`data/veilbound/veilbound/balance/ontology_industry.json`

Example bundled policy:

```json
{
  "harvester": {
    "potential_per_vane_per_cycle": 2,
    "max_contributing_vanes": 64,
    "base_stability_load_per_vane": 0.35,
    "fracture_yield_bonus_at_full_meter": 1.0,
    "breach_yield_bonus_per_open_breach": 0.15
  },
  "compiler": {
    "matter_per_potential": 256,
    "dimensional_energy_per_potential": 32,
    "max_potential_per_cycle": 256
  }
}
```

All production/capacity fields must be positive. Stability load and instability-bonus fields must be non-negative. The policy is constructed and replaced as one validated snapshot; malformed or invalid content falls back to Veilbound's bundled development default rather than leaving Harvester and Compiler balance on different generations. The live Ontology Console reads the same runtime policy that the machines use, so datapack tuning is reflected in player telemetry after reload.

## Core-era Domain expansion balance

`data/veilbound/veilbound/balance/domain_expansion.json`

```json
{
  "cycle_ticks": 200,
  "dimensional_energy_per_new_block": 4,
  "vertical_span_cap": 4064,
  "transcendent_horizontal_cap": 0
}
```

`cycle_ticks=200` is the settled Stable-mode rate of **0.1 block/second**. Pylon speed modes derive their cadence from this Stable interval: Gentle 0.5×, Stable 1×, Driven 2×, Forced 4×, Rupture 8×. The configured per-block DE cost and active-Pylon Stability Load both scale with the **square** of the speed multiplier. The bundled Stable DE cost of 4 is current implementation balance rather than a previously fixed design number. Vertical span may never exceed the hard 4,064-block Minecraft/Veilbound envelope even if a datapack requests more.
