# Veilbound Player Guide

This guide describes the intended survival progression. Veilbound is built around one personal Domain per player. The Domain begins as almost nothing and becomes an engineered reality through Matter, Dimensional Energy (DE), Memories, Laws, Stability control, and large fabrication projects.

## 1. Bind a Domain

Craft or otherwise obtain a **Genesis Seed** from the active datapack recipe and use it to bind your one personal Domain. Press **V** to enter or leave after binding. A new Domain is a sterile 1×1×2 pocket with one reusable Void Anchor below you. Nothing is granted automatically: no Core, Memories, Laws, ecology, or free infrastructure.

## 2. Pre-Core expansion

Use a **Spatial Generator** to convert real Matter-valued items plus FE into one Condensed Charge resource. Condensation is 35% efficient. Spend Condensed Charge to expand the pre-Core pocket, up to 10 usable blocks on each axis. Newly admitted slices can form early Resonant accretions, giving the first native dimensional engineering material.

Reach at least a 3×3×2 usable pocket. At the permanent Domain origin, use the **Nucleus Catalyst** with 50,000 Condensed Charge to awaken the Dimensional Core.

## 3. The Core and DE

The Core stores **DE only**. It does not consume Matter and has no Matter-intake aura. Normal empty-hand Core use toggles global Boundary Pylon expansion. Detailed Domain Controls are opened through the Resonance Lens.

The **Dimensional Transducer** is the normal automated DE producer: pipe Matter-valued physical items and FE into it. The Transducer values those items into its own local Matter buffer, consumes that local Matter plus FE, and sends DE to the Core. It never drains Veil Inventory Matter.

## 4. Dimensional Fabrication

Build a **Dimensional Fabricator** as soon as the progression tree permits. Advanced recipes can simultaneously require:

- physical components,
- the station's own local Matter buffer,
- Core DE,
- Potential,
- archived Memories,
- imposed Laws,
- a minimum Core tier,
- processing time.

A fabrication job is transactional: the station validates the complete recipe before committing the expensive inputs. Use the station interface to inspect every missing requirement.

The **Veil Foundry** is the later manufacturing tier for causal, axiomatic, sovereign, and Transcendent engineering.

Once you reach Ascendant, do not expect a short straight-line upgrade. The bundled capstone tree fans into continuity, worldline, mnemonic, axiomatic, causal, and paradox subassemblies. Manufacture these in quantity: Continuity Spindles lead into Worldline Bearings and Flywheels; Axiom/Mnemonic hardware leads into Transfinite Logic; Paradox control leads into Singularity Crowns; structural branches become Reality Lattices and Domain Spines. Those branches finally become the animated **Worldline Lattice**, **Paradox Containment**, **Sovereign Conduit**, and **Crowned Singularity** blocks consumed by the Transcendent Core project.

The default **Transcendent Core Assembly** costs 268,435,456 station Matter and 24,000,000 DE at the final operation, in addition to all nested subassemblies, Potential, Memories, Laws, and Breach-only materials used to reach it.

## 5. Boundary engineering

Place one **Boundary Pylon** on each desired Domain face. A Pylon occupies the Veil one block beyond usable space and moves outward as that face expands. Stable mode grows at 0.1 block/s. Gentle, Stable, Driven, Forced, and Rupture operate at 0.5×, 1×, 2×, 4×, and 8×; DE and Stability cost rise with speed squared.

Expansion can form Veil accretion nodes. Resonant material appears first. Phase, Mnemonic, Causalite, and Axiomite become part of later dimensional engineering. Paradox material does not generate as ordinary expansion ore.

## 6. Veil Inventory and Matter

After the Transmutation upgrade, Veil Inventory is hybrid:

- items with a real positive Matter value are converted immediately into Matter and teach their canonical pattern;
- items with no Matter value remain as exact physical stacks;
- unvalued items cannot be synthesized or used as Matter fuel;
- crafting can combine physical unvalued ingredients with Matter-synthesized valued ingredients.

There is **no fallback Matter value**. Matter values use the ProjectE-compatible scale where possible and conservative recipe inference for compatible vanilla/modded items.

Operators can adjust a held item's value live with `/veilbound matter get`, `/veilbound matter set <value>`, and `/veilbound matter clear`. These commands do not require `/reload`.

## 7. Memories and environmental engineering

Memories are earned, never granted. Capture a Memory in a **Mnemonic Vessel**, archive it in the **Memory Archive**, then select archived Memories through the **Domain Orrery**. Environmental Zones allow different parts of one Domain to use different remembered conditions.

The Engineering Codex and machine screens show which Memories an advanced recipe requires. Required Memories are knowledge checks; fabrication does not consume them.

## 8. Laws

A Law is not a menu toggle you receive for free. Manufacture its dedicated **Axiom**, insert that Axiom into a fresh **Axiom Monolith**, and the Monolith becomes permanently dedicated to that Law. Empty-hand use toggles the installed Law. Axioms are intentionally expensive dimensional-engineering artifacts.

## 9. Ontological Matter industry

The signature renewable Matter industry is not a furnace-generator block.

1. Build **Probability Vanes** against a current Domain boundary.
2. Connect them to an **Ontological Harvester**.
3. Empty-hand use the Harvester to open its **Ontology Console**. It shows live boundary-Vane contribution, Potential, fracture/Breach yield multiplier, and Stability load.
4. Choose Quiet, Stable, Driven, or Paradox mode in the console. Higher modes produce more Potential but add disproportionately more Stability load. Sneak + empty-hand use remains a quick mode-cycle gesture.
5. Feed Potential to an **Ontological Compiler** and empty-hand use it to inspect its live console.
6. The Compiler consumes Potential + Core DE and deposits Matter into Veil Inventory. Its console shows the active conversion ratios, cycle cap, Core DE, and Matter reserve.
7. Both consoles are owner-only/server-authoritative; moving too far away or losing ownership prevents actions rather than trusting stale client state.

Vanes must remain exposed to the moving Veil boundary. Expansion can bury an old array, forcing real boundary engineering instead of permanent passive generation.

## 10. Breaches and intentional rupture

Instability can naturally form Breaches. Breaches produce hazards, Veil creatures, and materials that are deliberately excluded from normal Matter transmutation.

The late-game **Veil Lance** intentionally creates a Breach. Place it inside your Domain and aim it at a current unobstructed Domain boundary. FE charges and maintains the beam; when rupture succeeds, the machine spends the final Core-DE cost and applies a large fracture shock. If the shot cannot complete, the final DE payment is not taken. FE already spent charging is not refunded.

Controls:

- use a **Resonance Multitool** on the Lance to cycle its beam direction through all six axes;
- sneak + empty-hand use cycles **Controlled / Overdrive**;
- empty-hand use starts or aborts charging and also reports status/cooldown.

Development-default firing profiles:

- **Controlled**: Severe Breach, **4,000,000 FE**, **250,000 DE**, 20-second charge, 60 Stability-fracture shock, 120-second cooldown;
- **Overdrive**: Extreme Breach, **12,000,000 FE**, **1,000,000 DE**, 30-second charge, 120 Stability-fracture shock, 240-second cooldown.

The Lance requires at least a Resonant Core, has a 512-block maximum boundary beam distance, and refuses to fire once the configured open-Breach cap is reached. These are policy values rather than hidden magic constants and can be retuned with the balance layer.

Forced Breaches are normal Breaches: they use the same hazard, creature, Paradox accretion, open-Breach cap, and Veil Stitcher repair systems.

## 11. Veilforged equipment

The equipment tree is part of dimensional engineering, not a separate generic armor tier.

- **Phasebreaker**: Normal, Vein, Plane, and Phase mining modes. Additional breaks are bounded and consume Core DE.
- **Boundary Spade**: Precision or Terraform mode; Terraform removes a matching 3×3 plane and consumes DE per additional block.
- **Rift Cutter**: DE-backed spatial-shear damage.
- **Resonance Multitool**: diagnostics and configuration work for Veilbound machinery.
- **Phaseweave, Causal, Sovereign sets**: real humanoid armor with progressively stronger DE-backed mitigation and their own layered Veilbound worn-equipment textures. Full Sovereign Regalia grants creative-style flight while inside your own Domain; DE is drained only while actively flying. Wearing the full set also lets the Resonance Multitool open remote Core controls from anywhere inside that Domain.

Sovereign Regalia is intentionally a **post-Transcendent engineering project**, not an immediate reward for reaching the tier. Build Eventide Plates, Sovereign Servos, Regalia Cores, and Absolute Boundary Nodes first. The default Sovereign Chestplate final operation alone consumes 268,435,456 Matter and 160,000,000 DE, with the other pieces scaled similarly.

Protection/claim mods can still veto extra tool breaks because Veilbound routes them through Minecraft's normal server block-destruction path.

## 12. What to build toward

The long-form target is:

**Genesis → pre-Core expansion → Core awakening → Fabricator → Anchored → Matter/Memory infrastructure → Resonant → Ontological industry/Breaches/advanced tools → Foundry/Laws → Ascendant → worldline/causal/axiomatic/paradox megastructure chain → Transcendent Core → Regalia megaproject.**

Use the **Veil Engineering Codex** in game for a compact progression reference and the specialized documents in this folder for exact system behavior.
