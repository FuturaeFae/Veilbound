# Matter values

## ProjectE compatibility baseline

As of Veilbound **0.1.32-dev**, canonical item/block Matter uses the same numeric unit as ProjectE EMC. The compatibility baseline is **ProjectE 1.1.0 for Minecraft 1.21.1**, the current public ProjectE branch used while Veilbound targets Minecraft 26.2. ProjectE does not maintain one authoritative hand-written final table for every item. Instead it seeds raw/natural items and tags, registers special conversions, and maps the loaded recipe/conversion graph. Veilbound mirrors that model rather than maintaining a competing custom value scale.

Examples of the ProjectE scale now used by Veilbound include cobblestone **1**, coal **128**, copper ingot **128**, iron ingot **256**, gold ingot **2,048**, diamond **8,192**, netherite scrap **12,288**, emerald **16,384**, heavy core **40,960**, nether star **139,264**, and dragon egg **262,144**. ProjectE's own current direct value for echo shard is **192**.

Veilbound installs **184 registry-facing ProjectE seed entries** plus **4 internal graph constants**, **43 ProjectE tag/equivalence seeds**, and **74 loader-neutral ProjectE special conversions** before applying normal Minecraft/NeoForge recipe inference. Tag seeds are expanded against the live registry after tags load, so compatible modded metals/materials can inherit ProjectE's standard equivalences. Ordinary craftables are then derived from the loaded recipe graph, including safe reverse propagation through one-input smelting/blasting where ProjectE's fixed output establishes the raw input value. General reverse-crafting is deliberately not enabled because it can create circular or exploit-prone valuation.

ProjectE source provenance used for this baseline:

- `src/datagen/generated/data/projecte/pe_custom_conversions/defaults.json` on ProjectE's `mc1.21.1` branch;
- `src/datagen/generated/data/projecte/pe_custom_conversions/metals.json`;
- ProjectE's conversion/mapping model (`MappingCollector` and the documented custom conversion format).

For Minecraft 26.2 vanilla additions that do not exist in ProjectE 1.21.1, and for other mods, Veilbound derives Matter from recipes using those ProjectE-compatible seeds whenever a safe production chain exists. A datapack can explicitly set any value and always wins over both ProjectE seeds and inference.

### Canonical item identity and component variants

Veilbound's Matter terminal intentionally learns/synthesizes **base item identities**, not arbitrary component/NBT state. Depositing an enchanted, damaged, renamed, or otherwise component-bearing stack therefore uses the canonical base item Matter value and discards variant state. ProjectE can distinguish some data-component variants (goat-horn instruments are one current example), so component-specific EMC is the one deliberate semantic difference from a live ProjectE mapper. Preserving Veilbound's canonicalization prevents component mutation from becoming a state-cloning or Matter-arbitrage primitive.

### Items ProjectE cannot value

ProjectE can legitimately leave an item without EMC when no seed or safe conversion resolves it. Veilbound assigns **no fallback value**. After the Transmutation Upgrade, an unvalued item remains an exact physical Veil Inventory stack and teaches no pattern. It is rejected by every Matter-powered conversion path, including the Dimensional Transducer and Spatial Generator condensation.

Veilbound resolves Matter values in this precedence order:

1. datapack override;
2. built-in conservative seed value;
3. inferred recipe value.

Recipe inference uses the cheapest fully understood production path, divides by recipe output count, subtracts detectable returned/remainder inputs, resolves chains recursively, and leaves unsafe/opaque paths unresolved.

## Datapack override layout

The resource path is the target item id. For `minecraft:diamond`, create:

`data/minecraft/veilbound/matter_values/diamond.json`

```json
{
  "value": 300
}
```

For `examplemod:parts/void_gear`, create:

`data/examplemod/veilbound/matter_values/parts/void_gear.json`

Datapack resource priority therefore resolves conflicts naturally: a higher-priority pack replaces the same target resource. A reload clears stale overrides before rebuilding recipe inference.

A value of `0` is valid and can be used to explicitly make an item yield no Matter. Negative values and malformed JSON are rejected.

## Matter terminal valuation and hybrid storage

The Matter catalog can legitimately be unresolved. There is **no fallback Matter value**. Resolution remains datapack/explicit override, built-in ProjectE-compatible seed, then conservative recipe inference. If none produces a positive value, the item is unvalued. An explicit `0` is an intentional unvalued override and prevents inference from assigning a replacement value.

After the Veil Transmutation Upgrade, valued deposits are immediately converted to Matter and teach the canonical base-item pattern. Unvalued deposits remain exact physical stacks in Veil Inventory. Their component data is preserved because no transmutation occurred. If a reload later gives a stored item a positive Matter value, terminal reconciliation converts that stored stack and learns its base pattern at that time.

Patterns remain base item identities. Component/NBT state on a **valued** deposit is intentionally canonicalized and is not reproduced by synthesis. Unvalued physical storage remains exact.

## Dimensional Transducer separation

The Dimensional Transducer does **not** consume Veil Inventory Matter. It exposes a physical item-input capability plus an FE capability. Accepted item stacks are immediately valued through the normal Matter catalog and converted into the Transducer's own persistent local Matter reservoir; FE is buffered separately. A transduction cycle consumes only those two machine-local buffers and transfers the resulting Dimensional Energy to the owner's Core.

An item with no positive built-in, explicit datapack, or inferred Matter value is rejected by the Transducer. It may be stored physically in Veil Inventory, but it cannot enter the Transducer's Matter buffer. This keeps personal storage completely separate from physical DE generation.
