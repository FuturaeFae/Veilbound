# Dimensional Engineering

Veilbound's advanced progression is intentionally large. Cost is expressed through multiple engineering disciplines rather than repeated compressed-block recipes.

## Component families

- **Resonant Frame Segments** — first structural components.
- **Phase Coils / Phase Logic Arrays** — spatial manipulation and machine control.
- **Dimensional Capacitors** — DE-oriented machine components.
- **Boundary Skeletons** — large structures that survive contact with the Veil.
- **Causal Lattices / Causal Processors** — high-order state sequencing; Causal Processors also require Breach-derived Causal Shards.
- **Mnemonic Matrices** — Memory-aware computation.
- **Pattern Matrices / Transmutation Lattices / Material Phase Regulators** — Matter engineering.
- **Continuity Inductors / Continuity Crystals** — persistence across dimensional discontinuities.
- **Axiomatic Controllers / Law Kernels / Axiomatic Glass** — physical Law engineering. Law Kernels require Paradox material.
- **Ontological Matrices** — probability-state machinery; also consume Breach-derived Veil Residue.
- **Folded Matter** — manufactured Matter state using Unresolved Matter from Breach creatures.
- **Causal Steel, Sovereign Alloy, Transcendent Frameworks** — late Foundry materials.
- **Continuity Spindles / Worldline Bearings / Continuity Flywheels** — mechanical continuity hardware that keeps a machine coherent across competing positions.
- **Axiom Buses / Axiom Shunts / Memory Refractors / Mnemonic Prisms** — Law and Memory signal hardware used by the capstone computation branch.
- **Void Pressure Regulators / Paradox Governors / Horizon Lenses / Singularity Crowns** — Breach-fed singularity-control assemblies.
- **Invariant Meshes / Causal Manifolds / Reality Lattices / Domain Spines** — large structural subassemblies; these deliberately force bulk production of earlier components.
- **Worldline Lattice, Paradox Containment, Sovereign Conduit, and Crowned Singularity blocks** — animated structural modules consumed by the Transcendent Core megaproject.
- **Eventide Plates / Sovereign Servos / Regalia Cores / Absolute Boundary Nodes** — post-Transcendent Regalia components. These are intentionally far more expensive than ordinary armor ingredients.

Finished Veilbound engineering components and equipment are explicitly unvalued for Matter. Expensive fabrication cannot be reversed into a Matter-profit loop.

## Fabricator

The Dimensional Fabricator is the first advanced manufacturing station. It stores exact physical ingredients, local fabrication Matter, and local Potential. A selected recipe additionally queries the owner's Core for DE and progression prerequisites.

The station starts only when every requirement is satisfied. Resource commitment is atomic at job start; the output appears only after its process time completes. Machine state persists across saves.

## Veil Foundry

The Veil Foundry is the upper manufacturing tier. It handles components whose production requires large Matter/DE/Potential budgets and advanced causal/axiomatic materials. Foundry recipes are intentionally long-form and may require archived Memories or already-imposed Laws.

At Ascendant tier the Foundry becomes a **megastructure supply chain**, not a single-recipe machine. Worldline, causal, mnemonic, axiomatic and paradox branches converge through multiple layers before the Transcendent Core Assembly is even selectable. The bundled tree now contains 96 unique engineering outputs.

## Core assemblies

Core progression is represented as engineering assemblies rather than one-step ingot recipes. Each next-tier assembly is manufactured at a tier the player can actually reach; the recipe graph is validated to prevent a component from requiring the tier that the assembly itself is meant to unlock.

Current broad order:

- **Anchored Core Assembly** — Nascent-era project, no Potential dependency.
- **Resonant Core Assembly** — Anchored-era project after the first Harvester/Potential infrastructure can exist.
- **Ascendant Core Assembly** — Resonant-era large engineering project.
- **Transcendent Core Assembly** — Ascendant-era megaproject requiring eight Transcendent Frameworks plus sovereign computation/alloy, Worldline Lattice, Paradox Containment, Sovereign Conduit and Crowned Singularity structures, enormous Matter/DE/Potential expenditure, all current Memories, and all ten built-in Laws. The bundled default recipe alone requires 268,435,456 fabrication Matter and 24,000,000 Core DE after all nested subassemblies have already been manufactured.

## Why the tree is expensive

Matter absorbs bulk material cost while physical components prove that the player built the preceding infrastructure. DE proves Domain energy capacity. Potential proves boundary industry. Memories prove exploration/capture. Laws prove axiomatic engineering. Breach-only drops prove deliberate engagement with dimensional instability.

This is intended to feel like constructing impossible machinery, not merely storing enough cobblestone. The tree is deliberately wide and nested: high-tier recipes consume manufactured subassemblies that themselves consume other manufactured subassemblies, while Breach-only materials remain physical and untransmutable.

The post-Transcendent Regalia branch is intentionally even more extreme. A Sovereign Chestplate consumes Eventide Plates, Sovereign Servos, Regalia Cores and an Absolute Boundary Node and carries a bundled station cost of 268,435,456 Matter plus 160,000,000 DE before counting the nested cost of those components.

## Veilforged equipment

Veilforged equipment is manufactured through the same engineering tree rather than ordinary one-step armor recipes. Phaseweave provides the first dimensional armor layer, Causal equipment adds stronger DE-backed protection, and Sovereign Regalia is the Transcendent capstone. Full Sovereign Regalia grants flight only inside the owner's Domain and drains Core DE while the player is actually flying. The Resonance Multitool can also open remote Core controls while the full Sovereign set is worn.

Tool and armor inventory textures use animated dimensional highlights; their gameplay abilities remain server-authoritative. Phaseweave, Causal and Sovereign armor also use dedicated modern equipment assets with layered worn textures instead of borrowing Diamond/Netherite player-model visuals.

## Veil Lance

The Veil Lance is manufactured in the Veil Foundry once Resonant-era Breach engineering is available. It accepts FE through its normal energy capability, but FE only powers the physical beam apparatus. The actual dimensional rupture is authorized by a transactional Core-DE payment when the Breach successfully opens. Losing the boundary target, running out of charge conditions, or otherwise failing the rupture never consumes the final DE payment.

Rotate the beam with a Resonance Multitool, sneak-use empty-handed to change firing profile, and empty-hand use to charge/abort. Controlled mode is the repeatable Severe-Breach profile; Overdrive deliberately trades much larger FE/DE costs, fracture shock, and cooldown for an Extreme Breach.
