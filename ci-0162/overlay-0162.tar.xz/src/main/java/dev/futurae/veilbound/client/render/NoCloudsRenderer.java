package dev.futurae.veilbound.client.render;

import net.minecraft.client.CloudStatus;
import net.minecraft.client.renderer.state.level.LevelRenderState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.CustomCloudsRenderer;
import org.joml.Matrix4fc;

/** Domain cloud renderer that intentionally suppresses vanilla clouds at every Domain height. */
public final class NoCloudsRenderer implements CustomCloudsRenderer {
    @Override
    public boolean renderClouds(
            LevelRenderState levelRenderState, Vec3 camPos, CloudStatus cloudStatus,
            int cloudColor, float cloudHeight, int cloudRange, Matrix4fc modelViewMatrix) {
        return true;
    }
}
