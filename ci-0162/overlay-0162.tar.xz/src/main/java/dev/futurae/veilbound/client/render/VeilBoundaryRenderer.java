package dev.futurae.veilbound.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.boundary.VeilBoundaryCollisionState;
import dev.futurae.veilbound.boundary.VeilBoundaryCollisionState.BreachOpening;
import dev.futurae.veilbound.boundary.VeilBoundaryCollisionState.ShellBounds;
import dev.futurae.veilbound.boundary.VeilBoundaryCollisionState.Snapshot;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.util.context.ContextKey;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.ExtractLevelRenderStateEvent;
import net.neoforged.neoforge.client.event.SubmitCustomGeometryEvent;

/**
 * Renders the personal-Domain boundary as a completely opaque black membrane with dense inward fog.
 *
 * <p>The membrane itself contains no animated color at all. Fog depth is resolved per wall axis from
 * wall area and available inward span: tiny Domains receive a shallow bank that cannot crowd the
 * player, while larger Domains progressively grow deeper rolling fog. Sixteen optically compensated
 * slices are retained, but only the local part of a wall inside the boundary render radius is submitted.
 * A true one-block spherical clearance is carved around the active camera so fog never renders directly
 * in the player's face. Visual faces deliberately overlap past tangential edges so adjoining walls cannot
 * expose a rasterized crack.</p>
 */
public final class VeilBoundaryRenderer {
    private static final ContextKey<Snapshot> RENDER_STATE_KEY = new ContextKey<>(
            Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "veil_boundary_render_state"));
    private static final double SURFACE_EPSILON = 0.002D;
    /** Extra visual length past each edge, intentionally overlapping adjoining boundary faces. */
    private static final double EDGE_OVERLAP = 0.10D;
    private static final int FOG_LAYERS = 16;
    private static final double MIN_FOG_DEPTH = 0.30D;
    private static final double MAX_FOG_DEPTH = 6.00D;
    private static final double MAX_AXIS_FOG_FRACTION = 0.34D;
    private static final double FOG_WALL_AREA_SCALE = 0.17D;
    private static final double FOG_BASE_DEPTH = 0.35D;
    private static final double CAMERA_CLEAR_RADIUS = 1.00D;
    private static final double MAX_BOUNDARY_RENDER_DISTANCE = 224.0D;
    private static final float FOG_NEAR_ALPHA = 0.125F;
    private static final double BASE_FOG_TIME_SPEED = 0.175D;

    private VeilBoundaryRenderer() {}

    public static void onExtractLevelRenderState(ExtractLevelRenderStateEvent event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) return;
        Snapshot snapshot = VeilBoundaryCollisionState.clientSnapshot(
                minecraft.level.dimension().identifier().toString());
        if (snapshot != null) event.getRenderState().setRenderData(RENDER_STATE_KEY, snapshot);
    }

    public static void onSubmitCustomGeometry(SubmitCustomGeometryEvent event) {
        Snapshot snapshot = event.getLevelRenderState().getRenderData(RENDER_STATE_KEY);
        if (snapshot == null) return;

        PoseStack poseStack = event.getPoseStack();
        Vec3 camera = event.getLevelRenderState().cameraRenderState.pos;
        ShellBounds shell = VeilBoundaryCollisionState.shellBounds(snapshot.bounds());
        // Continuous process-time phase. A modulo here causes a periodic visible snap; keep the
        // advection continuous and independent of camera/player coordinates.
        double fogSpeedMultiplier = clamp(snapshot.fogSpeedMultiplier(), 0.10D, 6.00D);
        float time = (float) (System.nanoTime() / 1_000_000_000.0D * BASE_FOG_TIME_SPEED * fogSpeedMultiplier);

        poseStack.pushPose();
        poseStack.translate(-camera.x, -camera.y, -camera.z);
        var collector = event.getSubmitNodeCollector();

        collector.submitCustomGeometry(poseStack, VeilBoundaryRenderPipeline.type(), (pose, out) ->
                renderOpaqueShell(out, pose, shell, camera));

        collector.submitCustomGeometry(poseStack, VeilBoundaryFogRenderPipeline.type(), (pose, out) ->
                renderFogVolume(out, pose, shell, camera, time));

        if (!snapshot.openBreaches().isEmpty()) {
            collector.submitCustomGeometry(poseStack, VeilBoundaryFogRenderPipeline.type(), (pose, out) -> {
                for (BreachOpening breach : snapshot.openBreaches()) {
                    renderBreachMist(out, pose, breach, shell, camera, time);
                }
            });
        }

        poseStack.popPose();
    }

    private static void renderOpaqueShell(
            VertexConsumer out, PoseStack.Pose pose, ShellBounds s, Vec3 camera) {
        int black = 0xFFFFFFFF; // Fragment shader ignores RGB and resolves every pixel to black.
        visibleQuadX(out, pose, s.minX() + SURFACE_EPSILON,
                s.minY() - EDGE_OVERLAP, s.maxY() + EDGE_OVERLAP,
                s.minZ() - EDGE_OVERLAP, s.maxZ() + EDGE_OVERLAP,
                camera, black, false);
        visibleQuadX(out, pose, s.maxX() - SURFACE_EPSILON,
                s.minY() - EDGE_OVERLAP, s.maxY() + EDGE_OVERLAP,
                s.minZ() - EDGE_OVERLAP, s.maxZ() + EDGE_OVERLAP,
                camera, black, true);
        visibleQuadY(out, pose, s.minY() + SURFACE_EPSILON,
                s.minX() - EDGE_OVERLAP, s.maxX() + EDGE_OVERLAP,
                s.minZ() - EDGE_OVERLAP, s.maxZ() + EDGE_OVERLAP,
                camera, black, true);
        visibleQuadY(out, pose, s.maxY() - SURFACE_EPSILON,
                s.minX() - EDGE_OVERLAP, s.maxX() + EDGE_OVERLAP,
                s.minZ() - EDGE_OVERLAP, s.maxZ() + EDGE_OVERLAP,
                camera, black, false);
        visibleQuadZ(out, pose, s.minZ() + SURFACE_EPSILON,
                s.minX() - EDGE_OVERLAP, s.maxX() + EDGE_OVERLAP,
                s.minY() - EDGE_OVERLAP, s.maxY() + EDGE_OVERLAP,
                camera, black, true);
        visibleQuadZ(out, pose, s.maxZ() - SURFACE_EPSILON,
                s.minX() - EDGE_OVERLAP, s.maxX() + EDGE_OVERLAP,
                s.minY() - EDGE_OVERLAP, s.maxY() + EDGE_OVERLAP,
                camera, black, false);
    }

    private static void renderFogVolume(
            VertexConsumer out, PoseStack.Pose pose, ShellBounds s, Vec3 camera, float time) {
        double spanX = Math.max(0.01D, s.maxX() - s.minX());
        double spanY = Math.max(0.01D, s.maxY() - s.minY());
        double spanZ = Math.max(0.01D, s.maxZ() - s.minZ());
        double depthX = smartFogDepth(spanX, spanY, spanZ);
        double depthY = smartFogDepth(spanY, spanX, spanZ);
        double depthZ = smartFogDepth(spanZ, spanX, spanY);

        for (int layer = 0; layer < FOG_LAYERS; layer++) {
            float depth01 = (layer + 0.5F) / FOG_LAYERS;
            double distanceX = layerDistance(depthX, depth01);
            double distanceY = layerDistance(depthY, depth01);
            double distanceZ = layerDistance(depthZ, depth01);
            float alphaX = fogAlpha(distanceX, depthX);
            float alphaY = fogAlpha(distanceY, depthY);
            float alphaZ = fogAlpha(distanceZ, depthZ);

            fogQuadXWithCameraClearance(out, pose, s.minX() + distanceX,
                    s.minY() - EDGE_OVERLAP, s.maxY() + EDGE_OVERLAP,
                    s.minZ() - EDGE_OVERLAP, s.maxZ() + EDGE_OVERLAP,
                    camera, time, depth01, alphaX, false);
            fogQuadXWithCameraClearance(out, pose, s.maxX() - distanceX,
                    s.minY() - EDGE_OVERLAP, s.maxY() + EDGE_OVERLAP,
                    s.minZ() - EDGE_OVERLAP, s.maxZ() + EDGE_OVERLAP,
                    camera, time, depth01, alphaX, true);
            fogQuadYWithCameraClearance(out, pose, s.minY() + distanceY,
                    s.minX() - EDGE_OVERLAP, s.maxX() + EDGE_OVERLAP,
                    s.minZ() - EDGE_OVERLAP, s.maxZ() + EDGE_OVERLAP,
                    camera, time, depth01, alphaY, true);
            fogQuadYWithCameraClearance(out, pose, s.maxY() - distanceY,
                    s.minX() - EDGE_OVERLAP, s.maxX() + EDGE_OVERLAP,
                    s.minZ() - EDGE_OVERLAP, s.maxZ() + EDGE_OVERLAP,
                    camera, time, depth01, alphaY, false);
            fogQuadZWithCameraClearance(out, pose, s.minZ() + distanceZ,
                    s.minX() - EDGE_OVERLAP, s.maxX() + EDGE_OVERLAP,
                    s.minY() - EDGE_OVERLAP, s.maxY() + EDGE_OVERLAP,
                    camera, time, depth01, alphaZ, true);
            fogQuadZWithCameraClearance(out, pose, s.maxZ() - distanceZ,
                    s.minX() - EDGE_OVERLAP, s.maxX() + EDGE_OVERLAP,
                    s.minY() - EDGE_OVERLAP, s.maxY() + EDGE_OVERLAP,
                    camera, time, depth01, alphaZ, false);
        }
    }

    /**
     * Fog grows with wall area but is always capped by the available inward span. This prevents
     * opposing banks in starter/small Domains from filling the room while allowing large engineered
     * Domains to carry a much deeper boundary atmosphere.
     */
    private static double smartFogDepth(double inwardSpan, double wallSpanA, double wallSpanB) {
        double wallScale = Math.sqrt(Math.max(1.0D, wallSpanA * wallSpanB));
        double desired = FOG_BASE_DEPTH + wallScale * FOG_WALL_AREA_SCALE;
        double crowdCap = Math.max(MIN_FOG_DEPTH, inwardSpan * MAX_AXIS_FOG_FRACTION);
        return clamp(Math.min(desired, crowdCap), MIN_FOG_DEPTH, MAX_FOG_DEPTH);
    }

    private static double layerDistance(double fogDepth, float depth01) {
        return 0.025D + depth01 * Math.max(0.0D, fogDepth - 0.025D);
    }

    private static float fogAlpha(double distance, double fogDepth) {
        if (fogDepth <= 1.0D || distance <= 1.0D) return FOG_NEAR_ALPHA;
        float tail = (float) clamp((fogDepth - distance) / (fogDepth - 1.0D), 0.0D, 1.0D);
        return FOG_NEAR_ALPHA * (0.045F + 0.955F * tail * tail);
    }

    private static void renderBreachMist(
            VertexConsumer out, PoseStack.Pose pose, BreachOpening breach, ShellBounds shell,
            Vec3 camera, float time) {
        double radius = switch (breach.severity()) {
            case MINOR -> 1.05D;
            case SEVERE -> 1.70D;
            case EXTREME -> 2.35D;
        };
        double x = breach.position().x() + 0.5D;
        double y = breach.position().y() + 0.5D;
        double z = breach.position().z() + 0.5D;
        double dx = camera.x - x;
        double dy = camera.y - y;
        double dz = camera.z - z;
        if (dx * dx + dy * dy + dz * dz > MAX_BOUNDARY_RENDER_DISTANCE * MAX_BOUNDARY_RENDER_DISTANCE) return;
        // Breach mist is brighter neutral grey; no purple contribution is permitted in this pass.
        float alpha = 0.18F;
        switch (breach.face()) {
            case NEGATIVE_X -> fogQuadXWithCameraClearance(out, pose, shell.minX() + 0.045D,
                    y - radius, y + radius, z - radius, z + radius, camera, time, 0.0F, alpha, false);
            case POSITIVE_X -> fogQuadXWithCameraClearance(out, pose, shell.maxX() - 0.045D,
                    y - radius, y + radius, z - radius, z + radius, camera, time, 0.0F, alpha, true);
            case NEGATIVE_Y -> fogQuadYWithCameraClearance(out, pose, shell.minY() + 0.045D,
                    x - radius, x + radius, z - radius, z + radius, camera, time, 0.0F, alpha, true);
            case POSITIVE_Y -> fogQuadYWithCameraClearance(out, pose, shell.maxY() - 0.045D,
                    x - radius, x + radius, z - radius, z + radius, camera, time, 0.0F, alpha, false);
            case NEGATIVE_Z -> fogQuadZWithCameraClearance(out, pose, shell.minZ() + 0.045D,
                    x - radius, x + radius, y - radius, y + radius, camera, time, 0.0F, alpha, true);
            case POSITIVE_Z -> fogQuadZWithCameraClearance(out, pose, shell.maxZ() - 0.045D,
                    x - radius, x + radius, y - radius, y + radius, camera, time, 0.0F, alpha, false);
        }
    }

    /** Draw an X plane with a true one-block spherical camera hole carved out of it. */
    private static void fogQuadXWithCameraClearance(
            VertexConsumer out, PoseStack.Pose pose, double x,
            double minY, double maxY, double minZ, double maxZ,
            Vec3 camera, float time, float depth, float alpha, boolean flip) {
        double normal = Math.abs(camera.x - x);
        if (normal > MAX_BOUNDARY_RENDER_DISTANCE) return;
        double renderRadius = Math.sqrt(MAX_BOUNDARY_RENDER_DISTANCE * MAX_BOUNDARY_RENDER_DISTANCE - normal * normal);
        minY = Math.max(minY, camera.y - renderRadius);
        maxY = Math.min(maxY, camera.y + renderRadius);
        minZ = Math.max(minZ, camera.z - renderRadius);
        maxZ = Math.min(maxZ, camera.z + renderRadius);
        if (maxY <= minY || maxZ <= minZ) return;
        if (normal >= CAMERA_CLEAR_RADIUS) {
            fogQuadX(out, pose, x, minY, maxY, minZ, maxZ, time, depth, alpha, flip);
            return;
        }
        double radius = Math.sqrt(CAMERA_CLEAR_RADIUS * CAMERA_CLEAR_RADIUS - normal * normal);
        double hMinY = clamp(camera.y - radius, minY, maxY);
        double hMaxY = clamp(camera.y + radius, minY, maxY);
        double hMinZ = clamp(camera.z - radius, minZ, maxZ);
        double hMaxZ = clamp(camera.z + radius, minZ, maxZ);
        if (hMinY <= minY && hMaxY >= maxY && hMinZ <= minZ && hMaxZ >= maxZ) return;
        if (hMinY > minY) fogQuadX(out, pose, x, minY, hMinY, minZ, maxZ, time, depth, alpha, flip);
        if (hMaxY < maxY) fogQuadX(out, pose, x, hMaxY, maxY, minZ, maxZ, time, depth, alpha, flip);
        if (hMaxY > hMinY) {
            if (hMinZ > minZ) fogQuadX(out, pose, x, hMinY, hMaxY, minZ, hMinZ, time, depth, alpha, flip);
            if (hMaxZ < maxZ) fogQuadX(out, pose, x, hMinY, hMaxY, hMaxZ, maxZ, time, depth, alpha, flip);
        }
    }

    /** Draw a Y plane with a true one-block spherical camera hole carved out of it. */
    private static void fogQuadYWithCameraClearance(
            VertexConsumer out, PoseStack.Pose pose, double y,
            double minX, double maxX, double minZ, double maxZ,
            Vec3 camera, float time, float depth, float alpha, boolean flip) {
        double normal = Math.abs(camera.y - y);
        if (normal > MAX_BOUNDARY_RENDER_DISTANCE) return;
        double renderRadius = Math.sqrt(MAX_BOUNDARY_RENDER_DISTANCE * MAX_BOUNDARY_RENDER_DISTANCE - normal * normal);
        minX = Math.max(minX, camera.x - renderRadius);
        maxX = Math.min(maxX, camera.x + renderRadius);
        minZ = Math.max(minZ, camera.z - renderRadius);
        maxZ = Math.min(maxZ, camera.z + renderRadius);
        if (maxX <= minX || maxZ <= minZ) return;
        if (normal >= CAMERA_CLEAR_RADIUS) {
            fogQuadY(out, pose, y, minX, maxX, minZ, maxZ, time, depth, alpha, flip);
            return;
        }
        double radius = Math.sqrt(CAMERA_CLEAR_RADIUS * CAMERA_CLEAR_RADIUS - normal * normal);
        double hMinX = clamp(camera.x - radius, minX, maxX);
        double hMaxX = clamp(camera.x + radius, minX, maxX);
        double hMinZ = clamp(camera.z - radius, minZ, maxZ);
        double hMaxZ = clamp(camera.z + radius, minZ, maxZ);
        if (hMinX <= minX && hMaxX >= maxX && hMinZ <= minZ && hMaxZ >= maxZ) return;
        if (hMinX > minX) fogQuadY(out, pose, y, minX, hMinX, minZ, maxZ, time, depth, alpha, flip);
        if (hMaxX < maxX) fogQuadY(out, pose, y, hMaxX, maxX, minZ, maxZ, time, depth, alpha, flip);
        if (hMaxX > hMinX) {
            if (hMinZ > minZ) fogQuadY(out, pose, y, hMinX, hMaxX, minZ, hMinZ, time, depth, alpha, flip);
            if (hMaxZ < maxZ) fogQuadY(out, pose, y, hMinX, hMaxX, hMaxZ, maxZ, time, depth, alpha, flip);
        }
    }

    /** Draw a Z plane with a true one-block spherical camera hole carved out of it. */
    private static void fogQuadZWithCameraClearance(
            VertexConsumer out, PoseStack.Pose pose, double z,
            double minX, double maxX, double minY, double maxY,
            Vec3 camera, float time, float depth, float alpha, boolean flip) {
        double normal = Math.abs(camera.z - z);
        if (normal > MAX_BOUNDARY_RENDER_DISTANCE) return;
        double renderRadius = Math.sqrt(MAX_BOUNDARY_RENDER_DISTANCE * MAX_BOUNDARY_RENDER_DISTANCE - normal * normal);
        minX = Math.max(minX, camera.x - renderRadius);
        maxX = Math.min(maxX, camera.x + renderRadius);
        minY = Math.max(minY, camera.y - renderRadius);
        maxY = Math.min(maxY, camera.y + renderRadius);
        if (maxX <= minX || maxY <= minY) return;
        if (normal >= CAMERA_CLEAR_RADIUS) {
            fogQuadZ(out, pose, z, minX, maxX, minY, maxY, time, depth, alpha, flip);
            return;
        }
        double radius = Math.sqrt(CAMERA_CLEAR_RADIUS * CAMERA_CLEAR_RADIUS - normal * normal);
        double hMinX = clamp(camera.x - radius, minX, maxX);
        double hMaxX = clamp(camera.x + radius, minX, maxX);
        double hMinY = clamp(camera.y - radius, minY, maxY);
        double hMaxY = clamp(camera.y + radius, minY, maxY);
        if (hMinX <= minX && hMaxX >= maxX && hMinY <= minY && hMaxY >= maxY) return;
        if (hMinX > minX) fogQuadZ(out, pose, z, minX, hMinX, minY, maxY, time, depth, alpha, flip);
        if (hMaxX < maxX) fogQuadZ(out, pose, z, hMaxX, maxX, minY, maxY, time, depth, alpha, flip);
        if (hMaxX > hMinX) {
            if (hMinY > minY) fogQuadZ(out, pose, z, hMinX, hMaxX, minY, hMinY, time, depth, alpha, flip);
            if (hMaxY < maxY) fogQuadZ(out, pose, z, hMinX, hMaxX, hMaxY, maxY, time, depth, alpha, flip);
        }
    }

    /**
     * Fog sampling coordinates are absolute world tangential coordinates. The geometry itself is
     * still translated by -camera for rendering, but the procedural field no longer reads the
     * camera-relative Position attribute. Walking therefore cannot drag the fog pattern around.
     */
    private static void fogQuadX(VertexConsumer out, PoseStack.Pose pose, double x,
            double minY, double maxY, double minZ, double maxZ,
            float time, float depth, float alpha, boolean flip) {
        if (maxY <= minY || maxZ <= minZ) return;
        float faceSeed = 0.0F;
        if (flip) {
            fogVertex(out, pose, x, minY, minZ, minY, minZ, time, depth, faceSeed, alpha);
            fogVertex(out, pose, x, minY, maxZ, minY, maxZ, time, depth, faceSeed, alpha);
            fogVertex(out, pose, x, maxY, maxZ, maxY, maxZ, time, depth, faceSeed, alpha);
            fogVertex(out, pose, x, maxY, minZ, maxY, minZ, time, depth, faceSeed, alpha);
        } else {
            fogVertex(out, pose, x, minY, maxZ, minY, maxZ, time, depth, faceSeed, alpha);
            fogVertex(out, pose, x, minY, minZ, minY, minZ, time, depth, faceSeed, alpha);
            fogVertex(out, pose, x, maxY, minZ, maxY, minZ, time, depth, faceSeed, alpha);
            fogVertex(out, pose, x, maxY, maxZ, maxY, maxZ, time, depth, faceSeed, alpha);
        }
    }

    private static void fogQuadY(VertexConsumer out, PoseStack.Pose pose, double y,
            double minX, double maxX, double minZ, double maxZ,
            float time, float depth, float alpha, boolean flip) {
        if (maxX <= minX || maxZ <= minZ) return;
        float faceSeed = 0.5F;
        if (flip) {
            fogVertex(out, pose, minX, y, maxZ, minX, maxZ, time, depth, faceSeed, alpha);
            fogVertex(out, pose, maxX, y, maxZ, maxX, maxZ, time, depth, faceSeed, alpha);
            fogVertex(out, pose, maxX, y, minZ, maxX, minZ, time, depth, faceSeed, alpha);
            fogVertex(out, pose, minX, y, minZ, minX, minZ, time, depth, faceSeed, alpha);
        } else {
            fogVertex(out, pose, minX, y, minZ, minX, minZ, time, depth, faceSeed, alpha);
            fogVertex(out, pose, maxX, y, minZ, maxX, minZ, time, depth, faceSeed, alpha);
            fogVertex(out, pose, maxX, y, maxZ, maxX, maxZ, time, depth, faceSeed, alpha);
            fogVertex(out, pose, minX, y, maxZ, minX, maxZ, time, depth, faceSeed, alpha);
        }
    }

    private static void fogQuadZ(VertexConsumer out, PoseStack.Pose pose, double z,
            double minX, double maxX, double minY, double maxY,
            float time, float depth, float alpha, boolean flip) {
        if (maxX <= minX || maxY <= minY) return;
        float faceSeed = 1.0F;
        if (flip) {
            fogVertex(out, pose, maxX, minY, z, maxX, minY, time, depth, faceSeed, alpha);
            fogVertex(out, pose, minX, minY, z, minX, minY, time, depth, faceSeed, alpha);
            fogVertex(out, pose, minX, maxY, z, minX, maxY, time, depth, faceSeed, alpha);
            fogVertex(out, pose, maxX, maxY, z, maxX, maxY, time, depth, faceSeed, alpha);
        } else {
            fogVertex(out, pose, minX, minY, z, minX, minY, time, depth, faceSeed, alpha);
            fogVertex(out, pose, maxX, minY, z, maxX, minY, time, depth, faceSeed, alpha);
            fogVertex(out, pose, maxX, maxY, z, maxX, maxY, time, depth, faceSeed, alpha);
            fogVertex(out, pose, minX, maxY, z, minX, maxY, time, depth, faceSeed, alpha);
        }
    }

    private static void fogVertex(VertexConsumer out, PoseStack.Pose pose,
            double x, double y, double z, double fieldU, double fieldV, float time,
            float depth, float faceSeed, float alpha) {
        // Time-only advection keeps the bank world-locked but alive. Near/deep slices intentionally
        // shear at different rates, and two slow world-space eddies fold that shear back across the
        // wall instead of producing one rigid scrolling sheet.
        float shear = 0.70F + depth * 0.82F;
        float u = (float) (fieldU + time * (0.72F + 0.30F * depth));
        float v = (float) (fieldV - time * (0.35F + 0.23F * depth));
        float eddyStrength = 0.16F + depth * 0.18F;
        u += (float) Math.sin(fieldV * 0.085D + time * 0.47F + faceSeed * 4.7F) * eddyStrength;
        v += (float) Math.cos(fieldU * 0.079D - time * 0.39F - faceSeed * 3.9F) * eddyStrength;

        // Gravity: on vertical X faces world-Y is U; on vertical Z faces world-Y is V. Horizontal
        // Y faces intentionally receive no vertical sinking component.
        float gravity = time * (0.41F + depth * 0.61F) * shear;
        if (faceSeed < 0.25F) u += gravity;
        else if (faceSeed > 0.75F) v += gravity;

        out.addVertex(pose, (float) x, (float) y, (float) z)
                .setUv(u, v)
                .setColor(depth, faceSeed, 1.0F, alpha);
    }

    private static void visibleQuadX(VertexConsumer out, PoseStack.Pose pose, double x,
            double minY, double maxY, double minZ, double maxZ, Vec3 camera, int color, boolean flip) {
        double normal = Math.abs(camera.x - x);
        if (normal > MAX_BOUNDARY_RENDER_DISTANCE) return;
        double r = Math.sqrt(MAX_BOUNDARY_RENDER_DISTANCE * MAX_BOUNDARY_RENDER_DISTANCE - normal * normal);
        quadX(out, pose, x,
                Math.max(minY, camera.y - r), Math.min(maxY, camera.y + r),
                Math.max(minZ, camera.z - r), Math.min(maxZ, camera.z + r),
                0.0F, 0.0F, color, flip);
    }

    private static void visibleQuadY(VertexConsumer out, PoseStack.Pose pose, double y,
            double minX, double maxX, double minZ, double maxZ, Vec3 camera, int color, boolean flip) {
        double normal = Math.abs(camera.y - y);
        if (normal > MAX_BOUNDARY_RENDER_DISTANCE) return;
        double r = Math.sqrt(MAX_BOUNDARY_RENDER_DISTANCE * MAX_BOUNDARY_RENDER_DISTANCE - normal * normal);
        quadY(out, pose, y,
                Math.max(minX, camera.x - r), Math.min(maxX, camera.x + r),
                Math.max(minZ, camera.z - r), Math.min(maxZ, camera.z + r),
                0.0F, 0.0F, color, flip);
    }

    private static void visibleQuadZ(VertexConsumer out, PoseStack.Pose pose, double z,
            double minX, double maxX, double minY, double maxY, Vec3 camera, int color, boolean flip) {
        double normal = Math.abs(camera.z - z);
        if (normal > MAX_BOUNDARY_RENDER_DISTANCE) return;
        double r = Math.sqrt(MAX_BOUNDARY_RENDER_DISTANCE * MAX_BOUNDARY_RENDER_DISTANCE - normal * normal);
        quadZ(out, pose, z,
                Math.max(minX, camera.x - r), Math.min(maxX, camera.x + r),
                Math.max(minY, camera.y - r), Math.min(maxY, camera.y + r),
                0.0F, 0.0F, color, flip);
    }

    private static void quadX(VertexConsumer out, PoseStack.Pose pose, double x, double minY, double maxY, double minZ, double maxZ, float u, float v, int color, boolean flip) {
        if (maxY <= minY || maxZ <= minZ) return;
        if (flip) {
            vertex(out, pose, x, minY, minZ, u, v, color); vertex(out, pose, x, minY, maxZ, u, v, color);
            vertex(out, pose, x, maxY, maxZ, u, v, color); vertex(out, pose, x, maxY, minZ, u, v, color);
        } else {
            vertex(out, pose, x, minY, maxZ, u, v, color); vertex(out, pose, x, minY, minZ, u, v, color);
            vertex(out, pose, x, maxY, minZ, u, v, color); vertex(out, pose, x, maxY, maxZ, u, v, color);
        }
    }

    private static void quadY(VertexConsumer out, PoseStack.Pose pose, double y, double minX, double maxX, double minZ, double maxZ, float u, float v, int color, boolean flip) {
        if (maxX <= minX || maxZ <= minZ) return;
        if (flip) {
            vertex(out, pose, minX, y, maxZ, u, v, color); vertex(out, pose, maxX, y, maxZ, u, v, color);
            vertex(out, pose, maxX, y, minZ, u, v, color); vertex(out, pose, minX, y, minZ, u, v, color);
        } else {
            vertex(out, pose, minX, y, minZ, u, v, color); vertex(out, pose, maxX, y, minZ, u, v, color);
            vertex(out, pose, maxX, y, maxZ, u, v, color); vertex(out, pose, minX, y, maxZ, u, v, color);
        }
    }

    private static void quadZ(VertexConsumer out, PoseStack.Pose pose, double z, double minX, double maxX, double minY, double maxY, float u, float v, int color, boolean flip) {
        if (maxX <= minX || maxY <= minY) return;
        if (flip) {
            vertex(out, pose, maxX, minY, z, u, v, color); vertex(out, pose, minX, minY, z, u, v, color);
            vertex(out, pose, minX, maxY, z, u, v, color); vertex(out, pose, maxX, maxY, z, u, v, color);
        } else {
            vertex(out, pose, minX, minY, z, u, v, color); vertex(out, pose, maxX, minY, z, u, v, color);
            vertex(out, pose, maxX, maxY, z, u, v, color); vertex(out, pose, minX, maxY, z, u, v, color);
        }
    }

    private static void vertex(VertexConsumer out, PoseStack.Pose pose, double x, double y, double z, float u, float v, int color) {
        out.addVertex(pose, (float) x, (float) y, (float) z).setUv(u, v).setColor(color);
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private static int rgba(float r, float g, float b, float a) {
        int ai = Math.round(clamp01(a) * 255.0F);
        int ri = Math.round(clamp01(r) * 255.0F);
        int gi = Math.round(clamp01(g) * 255.0F);
        int bi = Math.round(clamp01(b) * 255.0F);
        return (ai << 24) | (ri << 16) | (gi << 8) | bi;
    }

    private static float clamp01(float value) { return Math.max(0.0F, Math.min(1.0F, value)); }
}
