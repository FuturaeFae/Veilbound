#version 330

in vec2 fogFieldPos;
in vec4 fogControl;
out vec4 fragColor;

float hash13(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
}

float noise3(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float n000 = hash13(i + vec3(0,0,0));
    float n100 = hash13(i + vec3(1,0,0));
    float n010 = hash13(i + vec3(0,1,0));
    float n110 = hash13(i + vec3(1,1,0));
    float n001 = hash13(i + vec3(0,0,1));
    float n101 = hash13(i + vec3(1,0,1));
    float n011 = hash13(i + vec3(0,1,1));
    float n111 = hash13(i + vec3(1,1,1));
    float nx00 = mix(n000, n100, f.x);
    float nx10 = mix(n010, n110, f.x);
    float nx01 = mix(n001, n101, f.x);
    float nx11 = mix(n011, n111, f.x);
    return mix(mix(nx00, nx10, f.y), mix(nx01, nx11, f.y), f.z);
}

float fbm(vec3 p) {
    float sum = 0.0;
    float amp = 0.54;
    for (int i = 0; i < 4; ++i) {
        sum += noise3(p) * amp;
        p = p * 2.03 + vec3(7.13, -4.91, 9.77);
        amp *= 0.49;
    }
    return sum;
}

void main() {
    // Color channels are control data authored per world-space fog plane:
    // R = volume depth, G = face-axis seed (X/Y/Z), A = optical density.
    float depth01 = clamp(fogControl.r, 0.0, 1.0);
    float faceSeed = fogControl.g;

    // This field is built from absolute world coordinates plus time-only advection. It contains
    // no camera/player position, so walking cannot translate the procedural pattern.
    vec2 field = fogFieldPos * 0.28;

    // Domain-warp the field before density sampling. Because fogFieldPos contains world-space
    // coordinates plus time-only advection from the CPU, this produces slow folding/churning
    // without ever becoming camera-relative.
    float warpA = fbm(vec3(field * 0.46 + vec2(3.2, -1.7), depth01 * 2.2 + faceSeed * 7.0));
    float warpB = fbm(vec3(field.yx * 0.53 + vec2(-5.4, 2.6), depth01 * 2.7 + faceSeed * 11.0));
    vec2 warp = vec2(warpA - 0.5, warpB - 0.5);

    // Fold the existing warp channels through a local rotation and a counter-moving eddy. This
    // creates substantially stronger visible churning without adding another expensive FBM stack.
    float spin = (warpA - warpB) * 3.8 + faceSeed * 1.7;
    float cs = cos(spin);
    float sn = sin(spin);
    vec2 spunWarp = mat2(cs, -sn, sn, cs) * warp;
    vec2 eddy = vec2(
            sin(field.y * 1.31 + warpA * 5.2 + depth01 * 2.4),
            cos(field.x * 1.23 - warpB * 4.8 - depth01 * 2.0));
    field += spunWarp * (0.54 + depth01 * 0.70);
    field += eddy * (0.12 + depth01 * 0.17);

    vec3 p = vec3(field, depth01 * 2.75 + faceSeed * 9.0);
    float broad = fbm(p);
    float billow = fbm(vec3(field * 1.73 + vec2(6.9, -4.7),
            depth01 * 4.1 + faceSeed * 13.0));
    float curl = fbm(vec3(field * 3.10 + vec2(-8.2, 5.4),
            depth01 * 7.3 + faceSeed * 19.0));
    float smoke = broad * 0.54 + billow * 0.32 + curl * 0.14;
    smoke = smoothstep(0.24, 0.77, smoke);

    // High-frequency world-anchored detail breaks up the sixteen physical slice planes without
    // adding geometry. Adjacent slices get distinct but coherent detail fields.
    vec3 detailCoord = vec3(fogFieldPos * 1.92,
            depth01 * 17.29 + faceSeed * 23.0);
    float detailNoise = noise3(detailCoord);
    float detailSigned = detailNoise - 0.5;

    float denseCore = 1.0 - smoothstep(0.30, 0.48, depth01);
    float sourcePresence = pow(max(0.0, 1.0 - depth01), 1.45);
    float tail = 1.0 - smoothstep(0.30, 1.0, depth01);
    float shape = mix(0.20 + smoke * 0.80, 0.58 + smoke * 0.42, sourcePresence);
    shape = max(shape, denseCore * (0.82 + smoke * 0.18));

    // Farther from the source wall the fog not only gets fainter, it breaks apart. This creates
    // dissipating streamers instead of a uniformly transparent final slice.
    float dissolve = smoothstep(0.20 + depth01 * 0.22, 0.76, smoke + sourcePresence * 0.18);
    shape *= mix(0.20 + dissolve * 0.80, 1.0, sourcePresence);

    float detailStrength = mix(0.055, 0.14, 1.0 - denseCore);
    shape = clamp(shape * (1.0 + detailSigned * detailStrength)
            + detailSigned * detailStrength * 0.22, 0.0, 1.15);

    // Sixteen slices are optically compensated to preserve the density of the older 32-slice pass.
    float sourceAlpha = clamp(fogControl.a * shape, 0.012, 0.19);
    float alpha = 1.0 - (1.0 - sourceAlpha) * (1.0 - sourceAlpha);

    // Neutral charcoal/ash fog only. No violet, blue or colored wall glow.
    float grey = 0.075 + smoke * 0.105 + denseCore * 0.025;
    grey += detailSigned * 0.010 * (1.0 - denseCore * 0.65);
    fragColor = vec4(vec3(grey), alpha);
}
