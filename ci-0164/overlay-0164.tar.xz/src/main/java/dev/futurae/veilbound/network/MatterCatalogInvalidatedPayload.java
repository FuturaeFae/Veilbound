package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Clears lazy Matter tooltip caches after server Matter data changes. */
public record MatterCatalogInvalidatedPayload() implements CustomPacketPayload {
    public static final MatterCatalogInvalidatedPayload INSTANCE = new MatterCatalogInvalidatedPayload();
    public static final Type<MatterCatalogInvalidatedPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "matter_catalog_invalidated"));
    public static final StreamCodec<RegistryFriendlyByteBuf, MatterCatalogInvalidatedPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override public MatterCatalogInvalidatedPayload decode(RegistryFriendlyByteBuf b) { return INSTANCE; }
        @Override public void encode(RegistryFriendlyByteBuf b, MatterCatalogInvalidatedPayload p) { }
    };
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
