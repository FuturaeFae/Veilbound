package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Server-authoritative Spatial Generator screen state, valid both inside and outside Domains. */
public record SpatialGeneratorSnapshotPayload(
        boolean allowed, String reason, boolean domainAvailable, boolean inOwnDomain, boolean coreActive,
        int sizeX, int sizeY, int sizeZ, int storedForgeEnergy, int forgeEnergyCapacity, long chargeMilli,
        long chargePerNewBlock, long awakeningCharge, long feedMatterValue, int feedCount, boolean hasCatalyst,
        boolean atOriginRange, boolean originClear) implements CustomPacketPayload {
    public static final Type<SpatialGeneratorSnapshotPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "spatial_generator_snapshot"));
    public static final StreamCodec<RegistryFriendlyByteBuf, SpatialGeneratorSnapshotPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override public SpatialGeneratorSnapshotPayload decode(RegistryFriendlyByteBuf b) {
            return new SpatialGeneratorSnapshotPayload(
                    b.readBoolean(), b.readUtf(96), b.readBoolean(), b.readBoolean(), b.readBoolean(),
                    b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarLong(),
                    b.readVarLong(), b.readVarLong(), b.readVarLong(), b.readVarInt(), b.readBoolean(), b.readBoolean(), b.readBoolean());
        }
        @Override public void encode(RegistryFriendlyByteBuf b, SpatialGeneratorSnapshotPayload p) {
            b.writeBoolean(p.allowed()); b.writeUtf(p.reason(), 96);
            b.writeBoolean(p.domainAvailable()); b.writeBoolean(p.inOwnDomain()); b.writeBoolean(p.coreActive());
            b.writeVarInt(p.sizeX()); b.writeVarInt(p.sizeY()); b.writeVarInt(p.sizeZ());
            b.writeVarInt(p.storedForgeEnergy()); b.writeVarInt(p.forgeEnergyCapacity()); b.writeVarLong(p.chargeMilli());
            b.writeVarLong(p.chargePerNewBlock()); b.writeVarLong(p.awakeningCharge());
            b.writeVarLong(p.feedMatterValue()); b.writeVarInt(p.feedCount());
            b.writeBoolean(p.hasCatalyst()); b.writeBoolean(p.atOriginRange()); b.writeBoolean(p.originClear());
        }
    };
    public SpatialGeneratorSnapshotPayload {
        reason = reason == null ? "unknown" : reason;
        feedMatterValue = Math.max(0L, feedMatterValue);
        feedCount = Math.max(0, feedCount);
    }
    public long chargeWhole() { return chargeMilli / 1000L; }
    public int chargeFractionMilli() { return (int) (chargeMilli % 1000L); }
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
