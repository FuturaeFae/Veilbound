package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** One resolved Matter value; zero means deliberately or currently unvalued. */
public record MatterValueSnapshotPayload(String itemId, long matter) implements CustomPacketPayload {
    public static final Type<MatterValueSnapshotPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "matter_value_snapshot"));
    public static final StreamCodec<RegistryFriendlyByteBuf, MatterValueSnapshotPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override public MatterValueSnapshotPayload decode(RegistryFriendlyByteBuf b) {
            return new MatterValueSnapshotPayload(b.readUtf(256), b.readVarLong());
        }
        @Override public void encode(RegistryFriendlyByteBuf b, MatterValueSnapshotPayload p) {
            b.writeUtf(p.itemId(), 256);
            b.writeVarLong(Math.max(0L, p.matter()));
        }
    };
    public MatterValueSnapshotPayload {
        if (itemId == null || itemId.isBlank()) itemId = "minecraft:air";
        matter = Math.max(0L, matter);
    }
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
