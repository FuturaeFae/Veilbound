package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Lazy client query for one server-authoritative Matter value. */
public record MatterValueRequestPayload(String itemId) implements CustomPacketPayload {
    public static final Type<MatterValueRequestPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "matter_value_request"));
    public static final StreamCodec<RegistryFriendlyByteBuf, MatterValueRequestPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override public MatterValueRequestPayload decode(RegistryFriendlyByteBuf b) {
            return new MatterValueRequestPayload(b.readUtf(256));
        }
        @Override public void encode(RegistryFriendlyByteBuf b, MatterValueRequestPayload p) {
            b.writeUtf(p.itemId(), 256);
        }
    };
    public MatterValueRequestPayload {
        if (itemId == null || itemId.isBlank()) itemId = "minecraft:air";
    }
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
