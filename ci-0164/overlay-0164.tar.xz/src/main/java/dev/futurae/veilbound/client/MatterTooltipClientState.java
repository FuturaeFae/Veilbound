package dev.futurae.veilbound.client;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.OptionalLong;
import java.util.Set;

/** Small lazy cache for server-authoritative per-item Matter tooltip values. */
public final class MatterTooltipClientState {
    private static final Map<String, Long> VALUES = new HashMap<>();
    private static final Set<String> PENDING = new HashSet<>();

    private MatterTooltipClientState() {}

    public static OptionalLong lookup(String itemId) {
        Long value = VALUES.get(itemId);
        return value == null ? OptionalLong.empty() : OptionalLong.of(value);
    }

    /** Returns true only for the first unresolved request until a response/invalidation arrives. */
    public static boolean beginRequest(String itemId) {
        return !VALUES.containsKey(itemId) && PENDING.add(itemId);
    }

    public static void accept(String itemId, long matter) {
        VALUES.put(itemId, Math.max(0L, matter));
        PENDING.remove(itemId);
    }

    public static void clear() {
        VALUES.clear();
        PENDING.clear();
    }
}
