package dev.futurae.veilbound.network;

import dev.futurae.veilbound.boundary.VeilBoundaryCollisionState;
import dev.futurae.veilbound.domain.DomainBounds;
import java.util.List;
import net.minecraft.world.phys.AABB;

/** Regression for the 0.1.38 axis-order bug that turned the 1x1x2 pocket into a 2x1x1 cage. */
public final class VeilBoundarySnapshotPayloadSelfTest {
    public static void main(String[] args) {
        DomainBounds starter = DomainBounds.initial();
        VeilBoundarySnapshotPayload starterPayload = payload(starter);
        eq(starter, starterPayload.bounds(), "starter snapshot must preserve X/Y/Z bound order");
        eq(1, starterPayload.bounds().sizeX(), "starter X size");
        eq(2, starterPayload.bounds().sizeY(), "starter Y size");
        eq(1, starterPayload.bounds().sizeZ(), "starter Z size");

        DomainBounds asymmetric = new DomainBounds(-7, -3, -11, 12, 19, 5);
        eq(asymmetric, payload(asymmetric).bounds(), "asymmetric bounds must round-trip without axis permutation");

        // The canonical starter player stands at x/z=.5 with feet at y=0. No Veil wall may
        // intersect that standing box; the ceiling begins at y=2 and side walls begin at x/z=0/1.
        AABB standingPlayer = new AABB(0.2D, 0.0D, 0.2D, 0.8D, 1.8D, 0.8D);
        for (AABB wall : VeilBoundaryCollisionState.wallBoxes(starterPayload.bounds())) {
            truth(!wall.intersects(standingPlayer), "starter player must not spawn embedded in wall " + wall);
        }

        List<AABB> walls = VeilBoundaryCollisionState.wallBoxes(starterPayload.bounds());
        eq(2.0D, walls.get(3).minY, "starter positive-Y wall begins above the two-block pocket");
        eq(1.0D, walls.get(1).minX, "starter positive-X wall begins outside usable X cell");
        eq(1.0D, walls.get(5).minZ, "starter positive-Z wall begins outside usable Z cell");
        System.out.println("VeilBoundarySnapshotPayloadSelfTest: PASS");
    }

    private static VeilBoundarySnapshotPayload payload(DomainBounds b) {
        return new VeilBoundarySnapshotPayload(
                "veilbound:domain/test",
                b.minX(), b.maxX(), b.minY(), b.maxY(), b.minZ(), b.maxZ(),
                0.0D, List.of());
    }

    private static void truth(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    private static void eq(Object expected, Object actual, String message) {
        if (!expected.equals(actual)) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }

    private static void eq(int expected, int actual, String message) {
        if (expected != actual) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }

    private static void eq(double expected, double actual, String message) {
        if (Double.compare(expected, actual) != 0) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }
}
