package dev.futurae.veilbound.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.boundary.VeilBoundaryCollisionState;
import dev.futurae.veilbound.boundary.VeilBoundaryCollisionState.BreachOpening;
import dev.futurae.veilbound.boundary.VeilBoundaryCollisionState.Snapshot;
import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.DomainBounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.resources.Identifier;
import net.minecraft.util.context.ContextKey;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.ExtractLevelRenderStateEvent;
import net.neoforged.neoforge.client.event.SubmitCustomGeometryEvent;

/**
 * Renders the six physical collision faces as the visible Veil membrane.
 *
 * <p>0.1.39 deliberately uses two layers. A vanilla End-Portal shader layer is the dependable
 * GPU/driver-safe foundation, while Veilbound's custom translucent pipeline adds its animated
 * purple/cyan fracture field. If a resource pack or driver rejects the custom program, the player
 * still sees the boundary instead of an invisible wall.
 *
 * <p>Boundary state is copied into {@link net.minecraft.client.renderer.state.level.LevelRenderState}
 * during NeoForge's extraction phase, matching the 26.2 render-state architecture. Geometry is then
 * submitted camera-relative during {@link SubmitCustomGeometryEvent}.
 */
public final class VeilBoundaryRenderer {
    private static final ContextKey<Snapshot> RENDER_STATE_KEY = new ContextKey<>(
            Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "veil_boundary_render_state"));
    private static final double SURFACE_EPSILON = 0.003D;
    private static final double FALLBACK_EPSILON = 0.010D;

    private VeilBoundaryRenderer() {}

    /** Freeze the synchronized boundary snapshot into the current frame's render state. */
    public static void onExtractLevelRenderState(ExtractLevelRenderStateEvent event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) return;
        Snapshot snapshot = VeilBoundaryCollisionState.clientSnapshot(
                minecraft.level.dimension().identifier().toString());
        if (snapshot != null) event.getRenderState().setRenderData(RENDER_STATE_KEY, snapshot);
    }

    public static void onSubmitCustomGeometry(SubmitCustomGeometryEvent event) {
        Snapshot snapshot = event.getLevelRenderState().getRenderData(RENDER_STATE_KEY);
        if (snapshot == null) return;

        PoseStack poseStack = event.getPoseStack();
        Vec3 camera = event.getLevelRenderState().cameraRenderState.pos;
        DomainBounds b = snapshot.bounds();
        double phase = (System.nanoTime() % 60_000_000_000L) / 1_000_000_000.0D;
        float fracture = (float) Math.min(1.0D, snapshot.fractureMeter() / 200.0D);
        int baseColor = rgba(fracture, 0.62F, 1.0F, 0.38F + fracture * 0.14F);

        // SubmitCustomGeometryEvent's pose stack is not pre-translated to world coordinates.
        // NeoForge's own 26.2 debug renderer subtracts the camera in exactly this way.
        poseStack.pushPose();
        poseStack.translate(-camera.x, -camera.y, -camera.z);
        var collector = event.getSubmitNodeCollector();

        // First layer: built-in shader fallback. Render both windings because the camera is normally
        // inside the shell and the vanilla End-Portal pipeline may cull one side.
        collector.submitCustomGeometry(poseStack, RenderTypes.endPortal(), (pose, out) ->
                renderShaderFallback(out, pose, b));

        // Second layer: Veilbound animated membrane. This remains translucent and no-cull.
        collector.submitCustomGeometry(poseStack, VeilBoundaryRenderPipeline.type(), (pose, out) -> {
            double minX = b.minX();
            double maxX = b.maxX() + 1.0D;
            double minY = b.minY();
            double maxY = b.maxY() + 1.0D;
            double minZ = b.minZ();
            double maxZ = b.maxZ() + 1.0D;
            float scroll = (float) (phase * 0.08D);

            // Slightly inset into usable space so this colored translucent layer wins depth against
            // the fallback foundation and remains visible over blocks built flush with a face.
            quadX(out, pose, minX + SURFACE_EPSILON, minY, maxY, minZ, maxZ, scroll, baseColor, false);
            quadX(out, pose, maxX - SURFACE_EPSILON, minY, maxY, minZ, maxZ, scroll, baseColor, true);
            quadY(out, pose, minY + SURFACE_EPSILON, minX, maxX, minZ, maxZ, scroll, baseColor, true);
            quadY(out, pose, maxY - SURFACE_EPSILON, minX, maxX, minZ, maxZ, scroll, baseColor, false);
            quadZ(out, pose, minZ + SURFACE_EPSILON, minX, maxX, minY, maxY, scroll, baseColor, true);
            quadZ(out, pose, maxZ - SURFACE_EPSILON, minX, maxX, minY, maxY, scroll, baseColor, false);

            for (BreachOpening breach : snapshot.openBreaches()) {
                renderBreachPulse(out, pose, breach, phase, fracture);
            }
        });
        poseStack.popPose();
    }

    private static void renderShaderFallback(VertexConsumer out, PoseStack.Pose pose, DomainBounds b) {
        double minX = b.minX();
        double maxX = b.maxX() + 1.0D;
        double minY = b.minY();
        double maxY = b.maxY() + 1.0D;
        double minZ = b.minZ();
        double maxZ = b.maxZ() + 1.0D;

        // Place the fallback a hair outside the physical plane. The custom translucent membrane is
        // drawn just inside, so it can tint this foundation when the custom shader is healthy.
        portalQuadX(out, pose, minX - FALLBACK_EPSILON, minY, maxY, minZ, maxZ, false);
        portalQuadX(out, pose, minX - FALLBACK_EPSILON, minY, maxY, minZ, maxZ, true);
        portalQuadX(out, pose, maxX + FALLBACK_EPSILON, minY, maxY, minZ, maxZ, false);
        portalQuadX(out, pose, maxX + FALLBACK_EPSILON, minY, maxY, minZ, maxZ, true);
        portalQuadY(out, pose, minY - FALLBACK_EPSILON, minX, maxX, minZ, maxZ, false);
        portalQuadY(out, pose, minY - FALLBACK_EPSILON, minX, maxX, minZ, maxZ, true);
        portalQuadY(out, pose, maxY + FALLBACK_EPSILON, minX, maxX, minZ, maxZ, false);
        portalQuadY(out, pose, maxY + FALLBACK_EPSILON, minX, maxX, minZ, maxZ, true);
        portalQuadZ(out, pose, minZ - FALLBACK_EPSILON, minX, maxX, minY, maxY, false);
        portalQuadZ(out, pose, minZ - FALLBACK_EPSILON, minX, maxX, minY, maxY, true);
        portalQuadZ(out, pose, maxZ + FALLBACK_EPSILON, minX, maxX, minY, maxY, false);
        portalQuadZ(out, pose, maxZ + FALLBACK_EPSILON, minX, maxX, minY, maxY, true);
    }

    private static void renderBreachPulse(VertexConsumer out, PoseStack.Pose pose, BreachOpening breach, double phase, float fracture) {
        double radius = switch (breach.severity()) {
            case MINOR -> 1.05D;
            case SEVERE -> 1.7D;
            case EXTREME -> 2.35D;
        };
        double x = breach.position().x() + 0.5D;
        double y = breach.position().y() + 0.5D;
        double z = breach.position().z() + 0.5D;
        float pulse = (float) (0.5D + 0.5D * Math.sin(phase * 4.0D));
        int color = rgba(Math.max(fracture, 0.82F), 0.18F + pulse * 0.18F, 0.9F, 0.62F);
        float uv = (float) phase * 0.35F;
        switch (breach.face()) {
            case NEGATIVE_X, POSITIVE_X -> quadX(out, pose, x, y - radius, y + radius, z - radius, z + radius, uv, color, breach.face() == AxisDirection.POSITIVE_X);
            case NEGATIVE_Y, POSITIVE_Y -> quadY(out, pose, y, x - radius, x + radius, z - radius, z + radius, uv, color, breach.face() == AxisDirection.NEGATIVE_Y);
            case NEGATIVE_Z, POSITIVE_Z -> quadZ(out, pose, z, x - radius, x + radius, y - radius, y + radius, uv, color, breach.face() == AxisDirection.NEGATIVE_Z);
        }
    }

    private static void portalQuadX(VertexConsumer out, PoseStack.Pose pose, double x, double minY, double maxY, double minZ, double maxZ, boolean flip) {
        if (flip) {
            portalVertex(out, pose, x, minY, minZ); portalVertex(out, pose, x, minY, maxZ);
            portalVertex(out, pose, x, maxY, maxZ); portalVertex(out, pose, x, maxY, minZ);
        } else {
            portalVertex(out, pose, x, minY, maxZ); portalVertex(out, pose, x, minY, minZ);
            portalVertex(out, pose, x, maxY, minZ); portalVertex(out, pose, x, maxY, maxZ);
        }
    }

    private static void portalQuadY(VertexConsumer out, PoseStack.Pose pose, double y, double minX, double maxX, double minZ, double maxZ, boolean flip) {
        if (flip) {
            portalVertex(out, pose, minX, y, maxZ); portalVertex(out, pose, maxX, y, maxZ);
            portalVertex(out, pose, maxX, y, minZ); portalVertex(out, pose, minX, y, minZ);
        } else {
            portalVertex(out, pose, minX, y, minZ); portalVertex(out, pose, maxX, y, minZ);
            portalVertex(out, pose, maxX, y, maxZ); portalVertex(out, pose, minX, y, maxZ);
        }
    }

    private static void portalQuadZ(VertexConsumer out, PoseStack.Pose pose, double z, double minX, double maxX, double minY, double maxY, boolean flip) {
        if (flip) {
            portalVertex(out, pose, maxX, minY, z); portalVertex(out, pose, minX, minY, z);
            portalVertex(out, pose, minX, maxY, z); portalVertex(out, pose, maxX, maxY, z);
        } else {
            portalVertex(out, pose, minX, minY, z); portalVertex(out, pose, maxX, minY, z);
            portalVertex(out, pose, maxX, maxY, z); portalVertex(out, pose, minX, maxY, z);
        }
    }

    private static void portalVertex(VertexConsumer out, PoseStack.Pose pose, double x, double y, double z) {
        out.addVertex(pose, (float) x, (float) y, (float) z);
    }

    private static void quadX(VertexConsumer out, PoseStack.Pose pose, double x, double minY, double maxY, double minZ, double maxZ, float scroll, int color, boolean flip) {
        float u0 = (float) minZ * 0.32F + scroll;
        float u1 = (float) maxZ * 0.32F + scroll;
        float v0 = (float) minY * 0.32F - scroll * 0.7F;
        float v1 = (float) maxY * 0.32F - scroll * 0.7F;
        if (flip) {
            vertex(out, pose, x, minY, minZ, u0, v0, color); vertex(out, pose, x, minY, maxZ, u1, v0, color);
            vertex(out, pose, x, maxY, maxZ, u1, v1, color); vertex(out, pose, x, maxY, minZ, u0, v1, color);
        } else {
            vertex(out, pose, x, minY, maxZ, u1, v0, color); vertex(out, pose, x, minY, minZ, u0, v0, color);
            vertex(out, pose, x, maxY, minZ, u0, v1, color); vertex(out, pose, x, maxY, maxZ, u1, v1, color);
        }
    }

    private static void quadY(VertexConsumer out, PoseStack.Pose pose, double y, double minX, double maxX, double minZ, double maxZ, float scroll, int color, boolean flip) {
        float u0 = (float) minX * 0.32F + scroll;
        float u1 = (float) maxX * 0.32F + scroll;
        float v0 = (float) minZ * 0.32F - scroll * 0.7F;
        float v1 = (float) maxZ * 0.32F - scroll * 0.7F;
        if (flip) {
            vertex(out, pose, minX, y, maxZ, u0, v1, color); vertex(out, pose, maxX, y, maxZ, u1, v1, color);
            vertex(out, pose, maxX, y, minZ, u1, v0, color); vertex(out, pose, minX, y, minZ, u0, v0, color);
        } else {
            vertex(out, pose, minX, y, minZ, u0, v0, color); vertex(out, pose, maxX, y, minZ, u1, v0, color);
            vertex(out, pose, maxX, y, maxZ, u1, v1, color); vertex(out, pose, minX, y, maxZ, u0, v1, color);
        }
    }

    private static void quadZ(VertexConsumer out, PoseStack.Pose pose, double z, double minX, double maxX, double minY, double maxY, float scroll, int color, boolean flip) {
        float u0 = (float) minX * 0.32F + scroll;
        float u1 = (float) maxX * 0.32F + scroll;
        float v0 = (float) minY * 0.32F - scroll * 0.7F;
        float v1 = (float) maxY * 0.32F - scroll * 0.7F;
        if (flip) {
            vertex(out, pose, maxX, minY, z, u1, v0, color); vertex(out, pose, minX, minY, z, u0, v0, color);
            vertex(out, pose, minX, maxY, z, u0, v1, color); vertex(out, pose, maxX, maxY, z, u1, v1, color);
        } else {
            vertex(out, pose, minX, minY, z, u0, v0, color); vertex(out, pose, maxX, minY, z, u1, v0, color);
            vertex(out, pose, maxX, maxY, z, u1, v1, color); vertex(out, pose, minX, maxY, z, u0, v1, color);
        }
    }

    private static void vertex(VertexConsumer out, PoseStack.Pose pose, double x, double y, double z, float u, float v, int color) {
        out.addVertex(pose, (float) x, (float) y, (float) z).setUv(u, v).setColor(color);
    }

    private static int rgba(float r, float g, float b, float a) {
        int ai = Math.round(clamp01(a) * 255.0F);
        int ri = Math.round(clamp01(r) * 255.0F);
        int gi = Math.round(clamp01(g) * 255.0F);
        int bi = Math.round(clamp01(b) * 255.0F);
        return (ai << 24) | (ri << 16) | (gi << 8) | bi;
    }

    private static float clamp01(float value) { return Math.max(0.0F, Math.min(1.0F, value)); }
}
