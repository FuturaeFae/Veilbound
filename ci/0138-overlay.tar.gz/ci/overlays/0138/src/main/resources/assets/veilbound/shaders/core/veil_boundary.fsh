#version 330

in vec2 veilUv;
in vec4 veilControl;
out vec4 fragColor;

float hash21(vec2 p) {
    p = fract(p * vec2(123.34, 345.45));
    p += dot(p, p + 34.345);
    return fract(p.x * p.y);
}

void main() {
    // UVs are advanced every frame by the renderer. The shader turns them into two moving depth
    // layers, so this reads as a membrane/refraction field rather than a scrolling flat texture.
    vec2 uv = veilUv;
    float fracture = clamp(veilControl.r, 0.0, 1.0);

    float slowWave = sin(uv.x * 5.7 + sin(uv.y * 2.1) * 1.6);
    float crossWave = sin(uv.y * 7.1 - cos(uv.x * 1.8) * 1.9);
    vec2 warped = uv + vec2(crossWave, slowWave) * (0.018 + fracture * 0.026);

    vec2 cell = abs(fract(warped) - 0.5);
    float lattice = 1.0 - smoothstep(0.43, 0.49, max(cell.x, cell.y));
    float filament = 0.5 + 0.5 * sin((warped.x + warped.y) * 14.0 + slowWave * 2.4);

    vec2 crackCell = floor(warped * 2.5);
    float crackNoise = hash21(crackCell);
    float crackBand = smoothstep(0.79 - fracture * 0.26, 0.96, crackNoise + filament * 0.16);

    vec3 deepViolet = vec3(0.075, 0.018, 0.15);
    vec3 veilPurple = vec3(0.39, 0.10, 0.72);
    vec3 veilCyan = vec3(0.10, 0.78, 1.00);
    vec3 fractureWhite = vec3(0.82, 0.94, 1.00);

    float depth = 0.38 + 0.24 * slowWave + 0.16 * crossWave;
    vec3 color = mix(deepViolet, veilPurple, clamp(depth + 0.42, 0.0, 1.0));
    color = mix(color, veilCyan, lattice * (0.25 + filament * 0.35));
    color = mix(color, fractureWhite, crackBand * fracture * 0.76);

    // Breach pulse sheets use high red/low green vertex control values; make those look torn and
    // overexposed without needing a second shader or a detached visual coordinate system.
    float breachSignal = clamp((veilControl.r - veilControl.g) * 2.0, 0.0, 1.0);
    float tear = smoothstep(0.12, 0.82, abs(sin(warped.x * 11.0) * cos(warped.y * 13.0)));
    color = mix(color, vec3(0.02, 0.86, 1.0), breachSignal * tear * 0.72);

    float shimmer = 0.82 + 0.18 * filament;
    float alpha = veilControl.a * shimmer;
    alpha += lattice * 0.08;
    alpha += crackBand * fracture * 0.13;
    alpha = clamp(alpha, 0.08, 0.82);

    fragColor = vec4(color * veilControl.b, alpha);
}
