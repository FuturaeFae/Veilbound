package dev.futurae.veilbound.boundary;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.breach.Breach;
import dev.futurae.veilbound.breach.BreachSeverity;
import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import dev.futurae.veilbound.domain.DomainRecord;
import dev.futurae.veilbound.network.VeilBoundarySnapshotPayload;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Shared authoritative/client-predicted geometry for the six-sided Veil shell. */
public final class VeilBoundaryCollisionState {
    private static final double WALL_THICKNESS = 1.0D;
    private static volatile Snapshot clientSnapshot;

    private VeilBoundaryCollisionState() {}

    public static void acceptClient(VeilBoundarySnapshotPayload payload) {
        clientSnapshot = Snapshot.from(payload);
    }

    public static void clearClient() {
        clientSnapshot = null;
    }

    public static void clearClientIfDimensionChanged(String dimensionId) {
        Snapshot current = clientSnapshot;
        if (current != null && !current.dimensionId().equals(dimensionId)) clientSnapshot = null;
    }

    public static Snapshot clientSnapshot(String dimensionId) {
        Snapshot current = clientSnapshot;
        return current != null && current.dimensionId().equals(dimensionId) ? current : null;
    }

    public static Snapshot snapshotFor(Level level) {
        String dimensionId = level.dimension().identifier().toString();
        if (level.isClientSide()) return clientSnapshot(dimensionId);
        DomainRecord record = Veilbound.runtime().domains().records().stream()
                .filter(candidate -> candidate.identity().dimensionId().equals(dimensionId))
                .findFirst().orElse(null);
        return record == null ? null : Snapshot.from(record);
    }

    public static boolean mayPlaceAt(Level level, BlockPos pos) {
        Snapshot snapshot = snapshotFor(level);
        return snapshot == null || snapshot.bounds().contains(new DomainPosition(pos.getX(), pos.getY(), pos.getZ()));
    }

    /**
     * Returns six world-space collision slabs, with real openings carved for currently-open Breaches.
     * The slabs are mathematical shapes rather than stored blocks, so very large Domains do not
     * spend chunks/memory filling their entire boundary surface with barrier blocks.
     */
    public static List<VoxelShape> collisionShapes(Entity entity, Level level, AABB queryBox) {
        if (entity == null || entity.isSpectator()) return List.of();
        Snapshot snapshot = snapshotFor(level);
        if (snapshot == null) return List.of();
        DomainBounds b = snapshot.bounds();
        double minX = b.minX();
        double maxX = b.maxX() + 1.0D;
        double minY = b.minY();
        double maxY = b.maxY() + 1.0D;
        double minZ = b.minZ();
        double maxZ = b.maxZ() + 1.0D;

        List<FaceShape> faces = List.of(
                new FaceShape(AxisDirection.NEGATIVE_X, new AABB(minX - WALL_THICKNESS, minY - WALL_THICKNESS, minZ - WALL_THICKNESS, minX, maxY + WALL_THICKNESS, maxZ + WALL_THICKNESS)),
                new FaceShape(AxisDirection.POSITIVE_X, new AABB(maxX, minY - WALL_THICKNESS, minZ - WALL_THICKNESS, maxX + WALL_THICKNESS, maxY + WALL_THICKNESS, maxZ + WALL_THICKNESS)),
                new FaceShape(AxisDirection.NEGATIVE_Y, new AABB(minX - WALL_THICKNESS, minY - WALL_THICKNESS, minZ - WALL_THICKNESS, maxX + WALL_THICKNESS, minY, maxZ + WALL_THICKNESS)),
                new FaceShape(AxisDirection.POSITIVE_Y, new AABB(minX - WALL_THICKNESS, maxY, minZ - WALL_THICKNESS, maxX + WALL_THICKNESS, maxY + WALL_THICKNESS, maxZ + WALL_THICKNESS)),
                new FaceShape(AxisDirection.NEGATIVE_Z, new AABB(minX - WALL_THICKNESS, minY - WALL_THICKNESS, minZ - WALL_THICKNESS, maxX + WALL_THICKNESS, maxY + WALL_THICKNESS, minZ)),
                new FaceShape(AxisDirection.POSITIVE_Z, new AABB(minX - WALL_THICKNESS, minY - WALL_THICKNESS, maxZ, maxX + WALL_THICKNESS, maxY + WALL_THICKNESS, maxZ + WALL_THICKNESS))
        );

        List<VoxelShape> result = new ArrayList<>(6);
        AABB expandedQuery = queryBox.inflate(2.0D);
        for (FaceShape face : faces) {
            if (!face.box().intersects(expandedQuery)) continue;
            VoxelShape shape = Shapes.create(face.box());
            for (BreachOpening breach : snapshot.openBreaches()) {
                if (breach.face() != face.face()) continue;
                shape = Shapes.joinUnoptimized(shape, Shapes.create(openingBox(breach)), BooleanOp.ONLY_FIRST);
            }
            if (!shape.isEmpty()) result.add(shape);
        }
        return result;
    }

    private static AABB openingBox(BreachOpening breach) {
        DomainPosition p = breach.position();
        double cx = p.x() + 0.5D;
        double cy = p.y() + 0.5D;
        double cz = p.z() + 0.5D;
        double radius = switch (breach.severity()) {
            case MINOR -> 1.0D;
            case SEVERE -> 1.6D;
            case EXTREME -> 2.25D;
        };
        double depth = 2.5D;
        return switch (breach.face()) {
            case NEGATIVE_X, POSITIVE_X -> new AABB(cx - depth, cy - radius, cz - radius, cx + depth, cy + radius, cz + radius);
            case NEGATIVE_Y, POSITIVE_Y -> new AABB(cx - radius, cy - depth, cz - radius, cx + radius, cy + depth, cz + radius);
            case NEGATIVE_Z, POSITIVE_Z -> new AABB(cx - radius, cy - radius, cz - depth, cx + radius, cy + radius, cz + depth);
        };
    }

    private record FaceShape(AxisDirection face, AABB box) {}

    public record BreachOpening(DomainPosition position, AxisDirection face, BreachSeverity severity) {}

    public record Snapshot(String dimensionId, DomainBounds bounds, double fractureMeter, List<BreachOpening> openBreaches) {
        public Snapshot {
            openBreaches = List.copyOf(openBreaches);
        }

        public static Snapshot from(DomainRecord record) {
            List<BreachOpening> breaches = record.state().breaches().stream()
                    .filter(Breach::open)
                    .limit(VeilBoundarySnapshotPayload.MAX_BREACHES)
                    .map(b -> new BreachOpening(b.position(), b.veilFace(), b.severity()))
                    .toList();
            return new Snapshot(record.identity().dimensionId(), record.state().bounds(), record.state().fractureMeter(), breaches);
        }

        public static Snapshot from(VeilBoundarySnapshotPayload payload) {
            return new Snapshot(
                    payload.dimensionId(), payload.bounds(), payload.fractureMeter(),
                    payload.openBreaches().stream()
                            .map(b -> new BreachOpening(b.position(), b.face(), b.severity()))
                            .toList());
        }
    }
}
