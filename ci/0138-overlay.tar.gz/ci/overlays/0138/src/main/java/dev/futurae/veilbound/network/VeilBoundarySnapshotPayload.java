package dev.futurae.veilbound.network;

import dev.futurae.veilbound.Veilbound;
import dev.futurae.veilbound.breach.BreachSeverity;
import dev.futurae.veilbound.domain.AxisDirection;
import dev.futurae.veilbound.domain.DomainBounds;
import dev.futurae.veilbound.domain.DomainPosition;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/**
 * Server-authoritative physical/visual Veil boundary snapshot for the currently loaded personal
 * Domain. The same snapshot drives client collision prediction and the rendered boundary shell so
 * the visible Veil cannot drift away from the wall the server actually enforces.
 */
public record VeilBoundarySnapshotPayload(
        String dimensionId,
        int minX, int maxX, int minY, int maxY, int minZ, int maxZ,
        double fractureMeter,
        List<OpenBreach> openBreaches) implements CustomPacketPayload {

    public static final int MAX_DIMENSION_ID = 256;
    public static final int MAX_BREACHES = 64;
    public static final Type<VeilBoundarySnapshotPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "veil_boundary_snapshot"));

    public static final StreamCodec<RegistryFriendlyByteBuf, VeilBoundarySnapshotPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override
        public VeilBoundarySnapshotPayload decode(RegistryFriendlyByteBuf b) {
            String dimensionId = b.readUtf(MAX_DIMENSION_ID);
            int minX = b.readInt();
            int maxX = b.readInt();
            int minY = b.readInt();
            int maxY = b.readInt();
            int minZ = b.readInt();
            int maxZ = b.readInt();
            double fracture = b.readDouble();
            int count = b.readVarInt();
            if (count < 0 || count > MAX_BREACHES) {
                throw new IllegalArgumentException("Invalid Veil boundary breach count: " + count);
            }
            List<OpenBreach> breaches = new ArrayList<>(count);
            for (int i = 0; i < count; i++) {
                int x = b.readInt();
                int y = b.readInt();
                int z = b.readInt();
                int face = b.readVarInt();
                int severity = b.readVarInt();
                if (face < 0 || face >= AxisDirection.values().length) {
                    throw new IllegalArgumentException("Invalid Veil boundary face ordinal: " + face);
                }
                if (severity < 0 || severity >= BreachSeverity.values().length) {
                    throw new IllegalArgumentException("Invalid Veil boundary severity ordinal: " + severity);
                }
                breaches.add(new OpenBreach(
                        new DomainPosition(x, y, z),
                        AxisDirection.values()[face],
                        BreachSeverity.values()[severity]));
            }
            return new VeilBoundarySnapshotPayload(
                    dimensionId, minX, maxX, minY, maxY, minZ, maxZ, fracture, breaches);
        }

        @Override
        public void encode(RegistryFriendlyByteBuf b, VeilBoundarySnapshotPayload p) {
            b.writeUtf(p.dimensionId(), MAX_DIMENSION_ID);
            b.writeInt(p.minX());
            b.writeInt(p.maxX());
            b.writeInt(p.minY());
            b.writeInt(p.maxY());
            b.writeInt(p.minZ());
            b.writeInt(p.maxZ());
            b.writeDouble(p.fractureMeter());
            int count = Math.min(MAX_BREACHES, p.openBreaches().size());
            b.writeVarInt(count);
            for (int i = 0; i < count; i++) {
                OpenBreach breach = p.openBreaches().get(i);
                b.writeInt(breach.position().x());
                b.writeInt(breach.position().y());
                b.writeInt(breach.position().z());
                b.writeVarInt(breach.face().ordinal());
                b.writeVarInt(breach.severity().ordinal());
            }
        }
    };

    public VeilBoundarySnapshotPayload {
        dimensionId = dimensionId == null ? "" : dimensionId;
        if (minX > maxX || minY > maxY || minZ > maxZ) {
            throw new IllegalArgumentException("Invalid Veil boundary bounds");
        }
        if (!Double.isFinite(fractureMeter) || fractureMeter < 0.0) {
            throw new IllegalArgumentException("fractureMeter must be finite and >= 0");
        }
        openBreaches = List.copyOf(openBreaches == null ? List.of() : openBreaches);
        if (openBreaches.size() > MAX_BREACHES) {
            throw new IllegalArgumentException("Too many open Breaches in boundary snapshot");
        }
    }

    public DomainBounds bounds() {
        return new DomainBounds(minX, maxX, minY, maxY, minZ, maxZ);
    }

    public record OpenBreach(DomainPosition position, AxisDirection face, BreachSeverity severity) {
        public OpenBreach {
            if (position == null || face == null || severity == null) {
                throw new IllegalArgumentException("Open Breach fields may not be null");
            }
        }
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
