package dev.futurae.veilbound.platform.neoforge.mixin;

import dev.futurae.veilbound.boundary.VeilBoundaryCollisionState;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Injects the mathematical Veil shell into vanilla's final movement-collider collection. */
@Mixin(Entity.class)
public abstract class EntityVeilBoundaryCollisionMixin {
    @Inject(method = "collectColliders", at = @At("RETURN"), cancellable = true)
    private static void veilbound$appendBoundaryCollision(
            Entity entity,
            Level level,
            List<VoxelShape> regularCollisions,
            AABB movementBox,
            CallbackInfoReturnable<List<VoxelShape>> cir) {
        List<VoxelShape> boundary = VeilBoundaryCollisionState.collisionShapes(entity, level, movementBox);
        if (boundary.isEmpty()) return;
        List<VoxelShape> combined = new ArrayList<>(cir.getReturnValue());
        combined.addAll(boundary);
        cir.setReturnValue(combined);
    }
}
