package dev.futurae.veilbound.client.render;

import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import dev.futurae.veilbound.Veilbound;
import net.minecraft.client.renderer.BindGroupLayouts;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.resources.Identifier;
import net.neoforged.neoforge.client.event.RegisterRenderPipelinesEvent;

/** Dedicated translucent shader pipeline for the personal-Domain Veil shell. */
public final class VeilBoundaryRenderPipeline {
    public static final RenderPipeline PIPELINE = RenderPipeline.builder()
            .withLocation(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "pipeline/veil_boundary"))
            .withVertexShader(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "core/veil_boundary"))
            .withFragmentShader(Identifier.fromNamespaceAndPath(Veilbound.MOD_ID, "core/veil_boundary"))
            .withBindGroupLayout(BindGroupLayouts.MATRICES_PROJECTION)
            .withBlend(BlendFunction.TRANSLUCENT)
            .withCull(false)
            .withDepthWrite(false)
            .withVertexBinding(0, DefaultVertexFormat.POSITION_TEX_COLOR)
            .withPrimitiveTopology(PrimitiveTopology.QUADS)
            .build();

    private static final RenderType TYPE = RenderType.create(
            "veilbound:veil_boundary",
            RenderSetup.builder(PIPELINE)
                    .sortOnUpload()
                    .createRenderSetup());

    private VeilBoundaryRenderPipeline() {}

    public static void register(RegisterRenderPipelinesEvent event) {
        event.registerPipeline(PIPELINE);
    }

    public static RenderType type() {
        return TYPE;
    }
}
